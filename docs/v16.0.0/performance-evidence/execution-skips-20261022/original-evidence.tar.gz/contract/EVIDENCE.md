# Execution skip contract evidence

Scope: only `test/refresh-execution-skips-contract-v16.test.js` and temporary
reference/evidence files were authored by this agent. Product files and other
tests were owned by other agents. No build was run by this agent.

## Timing boundary

- `fetchRefreshEstimateRows.before.js` was frozen before the parent edited the
  App function, and parent was notified that the independent reference existed.
- By the first contract test invocation the parent had already implemented
  App/executor. There is no live product pre-implementation RED in this folder.
- The first two-test invocation had one PASS and one test-only failure because
  rolldown retains a `ParenthesizedExpression` around the spread conditional.
  Its original misleading `contract-red.log` filename was renamed to
  `contract-initial-parser-assertion-failure-not-business-red.log`.
- The subsequent `contract-current-first.log` contains test-harness failures
  (cross-VM object prototypes and an unknown financial fixture field stripped
  by the existing real resource allowlist). These are not product regressions
  or evidence of missing execution-skip behavior.
- `LEGACY_SEAM_NEGATIVE` uses the complete independently frozen old App function;
  `LEGACY_CALL_NEGATIVE` uses only the independently frozen old four-argument
  executor call expression. Neither is a complete historical site/build RED.

## Command

`node --test test/refresh-execution-skips-contract-v16.test.js`

Final current implementation output is captured in `contract-green.log`.
