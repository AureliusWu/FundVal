async function fetchRefreshEstimateRows(snapshot, options, context, dispatch) {
  var sourceId = 'sinan-estimate-proxy';
  var claim = context.claimSourceAttempt(sourceId);
  if (!claim.allowed) {
    context.recordDiagnostic('source_cooldown', { sourceId: sourceId, reason: 'circuit_breaker_open' });
    return new Map();
  }
  var startedAt = Date.now();
  try {
    var rows = await dispatch(() => fetchEstimateRows(
      snapshot.map(function(h) { return h.code; }),
      { force: options.force !== false, signal: context.signal }
    ));
    var usableCount = Array.from(rows.values()).filter(function(row) {
      return row && row.status === 'ok' && row.source_quote && !['stale', 'unavailable'].includes(row.source_quote.status);
    }).length;
    var responseMs = Math.max(0, Date.now() - startedAt);
    if (usableCount === snapshot.length) {
      context.recordSourceSuccess(sourceId, { responseMs: responseMs });
    } else if (usableCount > 0) {
      context.recordSourcePartial(sourceId, {
        responseMs: responseMs,
        reason: 'partial_coverage_' + usableCount + '_of_' + snapshot.length,
      });
      context.recordDiagnostic('source_partial', {
        sourceId: sourceId, usable: usableCount, requested: snapshot.length,
      });
    } else {
      context.recordSourceFailure(sourceId, {
        code: 'BUSINESS_EMPTY', reason: 'no_usable_quotes', responseMs: responseMs,
      });
      context.recordDiagnostic('source_empty', { sourceId: sourceId, requested: snapshot.length });
    }
    return rows;
  } catch (error) {
    if (isRefreshAbort(error, context.signal)) {
      // A cancelled half-open probe is released without treating cancellation
      // as another upstream failure.
      context.recordSourceFailure(sourceId, { name: 'AbortError', aborted: true });
      throw error;
    }
    context.recordSourceFailure(sourceId, { error: error, responseMs: Math.max(0, Date.now() - startedAt) });
    context.recordDiagnostic('source_failed', { sourceId: sourceId, reason: error.name || error.message || 'request_failed' });
    return new Map();
  }
}
