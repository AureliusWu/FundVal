# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v16-refresh.spec.js >> refresh diagnostics observe a real estimate source gate rejection without requesting or renewing official NAV
- Location: e2e\v16-refresh.spec.js:557:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#fund-toggle-005844').locator('.quote-kind')
Expected: "正式净值"
Received: "最新净值涨跌"
Timeout:  8000ms

Call log:
  - Expect "toHaveText" with timeout 8000ms
  - waiting for locator('#fund-toggle-005844').locator('.quote-kind')
    20 × locator resolved to <span class="quote-kind">最新净值涨跌</span>
       - unexpected value "最新净值涨跌"

```

```yaml
- text: 最新净值涨跌
```

# Test source

```ts
  495 |   expect(Object.keys(cold.stable)).toHaveLength(3);
  496 |   expect(harness.requests('cold', 'holdings')).toHaveLength(1);
  497 |   expect(harness.requests('cold', 'nav')).toHaveLength(1);
  498 |   const coldRequests = requestCounts('cold');
  499 |   await testInfo.attach('cold-refresh-network-categories', {
  500 |     contentType: 'application/json', body: JSON.stringify({ scope: 'real app and opaque Bridge; synthetic network only', counts: coldRequests }),
  501 |   });
  502 |   await openDiagnostics('coldDiagnostics');
  503 |   expect(await counter('实际请求')).toBe(requestTotal('cold'));
  504 |   expect(await counter('已进入请求中止')).toBe(0);
  505 |   expect(await counter('资源取消拒绝')).toBe(0);
  506 |   expect(await counter('写尝试')).toBe(1);
  507 |   expect(await counter('缓存写入')).toBe(1);
  508 |   await expect(diagnosticValue('刷新计划')).toContainText(/estimates/);
  509 |   await expect(diagnosticValue('刷新计划')).toContainText(/fetch/);
  510 |   // Startup forces the three volatile resources. The three stable resources
  511 |   // miss their cache; the two phase-B resources remain pending at plan time.
  512 |   const coldPlanReasons = await assertPlanReasons([0, 3, 0, 0, 0, 3, 0, 0, 2, 0]);
  513 |   const coldExecutionSkips = await assertExecutionSkips([0, 0, 0, 0, 0]);
  514 |   await expect(diagnosticValue('请求来源')).toContainText('sinan-estimate-proxy');
  515 |   await expect(diagnosticValue('最终报价')).toContainText(/基金详情.*数据说明/);
  516 |   expect(await readCache(), 'reading diagnostics must preserve all cache acquisition bytes and holdings identity').toEqual(cold);
  517 |   expect(requestTotal('coldDiagnostics')).toBe(0);
  518 |   expect(await harness.writes(page, 'coldDiagnostics')).toEqual([]);
  519 |   assertPrivateFeaturesAbsent();
  520 | 
  521 |   await page.locator('#diagnostics-center > summary').click();
  522 |   await page.locator('#nav-market').click();
  523 |   await page.evaluate(() => window.scrollTo(0, 0));
  524 |   await harness.refresh(page);
  525 |   expect(harness.requests('warm', 'holdings')).toHaveLength(0);
  526 |   expect(harness.requests('warm', 'nav')).toHaveLength(0);
  527 |   const warm = await readCache();
  528 |   expect(warm.holdingsHash).toBe(cold.holdingsHash);
  529 |   expect(warm.stable, 'warm refresh cannot renew NAV, disclosure or metadata acquisition envelopes').toEqual(cold.stable);
  530 |   await openDiagnostics('warmDiagnostics');
  531 |   expect(await counter('实际请求')).toBe(requestTotal('warm'));
  532 |   expect(await counter('缓存命中')).toBeGreaterThan(0);
  533 |   expect(await counter('已进入请求中止')).toBe(0);
  534 |   expect(await counter('资源取消拒绝')).toBe(0);
  535 |   expect(await counter('写尝试')).toBe(1);
  536 |   expect(await counter('缓存写入')).toBe(1);
  537 |   await expect(diagnosticValue('刷新计划')).toContainText(/cache/);
  538 |   await expect(diagnosticValue('跳过原因')).not.toBeEmpty();
  539 |   // A warm manual refresh still forces live data; only NAV, disclosure and
  540 |   // metadata become fresh-cache decisions, without renewing their envelopes.
  541 |   const warmPlanReasons = await assertPlanReasons([3, 0, 0, 0, 0, 3, 0, 0, 2, 0]);
  542 |   const warmExecutionSkips = await assertExecutionSkips([0, 0, 0, 0, 0]);
  543 |   const summary = (await Promise.all(['刷新诊断', '刷新计划', '计划原因', '执行跳过', '刷新请求', '跳过原因', '请求来源', '最终报价']
  544 |     .map(label => diagnosticValue(label).innerText()))).join('\n');
  545 |   expect(summary).not.toMatch(/005844|合成境内混合基金A|ghp_|Authorization|https?:|source_quote|baseNav|shares|cost/);
  546 |   expect(await readCache(), 'opening warm diagnostics must not change aggregate dates, hash or stored data').toEqual(warm);
  547 |   expect(requestTotal('warmDiagnostics')).toBe(0);
  548 |   expect(await harness.writes(page, 'warmDiagnostics')).toEqual([]);
  549 |   assertPrivateFeaturesAbsent();
  550 |   await testInfo.attach('refresh-diagnostics-cold-warm', {
  551 |     contentType: 'application/json', body: JSON.stringify({ scope: 'synthetic completed generations only; no cancellation or production acceptance',
  552 |       cold: coldRequests, warm: requestCounts('warm'), coldPlanReasons, warmPlanReasons,
  553 |       coldExecutionSkips, warmExecutionSkips, summary }),
  554 |   });
  555 | });
  556 | 
  557 | test('refresh diagnostics observe a real estimate source gate rejection without requesting or renewing official NAV', async ({ context, page }, testInfo) => {
  558 |   // Keep disclosure acquisition healthy, but leave its securities unpriced so
  559 |   // neither holdings enrichment nor the model's index leg replaces official NAV.
  560 |   const harness = await installHarness(context, { failEstimates: true, securityChange: null,
  561 |     omitTencentCodes: ['sh000300', ...Array.from({ length: 10 }, (_, i) => `sz${String(i + 1).padStart(6, '0')}`)] });
  562 |   await context.addInitScript(origin => {
  563 |     if (window !== window.top || location.origin !== origin) return;
  564 |     globalThis.__diagnosticsStorageMutations = [];
  565 |     for (const method of ['setItem', 'removeItem', 'clear']) {
  566 |       const native = Storage.prototype[method];
  567 |       Storage.prototype[method] = function(...args) {
  568 |         const result = native.apply(this, args);
  569 |         if (this === localStorage) globalThis.__diagnosticsStorageMutations.push({ method, phase: globalThis.__refreshTestPhase });
  570 |         return result;
  571 |       };
  572 |     }
  573 |   }, ORIGIN);
  574 |   const diagnosticValue = label => page.locator('#diagnostics-content .diagnostics-row')
  575 |     .filter({ has: page.getByText(label, { exact: true }) }).locator('strong');
  576 |   const refreshDiagnostics = () => page.getByRole('button', { name: '刷新诊断', exact: true }).click();
  577 |   const dataCategories = ['estimates', 'holdings', 'nav', 'eastmoneySecurities', 'gold', 'tencent'];
  578 |   const requestCounts = phase => Object.fromEntries(dataCategories.map(category =>
  579 |     [category, harness.requests(phase, category).length]));
  580 |   const readCache = () => page.evaluate(({ key, code }) => {
  581 |     const raw = localStorage.getItem(key);
  582 |     const cache = raw && JSON.parse(raw);
  583 |     const quote = cache?.data?.find(row => row.code === code)?.quote;
  584 |     return { raw, holdingsHash: cache?.holdingsHash,
  585 |       stable: Object.fromEntries(Object.entries(cache?.refreshResources || {})
  586 |         .filter(([resource]) => /^(?:nav|holdings|meta):/.test(resource))),
  587 |       official: quote && { value: quote.value, valueKind: quote.valueKind, baseNav: quote.baseNav,
  588 |         baseNavDate: quote.baseNavDate, targetDate: quote.targetDate, officialNavDate: quote.officialNavDate } };
  589 |   }, { key: FUND_CACHE, code: HOLDINGS[0].code });
  590 |   const assertOfficialNav = async () => {
  591 |     const row = page.locator(`#fund-toggle-${HOLDINGS[0].code}`);
  592 |     await expect(row.locator('.nav-cur')).toHaveText('1.2000');
  593 |     await expect(row.locator('.nav-prev')).toHaveText('1.1900');
  594 |     await expect(row.locator('.fund-pct')).toHaveText('+0.84%');
> 595 |     await expect(row.locator('.quote-kind')).toHaveText('正式净值');
      |                                              ^ Error: expect(locator).toHaveText(expected) failed
  596 |     await expect(row.locator('.quote-time')).toHaveText('2026-09-28');
  597 |     expect((await readCache()).official).toEqual({ value: 1.2, valueKind: 'official_nav', baseNav: 1.19,
  598 |       baseNavDate: '2026-09-25', targetDate: '2026-09-28', officialNavDate: '2026-09-28' });
  599 |   };
  600 | 
  601 |   await page.goto('/');
  602 |   await harness.settle(page);
  603 |   await assertOfficialNav();
  604 |   const cold = await readCache();
  605 |   expect(harness.requests('cold', 'estimates')).toHaveLength(1);
  606 |   expect(harness.requests('cold', 'nav')).toHaveLength(1);
  607 |   for (const phase of ['secondFailure', 'thirdFailure']) {
  608 |     await harness.refresh(page, phase);
  609 |     expect(harness.requests(phase, 'estimates')).toHaveLength(1);
  610 |     expect(harness.requests(phase, 'nav')).toHaveLength(0);
  611 |     expect(harness.requests(phase, 'holdings')).toHaveLength(0);
  612 |     await assertOfficialNav();
  613 |   }
  614 |   expect(harness.state.estimateRequests, 'three real failures must reach the unchanged default circuit threshold').toBe(3);
  615 |   const beforeDenied = await readCache();
  616 |   expect(beforeDenied.stable, 'failed estimates cannot renew official NAV, metadata or disclosure acquisition dates').toEqual(cold.stable);
  617 |   expect(beforeDenied.holdingsHash).toBe(cold.holdingsHash);
  618 | 
  619 |   // Public diagnostics expose the real third-generation cooldown; do not read
  620 |   // or mutate the private coordinator, registry, observer or source policy.
  621 |   await harness.phase(page, 'thresholdDiagnostics');
  622 |   await page.locator('#nav-edit').click();
  623 |   await page.locator('#diagnostics-center > summary').click();
  624 |   await expect(diagnosticValue('刷新诊断')).toHaveText('第3代 / 已完成 / observed=true');
  625 |   await expect(diagnosticValue('数据源健康')).toContainText('sinan-estimate-proxy cooldown / 连续失败 3');
  626 |   await harness.settle(page);
  627 | 
  628 |   // The existing online handler starts generation four. Unlike manual helper
  629 |   // refresh(), this path must not wait for an estimate request that is denied.
  630 |   await harness.phase(page, 'sourceDenied');
  631 |   await page.evaluate(() => window.dispatchEvent(new Event('online')));
  632 |   await expect.poll(async () => {
  633 |     await refreshDiagnostics();
  634 |     return diagnosticValue('刷新诊断').innerText();
  635 |   }, { message: 'the real online generation must complete through public diagnostics' })
  636 |     .toBe('第4代 / 已完成 / observed=true');
  637 |   await harness.settle(page);
  638 |   expect(harness.state.estimateRequests).toBe(3);
  639 |   expect(harness.requests('sourceDenied', 'estimates'), 'a denied estimate claim is not a dispatched network request').toHaveLength(0);
  640 |   expect(harness.requests('sourceDenied', 'nav')).toHaveLength(0);
  641 |   expect(harness.requests('sourceDenied', 'holdings')).toHaveLength(0);
  642 |   const executionSkips = { estimate_claim_denied: 1, holdings_claim_denied: 0, holdings_probe_used: 0,
  643 |     model_claim_denied: 0, model_probe_used: 0 };
  644 |   await expect(diagnosticValue('执行跳过')).toHaveText('估值源拒绝 1；重仓源拒绝 0；重仓半开额度已用 0；模型源拒绝 0；模型半开额度已用 0；按门控检查次数统计，非请求或唯一资源数；拒绝细因未记录');
  645 |   await expect(diagnosticValue('请求来源')).not.toContainText(/sinan-estimate-proxy=[1-9]\d*/);
  646 |   await assertOfficialNav();
  647 |   const denied = await readCache();
  648 |   expect(denied.stable).toEqual(beforeDenied.stable);
  649 |   expect(denied.official).toEqual(beforeDenied.official);
  650 |   expect(denied.holdingsHash).toBe(beforeDenied.holdingsHash);
  651 | 
  652 |   // Once completed, re-reading diagnostics must be entirely read-only across
  653 |   // every request category and every localStorage mutation API, not only Gist.
  654 |   await harness.phase(page, 'deniedDiagnostics');
  655 |   const requestsBeforeRead = harness.state.requests.length;
  656 |   const storageBeforeRead = await page.evaluate(() => Object.fromEntries(Object.entries(localStorage)));
  657 |   await refreshDiagnostics();
  658 |   await expect(diagnosticValue('刷新诊断')).toHaveText('第4代 / 已完成 / observed=true');
  659 |   await harness.settle(page);
  660 |   expect(harness.state.requests.length).toBe(requestsBeforeRead);
  661 |   expect(await harness.writes(page, 'deniedDiagnostics')).toEqual([]);
  662 |   expect(await page.evaluate(() => globalThis.__diagnosticsStorageMutations
  663 |     .filter(row => row.phase === 'deniedDiagnostics'))).toEqual([]);
  664 |   expect(await page.evaluate(() => Object.fromEntries(Object.entries(localStorage)))).toEqual(storageBeforeRead);
  665 |   expect(await readCache()).toEqual(denied);
  666 |   expect(harness.state.requests.filter(row => row.category === 'gist')).toEqual([]);
  667 |   expect(harness.state.requests.filter(row => /(?:\/assets\/ocr\/|ocr-import\.html|paddle|tesseract|\.wasm(?:$|\?))/i.test(row.url))).toEqual([]);
  668 |   expect(harness.state.gistWrites).toEqual([]);
  669 |   const summary = (await Promise.all(['刷新诊断', '执行跳过', '刷新请求', '请求来源', '最终报价']
  670 |     .map(label => diagnosticValue(label).innerText()))).join('\n');
  671 |   expect(summary).not.toMatch(/005844|合成境内混合基金A|ghp_|Authorization|https?:|source_quote|baseNav|shares|cost/);
  672 |   await testInfo.attach('refresh-diagnostics-real-source-gate-denied', {
  673 |     contentType: 'application/json', body: JSON.stringify({ scope: 'real default source-health cooldown and public online handler; synthetic network only; no half-open or production acceptance',
  674 |       completedGeneration: 4, executionSkips, cold: requestCounts('cold'), secondFailure: requestCounts('secondFailure'),
  675 |       thirdFailure: requestCounts('thirdFailure'), sourceDenied: requestCounts('sourceDenied'), summary }),
  676 |   });
  677 | });
  678 | 
```