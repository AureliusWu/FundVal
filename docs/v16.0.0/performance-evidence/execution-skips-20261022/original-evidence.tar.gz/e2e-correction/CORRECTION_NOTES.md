# Nonzero source-gate E2E precise presentation correction

- Parent reported the first full E2E result as 32 PASS / 1 FAIL, at the new quote-kind assertion. Parent's first-failure logs and `e2e-first-failure-artifacts` are preserved without changes.
- Sole repository correction: `e2e/v16-refresh.spec.js:595`, expected `.quote-kind` changed exactly from `正式净值` to `最新净值涨跌`.
- Product source was not edited. `quote-presentation.js` separates `statusLabel` from `kindLabel`: `official` status is `正式净值`, while kind uses `quoteValueKindLabel(valueKind)`; `quote-contract.js` maps `official_nav` to `最新净值涨跌`.
- Read and verified the other new assumptions against current source: `formatQuoteDataTime` returns `officialNavDate` for official NAV; `normalizeOfficialNavQuote` keeps nav/prevNav, previous date, publication target date and officialNavDate; `serializeRefreshAggregate` preserves the quote on fund data rows. The exact 1.2000/1.1900/+0.84% and 2026-09-25/2026-09-28 assertions remain unchanged.
- Before and after copies are sibling `v16-refresh.before.spec.js` and `v16-refresh.after.spec.js`.
- Current already-built real site is tested without a build, on port 12449. `--grep=rejection` is unique to the new test. `--grep=renewing` would also select the pre-existing cold/warm diagnostics test, so is not used.
- Complete invocation is in `run-corrected-e2e.ps1`; exact stdout/stderr and a dedicated Playwright artifact output directory are retained here.
- This is a synthetic real-App/Bridge behavior check, not a production, performance or release acceptance result.
- Corrected unique-test result: `Running 1 test using 1 worker`; `1 passed (8.0s)`; test runtime 5.8 seconds; process exit code `0`. Exact stdout and stderr are retained. Stderr contains only existing NO_COLOR/FORCE_COLOR warnings.
- After-file SHA256: `E0EBD1F582BEC191EBC6213C2EFC0A6BD563629349597E19C0A9CDB050AAB7CF`.
- A second, separate unique-test JSON capture passed: expected=1, unexpected=0, skipped=0, flaky=0; process exit code `0`, total duration 7885.343 ms. `report.json` is exact JSON-reporter stdout, including the test attachment body; `json.stderr.log` is exact stderr. The separate `json-artifacts` directory prevents overwriting the first corrected pass or any parent failure artifacts. No further runs are performed by this subtask.
