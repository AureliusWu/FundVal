$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath 'D:\AI项目\FundVal'
$env:FUNDVAL_E2E_PORT = '12449'
& 'C:\Program Files\nodejs\node.exe' 'D:\AI项目\FundVal\node_modules\@playwright\test\cli.js' test -c playwright.config.mjs e2e/v16-refresh.spec.js --grep=rejection --workers=1 --reporter=json --output=C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-nonzero-correction-20261022-103212-339\json-artifacts 1> 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-nonzero-correction-20261022-103212-339\report.json' 2> 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-nonzero-correction-20261022-103212-339\json.stderr.log'
$taskExitCode = $LASTEXITCODE
$taskReport = Get-Content -LiteralPath 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-nonzero-correction-20261022-103212-339\report.json' -Encoding UTF8 -Raw | ConvertFrom-Json
$taskReport.stats | Format-List
Get-Content -LiteralPath 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-nonzero-correction-20261022-103212-339\json.stderr.log' -Encoding UTF8
Write-Output "PLAYWRIGHT_JSON_EXIT_CODE=$taskExitCode"
exit $taskExitCode
