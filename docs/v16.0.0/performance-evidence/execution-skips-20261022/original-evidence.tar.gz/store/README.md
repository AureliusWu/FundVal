# Execution-skips store/view verification

Workspace: `D:\AI项目\FundVal`

This subtask exclusively changed:

- `js/runtime/refresh-generation.js`
- `js/runtime/diagnostics-ui.js`
- `test/refresh-diagnostics-store-v16.test.js`
- `test/refresh-diagnostics-view-v16.test.js`

All pre-existing dirty work was preserved. No build, dependency, budget, commit, push, or release action was performed by this subtask.

## Test provenance

The initial workspace already contained seven execution-skips store tests and two execution-skips view tests from interrupted work, without the corresponding implementation. They were preserved. This subtask added one store test for explicit own-data-field opt-in and null/zero continuity, and one view test for the readonly clipboard fallback. It also clarified the existing hostile-input test expectation: an explicitly supplied invalid own data field opts in as `executionSkips: null`; inherited/accessor/missing fields do not opt in on an old-shape record.

The RED result is not a claim that eleven old business behaviors regressed or that all eleven failures were newly authored here. It combines nine pre-existing interrupted-work execution-skips tests with two newly added contract tests. The 28 older store/view behaviors passed before implementation.

Contract: initial own data `executionSkips` (even null/invalid/explicit undefined) opts in as unobserved null; an old record with a truly absent, inherited, or accessor-only field keeps its original shape. Once opted in, an accepted missing/invalid/null sample becomes null rather than inheriting earlier counts. Started-only terminal records are null until a valid late drain/final observation arrives. The original plan/planReasons inheritance and three-slot lifecycle remain unchanged.

## RED raw command and result

```powershell
$taskEvidence = Join-Path $env:TEMP ('fundval-execution-skips-store-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')); New-Item -ItemType Directory -Path $taskEvidence | Out-Null; $taskEvidence; node --test test/refresh-diagnostics-store-v16.test.js test/refresh-diagnostics-view-v16.test.js 2>&1 | Tee-Object -FilePath (Join-Path $taskEvidence 'store-view-red.log'); $taskExit = $LASTEXITCODE; "exit_code=$taskExit"; exit $taskExit
```

Resolved evidence directory: `C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-store-20261022-102316-631`

Result: exit 1; tests 39; pass 28; fail 11; cancelled 0; skipped 0; todo 0. Full untruncated test output: `store-view-red.log`.

## GREEN raw command and result

```powershell
node --test test/refresh-diagnostics-store-v16.test.js test/refresh-diagnostics-view-v16.test.js 2>&1 | Tee-Object -FilePath C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-store-20261022-102316-631\store-view-green.log; $taskExit = $LASTEXITCODE; "exit_code=$taskExit"; exit $taskExit
```

Result: exit 0; tests 39; pass 39; fail 0; cancelled 0; skipped 0; todo 0. Full untruncated test output: `store-view-green.log`.

This is a targeted local test result only, not a build, production, performance-admission, or release claim. The root task owns integration verification.
