# Execution skip diagnostics RED

- Working directory: `D:\AI项目\FundVal`
- Existing real `site` was served without running a build.
- Environment: `FUNDVAL_E2E_PORT=12449`
- Complete invoked command:

```powershell
& 'C:\Program Files\nodejs\node.exe' 'D:\AI项目\FundVal\node_modules\@playwright\test\cli.js' test -c playwright.config.mjs e2e/v16-refresh.spec.js --grep=diagnostics --workers=1 --reporter=list --output=C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-red-20261022-102251-755\artifacts
```

- Exit code: `1`
- Discovery: `Running 1 test using 1 worker`
- Result: `1 failed`; diagnostic row `执行跳过` missing (Expected 1, Received 0, timeout 8000 ms).
- Failure: `e2e/v16-refresh.spec.js:459`; first cold assertion at line 513.
- Exact stdout: `stdout.log`; exact stderr: `stderr.log`.
- Screenshot, error context and trace are retained under `artifacts`.
- No source file was edited by this verification; the requested five-label cold/warm assertions were already present in the assigned dirty file.
- Scope: real app/bootstrap/opaque Bridge with synthetic data-provider responses; not production or performance admission evidence.
