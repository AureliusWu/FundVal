$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath 'D:\AI项目\FundVal'
$env:FUNDVAL_E2E_PORT = '12449'
& 'C:\Program Files\nodejs\node.exe' 'D:\AI项目\FundVal\node_modules\@playwright\test\cli.js' test -c playwright.config.mjs e2e/v16-refresh.spec.js --grep=diagnostics --workers=1 --reporter=list --output=C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-red-20261022-102251-755\artifacts 1> 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-red-20261022-102251-755\stdout.log' 2> 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-red-20261022-102251-755\stderr.log'
$taskExitCode = $LASTEXITCODE
Get-Content -LiteralPath 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-red-20261022-102251-755\stdout.log' -Encoding UTF8
Get-Content -LiteralPath 'C:\Users\84046\AppData\Local\Temp\fundval-execution-skips-red-20261022-102251-755\stderr.log' -Encoding UTF8
Write-Output "PLAYWRIGHT_EXIT_CODE=$taskExitCode"
exit $taskExitCode
