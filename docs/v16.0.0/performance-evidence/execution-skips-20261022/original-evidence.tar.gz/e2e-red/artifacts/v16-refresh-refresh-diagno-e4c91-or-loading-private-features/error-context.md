# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v16-refresh.spec.js >> refresh diagnostics reconcile real cold and warm requests without renewing data or loading private features
- Location: e2e\v16-refresh.spec.js:432:1

# Error details

```
Error: execution gate observations must be visible in the real diagnostics center

expect(locator).toHaveCount(expected) failed

Locator:  locator('#diagnostics-content .diagnostics-row').filter({ has: getByText('执行跳过', { exact: true }) }).locator('strong')
Expected: 1
Received: 0
Timeout:  8000ms

Call log:
  - execution gate observations must be visible in the real diagnostics center with timeout 8000ms
  - waiting for locator('#diagnostics-content .diagnostics-row').filter({ has: getByText('执行跳过', { exact: true }) }).locator('strong')
    20 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e4]:
    - generic [ref=e5]: 蜉蝣基金
    - generic [ref=e6]:
      - generic [ref=e7]: 15.0.2
      - emphasis [ref=e8]: 下午盘
  - generic: 下拉刷新
  - generic [ref=e10]:
    - generic [ref=e11]:
      - generic [ref=e12]: 黄金9999
      - generic [ref=e13]: "900"
      - generic [ref=e14]: +1.12%
    - generic [ref=e15]:
      - generic [ref=e16]: 上证
      - generic [ref=e17]: "10"
      - generic [ref=e18]: +1.00%
    - generic [ref=e19]:
      - generic [ref=e20]: 沪深300
      - generic [ref=e21]: "10"
      - generic [ref=e22]: +1.00%
    - generic [ref=e23]:
      - generic [ref=e24]:
        - text: 纳指100
        - generic [ref=e25]: 旧
      - generic [ref=e26]: "10"
      - generic [ref=e27]: +1.00%
    - generic [ref=e28]:
      - generic [ref=e29]:
        - text: 标普500
        - generic [ref=e30]: 旧
      - generic [ref=e31]: "10"
      - generic [ref=e32]: +1.00%
  - generic [ref=e33]: 最新可信数据 14:30 · 今日估算 1/1
  - generic [ref=e35]:
    - generic [ref=e36]: 当前持仓
    - generic [ref=e38] [cursor=pointer]:
      - generic [ref=e39]:
        - generic [ref=e40]: 合成境内混合基金A
        - generic [ref=e41]: 005844 · 100份 · 成本1.2
      - button "删除 合成境内混合基金A" [ref=e42]: ×
    - region [ref=e43]:
      - generic [ref=e44]:
        - generic [ref=e45]: 本地识别
        - heading "支付宝 / 蚂蚁财富基金截图导入" [level=2] [ref=e46]
        - paragraph [ref=e47]: 优先支持支付宝生态的基金持有页；将在独立本地识别页处理图片，不上传、不保存。识别后请逐项确认基金与真实份额。
      - button "选择截图" [ref=e48] [cursor=pointer]
    - generic [ref=e49]: 添加基金
    - generic [ref=e50]:
      - generic [ref=e51]:
        - generic [ref=e52]: 基金代码（6位）
        - textbox "例：110020" [ref=e53]
      - generic [ref=e54]:
        - generic [ref=e55]: 基金名称（可留空，自动获取）
        - textbox "留空则自动获取" [ref=e56]
      - generic [ref=e57]:
        - generic [ref=e58]:
          - generic [ref=e59]: 持有份额
          - textbox "0" [ref=e60]
        - generic [ref=e61]:
          - generic [ref=e62]: 成本净值
          - textbox "0.000" [ref=e63]
      - button "+ 添加" [ref=e65] [cursor=pointer]
    - generic [ref=e66]: 云同步 (GitHub Gist) 自动双向同步
    - generic [ref=e67]:
      - generic [ref=e68]:
        - generic [ref=e69]: GitHub Personal Access Token
        - textbox "ghp_xxxxxxxxxxxx" [ref=e70]
        - generic [ref=e71]:
          - text: 需要
          - code [ref=e72]: gist
          - text: 权限，
          - link "创建 Classic Token" [ref=e73] [cursor=pointer]:
            - /url: https://github.com/settings/tokens
          - text: · 填入 Token 后首次点击「上传」即开始自动同步
      - generic [ref=e74]: 配置 Token 后自动同步
      - generic [ref=e75]:
        - button "上传到云端" [ref=e76] [cursor=pointer]
        - button "从云端下载" [ref=e77] [cursor=pointer]
      - button "恢复最近备份" [ref=e78] [cursor=pointer]
      - button "清除云同步配置" [ref=e79] [cursor=pointer]
    - generic [ref=e80]:
      - button "↓ 导出持仓" [ref=e81] [cursor=pointer]
      - button "↑ 导入持仓" [ref=e82] [cursor=pointer]
    - generic [ref=e83]: 可信行情通知
    - generic [ref=e84]:
      - generic [ref=e85]: 仅在你主动启用后请求通知权限
      - generic [ref=e86]: 只通知当日且仍在有效期内的盘中估值；正式净值、模型估算、重仓估算和旧数据不会冒充“今日涨跌”。
      - button "启用 14:30 通知" [ref=e87] [cursor=pointer]
    - group [ref=e88]:
      - generic "运行诊断" [active] [ref=e89] [cursor=pointer]
      - paragraph [ref=e90]: 仅显示本机运行状态；不上传数据，也不会复制 Token、图片、OCR 原文、持仓金额或本地路径。
      - generic [ref=e91]:
        - generic [ref=e92]:
          - generic [ref=e93]:
            - generic [ref=e94]: 应用版本
            - strong [ref=e95]: 15.0.2
          - generic [ref=e96]:
            - generic [ref=e97]: Service Worker
            - strong [ref=e98]: 未控制当前页面
          - generic [ref=e99]:
            - generic [ref=e100]: 网络
            - strong [ref=e101]: 在线
          - generic [ref=e102]:
            - generic [ref=e103]: 最近启动自检
            - strong [ref=e104]: ok / ok / 缓存无需修复
          - generic [ref=e105]:
            - generic [ref=e106]: 持仓 Schema
            - strong [ref=e107]: Schema 3
          - generic [ref=e108]:
            - generic [ref=e109]: 最近本地备份
            - strong [ref=e110]: 2026/09/29 14:30:00
          - generic [ref=e111]:
            - generic [ref=e112]: 最后完整刷新
            - strong [ref=e113]: 2026/09/29 14:30:00 / startup
          - generic [ref=e114]:
            - generic [ref=e115]: 数据源健康
            - strong [ref=e116]: sinan-estimate-proxy healthy / 31ms；sinan-holdings-proxy healthy；eastmoney-official-nav healthy；eastmoney-security-quote healthy；tencent-market-quote healthy；market-model healthy；quarterly-holdings-model healthy / 25ms；local-cache healthy
          - generic [ref=e117]:
            - generic [ref=e118]: 当前市场
            - strong [ref=e119]: cn 交易中
          - generic [ref=e120]:
            - generic [ref=e121]: 本地缓存条目
            - strong [ref=e122]: "7"
          - generic [ref=e123]:
            - generic [ref=e124]: OCR 能力
            - strong [ref=e125]: WebGPU 可尝试 / WASM 可用；暂无识别记录
          - generic [ref=e126]:
            - generic [ref=e127]: OCR 账本条目
            - strong [ref=e128]: "0"
          - generic [ref=e129]:
            - generic [ref=e130]: 运行错误条目
            - strong [ref=e131]: "0"
          - generic [ref=e132]:
            - generic [ref=e133]: 刷新诊断
            - strong [ref=e134]: 第1代 / 已完成 / observed=true
          - generic [ref=e135]:
            - generic [ref=e136]: 刷新计划
            - strong [ref=e137]: estimates cache=0 fetch=1 skip=0；nav cache=0 fetch=1 skip=0；holdings cache=0 fetch=1 skip=0；meta cache=0 fetch=1 skip=0；indices cache=0 fetch=1 skip=0；gold cache=0 fetch=1 skip=0；securities cache=0 fetch=1 skip=0；model-quotes cache=0 fetch=1 skip=0
          - generic [ref=e138]:
            - generic [ref=e139]: 计划原因
            - strong [ref=e140]: 缓存新鲜 0；缓存缺失 3；元数据无效 0；缓存质量不可用 0；缓存过期 0；强制实时 3；强制稳定 0；市场不适用 0；阶段待定 2；无活动持仓 0；仅表示计划时决策；实际执行 gate 细因未记录
          - generic [ref=e141]:
            - generic [ref=e142]: 刷新请求
            - strong [ref=e143]: 实际请求 6；缓存命中 0；去重 0；已进入请求中止 0；资源取消拒绝 0；失败请求 0；写尝试 1；缓存写入 1
          - generic [ref=e144]:
            - generic [ref=e145]: 跳过原因
            - strong [ref=e146]: 不适用市场 0；无活动持仓 0
          - generic [ref=e147]:
            - generic [ref=e148]: 请求来源
            - strong [ref=e149]: sinan-estimate-proxy=1；sinan-holdings-proxy=1；eastmoney-official-nav=1；eastmoney-security-quote=2；tencent-market-quote=1；gold=未观测；model-config=未观测
          - generic [ref=e150]:
            - generic [ref=e151]: 最终报价
            - strong [ref=e152]: 请查看各基金详情 → 数据说明；本摘要不复制报价或金额
        - generic [ref=e153]: 最近没有记录到运行错误
      - generic [ref=e154]:
        - button "刷新诊断" [ref=e155] [cursor=pointer]
        - button "复制脱敏摘要" [ref=e156] [cursor=pointer]
  - generic [ref=e157]:
    - button "📈 行情" [ref=e158] [cursor=pointer]:
      - generic [ref=e159]: 📈
      - text: 行情
    - button "⚙️ 持仓" [ref=e160] [cursor=pointer]:
      - generic [ref=e161]: ⚙️
      - text: 持仓
```

# Test source

```ts
  359 |   const toggle = page.locator(`#fund-toggle-${HOLDINGS[0].code}`);
  360 |   await toggle.click();
  361 |   await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  362 |   await harness.settle(page);
  363 |   const clocks = page.locator('.stock-quote-time');
  364 |   await expect(clocks).toHaveCount(10);
  365 |   await expect(clocks.first()).toHaveText('最近行情 · 2026-09-29 14:30:00');
  366 |   await expect(page.locator('.holdings-row').first()).toContainText('+1.00%');
  367 |   await toggle.click();
  368 |   await expect(toggle).toHaveAttribute('aria-expanded', 'false');
  369 |   const cache = await page.evaluate(key => localStorage.getItem(key), FUND_CACHE);
  370 |   harness.state.failAll = true;
  371 |   await page.evaluate(() => { globalThis.__refreshTestClockAdvance = 24 * 60 * 60_000; });
  372 |   await harness.phase(page, 'oldDetail');
  373 |   await toggle.click();
  374 |   await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  375 |   await harness.settle(page);
  376 |   await expect(clocks).toHaveCount(10);
  377 |   await expect(clocks.first()).toHaveText('旧行情 · 2026-09-29 14:30:00');
  378 |   await expect(page.locator('.holdings-row').first()).toContainText('+1.00%');
  379 |   expect(harness.requests('oldDetail', 'eastmoneySecurities')).toHaveLength(1);
  380 |   expect(harness.requests('oldDetail', 'tencent')).toHaveLength(1);
  381 |   expect(harness.requests('oldDetail', 'holdings')).toHaveLength(0);
  382 |   expect(harness.requests('oldDetail', 'nav')).toHaveLength(0);
  383 |   expect(await harness.writes(page, 'oldDetail')).toEqual([]);
  384 |   expect(await page.evaluate(key => localStorage.getItem(key), FUND_CACHE)).toBe(cache);
  385 |   expect(harness.state.gistWrites).toEqual([]);
  386 | });
  387 | 
  388 | for (const [name, change, value, caption] of [
  389 |   ['zero', 0, '+0.00%', '最近行情 · 2026-09-29 14:30:00'],
  390 |   ['missing', null, '--', '行情暂不可用'],
  391 | ]) test(`detail renderer distinguishes a genuine ${name} change without borrowing adjacent quotes`, async ({ context, page }) => {
  392 |   const harness = await installHarness(context, { securityChange: change,
  393 |     omitTencentCodes: Array.from({ length: 10 }, (_, i) => `sz${String(i + 1).padStart(6, '0')}`) });
  394 |   await page.goto('/');
  395 |   await harness.settle(page);
  396 |   await page.locator(`#fund-toggle-${HOLDINGS[0].code}`).click();
  397 |   await harness.settle(page);
  398 |   await expect(page.locator('.holdings-row')).toHaveCount(10);
  399 |   await expect(page.locator('.holdings-row').first().locator(':scope > span').nth(2)).toHaveText(value);
  400 |   await expect(page.locator('.stock-quote-time').first()).toHaveText(caption);
  401 |   expect(harness.state.gistWrites).toEqual([]);
  402 | });
  403 | 
  404 | test('a non-cooperative late response cannot overwrite the current generation UI or cache', async ({ context, page }) => {
  405 |   const harness = await installHarness(context, { holdFirstEstimate: true });
  406 |   await page.goto('/');
  407 |   await harness.ready(page);
  408 |   await expect.poll(() => typeof harness.state.heldEstimate).toBe('function');
  409 |   try {
  410 |     harness.state.estimateValue = 1.23;
  411 |     await harness.phase(page, 'current');
  412 |     // Online intentionally supersedes an active generation; pull-to-refresh is
  413 |     // correctly disabled while a refresh is active and cannot test this path.
  414 |     await page.evaluate(() => window.dispatchEvent(new Event('online')));
  415 |     await expect.poll(() => harness.state.estimateRequests).toBe(2);
  416 |     await expect(navValue(page)).toHaveText('1.2300');
  417 |     await harness.settle(page, { allowHeld: true });
  418 |     await harness.phase(page, 'late');
  419 |     await harness.state.heldEstimate();
  420 |     harness.state.heldEstimate = null;
  421 |     await harness.settle(page);
  422 |     await expect(navValue(page)).toHaveText('1.2300');
  423 |     expect(await harness.writes(page, 'late'), 'superseded results cannot persist after current generation commits').toEqual([]);
  424 |     const cache = await page.evaluate(key => JSON.parse(localStorage.getItem(key)), FUND_CACHE);
  425 |     expect(cache.data.find(row => row.code === HOLDINGS[0].code).quote.value).toBe(1.23);
  426 |     expect(harness.state.gistWrites).toEqual([]);
  427 |   } finally {
  428 |     if (harness.state.heldEstimate) await harness.state.heldEstimate();
  429 |   }
  430 | });
  431 | 
  432 | test('refresh diagnostics reconcile real cold and warm requests without renewing data or loading private features', async ({ context, page }, testInfo) => {
  433 |   const harness = await installHarness(context);
  434 |   const dataCategories = ['estimates', 'holdings', 'nav', 'eastmoneySecurities', 'gold', 'tencent'];
  435 |   const requestCounts = phase => Object.fromEntries(dataCategories.map(category =>
  436 |     [category, harness.requests(phase, category).length]));
  437 |   const requestTotal = phase => Object.values(requestCounts(phase)).reduce((sum, value) => sum + value, 0);
  438 |   const diagnosticValue = label => page.locator('#diagnostics-content .diagnostics-row')
  439 |     .filter({ has: page.getByText(label, { exact: true }) }).locator('strong');
  440 |   const counter = async label => {
  441 |     const text = await diagnosticValue('刷新请求').innerText();
  442 |     const match = new RegExp(`${label}\\s*[:：=]?\\s*(\\d+)`).exec(text);
  443 |     expect(match, `structured refresh request summary must expose ${label}`).not.toBeNull();
  444 |     return Number(match[1]);
  445 |   };
  446 |   const planReasonLabels = ['缓存新鲜', '缓存缺失', '元数据无效', '缓存质量不可用', '缓存过期',
  447 |     '强制实时', '强制稳定', '市场不适用', '阶段待定', '无活动持仓'];
  448 |   const assertPlanReasons = async counts => {
  449 |     const row = diagnosticValue('计划原因');
  450 |     await expect(row, 'planning reasons must be visible in the real diagnostics center').toHaveCount(1);
  451 |     await expect(row).toBeVisible();
  452 |     await expect(row).toHaveText(planReasonLabels.map((label, index) => `${label} ${counts[index]}`)
  453 |       .concat('仅表示计划时决策；实际执行 gate 细因未记录').join('；'));
  454 |     return row.innerText();
  455 |   };
  456 |   const executionSkipLabels = ['估值源拒绝', '重仓源拒绝', '重仓半开额度已用', '模型源拒绝', '模型半开额度已用'];
  457 |   const assertExecutionSkips = async counts => {
  458 |     const row = diagnosticValue('执行跳过');
> 459 |     await expect(row, 'execution gate observations must be visible in the real diagnostics center').toHaveCount(1);
      |                                                                                                     ^ Error: execution gate observations must be visible in the real diagnostics center
  460 |     await expect(row).toBeVisible();
  461 |     await expect(row).toHaveText(executionSkipLabels.map((label, index) => `${label} ${counts[index]}`)
  462 |       .concat('按门控检查次数统计，非请求或唯一资源数；拒绝细因未记录').join('；'));
  463 |     return row.innerText();
  464 |   };
  465 |   const readCache = () => page.evaluate(key => {
  466 |     const raw = localStorage.getItem(key);
  467 |     const cache = raw && JSON.parse(raw);
  468 |     return { raw, holdingsHash: cache?.holdingsHash,
  469 |       stable: Object.fromEntries(Object.entries(cache?.refreshResources || {})
  470 |         .filter(([resource]) => /^(?:nav|holdings|meta):/.test(resource))) };
  471 |   }, FUND_CACHE);
  472 |   const openDiagnostics = async phase => {
  473 |     await harness.phase(page, phase);
  474 |     await page.locator('#nav-edit').click();
  475 |     await page.locator('#diagnostics-center > summary').click();
  476 |     await expect(page.locator('#diagnostics-center')).toHaveAttribute('open', '');
  477 |     await expect(diagnosticValue('刷新诊断'), 'completed refresh must be observable through the real diagnostics center').toHaveCount(1);
  478 |     await expect(diagnosticValue('刷新诊断')).toContainText(/completed|已完成/);
  479 |     await expect(diagnosticValue('刷新诊断')).toContainText(/observed\s*[:：=]?\s*true/i);
  480 |     await harness.settle(page);
  481 |   };
  482 |   const assertPrivateFeaturesAbsent = () => {
  483 |     expect(harness.state.requests.filter(row => row.category === 'gist'), 'diagnostics must not initiate even read-only Gist requests').toEqual([]);
  484 |     expect(harness.state.requests.filter(row => /(?:\/assets\/ocr\/|ocr-import\.html|paddle|tesseract|\.wasm(?:$|\?))/i.test(row.url)),
  485 |       'opening or refreshing diagnostics must not load OCR assets or an OCR document').toEqual([]);
  486 |     expect(harness.state.gistWrites).toEqual([]);
  487 |   };
  488 | 
  489 |   await page.goto('/');
  490 |   await harness.settle(page);
  491 |   await expect(navValue(page)).not.toHaveText('--');
  492 |   const cold = await readCache();
  493 |   expect(cold.raw).not.toBeNull();
  494 |   expect(typeof cold.holdingsHash).toBe('string');
  495 |   expect(Object.keys(cold.stable)).toHaveLength(3);
  496 |   expect(harness.requests('cold', 'holdings')).toHaveLength(1);
  497 |   expect(harness.requests('cold', 'nav')).toHaveLength(1);
  498 |   const coldRequests = requestCounts('cold');
  499 |   await testInfo.attach('cold-refresh-network-categories', {
  500 |     contentType: 'application/json', body: JSON.stringify({ scope: 'real app and opaque Bridge; synthetic network only', counts: coldRequests }),
  501 |   });
  502 |   await openDiagnostics('coldDiagnostics');
  503 |   expect(await counter('实际请求')).toBe(requestTotal('cold'));
  504 |   expect(await counter('已进入请求中止')).toBe(0);
  505 |   expect(await counter('资源取消拒绝')).toBe(0);
  506 |   expect(await counter('写尝试')).toBe(1);
  507 |   expect(await counter('缓存写入')).toBe(1);
  508 |   await expect(diagnosticValue('刷新计划')).toContainText(/estimates/);
  509 |   await expect(diagnosticValue('刷新计划')).toContainText(/fetch/);
  510 |   // Startup forces the three volatile resources. The three stable resources
  511 |   // miss their cache; the two phase-B resources remain pending at plan time.
  512 |   const coldPlanReasons = await assertPlanReasons([0, 3, 0, 0, 0, 3, 0, 0, 2, 0]);
  513 |   const coldExecutionSkips = await assertExecutionSkips([0, 0, 0, 0, 0]);
  514 |   await expect(diagnosticValue('请求来源')).toContainText('sinan-estimate-proxy');
  515 |   await expect(diagnosticValue('最终报价')).toContainText(/基金详情.*数据说明/);
  516 |   expect(await readCache(), 'reading diagnostics must preserve all cache acquisition bytes and holdings identity').toEqual(cold);
  517 |   expect(requestTotal('coldDiagnostics')).toBe(0);
  518 |   expect(await harness.writes(page, 'coldDiagnostics')).toEqual([]);
  519 |   assertPrivateFeaturesAbsent();
  520 | 
  521 |   await page.locator('#diagnostics-center > summary').click();
  522 |   await page.locator('#nav-market').click();
  523 |   await page.evaluate(() => window.scrollTo(0, 0));
  524 |   await harness.refresh(page);
  525 |   expect(harness.requests('warm', 'holdings')).toHaveLength(0);
  526 |   expect(harness.requests('warm', 'nav')).toHaveLength(0);
  527 |   const warm = await readCache();
  528 |   expect(warm.holdingsHash).toBe(cold.holdingsHash);
  529 |   expect(warm.stable, 'warm refresh cannot renew NAV, disclosure or metadata acquisition envelopes').toEqual(cold.stable);
  530 |   await openDiagnostics('warmDiagnostics');
  531 |   expect(await counter('实际请求')).toBe(requestTotal('warm'));
  532 |   expect(await counter('缓存命中')).toBeGreaterThan(0);
  533 |   expect(await counter('已进入请求中止')).toBe(0);
  534 |   expect(await counter('资源取消拒绝')).toBe(0);
  535 |   expect(await counter('写尝试')).toBe(1);
  536 |   expect(await counter('缓存写入')).toBe(1);
  537 |   await expect(diagnosticValue('刷新计划')).toContainText(/cache/);
  538 |   await expect(diagnosticValue('跳过原因')).not.toBeEmpty();
  539 |   // A warm manual refresh still forces live data; only NAV, disclosure and
  540 |   // metadata become fresh-cache decisions, without renewing their envelopes.
  541 |   const warmPlanReasons = await assertPlanReasons([3, 0, 0, 0, 0, 3, 0, 0, 2, 0]);
  542 |   const warmExecutionSkips = await assertExecutionSkips([0, 0, 0, 0, 0]);
  543 |   const summary = (await Promise.all(['刷新诊断', '刷新计划', '计划原因', '执行跳过', '刷新请求', '跳过原因', '请求来源', '最终报价']
  544 |     .map(label => diagnosticValue(label).innerText()))).join('\n');
  545 |   expect(summary).not.toMatch(/005844|合成境内混合基金A|ghp_|Authorization|https?:|source_quote|baseNav|shares|cost/);
  546 |   expect(await readCache(), 'opening warm diagnostics must not change aggregate dates, hash or stored data').toEqual(warm);
  547 |   expect(requestTotal('warmDiagnostics')).toBe(0);
  548 |   expect(await harness.writes(page, 'warmDiagnostics')).toEqual([]);
  549 |   assertPrivateFeaturesAbsent();
  550 |   await testInfo.attach('refresh-diagnostics-cold-warm', {
  551 |     contentType: 'application/json', body: JSON.stringify({ scope: 'synthetic completed generations only; no cancellation or production acceptance',
  552 |       cold: coldRequests, warm: requestCounts('warm'), coldPlanReasons, warmPlanReasons,
  553 |       coldExecutionSkips, warmExecutionSkips, summary }),
  554 |   });
  555 | });
  556 | 
```