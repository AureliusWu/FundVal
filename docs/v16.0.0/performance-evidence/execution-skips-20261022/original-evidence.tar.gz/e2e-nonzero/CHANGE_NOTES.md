# Real nonzero source-gate diagnostics E2E

- Sole edited repository file: `D:\AI项目\FundVal\e2e\v16-refresh.spec.js`.
- Before copy: `v16-refresh.before.spec.js` (SHA256 `DC054DB9A26016C44A4D87509F5A046654D659E843D1D7E224BB9CC4304A9B52`).
- After copy: `v16-refresh.after.spec.js`.
- Preserved the existing cold/warm diagnostics test and its ten plan reasons, five zero execution-skip labels, read-only, redaction and attachment assertions unchanged.
- Added a separate diagnostics test using the real app/bootstrap/Bridge and default source-health policy. Three actual synthetic estimate failures (cold + two manual refreshes) lead to generation four through the existing public online event.
- Securities have no usable synthetic changes, while disclosure stays healthy; official NAV remains 1.2000 / previous 1.1900 / +0.84% / publication date 2026-09-28. No source policy, coordinator, application observer, clock or half-open probe is injected.
- Public diagnostics generation four completed status is the completion barrier. The test expects zero generation-four estimate requests and execution skips exactly `estimate_claim_denied=1`, all four other labels zero.
- Official value kind, base date, publication date, stable NAV/metadata/disclosure acquisition envelopes and holdings identity must survive all generations unchanged. It does not mistake an aggregate cache flush from other successful market requests for a NAV renewal.
- A subsequent public diagnostics refresh must produce no requests of any category, no localStorage mutation via setItem/removeItem/clear, no cache byte change, no Gist/OCR activity, and only a redacted synthetic artifact.
- Syntax command: `node --check e2e/v16-refresh.spec.js`; stdout/stderr are captured in the sibling syntax logs; exit code is recorded in `syntax-check.exit-code.txt`.
- This subtask does not run build or E2E. Root owns rebuilt-site GREEN verification. No production, performance-budget, half-open or release acceptance is claimed.
