# Closure SIMPLE prerequisite audit (not a compression experiment)

Read-only official-source review on 2026-10-20. No compiler/runtime installation, compression run, candidate bytes, or claimed size result.

The existing application retains top-level await in bootstrap/post-integrity. Current official FeatureSet.java classifies TOP_LEVEL_AWAIT as ES_UNSUPPORTED and explains that it cannot pass through the normal module output; CommandLineRunner rejects explicitly selecting UNSUPPORTED for language input/output. Therefore no direct ES2022-preserving command has been qualified for these 16 existing ESM chunks. Wrapping or removing await would alter the protected startup/loading design.

Sources:
- https://raw.githubusercontent.com/google/closure-compiler/master/src/com/google/javascript/jscomp/parsing/parser/FeatureSet.java (TOP_LEVEL_AWAIT)
- https://raw.githubusercontent.com/google/closure-compiler/master/src/com/google/javascript/jscomp/CommandLineRunner.java (unsupported language rejection; ES_MODULES enables wrapped-output options)
- https://raw.githubusercontent.com/google/closure-compiler/master/src/com/google/javascript/jscomp/CompilationLevel.java (SIMPLE wrapped-output enables global renaming/inlining/removal and module-export collapse)

Ordinary SIMPLE has property renaming OFF; do not claim that every SIMPLE invocation necessarily breaks function arity. The ES_MODULES route enables additional global optimizations, so it is not a proven drop-in post-minifier retaining the original Rolldown export/binding/chunk contract. This is a prerequisite-based stop, not an observed compressor regression or a proof that all possible adapters are impossible. Master URLs are time-dependent observations, not immutable compiler-version qualification.

A limited local search did not find a usable Java/Closure runtime in PATH, JAVA_HOME/JDK_HOME/JRE_HOME, common installation roots, root node_modules or the known experiment directories. It was not a whole-machine absence proof and was not the deciding compatibility blocker.

