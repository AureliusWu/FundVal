import test from 'node:test';
import assert from 'node:assert/strict';
import { createDiagnosticsCenter } from '../js/runtime/diagnostics-ui.js';

const zero = { generation: 1, planned: 4, staged: 0, cacheHits: 0, deduped: 0, requests: 0,
  abortedRequests: 0, failedRequests: 0, cancelledResources: 0, writeAttempts: 0, cacheWrites: 0, providers: {} };
function harness(t, snapshot) {
  let writes = 0, copied;
  const content = { textContent: '', innerHTML: '' };
  const globals = { localStorage: { length: 0, getItem: () => null, setItem() { writes++; } },
    navigator: { onLine: true, clipboard: { writeText: async text => { copied = text; } } },
    window: {}, document: { getElementById: () => content } };
  for (const [key, value] of Object.entries(globals)) {
    const previous = Object.getOwnPropertyDescriptor(globalThis, key);
    Object.defineProperty(globalThis, key, { value, configurable: true });
    t.after(() => previous ? Object.defineProperty(globalThis, key, previous) : delete globalThis[key]);
  }
  const center = createDiagnosticsCenter({ getHoldings: () => [], getHoldingsDocument: () => null,
    refreshCoordinator: { snapshot: () => ({}) }, getRefreshDiagnostics: () => snapshot, showToast() {},
    esc: value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;'), now: () => 0 });
  return { center, content, writes: () => writes, copied: () => copied };
}

test('diagnostics distinguishes unobserved cancellation from observed true zero, including clipboard text', async t => {
  const record = { generation: 1, phase: 'final', status: 'cancelled', observed: false, counters: null, plan: null, skipReasons: null };
  const snapshot = { current: record, lastCancelled: record, lastSettled: null };
  const h = harness(t, snapshot);
  let summary = await h.center.refreshDiagnosticsCenter();
  assert.match(summary, /刷新诊断：第1代[^\n]*已取消[^\n]*observed=false/);
  assert.match(summary, /刷新请求：未观测/);
  assert.doesNotMatch(summary, /实际请求 0/);
  snapshot.current = { ...record, status: 'completed', observed: true, counters: zero,
    plan: [{ kind: 'indices', cache: 1, fetch: 0, skip: 0 }], skipReasons: { market_ineligible: 0, no_active_holdings: 2 } };
  summary = await h.center.refreshDiagnosticsCenter();
  assert.match(summary, /刷新诊断：第1代[^\n]*已完成[^\n]*observed=true/);
  assert.match(summary, /实际请求 0；缓存命中 0/);
  assert.match(summary, /刷新计划：indices cache=1 fetch=0 skip=0/);
  assert.match(summary, /最终报价：[^\n]*基金详情[^\n]*数据说明/);
  await h.center.copyDiagnosticsSummary();
  assert.equal(h.copied(), summary);
  assert.equal(h.writes(), 0);
});

test('running new generation keeps a clearly labelled older cancellation summary, without private payloads', async t => {
  const h = harness(t, { current: { generation: 2, status: 'running', observed: false, counters: null },
    lastCancelled: { generation: 1, status: 'cancelled', observed: true,
      counters: { ...zero, requests: 2, abortedRequests: 2, cancelledResources: 3 } } });
  const summary = await h.center.refreshDiagnosticsCenter();
  assert.match(summary, /刷新诊断：第2代[^\n]*执行中/);
  assert.match(summary, /最近取消代：第1代[^\n]*已取消[^\n]*已进入请求中止 2[^\n]*资源取消拒绝 3/);
  assert.doesNotMatch(summary, /取消资源数|请求全部取消/);
  assert.equal(h.writes(), 0);
});
