import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync, execFileSync } from 'node:child_process';
import { cp, lstat, mkdir, mkdtemp, readFile, readdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import net from 'node:net';
const main=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const target=resolve(root,'docs/v16.0.0/performance-evidence/refresh-observability-20261020');
const hash=b=>createHash('sha256').update(b).digest('hex');
const build=JSON.parse(await readFile(resolve(main,'build-verification.json')));
for(const row of build.sourceAfter.rows){const b=await readFile(resolve(root,row.path));assert.equal(b.length,row.bytes);assert.equal(hash(b),row.sha256);}
const unit=JSON.parse(await readFile(resolve(main,'unit-final.json')));
const e2e=JSON.parse(await readFile(resolve(main,'e2e-final.json')));
const syntax=JSON.parse(await readFile(resolve(main,'syntax-final.json')));
const audit=JSON.parse(await readFile(resolve(main,'audit-final.json')));
for(const result of [unit,e2e,syntax,audit])assert.equal(result.exitCode,0);
assert.match(unit.stdout,/tests 1133/);assert.match(unit.stdout,/pass 1130/);assert.match(unit.stdout,/fail 0/);assert.match(unit.stdout,/skipped 3/);
assert.match(e2e.stdout,/32 passed/);assert.match(syntax.stdout,/210 JavaScript/);assert.match(audit.stdout,/0 vulnerabilities/);
const portStatus=await new Promise((accept,reject)=>{
 const socket=net.createConnection({host:'127.0.0.1',port:12437});
 socket.setTimeout(2000);
 socket.once('connect',()=>{socket.destroy();reject(Error('E2E port still listening'));});
 socket.once('error',error=>error.code==='ECONNREFUSED'?accept(error.code):reject(error));
 socket.once('timeout',()=>{socket.destroy();reject(Error('E2E port observation timed out'));});
});
const git=spawnSync('git',['diff','--check'],{cwd:root,encoding:'utf8',windowsHide:true});assert.equal(git.status,0);
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
assert.equal(head,'170fd3eadc6da02750882f8a542904ee2358d0d9');
const sourcePaths=['js/app.js','js/runtime/diagnostics-ui.js','js/runtime/refresh-execution.js','js/runtime/refresh-generation.js',
 'test/refresh-observation-v16.test.js','test/refresh-diagnostics-view-v16.test.js','test/refresh-diagnostics-store-v16.test.js',
 'test/refresh-execution-v16.test.js','test/runtime-plan-characterization-v16.test.js','e2e/v16-refresh.spec.js'];
for(const path of sourcePaths){await mkdir(resolve(main,'sources',dirname(path)),{recursive:true});await cp(resolve(root,path),resolve(main,'sources',path),{force:false,errorOnExist:true});}
const diff=execFileSync('git',['diff','--',...sourcePaths],{cwd:root,encoding:'utf8',maxBuffer:8*1024*1024});
await writeFile(resolve(main,'tracked-feature-diff.patch'),diff,{flag:'wx'});
await writeFile(resolve(main,'qa-summary.json'),JSON.stringify({schema:1,head,unit:{tests:1133,pass:1130,fail:0,skip:3},
 syntax:210,e2e:{pass:32,scope:'Synthetic desktop Chrome, not physical devices'},auditVulnerabilities:0,
 sourceCount:228,sourceSha256:build.sourceAfter.sha256,wholeSite:build.runs[0].site,critical:build.runs[0].critical,
 budget:build.runs[0].budget,ocr:build.runs[0].ocr,graph:build.runs[0].graph,sourceFiles:sourcePaths,
 e2ePort:portStatus,diffCheck:{exit:git.status,stdout:git.stdout,stderr:git.stderr},
 productChanged:true,version:'15.0.2',relativeLatencyQualified:false,ci:'NOT_RUN',production:'NOT_RUN',
 observedTrustScope:'CONDITIONALLY TRUSTED: deterministic synthetic resource counter chain only; not a new live market-data trust decision.'
},null,2)+'\n',{flag:'wx'});
const staging=await mkdtemp(resolve(tmpdir(),'fundval-observation-staging-'));
const groups=[
 ['main',main],
 ['store','C:/Users/84046/AppData/Local/Temp/fundval-refresh-diagnostics-store-483c09ff06f445839ff4015d79854099'],
 ['e2e-red-locator','C:/Users/84046/AppData/Local/Temp/fundval-refresh-diagnostics-red-20261020-161753-e7991be1b4f74ff79d462f9560b9c842'],
 ['e2e-red-missing-row','C:/Users/84046/AppData/Local/Temp/fundval-refresh-diagnostics-missing-row-red-20261020-161854-1d5b88de407f4f34a90d320e2c12394c'],
];
async function rows(base){
 const output=[];
 async function visit(path){
  assert.ok(path.split('/').every(part=>part&&part!=='.'&&part!=='..')&&!path.includes('\\'));
  const absolute=resolve(base,path),stat=await lstat(absolute);assert.equal(stat.isSymbolicLink(),false);
  if(stat.isDirectory())for(const name of await readdir(absolute))await visit(path+'/'+name);
  else{assert.ok(stat.isFile());const b=await readFile(absolute);output.push({path,bytes:b.length,sha256:hash(b)});}
 }
 for(const name of await readdir(base))await visit(name);
 return output.sort((a,b)=>a.path.localeCompare(b.path));
}
for(const [group,source]of groups){await rows(source);await cp(source,resolve(staging,group),{recursive:true,force:false,errorOnExist:true});}
const inventory=await rows(staging);
await mkdir(target);
const archive=resolve(target,'original-evidence.tar.gz');
execFileSync('tar',['-czf',archive,'-C',staging,...groups.map(([group])=>group)],{stdio:'pipe'});
const entries=execFileSync('tar',['-tf',archive],{encoding:'utf8'}).trim().split(/\r?\n/);
for(const p of entries)assert.ok(!/^(?:\/|[A-Za-z]:)/.test(p)&&!p.includes('\\')&&!p.split('/').includes('..'));
assert.deepEqual(entries.filter(p=>!p.endsWith('/')).sort(),inventory.map(r=>r.path).sort());
const extractionDirectory=await mkdtemp(resolve(tmpdir(),'fundval-observation-extracted-'));
execFileSync('tar',['-xzf',archive,'-C',extractionDirectory],{stdio:'pipe'});
assert.deepEqual(await rows(extractionDirectory),inventory);
const bytes=await readFile(archive);
const record={schema:1,fileCount:inventory.length,uncompressedBytes:inventory.reduce((n,r)=>n+r.bytes,0),files:inventory,
 archive:{path:'original-evidence.tar.gz',bytes:bytes.length,sha256:hash(bytes)},staging,extractionDirectory,extractionVerified:true,
 includes:'Exact captured command records, full source/test copies, diff, Store RED/GREEN windows and synthetic E2E RED/final attachments.',
 limits:'Initial uncaptured executor RED and initial verifier failure stdout exist only in tool history. Store after snapshot predates root onError fix; main/sources is final. No full product tree, real user image/holdings, node_modules, new latency qualification, CI or production evidence.'};
await writeFile(resolve(target,'archive-audit.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
await cp(resolve(main,'qa-summary.json'),resolve(target,'qa-summary.json'),{force:false,errorOnExist:true});
await cp(fileURLToPath(import.meta.url),resolve(target,'archive-tool.mjs.txt'),{force:false,errorOnExist:true});
process.stdout.write(JSON.stringify({target,fileCount:inventory.length,uncompressedBytes:record.uncompressedBytes,archiveBytes:bytes.length,archiveSha256:hash(bytes),extractionVerified:true,port:portStatus})+'\n');

