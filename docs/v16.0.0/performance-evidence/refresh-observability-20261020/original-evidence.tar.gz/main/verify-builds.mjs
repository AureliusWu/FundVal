import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { cp, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, resolve, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const directory=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const sha=b=>createHash('sha256').update(b).digest('hex');
async function inventory(base, selections=['.']){
 const rows=[];
 async function visit(path){
  const full=resolve(base,path);
  const {lstat}=await import('node:fs/promises'); const info=await lstat(full);
  assert.equal(info.isSymbolicLink(),false);
  if(info.isDirectory()){for(const name of await readdir(full))await visit(path==='.'?name:path+'/'+name);}
  else{assert.ok(info.isFile());const b=await readFile(full); rows.push({path:path.replaceAll('\\','/'),bytes:b.length,sha256:sha(b)});}
 }
 for(const path of selections)await visit(path);
 rows.sort((a,b)=>a.path.localeCompare(b.path));
 return {count:rows.length,bytes:rows.reduce((n,r)=>n+r.bytes,0),sha256:sha(JSON.stringify(rows)),rows};
}
const sources=['js','css','scripts','test','e2e','.github','data','package.json','package-lock.json','playwright.config.mjs','index.html','ocr-import.html','quote-bridge.html','manifest.json','sw.js','.node-version','.npmrc'];
const before=await inventory(root,sources);
// E2E outputs were copied here by v1 before its wrong OCR-root call failed.
const api=await import(pathToFileURL(resolve(root,'scripts/release-fingerprint.mjs')));
const runs=[];
for(let i=1;i<=3;i++){
 const child=spawnSync(process.execPath,[resolve(directory,'run-command.mjs'),'build-confirm-'+i,'0','NODE','C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js','run','build'],{cwd:root,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});
 assert.equal(child.status,0,child.stdout+'\n'+child.stderr);
 const site=await inventory(resolve(root,'site'));
 const critical=await api.fingerprintReleaseDirectory(resolve(root,'site'));
 const chunks=await api.verifyAppChunkReleaseDirectory(resolve(root,'site'));
 const budget=api.analyzeAppChunkBudgets(chunks);
 const graph=await api.verifyAppModuleGraphReleaseDirectory(resolve(root,'site'));
 const ocr=await api.verifyOcrReleaseDirectory(resolve(root,'site/assets/ocr'));
 runs.push({round:i,site,critical,chunks,budget,graph,ocr});
 process.stdout.write(JSON.stringify({round:i,files:site.count,siteHash:site.sha256,critical,budget,graph})+'\n');
}
for(const run of runs.slice(1))assert.deepEqual(run.site,runs[0].site);
assert.equal(new Set(runs.map(run=>run.critical)).size,1);
const after=await inventory(root,sources);assert.deepEqual(after,before);
assert.equal(runs[0].budget.actualAllNonOcrGzipBytes,83084);
assert.equal(runs[0].budget.actualColdStartGzipBytes,44386);
const report={schema:1,sourceDateEpoch:1792046773,sourceBefore:before,sourceAfter:after,runs,
 baseline:{allGzipBytes:80494,coldGzipBytes:42985,rawBytes:235647,critical:'4bda36bc3ed361fcbf69d44d96f30af47fc1fff3b75eefd8728a341a45680948',scope:'Historical same-day pre-feature actual OXC product; not a new paired latency measurement.'},
 productChanged:true,version:'15.0.2',relativeLatencyQualified:false,physicalDevices:'NOT_RUN',ci:'NOT_RUN',deployed:false};
await writeFile(resolve(directory,'build-verification.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});

