import { spawnSync } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const [label, expected, program, ...args] = process.argv.slice(2);
if(!/^[a-z0-9-]+$/.test(label)||!['0','1'].includes(expected))throw Error('Bad capture args');
const directory=dirname(fileURLToPath(import.meta.url));
const start=new Date().toISOString();
const child=spawnSync(program==='NODE'?process.execPath:program,args,{cwd:'D:/AI项目/FundVal',encoding:'utf8',windowsHide:true,env:{...process.env,SOURCE_DATE_EPOCH:'1792046773',FUNDVAL_E2E_PORT:'12437'},maxBuffer:64*1024*1024});
const record={label,program,args,startedAt:start,endedAt:new Date().toISOString(),expectedExit:Number(expected),exitCode:child.status,signal:child.signal,error:child.error?String(child.error):null,stdout:child.stdout,stderr:child.stderr};
await writeFile(resolve(directory,label+'.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
process.stdout.write((child.stdout||'')+(child.stderr||''));
process.stdout.write('\nCAPTURE '+JSON.stringify({label,exit:child.status,expected:Number(expected)})+'\n');
if(child.status!==Number(expected)||child.error)process.exitCode=1;

