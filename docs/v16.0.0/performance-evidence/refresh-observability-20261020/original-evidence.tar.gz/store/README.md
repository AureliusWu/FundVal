# Refresh diagnostics Store: focused RED / GREEN evidence

Date: 2026-10-20. Repository: `D:\AI项目\FundVal`. Node: v24.14.0.

This task changed only `js/runtime/refresh-generation.js` (one appended export)
and new `test/refresh-diagnostics-store-v16.test.js`. No full test run, build,
release, app execution, dependency installation or product configuration change
was performed by this subagent. The main agent owns integration and full QA.

## Actual command sequence

All commands ran from the repository, with native stdout/stderr piped through
PowerShell `Tee-Object -FilePath <the corresponding log>`; the Node exit code
was captured as `$LASTEXITCODE` and propagated by `exit $taskTestExit`.

1. `node --test test/refresh-diagnostics-store-v16.test.js`
   - `red.log.txt`: exit 1; the old module does not export
     `createRefreshDiagnosticsStore`, so import fails before test execution.
   - Old source SHA256 verified before and immediately after this run:
     `5dbfde625ee4caab0db63b6af0c016096dea7bab8cf199a3e932eda1d9cccaea`.
   - The exact old source is saved as `refresh-generation-before.js`.
   - The initial test revision was subsequently extended and was not separately
     saved; the original import failure log is retained, not regenerated.
2. `node --test test/refresh-diagnostics-store-v16.test.js`
   - `green-attempt-1.log.txt`: exit 0, 20/20 tests PASS, 113.153 ms.
3. `node --test test/refresh-diagnostics-store-v16.test.js`
   - `invalid-final-red.log.txt`: exit 1, 20 PASS / 1 FAIL, 103.6033 ms.
   - A new negative control proved that a missing/invalid final counter section
     incorrectly inherited started-only zero counts. This was corrected by
     retaining `null`, not promoting the earlier scope-creation sample.
4. `node --test test/refresh-diagnostics-store-v16.test.js test/refresh-generation.test.js test/refresh-runtime-characterization-v16.test.js`
   - `green-targeted.log.txt`: exit 0, 53/53 tests PASS, 243.994 ms.
   - 21 Store tests, 2 original generation tests, 30 existing characterization
     tests. No skipped/cancelled/todo tests.
5. `git diff --check -- js/runtime/refresh-generation.js test/refresh-diagnostics-store-v16.test.js`
   - Exit 0. Git warned that LF will become CRLF on a future checkout; this is
     not a failed check and no checkout/normalization was performed.

## Final scoped inputs, frozen before main-agent build / QA

The original 1,575-byte module is an identical raw byte prefix of the final
10,538-byte module. Existing functions were not edited. The addition is 164
lines. Raw and LF-normalized hashes are identical because these saved files use LF.

| Saved file | SHA256 |
| --- | --- |
| refresh-generation-before.js | 5dbfde625ee4caab0db63b6af0c016096dea7bab8cf199a3e932eda1d9cccaea |
| refresh-generation-after.js | 5e707aaeae55d7c6f862c6387dd3936cf2102bac49333914099f2d2368c505db |
| refresh-diagnostics-store-v16.test.js | e6f74d0ca42d65769a50fcddf1a9ef8b559dacd086964f3798d73b9fea17c527 |

The final source/test snapshots were copied after the GREEN run and matched
the files frozen for the main agent. They are evidence, not executable Temp
test fixtures (their relative imports are repository-relative).

## Meaning and limits

- At most three generation-record slots: current, lastSettled, lastCancelled.
  The latest explicit generation wins; executor report phase cannot regress.
- Only fixed fields, enums, safe non-negative integer counts, eight resource
  kinds and seven providers survive. Output is copied and deeply frozen; own
  data descriptors avoid reading accessors, and exceptions from hostile proxy
  traps are contained. No untrusted payload is stringified or enumerated.
- `observed: true` means an executor/scope report was received, not success.
  Unobserved records retain null counters/plan/reasons. Started-only counters
  become null on lifecycle terminal state; late real drain counts can populate
  cancelled/failed records without changing their terminal status.
- `observeState` consumes the production coordinator's synchronous
  `onStateChange` stream. An idle stop snapshot has no stop sequence; it cannot
  distinguish arbitrarily asynchronously replayed old stop events. No event
  bus with such replay is supported or claimed.
- Real production coordinator tests bind coalesced Promise identity, health
  snapshots, failure before scope start, supersession before execute and stop
  after scope start. The Store never wraps or replaces refresh Promises.
- This evidence is focused Node-level qualification. It is not full build,
  browser E2E, M3 budget acceptance, deployment or production evidence.

## Fixed archive inventory

1. README.md
2. red.log.txt
3. green-attempt-1.log.txt
4. invalid-final-red.log.txt
5. green-targeted.log.txt
6. refresh-generation-before.js
7. refresh-generation-after.js
8. refresh-diagnostics-store-v16.test.js

All four actual logs are retained, including the intermediate negative control.
