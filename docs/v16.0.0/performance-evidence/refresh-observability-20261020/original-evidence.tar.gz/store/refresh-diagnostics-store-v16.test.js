import test from 'node:test';
import assert from 'node:assert/strict';
import { createRefreshDiagnosticsStore } from '../js/runtime/refresh-generation.js';
import { RefreshCoordinator } from '../js/runtime/refresh-runtime.js';

const KINDS = ['estimates', 'nav', 'holdings', 'meta', 'indices', 'gold', 'securities', 'model-quotes'];
const PROVIDERS = ['sinan-estimate-proxy', 'sinan-holdings-proxy', 'eastmoney-official-nav',
  'eastmoney-security-quote', 'tencent-market-quote', 'gold', 'model-config'];
const COUNTERS = ['generation', 'planned', 'staged', 'cacheHits', 'deduped', 'requests',
  'abortedRequests', 'failedRequests', 'cancelledResources', 'writeAttempts', 'cacheWrites'];
const RECORD_KEYS = ['generation', 'phase', 'status', 'observed', 'counters', 'plan', 'skipReasons'];
const state = (active, completed = null, failed = null, current = active) => ({
  active: active === null ? null : { generation: active }, currentGeneration: current,
  lastCompleted: completed === null ? null : { generation: completed },
  lastFailure: failed === null ? null : { generation: failed },
});
function report(generation, phase = 'started', status = 'running', requests = 0) {
  return { generation, phase, status,
    counters: { generation, planned: 8, staged: 0, cacheHits: 0, deduped: 0, requests,
      abortedRequests: 0, failedRequests: 0, cancelledResources: 0, writeAttempts: 0,
      cacheWrites: 0, providers: { gold: requests } },
    plan: KINDS.map(kind => ({ kind, cache: 0, fetch: 1, skip: 0 })),
    skipReasons: { market_ineligible: 0, no_active_holdings: 0 } };
}
function assertFrozen(value) {
  if (!value || typeof value !== 'object') return;
  assert.equal(Object.isFrozen(value), true);
  Object.values(value).forEach(assertFrozen);
}
function deferred() {
  let resolve;
  const promise = new Promise(accept => { resolve = accept; });
  return { promise, resolve };
}

test('empty store has only three frozen slots and no fabricated observations', () => {
  const store = createRefreshDiagnosticsStore();
  assert.deepEqual(Object.keys(store), ['observeState', 'observe', 'snapshot']);
  assertFrozen(store);
  assert.deepEqual(store.snapshot(), { current: null, lastSettled: null, lastCancelled: null });
  assertFrozen(store.snapshot());
  store.observeState(state(1));
  assert.deepEqual(store.snapshot().current, { generation: 1, phase: null, status: 'running',
    observed: false, counters: null, plan: null, skipReasons: null });
});

test('new state cancels old running generation without zero-filling unobserved counters', () => {
  const store = createRefreshDiagnosticsStore();
  store.observeState(state(1));
  store.observeState(state(2));
  assert.equal(store.snapshot().current.generation, 2);
  assert.deepEqual(store.snapshot().lastCancelled, { generation: 1, phase: 'final',
    status: 'cancelled', observed: false, counters: null, plan: null, skipReasons: null });
  store.observeState(state(1));
  assert.equal(store.snapshot().current.generation, 2);
  assert.equal(store.snapshot().current.status, 'running');
});

test('old finishes cannot replace a newer start and cancellation history uses generation order', () => {
  const store = createRefreshDiagnosticsStore();
  store.observe(report(1));
  store.observe(report(2));
  store.observe(report(3));
  store.observe(report(1, 'final', 'completed', 99));
  store.observe(report(1, 'final', 'cancelled', 99));
  assert.equal(store.snapshot().current.generation, 3);
  assert.equal(store.snapshot().lastCancelled.generation, 2);
  assert.equal(store.snapshot().lastCancelled.counters, null);
  assert.equal(store.snapshot().lastSettled, null);
  store.observe(report(3, 'final', 'completed', 3));
  store.observe(report(2, 'resources_settled', 'cancelled', 2));
  assert.equal(store.snapshot().current.generation, 3);
  assert.equal(store.snapshot().current.status, 'completed');
  assert.equal(store.snapshot().lastSettled.generation, 3);
  assert.equal(store.snapshot().lastCancelled.generation, 2);
  assert.equal(store.snapshot().lastCancelled.counters.requests, 2);
});

test('terminal lifecycle records accept late scope counts without becoming running', () => {
  const store = createRefreshDiagnosticsStore();
  store.observeState(state(1));
  store.observeState(state(2));
  store.observe(report(1, 'resources_settled', 'running', 4));
  const cancelled = store.snapshot().lastCancelled;
  assert.equal(cancelled.phase, 'final');
  assert.equal(cancelled.status, 'cancelled');
  assert.equal(cancelled.observed, true);
  assert.equal(cancelled.counters.requests, 4);
  store.observe(report(1, 'started', 'running', 1));
  assert.strictEqual(store.snapshot().lastCancelled, cancelled);
  store.observe(report(1, 'final', 'completed', 5));
  assert.equal(store.snapshot().lastCancelled.status, 'cancelled');
  assert.equal(store.snapshot().lastCancelled.counters.requests, 5);
  store.observe(report(1, 'resources_settled', 'cancelled', 8));
  assert.equal(store.snapshot().lastCancelled.counters.requests, 5);
});

test('observed started plans survive cancellation and late drain updates abort counters', () => {
  const store = createRefreshDiagnosticsStore();
  store.observe(report(1, 'started', 'running', 1));
  store.observeState(state(2));
  const late = report(1, 'resources_settled', 'cancelled', 2);
  late.counters.abortedRequests = 2;
  store.observe(late);
  assert.equal(store.snapshot().lastCancelled.counters.abortedRequests, 2);
  assert.equal(store.snapshot().lastCancelled.phase, 'final');
  store.observeState(state(null, 2, null, 2));
  assert.equal(store.snapshot().current.observed, false);
  assert.equal(store.snapshot().current.counters, null);
  assert.equal(store.snapshot().lastSettled.status, 'completed');
});

test('started-only zero counts are not exposed as terminal actual counts after failure or stop', () => {
  for (const status of ['failed', 'cancelled']) {
    const store = createRefreshDiagnosticsStore();
    store.observe(report(1));
    store.observeState(state(null, null, status === 'failed' ? 1 : null, null));
    const terminal = store.snapshot().current;
    assert.equal(terminal.status, status);
    assert.equal(terminal.observed, true);
    assert.equal(terminal.counters, null);
    assert.equal(terminal.plan.length, 8);
    store.observe(report(1, 'started', 'running', 0));
    assert.equal(store.snapshot().current.counters, null);
    store.observe(report(1, 'resources_settled', 'running', 3));
    assert.equal(store.snapshot().current.status, status);
    assert.equal(store.snapshot().current.counters.requests, 3);
  }
});

test('failed or completed lifecycle can be observed later but terminal status cannot change', () => {
  for (const status of ['failed', 'completed']) {
    const store = createRefreshDiagnosticsStore();
    store.observeState(state(7));
    store.observeState(state(null, status === 'completed' ? 7 : null, status === 'failed' ? 7 : null,
      status === 'failed' ? null : 7));
    assert.equal(store.snapshot().current.status, status);
    assert.equal(store.snapshot().current.observed, false);
    store.observe(report(7, 'resources_settled', 'running', 6));
    assert.equal(store.snapshot().current.status, status);
    assert.equal(store.snapshot().current.phase, 'final');
    assert.equal(store.snapshot().current.counters.requests, 6);
    assert.strictEqual(store.snapshot().current, store.snapshot().lastSettled);
  }
});

test('phase rollback cannot replace final metrics or undo a terminal observation', () => {
  const store = createRefreshDiagnosticsStore();
  store.observe(report(1, 'resources_settled', 'running', 3));
  const settled = store.snapshot().current;
  store.observe(report(1, 'started', 'running', 1));
  assert.strictEqual(store.snapshot().current, settled);
  store.observe(report(1, 'final', 'completed', 4));
  const final = store.snapshot().current;
  store.observe(report(1, 'resources_settled', 'failed', 99));
  store.observeState(state(1));
  assert.strictEqual(store.snapshot().current, final);
  assert.equal(final.counters.requests, 4);
});

test('same-generation health/coalesce states do not reset observed plans or metrics', () => {
  const store = createRefreshDiagnosticsStore();
  store.observeState(state(4));
  store.observe(report(4, 'resources_settled', 'running', 8));
  const before = store.snapshot().current;
  for (let i = 0; i < 10; i++) store.observeState({ ...state(4), sourceRegistry: { token: 'PRIVATE' } });
  assert.strictEqual(store.snapshot().current, before);
  store.observeState(state(null, 4, null, 4));
  assert.equal(store.snapshot().current.counters.requests, 8);
  assert.equal(store.snapshot().current.status, 'completed');
});

test('inactive old generation snapshot does not cancel a newer current generation', () => {
  const store = createRefreshDiagnosticsStore();
  store.observeState(state(11));
  store.observeState(state(null, 10, null, 10));
  assert.equal(store.snapshot().current.generation, 11);
  assert.equal(store.snapshot().current.status, 'running');
  assert.equal(store.snapshot().lastSettled.generation, 10);
});

test('store retains at most three generation records, not an expanding history', () => {
  const store = createRefreshDiagnosticsStore();
  for (let generation = 1; generation <= 120; generation++) {
    store.observeState(state(generation));
    if (generation % 3 === 0) store.observe(report(generation, 'final', 'completed', generation));
    const snapshot = store.snapshot();
    assert.deepEqual(Object.keys(snapshot), ['current', 'lastSettled', 'lastCancelled']);
    assert.ok(new Set(Object.values(snapshot).filter(Boolean)).size <= 3);
    Object.values(snapshot).filter(Boolean).forEach(record => assert.deepEqual(Object.keys(record), RECORD_KEYS));
  }
  assert.equal(store.snapshot().current.generation, 120);
  assert.equal(store.snapshot().lastSettled.generation, 120);
  assert.equal(store.snapshot().lastCancelled.generation, 119);
  store.observe(report(1, 'final', 'cancelled', 999));
  assert.equal(store.snapshot().lastCancelled.generation, 119);
});

test('sanitizes fixed counter/provider/plan/skip fields and deep copies and freezes payload', () => {
  const store = createRefreshDiagnosticsStore();
  const input = report(3, 'resources_settled', 'running', 2);
  Object.assign(input, { code: '005844', name: 'PRIVATE', amount: 12345, token: 'PRIVATE', url: 'https://PRIVATE' });
  input.counters.name = 'PRIVATE';
  input.counters.providers.secret = 'PRIVATE';
  input.plan[0].code = 'PRIVATE';
  input.skipReasons.url = 'PRIVATE';
  store.observe(input);
  const snapshot = store.snapshot();
  const current = snapshot.current;
  assert.deepEqual(Object.keys(current), RECORD_KEYS);
  assert.deepEqual(Object.keys(current.counters), [...COUNTERS, 'providers']);
  assert.deepEqual(Object.keys(current.counters.providers), PROVIDERS);
  assert.equal(current.counters.providers.gold, 2);
  assert.equal(current.counters.providers['sinan-estimate-proxy'], null);
  assert.deepEqual(Object.keys(current.plan[0]), ['kind', 'cache', 'fetch', 'skip']);
  assert.deepEqual(Object.keys(current.skipReasons), ['market_ineligible', 'no_active_holdings']);
  assert.equal(JSON.stringify(snapshot).includes('PRIVATE'), false);
  assertFrozen(snapshot);
  input.counters.requests = 999;
  input.plan[0].fetch = 999;
  input.skipReasons.market_ineligible = 999;
  assert.equal(current.counters.requests, 2);
  assert.equal(current.plan[0].fetch, 1);
  assert.equal(current.skipReasons.market_ineligible, 0);
  assert.throws(() => { current.counters.requests = 20; }, TypeError);
});

test('invalid/missing measurements remain null, while real zero is preserved', () => {
  const store = createRefreshDiagnosticsStore();
  const input = report(2);
  input.counters = { generation: 2, planned: 0, staged: -1, cacheHits: '0', deduped: 1.5,
    requests: Infinity, abortedRequests: NaN, failedRequests: Number.MAX_SAFE_INTEGER + 1,
    providers: { gold: 0, 'model-config': '3', 'sinan-estimate-proxy': -1 } };
  input.plan = [{ kind: 'nav', cache: 0, fetch: '1', skip: -1 }];
  input.skipReasons = { market_ineligible: 0, no_active_holdings: '0' };
  store.observe(input);
  const { counters, plan, skipReasons } = store.snapshot().current;
  assert.equal(counters.planned, 0);
  for (const key of COUNTERS.filter(key => !['generation', 'planned'].includes(key))) assert.equal(counters[key], null);
  assert.equal(counters.providers.gold, 0);
  assert.equal(counters.providers['model-config'], null);
  assert.deepEqual(plan, [{ kind: 'nav', cache: 0, fetch: null, skip: null }]);
  assert.deepEqual(skipReasons, { market_ineligible: 0, no_active_holdings: null });
  assert.equal(store.snapshot().current.observed, true);
  assert.equal(store.snapshot().current.status, 'running');
});

test('rejects mismatched counter generation and never coerces inputs', () => {
  const store = createRefreshDiagnosticsStore();
  let coercions = 0;
  const malicious = { valueOf() { coercions++; throw new Error('PRIVATE'); }, toString() { coercions++; return 'PRIVATE'; } };
  const input = report(2);
  input.counters.generation = 1;
  input.skipReasons.market_ineligible = malicious;
  store.observe(input);
  assert.equal(store.snapshot().current.counters, null);
  assert.equal(store.snapshot().current.skipReasons.market_ineligible, null);
  for (const generation of [0, -1, '2', null, 1.5, Infinity, NaN, Number.MAX_SAFE_INTEGER + 1, malicious]) {
    store.observe({ ...report(9), generation });
    assert.equal(store.snapshot().current.generation, 2);
  }
  assert.equal(coercions, 0);
});

test('invalid or absent final counters do not promote an earlier started zero sample', () => {
  for (const counters of [null, undefined, { generation: 99, requests: 0 }]) {
    const store = createRefreshDiagnosticsStore();
    store.observe(report(1));
    store.observe({ ...report(1, 'final', 'completed'), counters });
    assert.equal(store.snapshot().current.status, 'completed');
    assert.equal(store.snapshot().current.observed, true);
    assert.equal(store.snapshot().current.counters, null);
  }
});

test('only bounded allowlisted kinds are kept, without duplicate or fabricated rows', () => {
  const store = createRefreshDiagnosticsStore();
  const input = report(1);
  input.plan = [
    { kind: 'gold', cache: 0, fetch: 2, skip: 0 },
    { kind: 'PRIVATE', cache: 999, fetch: 999, skip: 999 },
    { kind: 'nav', cache: 1, fetch: 0, skip: 0 },
    { kind: 'gold', cache: 999, fetch: 999, skip: 999 },
  ];
  store.observe(input);
  assert.deepEqual(store.snapshot().current.plan, [
    { kind: 'nav', cache: 1, fetch: 0, skip: 0 }, { kind: 'gold', cache: 0, fetch: 2, skip: 0 },
  ]);
  store.observe({ ...report(2), plan: Array(10000).fill({ kind: 'gold', fetch: 999 }) });
  assert.equal(store.snapshot().current.plan, null);
});

test('getters are not run and inherited properties or hostile proxies cannot leak payload', () => {
  const store = createRefreshDiagnosticsStore();
  let getterCalls = 0;
  const secretGetter = () => { getterCalls++; throw new Error('PRIVATE'); };
  const input = report(2);
  Object.defineProperty(input, 'url', { get: secretGetter });
  Object.defineProperty(input.counters, 'requests', { get: secretGetter });
  Object.defineProperty(input.counters.providers, 'gold', { get: secretGetter });
  Object.defineProperty(input.plan[0], 'fetch', { get: secretGetter });
  Object.defineProperty(input.skipReasons, 'market_ineligible', { get: secretGetter });
  store.observe(input);
  assert.equal(getterCalls, 0);
  assert.equal(store.snapshot().current.counters.requests, null);
  const proxy = new Proxy({}, { getOwnPropertyDescriptor() { throw new Error('PRIVATE'); },
    ownKeys() { throw new Error('PRIVATE'); }, get() { throw new Error('PRIVATE'); } });
  const revoked = Proxy.revocable({}, {}); revoked.revoke();
  for (const value of [proxy, revoked.proxy, null, undefined, [], 'PRIVATE']) {
    assert.doesNotThrow(() => store.observe(value));
    assert.doesNotThrow(() => store.observeState(value));
  }
  store.observe(Object.create(report(100)));
  assert.equal(store.snapshot().current.generation, 2);
  assert.equal(JSON.stringify(store.snapshot()).includes('PRIVATE'), false);
});

test('invalid headers and malformed lifecycle events cannot settle or replace records', () => {
  const store = createRefreshDiagnosticsStore();
  store.observe(report(2));
  const before = store.snapshot().current;
  for (const value of [
    { ...report(3), phase: 'PRIVATE' }, { ...report(3), status: 'PRIVATE' },
    { ...report(3), phase: 'final', status: 'running' },
    {}, { active: {} }, { active: null, currentGeneration: '2' },
  ]) {
    store.observe(value); store.observeState(value);
  }
  assert.strictEqual(store.snapshot().current, before);
});

test('production synchronous onStateChange preserves coalesced promise identity and final counts', async () => {
  const store = createRefreshDiagnosticsStore();
  const wait = deferred();
  const coordinator = new RefreshCoordinator({
    execute: async context => {
      store.observe(report(context.generation, 'started', 'running', 0));
      await wait.promise;
      store.observe(report(context.generation, 'final', 'completed', 2));
    },
    onStateChange: snapshot => store.observeState(snapshot),
  });
  const first = coordinator.request({ trigger: 'tick', coalesce: true });
  const coalesced = coordinator.request({ trigger: 'tick', coalesce: true });
  assert.strictEqual(first, coalesced);
  await Promise.resolve();
  assert.equal(store.snapshot().current.observed, true);
  wait.resolve();
  assert.equal((await first).status, 'completed');
  assert.equal(store.snapshot().current.counters.requests, 2);
  assert.equal(store.snapshot().current.status, 'completed');
  assert.strictEqual(store.snapshot().lastSettled, store.snapshot().current);
});

test('production superseded-before-execute and stop remain unobserved, not PASS with zero counts', async () => {
  const store = createRefreshDiagnosticsStore();
  let calls = 0;
  const coordinator = new RefreshCoordinator({ execute: () => { calls++; },
    onStateChange: snapshot => store.observeState(snapshot) });
  const first = coordinator.request();
  const second = coordinator.request();
  coordinator.stop();
  await Promise.all([first, second]);
  assert.equal(calls, 0);
  assert.equal(store.snapshot().current.generation, 2);
  assert.equal(store.snapshot().current.status, 'cancelled');
  assert.equal(store.snapshot().lastCancelled.generation, 2);
  assert.equal(store.snapshot().current.observed, false);
  assert.equal(store.snapshot().current.counters, null);
  // active:null/currentGeneration:null has no stop sequence. This API consumes
  // the coordinator's synchronous callbacks, not an asynchronously replayed bus.
});

test('production failure before scope start and stop-after-start have different observation evidence', async () => {
  const store = createRefreshDiagnosticsStore();
  const failing = new RefreshCoordinator({ execute: () => { throw new Error('PRIVATE'); },
    onStateChange: snapshot => store.observeState(snapshot) });
  await failing.request();
  assert.equal(store.snapshot().current.status, 'failed');
  assert.equal(store.snapshot().current.observed, false);
  assert.equal(store.snapshot().current.counters, null);
  const secondStore = createRefreshDiagnosticsStore();
  const wait = deferred();
  const stopped = new RefreshCoordinator({ execute: async context => {
    secondStore.observe(report(context.generation));
    await wait.promise;
    secondStore.observe(report(context.generation, 'resources_settled', 'cancelled', 1));
  }, onStateChange: snapshot => secondStore.observeState(snapshot) });
  const task = stopped.request();
  await Promise.resolve();
  stopped.stop();
  wait.resolve();
  await task;
  assert.equal(secondStore.snapshot().current.status, 'cancelled');
  assert.equal(secondStore.snapshot().current.observed, true);
  assert.equal(secondStore.snapshot().current.counters.requests, 1);
  assert.equal(JSON.stringify(store.snapshot()).includes('PRIVATE'), false);
});
