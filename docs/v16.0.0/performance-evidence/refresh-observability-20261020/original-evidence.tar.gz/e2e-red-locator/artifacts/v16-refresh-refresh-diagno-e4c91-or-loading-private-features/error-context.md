# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v16-refresh.spec.js >> refresh diagnostics reconcile real cold and warm requests without renewing data or loading private features
- Location: e2e\v16-refresh.spec.js:432:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#nav-holdings')

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - generic [ref=e5]: 蜉蝣基金
    - generic [ref=e6]:
      - generic [ref=e7]: 15.0.2
      - emphasis [ref=e8]: 下午盘
  - generic: 下拉刷新
  - generic [ref=e10]:
    - generic [ref=e11]:
      - generic [ref=e12]: 黄金9999
      - generic [ref=e13]: "900"
      - generic [ref=e14]: +1.12%
    - generic [ref=e15]:
      - generic [ref=e16]: 上证
      - generic [ref=e17]: "10"
      - generic [ref=e18]: +1.00%
    - generic [ref=e19]:
      - generic [ref=e20]: 沪深300
      - generic [ref=e21]: "10"
      - generic [ref=e22]: +1.00%
    - generic [ref=e23]:
      - generic [ref=e24]:
        - text: 纳指100
        - generic [ref=e25]: 旧
      - generic [ref=e26]: "10"
      - generic [ref=e27]: +1.00%
    - generic [ref=e28]:
      - generic [ref=e29]:
        - text: 标普500
        - generic [ref=e30]: 旧
      - generic [ref=e31]: "10"
      - generic [ref=e32]: +1.00%
  - generic [ref=e33]: 最新可信数据 14:30 · 今日估算 1/1
  - generic [ref=e34]:
    - button "可信等级优先 · 涨跌 ↓" [ref=e36] [cursor=pointer]
    - generic [ref=e37]:
      - generic [ref=e38]: 名称 / 代码
      - generic [ref=e39]: 当前显示涨跌
      - generic [ref=e40]: 显示值 / 基准净值
    - article [ref=e42]:
      - button "合成境内混合基金A 005844 · 最新正式净值 2026-09-28 +0.83% 盘中估值 14:30 实时 1.21001.2000" [ref=e43] [cursor=pointer]:
        - generic [ref=e44]:
          - generic [ref=e45]:
            - generic [ref=e46]: 合成境内混合基金A
            - generic [ref=e47]: 005844 · 最新正式净值 2026-09-28
          - generic [ref=e48]:
            - generic [ref=e49]: +0.83%
            - generic [ref=e50]:
              - generic [ref=e51]: 盘中估值
              - generic [ref=e52]: ·
              - generic [ref=e53]: 14:30
            - generic [ref=e54]: 实时
          - generic [ref=e56]: 1.21001.2000
  - generic [ref=e57]:
    - button "📈 行情" [ref=e58] [cursor=pointer]:
      - generic [ref=e59]: 📈
      - text: 行情
    - button "⚙️ 持仓" [ref=e60] [cursor=pointer]:
      - generic [ref=e61]: ⚙️
      - text: 持仓
```

# Test source

```ts
  355 | test('warm details keep failed prior quotes visibly historical with their real clock, not today or zero', async ({ context, page }) => {
  356 |   const harness = await installHarness(context);
  357 |   await page.goto('/');
  358 |   await harness.settle(page);
  359 |   const toggle = page.locator(`#fund-toggle-${HOLDINGS[0].code}`);
  360 |   await toggle.click();
  361 |   await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  362 |   await harness.settle(page);
  363 |   const clocks = page.locator('.stock-quote-time');
  364 |   await expect(clocks).toHaveCount(10);
  365 |   await expect(clocks.first()).toHaveText('最近行情 · 2026-09-29 14:30:00');
  366 |   await expect(page.locator('.holdings-row').first()).toContainText('+1.00%');
  367 |   await toggle.click();
  368 |   await expect(toggle).toHaveAttribute('aria-expanded', 'false');
  369 |   const cache = await page.evaluate(key => localStorage.getItem(key), FUND_CACHE);
  370 |   harness.state.failAll = true;
  371 |   await page.evaluate(() => { globalThis.__refreshTestClockAdvance = 24 * 60 * 60_000; });
  372 |   await harness.phase(page, 'oldDetail');
  373 |   await toggle.click();
  374 |   await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  375 |   await harness.settle(page);
  376 |   await expect(clocks).toHaveCount(10);
  377 |   await expect(clocks.first()).toHaveText('旧行情 · 2026-09-29 14:30:00');
  378 |   await expect(page.locator('.holdings-row').first()).toContainText('+1.00%');
  379 |   expect(harness.requests('oldDetail', 'eastmoneySecurities')).toHaveLength(1);
  380 |   expect(harness.requests('oldDetail', 'tencent')).toHaveLength(1);
  381 |   expect(harness.requests('oldDetail', 'holdings')).toHaveLength(0);
  382 |   expect(harness.requests('oldDetail', 'nav')).toHaveLength(0);
  383 |   expect(await harness.writes(page, 'oldDetail')).toEqual([]);
  384 |   expect(await page.evaluate(key => localStorage.getItem(key), FUND_CACHE)).toBe(cache);
  385 |   expect(harness.state.gistWrites).toEqual([]);
  386 | });
  387 | 
  388 | for (const [name, change, value, caption] of [
  389 |   ['zero', 0, '+0.00%', '最近行情 · 2026-09-29 14:30:00'],
  390 |   ['missing', null, '--', '行情暂不可用'],
  391 | ]) test(`detail renderer distinguishes a genuine ${name} change without borrowing adjacent quotes`, async ({ context, page }) => {
  392 |   const harness = await installHarness(context, { securityChange: change,
  393 |     omitTencentCodes: Array.from({ length: 10 }, (_, i) => `sz${String(i + 1).padStart(6, '0')}`) });
  394 |   await page.goto('/');
  395 |   await harness.settle(page);
  396 |   await page.locator(`#fund-toggle-${HOLDINGS[0].code}`).click();
  397 |   await harness.settle(page);
  398 |   await expect(page.locator('.holdings-row')).toHaveCount(10);
  399 |   await expect(page.locator('.holdings-row').first().locator(':scope > span').nth(2)).toHaveText(value);
  400 |   await expect(page.locator('.stock-quote-time').first()).toHaveText(caption);
  401 |   expect(harness.state.gistWrites).toEqual([]);
  402 | });
  403 | 
  404 | test('a non-cooperative late response cannot overwrite the current generation UI or cache', async ({ context, page }) => {
  405 |   const harness = await installHarness(context, { holdFirstEstimate: true });
  406 |   await page.goto('/');
  407 |   await harness.ready(page);
  408 |   await expect.poll(() => typeof harness.state.heldEstimate).toBe('function');
  409 |   try {
  410 |     harness.state.estimateValue = 1.23;
  411 |     await harness.phase(page, 'current');
  412 |     // Online intentionally supersedes an active generation; pull-to-refresh is
  413 |     // correctly disabled while a refresh is active and cannot test this path.
  414 |     await page.evaluate(() => window.dispatchEvent(new Event('online')));
  415 |     await expect.poll(() => harness.state.estimateRequests).toBe(2);
  416 |     await expect(navValue(page)).toHaveText('1.2300');
  417 |     await harness.settle(page, { allowHeld: true });
  418 |     await harness.phase(page, 'late');
  419 |     await harness.state.heldEstimate();
  420 |     harness.state.heldEstimate = null;
  421 |     await harness.settle(page);
  422 |     await expect(navValue(page)).toHaveText('1.2300');
  423 |     expect(await harness.writes(page, 'late'), 'superseded results cannot persist after current generation commits').toEqual([]);
  424 |     const cache = await page.evaluate(key => JSON.parse(localStorage.getItem(key)), FUND_CACHE);
  425 |     expect(cache.data.find(row => row.code === HOLDINGS[0].code).quote.value).toBe(1.23);
  426 |     expect(harness.state.gistWrites).toEqual([]);
  427 |   } finally {
  428 |     if (harness.state.heldEstimate) await harness.state.heldEstimate();
  429 |   }
  430 | });
  431 | 
  432 | test('refresh diagnostics reconcile real cold and warm requests without renewing data or loading private features', async ({ context, page }, testInfo) => {
  433 |   const harness = await installHarness(context);
  434 |   const dataCategories = ['estimates', 'holdings', 'nav', 'eastmoneySecurities', 'gold', 'tencent'];
  435 |   const requestCounts = phase => Object.fromEntries(dataCategories.map(category =>
  436 |     [category, harness.requests(phase, category).length]));
  437 |   const requestTotal = phase => Object.values(requestCounts(phase)).reduce((sum, value) => sum + value, 0);
  438 |   const diagnosticValue = label => page.locator('#diagnostics-content .diagnostics-row')
  439 |     .filter({ has: page.getByText(label, { exact: true }) }).locator('strong');
  440 |   const counter = async label => {
  441 |     const text = await diagnosticValue('刷新请求').innerText();
  442 |     const match = new RegExp(`${label}\\s*[:：=]?\\s*(\\d+)`).exec(text);
  443 |     expect(match, `structured refresh request summary must expose ${label}`).not.toBeNull();
  444 |     return Number(match[1]);
  445 |   };
  446 |   const readCache = () => page.evaluate(key => {
  447 |     const raw = localStorage.getItem(key);
  448 |     const cache = raw && JSON.parse(raw);
  449 |     return { raw, holdingsHash: cache?.holdingsHash,
  450 |       stable: Object.fromEntries(Object.entries(cache?.refreshResources || {})
  451 |         .filter(([resource]) => /^(?:nav|holdings|meta):/.test(resource))) };
  452 |   }, FUND_CACHE);
  453 |   const openDiagnostics = async phase => {
  454 |     await harness.phase(page, phase);
> 455 |     await page.locator('#nav-holdings').click();
      |                                         ^ Error: locator.click: Test timeout of 30000ms exceeded.
  456 |     await page.locator('#diagnostics-center > summary').click();
  457 |     await expect(page.locator('#diagnostics-center')).toHaveAttribute('open', '');
  458 |     await expect(diagnosticValue('刷新诊断'), 'completed refresh must be observable through the real diagnostics center').toHaveCount(1);
  459 |     await expect(diagnosticValue('刷新诊断')).toContainText(/completed|已完成/);
  460 |     await expect(diagnosticValue('刷新诊断')).toContainText(/observed\s*[:：=]?\s*true/i);
  461 |     await harness.settle(page);
  462 |   };
  463 |   const assertPrivateFeaturesAbsent = () => {
  464 |     expect(harness.state.requests.filter(row => row.category === 'gist'), 'diagnostics must not initiate even read-only Gist requests').toEqual([]);
  465 |     expect(harness.state.requests.filter(row => /(?:\/assets\/ocr\/|ocr-import\.html|paddle|tesseract|\.wasm(?:$|\?))/i.test(row.url)),
  466 |       'opening or refreshing diagnostics must not load OCR assets or an OCR document').toEqual([]);
  467 |     expect(harness.state.gistWrites).toEqual([]);
  468 |   };
  469 | 
  470 |   await page.goto('/');
  471 |   await harness.settle(page);
  472 |   await expect(navValue(page)).not.toHaveText('--');
  473 |   const cold = await readCache();
  474 |   expect(cold.raw).not.toBeNull();
  475 |   expect(typeof cold.holdingsHash).toBe('string');
  476 |   expect(Object.keys(cold.stable)).toHaveLength(3);
  477 |   expect(harness.requests('cold', 'holdings')).toHaveLength(1);
  478 |   expect(harness.requests('cold', 'nav')).toHaveLength(1);
  479 |   const coldRequests = requestCounts('cold');
  480 |   await testInfo.attach('cold-refresh-network-categories', {
  481 |     contentType: 'application/json', body: JSON.stringify({ scope: 'real app and opaque Bridge; synthetic network only', counts: coldRequests }),
  482 |   });
  483 |   await openDiagnostics('coldDiagnostics');
  484 |   expect(await counter('实际请求')).toBe(requestTotal('cold'));
  485 |   expect(await counter('已进入请求中止')).toBe(0);
  486 |   expect(await counter('资源取消拒绝')).toBe(0);
  487 |   expect(await counter('写尝试')).toBe(1);
  488 |   expect(await counter('缓存写入')).toBe(1);
  489 |   await expect(diagnosticValue('刷新计划')).toContainText(/estimates/);
  490 |   await expect(diagnosticValue('刷新计划')).toContainText(/fetch/);
  491 |   await expect(diagnosticValue('请求来源')).toContainText('sinan-estimate-proxy');
  492 |   await expect(diagnosticValue('最终报价')).toContainText(/基金详情.*数据说明/);
  493 |   expect(await readCache(), 'reading diagnostics must preserve all cache acquisition bytes and holdings identity').toEqual(cold);
  494 |   expect(requestTotal('coldDiagnostics')).toBe(0);
  495 |   expect(await harness.writes(page, 'coldDiagnostics')).toEqual([]);
  496 |   assertPrivateFeaturesAbsent();
  497 | 
  498 |   await page.locator('#diagnostics-center > summary').click();
  499 |   await page.locator('#nav-market').click();
  500 |   await page.evaluate(() => window.scrollTo(0, 0));
  501 |   await harness.refresh(page);
  502 |   expect(harness.requests('warm', 'holdings')).toHaveLength(0);
  503 |   expect(harness.requests('warm', 'nav')).toHaveLength(0);
  504 |   const warm = await readCache();
  505 |   expect(warm.holdingsHash).toBe(cold.holdingsHash);
  506 |   expect(warm.stable, 'warm refresh cannot renew NAV, disclosure or metadata acquisition envelopes').toEqual(cold.stable);
  507 |   await openDiagnostics('warmDiagnostics');
  508 |   expect(await counter('实际请求')).toBe(requestTotal('warm'));
  509 |   expect(await counter('缓存命中')).toBeGreaterThan(0);
  510 |   expect(await counter('已进入请求中止')).toBe(0);
  511 |   expect(await counter('资源取消拒绝')).toBe(0);
  512 |   expect(await counter('写尝试')).toBe(1);
  513 |   expect(await counter('缓存写入')).toBe(1);
  514 |   await expect(diagnosticValue('刷新计划')).toContainText(/cache/);
  515 |   await expect(diagnosticValue('跳过原因')).not.toBeEmpty();
  516 |   const summary = (await Promise.all(['刷新诊断', '刷新计划', '刷新请求', '跳过原因', '请求来源', '最终报价']
  517 |     .map(label => diagnosticValue(label).innerText()))).join('\n');
  518 |   expect(summary).not.toMatch(/005844|合成境内混合基金A|ghp_|Authorization|https?:|source_quote|baseNav|shares|cost/);
  519 |   expect(await readCache(), 'opening warm diagnostics must not change aggregate dates, hash or stored data').toEqual(warm);
  520 |   expect(requestTotal('warmDiagnostics')).toBe(0);
  521 |   expect(await harness.writes(page, 'warmDiagnostics')).toEqual([]);
  522 |   assertPrivateFeaturesAbsent();
  523 |   await testInfo.attach('refresh-diagnostics-cold-warm', {
  524 |     contentType: 'application/json', body: JSON.stringify({ scope: 'synthetic completed generations only; no cancellation or production acceptance',
  525 |       cold: coldRequests, warm: requestCounts('warm'), summary }),
  526 |   });
  527 | });
  528 | 
```