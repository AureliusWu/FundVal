import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const output = fileURLToPath(new URL('.', import.meta.url));
const root = 'D:/AI项目/FundVal';
const [label, ...tests] = process.argv.slice(2);
if (!/^[a-z0-9-]+$/.test(label || '') || !tests.length || tests.some(path => ![
  'test/service-worker-page-update-v16.test.js', 'test/service-worker.test.js',
].includes(path))) throw new Error('Only named targeted tests are permitted');
const files = ['js/runtime/pwa-update-controller.js', 'test/service-worker-page-update-v16.test.js',
  'test/service-worker.test.js', 'test/fixtures/pwa-update-v15-reference.js', 'js/app.js', 'sw.js'];
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const snapshot = () => files.map(path => { const bytes = readFileSync(resolve(root, path));
  return { path, bytes: bytes.length, sha256: digest(bytes) }; });
const before = snapshot();
const saved = join(output, `${label}.sources`);
mkdirSync(saved);
for (const path of files) writeFileSync(join(saved, path.replaceAll('/', '__')), readFileSync(resolve(root, path)), { flag: 'wx' });
const transcripts = join(output, `${label}.transcripts`);
mkdirSync(transcripts);
const startedAt = new Date().toISOString();
const result = spawnSync(process.execPath, ['--test', ...tests], { cwd: root,
  env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1', FUNDVAL_PWA_TRANSCRIPT_DIR: transcripts }, maxBuffer: 32 * 1024 * 1024, encoding: null });
const finishedAt = new Date().toISOString();
const stdout = result.stdout || Buffer.alloc(0), stderr = result.stderr || Buffer.alloc(0);
writeFileSync(join(output, `${label}.stdout.txt`), stdout, { flag: 'wx' });
writeFileSync(join(output, `${label}.stderr.txt`), stderr, { flag: 'wx' });
const receipt = { startedAt, finishedAt, command: process.execPath, args: ['--test', ...tests],
  nativeExit: result.status, signal: result.signal, error: result.error ? String(result.error) : null,
  stdout: { bytes: stdout.length, sha256: digest(stdout) }, stderr: { bytes: stderr.length, sha256: digest(stderr) },
  before, after: snapshot() };
writeFileSync(join(output, `${label}.receipt.json`), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(stdout); process.stderr.write(stderr);
process.stdout.write(JSON.stringify({ label, nativeExit: result.status, signal: result.signal, error: receipt.error }) + '\n');
process.exitCode = result.status ?? 1;
