# PWA extraction takeover — targeted proof only

2026-10-23. Original Temp and the prior completed audit reports remain immutable.

Own only js/runtime/pwa-update-controller.js and its necessary tests/fixture. Parent owns App, build, SW source inventory, and final integration tests. No full tests/check/build/E2E/performance/service/real network/Git writes here.

Read original PROTOCOL, frozen App/page test and all four baseline/controller stdout/stderr files. Both summaries show18pass/0fail; controller-01 covers18 old policy cases using the actual factory AST. It does not contain the planned transcript/structural/boundary additions. No original standalone machine native-exit receipt exists in that directory; do not fabricate one.

Frozen App SHA25617826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359. Six old policy functions extracted in declared source order are4756B/SHA1117cf166b68115f0d8f84fdbf92e6bd9dce35c52b9f8f8a0085451160ee2033; registration IfStatement1998B/SHAfaeab3ddbb03ba11413bf055c548d3552f35cf87647ff47dfb27da49cb2d75f6. Existing repository fixture must remain bound to those bytes, not the migrated App.

Preserve original18 assertions; compare independently frozen old policy to actual current factory AST with identical synthetic IO/DOM/clock/drain callbacks. Instrumentation changes only return test view, not policy/listener statements. Add complete checkpoint state/DOM/IO/listener transcripts and inert/unsupported/registration/drain/worker-transition boundary scenarios. Structural comparison permits only explicit state callback, timer ownership and stopAndDrain seams plus moving registration into inert start. No production global or test hook.

Retain each targeted run as unique stdout/stderr/native receipt and file identities, including failures. Tests must run from clean checkout without personal Temp. Parent later owns full integration, runtime/browser proof and final same-candidate byte/latency/CI gates; no old performance PASS inheritance.
