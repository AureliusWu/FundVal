import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, existsSync, mkdirSync, lstatSync, realpathSync, renameSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createServer } from 'node:net';
import { sha, inv, json, save } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';

const root = 'D:/AI项目/FundVal', here = import.meta.dirname;
const phase = process.argv[2], epoch = '1792046773';
const npm = 'C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js';
const baseline = json('C:/Users/84046/AppData/Local/Temp/FundVal-budget-policy-20261023-parent/BEFORE.json').expected;
const previous = json('C:/Users/84046/AppData/Local/Temp/FundVal-budget-policy-20261023-parent/FINAL_SOURCE_V2.json');
const exclusions = new Set(['.git','node_modules','site','Temp','.claude','docs']);
const freezePath = resolve(here, 'QA_SOURCE_V2.json');
const out = resolve(here, 'qa-v2', phase);
assert.equal(process.version, 'v24.14.0');
assert.equal(json('C:/Program Files/nodejs/node_modules/npm/package.json').version, '11.9.0');
assert.equal(existsSync(out), false, 'Each actual phase is preserved, never overwritten');
mkdirSync(out, { recursive: true });

async function native(label, command, args, extra = {}, timeoutMs = 300000) {
  const env = { ...process.env, SOURCE_DATE_EPOCH: epoch, ...extra };
  delete env.NODE_OPTIONS; delete env.NODE_V8_COVERAGE;
  const startedAt = new Date().toISOString();
  const child = spawn(command, args, { cwd: root, env, windowsHide: true, stdio: ['ignore','pipe','pipe'] });
  const stdout = [], stderr = []; let error = null, timedOut = false, termination = null, exitObserved = false;
  child.stdout.on('data', bytes => stdout.push(bytes)); child.stderr.on('data', bytes => stderr.push(bytes));
  child.on('error', value => { error = value.message; }); child.once('exit', () => { exitObserved = true; });
  const timer = setTimeout(() => {
    timedOut = true;
    if (child.pid && !exitObserved && child.exitCode === null && child.signalCode === null) {
      const stopped = spawnSync('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, encoding: null, timeout: 15000 });
      termination = { nativeExit: stopped.status, error: stopped.error?.message ?? null };
    }
  }, timeoutMs);
  const end = await new Promise(done => child.once('close', (nativeExit, signal) => done({ nativeExit, signal })));
  clearTimeout(timer);
  const outBytes = Buffer.concat(stdout), errBytes = Buffer.concat(stderr);
  save(resolve(out, label + '.stdout'), outBytes); save(resolve(out, label + '.stderr'), errBytes);
  const receipt = { label, command, args, cwd: root, envExtra: { SOURCE_DATE_EPOCH: epoch, ...extra }, startedAt,
    finishedAt: new Date().toISOString(), ...end, error, timedOut, termination,
    stdout: { bytes: outBytes.length, sha256: sha(outBytes) }, stderr: { bytes: errBytes.length, sha256: sha(errBytes) } };
  save(resolve(out, label + '.receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  process.stdout.write(JSON.stringify(receipt) + '\n');
  assert.equal(error, null); assert.equal(end.signal, null); assert.equal(timedOut, false); assert.equal(end.nativeExit, 0);
  return outBytes;
}
async function sourceState(label, frozen) {
  const noDocs = inv(root, exclusions);
  if (frozen) assert.deepEqual(noDocs, frozen.noDocs, 'Frozen physical source unchanged');
  const fixed = previous.full.find(row => row.path === 'docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');
  assert.equal(sha(readFileSync(resolve(root, fixed.path))), fixed.sha256);
  const full = [...noDocs, fixed].sort((a,b) => a.path.localeCompare(b.path));
  for (const row of baseline.installed) {
    const bytes = readFileSync(resolve(root, 'node_modules', row.path));
    assert.equal(bytes.length, row.bytes); assert.equal(sha(bytes), row.sha256);
  }
  const head = (await native(label + '-head', 'git', ['rev-parse','HEAD'])).toString().trim();
  const branch = (await native(label + '-branch', 'git', ['branch','--show-current'])).toString().trim();
  const indexSha256 = sha(await native(label + '-index', 'git', ['diff','--cached','--binary']));
  assert.equal(head, baseline.head); assert.equal(branch, baseline.branch); assert.equal(indexSha256, baseline.indexSha256);
  return { noDocs, full, sourceRowsSha256: sha(JSON.stringify(full)), head, branch, indexSha256, installed: baseline.installed };
}
async function freePort(port) {
  await new Promise((ok, fail) => { const server = createServer(); server.once('error', fail);
    server.listen(port, '127.0.0.1', () => server.close(error => error ? fail(error) : ok())); });
}
function preserveE2E() {
  const from = resolve(root, 'site/.playwright-results');
  if (!existsSync(from)) return null;
  assert.equal(dirname(from), resolve(root, 'site')); assert.equal(lstatSync(from).isSymbolicLink(), false);
  assert.equal(realpathSync(from).toLowerCase(), from.toLowerCase());
  const target = resolve(root, 'Temp/controller-extraction-e2e-20261025-v2-' + phase);
  assert.equal(dirname(target), resolve(root, 'Temp')); assert.equal(lstatSync(dirname(target)).isSymbolicLink(), false);
  assert.equal(existsSync(target), false);
  const rows = inv(from); renameSync(from, target); assert.deepEqual(inv(target), rows);
  const result = { from, target, rows, rowsSha256: sha(JSON.stringify(rows)) };
  save(resolve(out, 'E2E_ARTIFACTS.json'), JSON.stringify(result, null, 2) + '\n'); return result;
}

assert.ok(['freeze','test','check','build-01','e2e','build-02','artifact','audit'].includes(phase));
if (phase === 'freeze') {
  assert.equal(existsSync(freezePath), false);
  const state = await sourceState('freeze');
  const old = new Map(previous.noDocs.map(row => [row.path, row]));
  const added = state.noDocs.filter(row => !old.has(row.path)).map(row => row.path);
  const modified = state.noDocs.filter(row => old.has(row.path) && row.sha256 !== old.get(row.path).sha256).map(row => row.path);
  const removed = previous.noDocs.filter(row => !state.noDocs.some(current => current.path === row.path));
  assert.deepEqual(removed, []);
  save(freezePath, JSON.stringify({ ...state, added, modified, toolSha256: sha(readFileSync(import.meta.filename)), epoch }, null, 2) + '\n');
  process.stdout.write(JSON.stringify({ status: 'FROZEN', rows: state.full.length, added, modified, sourceRowsSha256: state.sourceRowsSha256 }) + '\n');
} else {
  const frozen = json(freezePath); assert.equal(sha(readFileSync(import.meta.filename)), frozen.toolSha256);
  let before = null, after = null, result = null, failure = null, postflightError = null;
  try {
    before = await sourceState('before', frozen);
    if (phase.startsWith('build')) {
      preserveE2E();
      const site = resolve(root, 'site'); assert.equal(dirname(site), resolve(root));
      assert.equal(lstatSync(site).isSymbolicLink(), false); assert.equal(realpathSync(site).toLowerCase(), site.toLowerCase());
      await native(phase, process.execPath, [npm,'run','build']);
      const rows = inv(site); save(resolve(out, 'site.inventory.json'), JSON.stringify(rows, null, 2) + '\n');
      if (phase === 'build-02') assert.deepEqual(rows, json(resolve(here,'qa-v2/build-01/site.inventory.json')), 'Entire deterministic site');
      result = { count: rows.length, bytes: rows.reduce((sum,row) => sum + row.bytes, 0), sha256: sha(JSON.stringify(rows)) };
    } else if (phase === 'artifact') {
      result = {};
      for (const [name,args] of [['chunks',['--verify-app-chunks-directory','site']],['graph',['--verify-app-module-graph','site']],
        ['ocr',['--verify-ocr-directory','site/assets/ocr']],['fingerprint',['--directory','site']],['budget',['--assert-app-bundle-budget','site']]]) {
        const bytes = await native(name, process.execPath, ['scripts/release-fingerprint.mjs',...args]);
        result[name] = bytes.toString().trim();
      }
    } else {
      const extra = phase === 'e2e' ? { FUNDVAL_E2E_PORT: '12447', PLAYWRIGHT_JSON_OUTPUT_FILE: resolve(out,'report.json') } : {};
      if (phase === 'e2e') { await freePort(12447); preserveE2E(); }
      const args = phase === 'test' ? ['test'] : phase === 'check' ? ['run','check']
        : phase === 'e2e' ? ['run','test:e2e','--','--reporter=list,json'] : ['audit','--audit-level=high','--registry=https://registry.npmjs.org'];
      result = (await native(phase, process.execPath, [npm,...args], extra)).toString();
      if (phase === 'e2e') { assert.equal(existsSync(resolve(out,'report.json')), true); await freePort(12447); }
    }
  } catch (error) { failure = { message: error.message, stack: error.stack }; }
  try { after = await sourceState('after', frozen); assert.deepEqual(after, before); }
  catch (error) { postflightError = { message: error.message, stack: error.stack }; }
  const status = failure || postflightError ? 'GATE_FAILURE' : 'LOCAL_GATE_PASS';
  save(resolve(out,'RESULT.json'), JSON.stringify({ phase,status,sourceRowsSha256:frozen.sourceRowsSha256,result,failure,postflightError,release:false,m3Exit:false }, null, 2) + '\n');
  process.stdout.write(JSON.stringify({ phase,status,failure,postflightError }) + '\n');
  if (failure || postflightError) process.exitCode = 1;
}
