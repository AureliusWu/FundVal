import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { sha, save } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';
const root='D:/AI项目/FundVal',bytes=readFileSync(resolve(root,'js/app.js'));
assert.equal(sha(bytes),'17826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359');
const {parseSync}=await import(pathToFileURL(createRequire(resolve(root,'package.json')).resolve('rolldown/utils')));
const source=bytes.toString('utf8').replaceAll('\r\n','\n'),program=parseSync('app.js',source).program;
const first=program.body.find(n=>n.type==='FunctionDeclaration'&&n.id.name==='hasServiceWorkerUpdateBlocker');
const last=program.body.find(n=>n.type==='FunctionDeclaration'&&n.id.name==='applyPendingServiceWorkerUpdate');
assert.deepEqual(program.body.filter(n=>n.type==='FunctionDeclaration'&&n.start>=first.start&&n.end<=last.end).map(n=>n.id.name),[
  'hasServiceWorkerUpdateBlocker','setupServiceWorkerUpdateChannel','otherPageBlocksServiceWorkerUpdate',
  'showServiceWorkerUpdate','handleActivatedServiceWorker','applyPendingServiceWorkerUpdate']);
const registrations=program.body.filter(n=>n.type==='IfStatement'&&source.slice(n.start,n.end).includes("navigator.serviceWorker.register('sw.js')"));assert.equal(registrations.length,1);
const flags=['let pendingServiceWorker = null;','let requestedServiceWorker = null;',
  'let serviceWorkerUpdateApplying = false;','let serviceWorkerReloadPending = false;',
  'let serviceWorkerUpdateChannel = null;','let reloadingForServiceWorkerUpdate = false;'].join('\n');assert.ok(source.includes(flags));
const facade=`function hasServiceWorkerUpdateBlocker() {
  return pwaUpdateController.hasServiceWorkerUpdateBlocker();
}

function applyPendingServiceWorkerUpdate() {
  return pwaUpdateController.applyPendingServiceWorkerUpdate();
}`;
const initialize=`const pwaUpdateController = createPwaUpdateController({
  hasUnsavedPageInput,
  isSyncing: () => syncController.isSyncing(),
  isSavingHolding: () => isSavingHolding,
  clearAutoRefresh() {
    if (autoRefreshTimer) {
      clearTimeout(autoRefreshTimer);
      autoRefreshTimer = null;
    }
  },
  startAutoRefresh,
  stopAndDrain: reason => refreshCoordinator.stopAndDrain(reason),
  showToast,
  updateIntervalMs: TIMING.SW_UPDATE_MS,
});
pwaUpdateController.start();`;
const hunk=(a,b)=>'@@\n'+a.split('\n').map(l=>'-'+l).join('\n')+'\n'+(b?b.split('\n').map(l=>'+'+l).join('\n')+'\n':'');
let patch='*** Begin Patch\n*** Update File: D:/AI项目/FundVal/js/app.js\n';
patch+=hunk("import { APP_VERSION } from './version.js';","import { APP_VERSION } from './version.js';\nimport { createPwaUpdateController } from './runtime/pwa-update-controller.js';");
patch+=hunk(flags,'');patch+=hunk(source.slice(first.start,last.end),facade);
patch+=hunk(source.slice(registrations[0].start,registrations[0].end),initialize);
patch+=hunk("  if (serviceWorkerUpdateApplying) {\n    return Promise.resolve({ status: 'skipped', reason: 'service_worker_update_pending', trigger: trigger });", "  if (pwaUpdateController.isUpdateApplying()) {\n    return Promise.resolve({ status: 'skipped', reason: 'service_worker_update_pending', trigger: trigger });");
patch+='*** End Patch\n';save(resolve(import.meta.dirname,'PWA_APP.patch'),patch);
save(resolve(import.meta.dirname,'APP_INTEGRATION_BASELINE.js'),bytes);
process.stdout.write(JSON.stringify({status:'GENERATED_NOT_APPLIED',originalSha256:sha(bytes),patchSha256:sha(patch),removedFunctions:6,facade,initialize})+'\n');
