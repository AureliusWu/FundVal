import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { native, save } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';
const result=native(import.meta.dirname,'wiring-red-01',process.execPath,['--test','D:/AI项目/FundVal/test/m3-controller-wiring-v16.test.js']);
save(resolve(import.meta.dirname,'WIRING_RED_OBSERVATION.json'),JSON.stringify(result.receipt,null,2)+'\n');
assert.equal(result.receipt.nativeExit,1);process.stdout.write(result.stdout);process.stderr.write(result.stderr);
process.stdout.write(JSON.stringify({actualNativeExit:result.receipt.nativeExit,expected:'App not wired, existing groups already updated; preserve RED'})+'\n');
