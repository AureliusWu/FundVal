# Integration follow-up, 2026-10-25

Initial integrated targeted suite: actual test child native0,104/104; the one-line reporting wrapper accidentally inspected receipt.status instead of nativeExit and therefore returned1. The original receipt/stdout remain authoritative, not the wrapper's invented failure.

Initial full suite integrated-full-test-01 native1 had two stale source-location assertions: cloud synchronization algorithms moved from App to sync-status. Assertions were relocated with extra App delegation checks and zero direct PATCH assertions, no safety checks removed. Relocated targeted4/4 passed.

QA V1 source280 SHA145784093378a4d1f66e04af7a2b8b7a51e4bc2db2abc9635432431097bbe195: full1406/1403PASS/3existing Windows skip; syntax222; build native0/all86778/cold46953. E2E native1/34PASS/1FAIL (105-fund official fallback). The trace shows the test's network-idle detector finished before Bridge requests started, then read105 placeholders while requests were still running. Preserve the whole failed trace/output; fix the completion wait, retain exact105 values/dates/queue assertions. Do not simply rerun or loosen timeouts.

Independent real-App/executor/repository delayed-lock probe also confirmed an actual pre-existing refresh race: automatic name completion may invalidate aggregate cache after generation completion. The next source revision will settle generation-owned name edits before its one final flush, keep synchronous commit guards, and prohibit cancelled edit results from installing App state. Schema3 validation, name/revision fingerprint and normal edit invalidation remain unchanged. New permanent regression must fail on existing code first.

QA V1 remains historical partial evidence. V2 must freeze the corrected full source and rerun complete QA, deterministic builds and original budgets. No paired performance run has started; prepared controller protocol is NOT_RUN and must bind the eventual corrected artifact. No commit/push/deploy/version change occurs here.
