import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { sha, save } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';
const here = import.meta.dirname;
const app = readFileSync('D:/AI项目/FundVal/js/app.js');
assert.equal(sha(app), '17826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359');
const source = app.toString('utf8').replaceAll('\r\n', '\n');
const results = [];
for (const [name, path] of [
  ['SYNC', 'C:/Users/84046/AppData/Local/Temp/FundVal-sync-status-extraction-20261023-worker/APP_WIRING.patch.txt'],
  ['PWA', resolve(here, 'PWA_APP.patch')],
]) {
  const original = readFileSync(path, 'utf8').replaceAll('\r\n', '\n').trim();
  const prefix = '*** Begin Patch\n*** Update File: D:/AI项目/FundVal/js/app.js\n';
  const suffix = '*** End Patch';
  assert.ok(original.startsWith(prefix) && original.endsWith(suffix));
  const chunks = original.slice(prefix.length, -suffix.length).trim().split(/(?=^@@$)/m).filter(chunk => chunk.trim());
  const entries = chunks.map(chunk => {
    assert.ok(chunk.startsWith('@@\n'));
    const body = chunk.slice(3).trimEnd();
    const old = body.split('\n').filter(line => line.startsWith('-') || line.startsWith(' ')).map(line => line.slice(1)).join('\n');
    assert.ok(old.length > 0, 'include context as well as removed lines');
    const index = source.indexOf(old);
    assert.ok(index >= 0, name + ': hunk is present');
    assert.equal(source.indexOf(old, index + 1), -1, name + ': unique hunk');
    return { index, chunk: '@@\n' + body + '\n' };
  });
  entries.sort((a, b) => a.index - b.index);
  for (let i = 1; i < entries.length; i++) assert.ok(entries[i].index > entries[i - 1].index);
  const corrected = prefix + entries.map(entry => entry.chunk).join('') + suffix + '\n';
  save(resolve(here, name + '_APP_ORDERED_V2.patch'), corrected);
  results.push({ name, originalPatchSha256: sha(original + '\n'), correctedPatchSha256: sha(corrected), hunks: entries.length, positions: entries.map(entry => entry.index) });
}
save(resolve(here, 'APP_PATCH_ORDER_V2.json'), JSON.stringify({ appSha256: sha(app), previousFailure: 'v1 ignored context lines, yielding an empty old match for insertion hunks; no App mutation occurred', correction: 'Include context and removed lines, sort unchanged hunks by source position. Runtime replacement content unchanged.', results }, null, 2) + '\n');
process.stdout.write(JSON.stringify(results) + '\n');
