import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
const ROOT='D:/AI项目/FundVal';
const OUT='C:/Users/84046/AppData/Local/Temp/FundVal-m3-scope-name-race-20261025-review';
const require=createRequire(ROOT+'/package.json');
const {parseSync}=require('rolldown/utils');
const load=p=>import(pathToFileURL(ROOT+'/'+p));
const {commitHoldingEdit}=await load('js/runtime/holding-edit.js');
const {executeRefreshPlan}=await load('js/runtime/refresh-execution.js');
const {RefreshCoordinator}=await load('js/runtime/refresh-runtime.js');
const schema=await load('js/storage/holdings-schema.js');
const {activeHoldingCodes,retainActiveFundData}=await load('js/runtime/active-holdings.js');
const {holdingQuoteAmounts}=await load('js/runtime/holding-quote-amounts.js');
const source=await readFile(ROOT+'/js/app.js','utf8');
const program=parseSync('app.js',source).program;
const fn=name=>{const node=program.body.find(n=>n.type==='FunctionDeclaration'&&n.id.name===name);assert.ok(node,name);return source.slice(node.start,node.end);};
const sha=v=>createHash('sha256').update(v).digest('hex');
const NOW=Date.parse('2026-09-30T06:00:00Z'), CODE='005844', CACHE_KEY='fuyu_funds_cache_v1';
const indices=['sh000001','sh000300','usINX','usNDX'];
const evidence={scope:'real App AST functions, real refresh executor/coordinator, real repository; synthetic in-memory storage/locks/provider clients; no browser or network',appSha256:sha(source),runs:[]};
async function scenario(delayNameLock) {
 let time=NOW,phase='seed',releaseName,renameTask;
 const values=new Map(),events=[],counts={};
 const storage={getItem:k=>values.get(k)??null,setItem(k,v){values.set(k,String(v));events.push({phase,kind:'set',key:k});},removeItem(k){values.delete(k);events.push({phase,kind:'remove',key:k});}};
 const direct={request:async(_n,_o,callback)=>callback({})};
 const seed=await commitHoldingEdit(storage,{code:CODE,baseline:null,operation:'add',values:{name:CODE,shares:10,cost:1.2}},{locks:direct,now:NOW-60000});
 assert.equal(seed.ok,true);
 const locks={request:(_n,_o,callback)=>delayNameLock?new Promise(resolve=>{releaseName=()=>resolve(callback({}));}):Promise.resolve(callback({}))};
 const imported=fn('saveHoldingEdit');
 const originalImport="await import('./runtime/business-features.js')";
 assert.equal(imported.split(originalImport).length,2);
 const saveText=imported.replace(originalImport,'await loadBusiness()');
 const bindings={...schema,activeHoldingCodes,retainActiveFundData,holdingQuoteAmounts,CACHE_KEY,
  SKIP_CACHE_KEYS:['_cached','message','quoteCandidates'],
  safeGetItem:storage.getItem,safeSetItem:(k,v)=>{storage.setItem(k,v);return true;},safeRemoveItem:storage.removeItem,
  renderFundList(){},renderHoldingsList(){},scheduleAutoPush(){events.push({phase,kind:'sync-scheduled'});},updateCurrentFundAccuracy(){},
  loadBusiness:async()=>({commitHoldingEdit:(_unused,edit,options)=>{renameTask=commitHoldingEdit(storage,edit,{...options,locks,now:time});return renameTask;}}),
  initial:seed.document,
 };
 const body=[
  'let holdingsDocument=initial,holdings=toLegacyHoldings(initial),holdingsStorageError="",fundsData=[],expandedFund=null;',
  'const holdingsCache={},holdingsMetaCache={},fundTypeCache={},fundFeeCache={},fundHoldingsRequests=new Map();',
  'function upsertFundData(code,data){const i=fundsData.findIndex(x=>x.code===code);if(i<0)fundsData.push(data);else fundsData[i]=data;}',
  ...['isRealFundName','holdingsHash','slimFundCache','saveCache','reconcileActiveFundState','installHoldingsDocument','commitRefreshedFund'].map(fn),saveText,
  'return {commit:commitRefreshedFund,holdings:()=>holdings,document:()=>holdingsDocument,hash:()=>holdingsHash(holdings),data:()=>slimFundCache(fundsData)};'
 ].join('\n');
 const app=new Function(...Object.keys(bindings),body)(...Object.values(bindings));
 const bump=kind=>{counts[phase]??={};counts[phase][kind]=(counts[phase][kind]||0)+1;};
 const row=()=>({code:CODE,name:'Synthetic 混合基金A',status:'ok',est_change:0,source_quote:{fundCode:CODE,fundName:'Synthetic 混合基金A',market:'cn',assetKind:'fund',valueKind:'intraday_estimate',value:1,changePct:0,baseNav:1,baseNavDate:'2026-09-29',targetDate:'2026-09-30',sourceId:'sinan-estimate-proxy',sourceTier:'primary',status:'realtime',observedAt:new Date(time-1000).toISOString(),fetchedAt:new Date(time).toISOString(),reasonCodes:[]}});
 const clients={
  estimates:async(active,_opts,_context,dispatch)=>dispatch(async()=>{bump('estimates');return new Map(active.map(h=>[h.code,row()]));}),
  nav:async()=>{bump('nav');return {nav:1.1,prevNav:1,date:'2026-09-29',prevDate:'2026-09-28',change:10,changeAmt:0.1,fundName:'Synthetic 混合基金A',meta:{manager:'Synthetic manager'}};},
  holdings:async()=>{bump('holdings');return {status:'ok',sourceStatus:'ok',wireVersion:2,reportDate:'2026-06-30',fetchedAt:new Date(time).toISOString(),source:'sinan-holdings-proxy',items:[{code:'600001',market:'sh',name:'Synthetic stock',ratio:20}]};},
  indices:async()=>{bump('indices');return indices.map(code=>({code,price:100,changePct:0,observedAt:new Date(time-1000).toISOString(),status:'current'}));},
  gold:async(_signal,dispatch)=>dispatch(async()=>{bump('gold');return {price:100,changePct:0,observedAt:new Date(time-1000).toISOString(),status:'current',cached:false};}),
  models:async()=>[],qualifyHoldings:(_h,items)=>items.map(x=>({...x,quoteCode:x.market+x.code})),calculateHoldings:async()=>null,
  normalizeTime:x=>x,eastmoney:async codes=>{bump('eastmoney');return {data:{diff:codes.map(code=>({f12:code.slice(2),f13:1,f2:100,f3:0,f124:Math.floor(time/1000)}))}};},bridge:async()=>({quotes:[]}),
 };
 let context;
 const coordinator=new RefreshCoordinator({withBuiltinSources:true,now:()=>time,execute(realContext){context=realContext;return executeRefreshPlan({
  context,snapshot:structuredClone(app.holdings()),options:{force:true},previous:storage.getItem(CACHE_KEY),clients,storage,now:()=>time,
  ui:{primary:(_h,raw)=>raw,publish:(h,raw)=>app.commit(context,h,{data:{...raw,code:h.code,quote:raw.source_quote},fetchedName:raw.name}),enriched(){},holdings(){},metadata(){},market(){},failure(_h,e){throw e;},cacheData:app.data,holdingsHash:app.hash,complete(){events.push({phase,kind:'complete'});}}
 });}});
 const hashBefore=app.hash();phase='cold';const cold=await coordinator.request({trigger:'startup'});
 assert.equal(cold.status,'completed');
 const rawAfterFlush=storage.getItem(CACHE_KEY);assert.ok(rawAfterFlush);
 const resourcesAfterFlush=Object.keys(JSON.parse(rawAfterFlush).refreshResources);
 const hashAtFlush=app.hash();
 if(delayNameLock){assert.equal(typeof releaseName,'function');phase='late-name';releaseName();}
 if(renameTask) await renameTask;
 for(let i=0;i<8;i++)await Promise.resolve();
 const rawAfterName=storage.getItem(CACHE_KEY),hashAfterName=app.hash();
 assert.notEqual(hashBefore,hashAfterName);
 if(delayNameLock){assert.equal(rawAfterName,null);assert.equal(hashAtFlush,hashBefore);}
 time+=1000;phase='warm';const warm=await coordinator.request({trigger:'manual'});assert.equal(warm.status,'completed');
 const result={delayNameLock,coldStatus:cold.status,warmStatus:warm.status,coldDiagnostics:cold.result.diagnostics,warmDiagnostics:warm.result.diagnostics,
  resourcesAfterFlush,cachePresentAfterName:rawAfterName!==null,hashBefore:sha(hashBefore),hashAtFlush:sha(hashAtFlush),hashAfterName:sha(hashAfterName),
  identityChanged:hashBefore!==hashAfterName,counts,cacheMutations:events.filter(x=>x.key===CACHE_KEY),events:events.filter(x=>!x.key),
  holdingAfterName:app.holdings().map(({code,name,shares,cost})=>({code,name,shares,cost}))};
 if(delayNameLock){assert.equal(counts.warm.nav,1);assert.equal(counts.warm.holdings,1);}
 else {assert.equal(counts.warm.nav??0,0);assert.equal(counts.warm.holdings??0,0);}
 return result;
}
evidence.runs.push(await scenario(true));
evidence.runs.push(await scenario(false));
assert.equal(sha(await readFile(ROOT+'/js/app.js','utf8')),evidence.appSha256);
await writeFile(OUT+'/RESULTS.json',JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(evidence,null,2));
