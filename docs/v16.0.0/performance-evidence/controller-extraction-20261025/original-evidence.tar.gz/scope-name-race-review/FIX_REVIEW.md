# Final scope follow-up after parent fix

2026-10-25. This report supersedes the unresolved-code portion of REPORT.md only; it does not rewrite historical observations or claim full M3 exit.

Reviewed final inputs:

- `js/app.js` SHA256 `d40895881eb10188a8346dfb461918654d25c10cf2e19be9bbcc5516b04d0f3a`.
- `js/runtime/refresh-execution.js` SHA256 `e0dee7d21e503c6142aa0acf1f5f81b9c17fe7c1df2d8d3ed7067b410ecb574f`.
- New permanent `test/refresh-name-settlement-v16.test.js` SHA256 `ed59639a89f5ef76fa3d4b6664249f19252afcc31dca5de5c80c3355ccb5102f`.

Parent's minimum fix is correctly wired in actual production:

1. `runRefresh` owns a fresh `pendingNameEdits` list for each generation. Its actual publisher provides `trackPendingEdit` as the fourth argument to `commitRefreshedFund`; its executor UI exposes settlement of that same list.
2. `commitRefreshedFund` preserves synchronous `context.commit`, observes the automatic-name promise immediately, records it and gates eventual sync scheduling through current context. The edit uses `persistCache:false` only for the page reconciliation projection.
3. `saveHoldingEdit` checks cancellation before loading/editing and after the asynchronous repository result, preventing late saved/conflict/failure results from replacing newer App state. Repository transaction cancellation/fingerprint/Web Lock behavior remains unchanged. The parent did not globally disable transaction cache invalidation.
4. `installHoldingsDocument` forwards the new optional reconciliation options. Other callers keep default behavior. No old hash is relabelled, no Schema 3 fields changed.
5. `executeRefreshPlan` awaits the pending edit settlement after its existing resource/metadata drain and before the final current-generation check and only aggregate cache flush. The resulting cache hash is read after the actual document installation.

Permanent tests cover the held lock preventing early completion/flush, one final write using the updated canonical hash, warm NAV/disclosure/metadata reuse, cancellation while awaiting the lock, late saved/conflict/failure results after newer App state, and the real `runRefresh` callback wiring (the last test executes its real AST body with injected IO rather than merely checking identifiers).

Original five behavior tests produced real native exit 1, five failures on the unchanged old App; `RED.*` retains them. That version's test SHA was `a5d3de1cd0af06ef8a2257217ca86c4a5e2b1f90eba2ec5c2c291415c0964d6f`. The sixth App-wiring test was added afterward; do not claim six tests were red before production changes. Parent ran all six plus refresh executor, holding-edit and accuracy lifecycle: 71/71, native exit 0, stderr 0, recorded at `FundVal-m3-responsibility-extraction-20261023-parent/name-settlement-green-01.*`. Reviewer read the receipt and stdout tail; reviewer did not repeat the target/full suite.

Known bounded limitation: cancellation prevents the pending automatic edit from writing/installing, but the origin Web Lock request itself is not newly made abortable. Draining an already queued name edit waits until that external lock is released. The cancellation regression releases the synthetic held lock before asserting final drain; it does not certify an infinite foreign lock holder or bounded stop latency. Parent deliberately kept this task scoped to existing repository lock semantics.

No additional concrete missing M3 runtime responsibility was found in the reviewed paths after this fix. Six 9.1 responsibility boundaries, layered plan/batching/TTL, once-flush, cross-generation guards and diagnostics all have actual production wiring as catalogued in REPORT.md. This is code-scope acceptance with a bounded targeted regression result, not M3 EXIT. Parent still must complete final-source QA, deterministic builds, bundle/graph/resource checks, final-candidate performance, immutable commit CI and stage reconciliation. M4/M5/M6 remain outside this completed extraction and are required for the overall v16 goal.

The new test file is finished and frozen by this reviewer. No further repository edits will be made without coordination; only this isolated Temp report was added after the final parent fix.
