# M3 scope review after controller extraction

2026-10-25. Read-only repository review; no repository edits, full tests, build or network initiated by this reviewer. A synthetic in-memory probe is the only execution. Parent owns QA, candidate CI and final performance.

## Verdict

The two previously missing 9.1 module boundaries are now real implementations wired into App. However, M3 cannot yet be declared complete: an existing asynchronous auto-name holding edit can remove the just-flushed aggregate cache after a generation completes, defeating the next warm generation's stable-resource TTL reuse. This is a confirmed scheduling/cache-loss issue, not a finding of corrupted holdings or incorrect finance values. Treat it as a functional/performance P2 and an unresolved M3 warm-cache acceptance case. Exact-candidate QA/performance/CI remain separately unproven by this review.

## Confirmed issue and reproduction

Relevant source locations:

- `js/app.js:689` `commitRefreshedFund` fires `saveHoldingEdit({ operation: 'name', signal: context.signal })` without returning/tracking the promise.
- `js/app.js:242` always passes `{ cacheKey: CACHE_KEY }` into the real `commitHoldingEdit` and installs the returned document.
- `js/runtime/holding-edit.js:5` acquires the repository Web Lock and checks cancellation, then performs the normal Schema 3 transaction.
- `js/storage/holdings-repository.js:310` removes the supplied cache key after successful persistence.
- `js/runtime/refresh-execution.js:323-334` drains enrichments, market/security/NAV and metadata, but not that asynchronous holding-name edit, then writes the aggregate once.
- `js/app.js:250-275` installs/reconciles the document; `saveCache` will not recreate a removed aggregate.

Trigger: a holding has only its six-digit code as name; a successful primary quote supplies its real name; an origin Web Lock is occupied long enough that the automatic rename runs after refresh resources settle. The completed current generation is still current/non-aborted, so the delayed name transaction legitimately succeeds.

`probe.mjs` uses real App AST functions (`commitRefreshedFund`, `saveHoldingEdit`, install/reconcile/hash/cache helpers), the production `executeRefreshPlan`, production runtime coordinator and production holdings repository. The sole dynamic-import expression is replaced with an injected loader returning the real repository edit with synthetic storage/locks. Providers, DOM sinks, accuracy and sync notification are synthetic; no browser, network, real Gist or user storage is involved. All outputs concern this bounded synthetic harness, not a full browser.

Native invocation completed with exit 0 (tool chunk `205a30`). `RESULTS.json` contains both delayed-lock and immediate-lock control:

| Fact | Delayed automatic-name lock | Immediate lock control |
|---|---:|---:|
| First generation | completed, cacheWrites=1 | completed, cacheWrites=1 |
| Resource entries at flush | 6 | 6 |
| Holding hash at flush | old hash | updated hash |
| Later name transaction | saved, hash changes | saved before flush |
| Cache after name settles | absent | present |
| Second generation, 1 second later | completed | completed |
| Second-generation NAV requests | 1 | 0 |
| Second-generation disclosure requests | 1 | 0 |
| Second-generation cache hits | 0 | 3 |
| Second-generation total provider requests | 6 | 4 |

The late case's cache mutations are exactly `cold set -> late-name remove -> warm set`. The control is `cold remove -> cold set -> warm set`. Shares stay 10 and cost stays 1.2; the name becomes `Synthetic 混合基金A`. Schema revision/timestamp/hash change because name is part of the canonical document. Hashes differ across separate scenarios due to generated device identity; only within-scenario comparisons are meaningful.

Interpretation: the repository's cache invalidation is a deliberate safety behavior for holding edits and must not be globally disabled. The defect is that an auto-name edit owned by the refresh escapes its completion/drain boundary. Simply keeping the old cache under its old holdings hash is also wrong. The engineering direction is to coordinate refresh-owned edits before the final cache snapshot/flush (including document projection and cancellation), or safely preserve/rebind validated resource envelopes through the explicit name-only edit; either approach needs cancellation and external-edit conflict coverage. Do not weaken Schema 3 transaction rules, Web Locks, fingerprint comparison or generic user-edit invalidation.

## M3 implementation coverage from actual source

| Requirement | Implementation observed | Scope note |
|---|---|---|
| Layered Refresh Plan | `refresh-plan.js:235`, policy module, execution `:27` | Production imports the private runtime projection; public contract factory is not the actual App path. Both paths exist. |
| Volatile and stable TTL separation | `config.js`, `refresh-resource-policy.js`, `refresh-resource-cache.js`, `getNav` at execution `:103` | Ordinary force affects live resources; stable force requires diagnostic trigger. Cache expiry rechecked at consumption. NAV/metadata share acquisition without renewing a warm NAV. |
| Provider union batching | `security-quote-batch.js:137`, execution `:256` | Per-generation union, bounded provider batches, missing-only fallback, disjoint Tencent model/security sets, validated index seed reuse. |
| Once-per-generation aggregate write | `generation-resource-scope.js:107`, execution `:334` | Scope guard and serialized synchronous Storage write present. Auto-name tail above remains outside this boundary. |
| Current generation gates/cancellation | `refresh-runtime.js`, `generation-resource-scope.js`, execution UI callbacks | Dispatch, post-await, cache stage/flush and UI commits check identity/signal; new generation aborts previous, final drain observes branches. Details wait for active refresh. |
| Requests/cancel/dedupe diagnostics | `refresh-generation.js:50`, execution reports, `diagnostics-ui.js` | Fixed aggregate fields include providers, cache hits, dedupe, aborted/failed requests, write attempts/writes, planning reasons, execution gates and cancelled generation. Unknown measurements stay null. Final quote trace is in per-fund detail, not copied into privacy-sensitive aggregate. |
| 9.1(1) valuation period | `valuation-period.js:11`, quote presentation, holding amounts, notification policy | Actual consumers route through central period/date semantics. |
| 9.1(2) refresh plan | Modules above | Real App routes through business-features dynamic import into executor. |
| 9.1(3) cache envelope | `cache-envelope.js:26`, refresh-resource-cache validators/adapters | Explicit source/date/TTL/cache state; reads do not renew provenance. |
| 9.1(4) sync status ownership | `sync-status.js:3`, App constructor `:107`, thin aliases `:345-407` | Four states/timers and 10 methods really moved; injected lazy cloud clients and live document lookup. No second App busy state. |
| 9.1(5) PWA controller ownership | `pwa-update-controller.js:3/78/129`, App `:1790-1805` | Six SW states, peer channel, dirty guard, banner, identity checks, drain/activation/listeners moved. Constructor inert, start at former phase; busy/applying cross-reads are functions, not snapshots. |
| 9.1(6) market clock | `market-clock.js:72`, config/freshness/App/presentation/diagnostics | Actual market-state consumers use MarketClock; legacy marketSession remains exported but production search found no call outside its own legacy wrapper. Calendar absence stays unverified. |
| No UI rewrite / loading boundary | build post-integrity membership and source SW CORE contain both controllers | Original five loading groups remain; OCR/cloud heavy resource separation needs built-artifact verification by parent. |

## M4/M5 work that must not be falsely claimed by M3

The extracted sync controller retains the old sync UI/timers/error handling. It does not yet implement the complete v16 archive selector, state-machine/backoff/credential policy or genuine dual-device proof; those belong to M4. The extracted PWA controller retains established update safety; manifest identity/icons, OCR preflight/importability/mobile changes, actual v15-to-v16 installed upgrade and offline/device acceptance remain M5/M6. Their future milestone placement permits this behavior-preserving extraction; it does not permit claiming those final capabilities are complete.

## Required gates before M3 exit

1. Close the confirmed late-name boundary with a regression that exercises real App wiring, delayed lock, final hash/cache, next warm stable-request counts, cancellation and concurrent edit conflict. Existing refresh E2E fixtures use real names and do not cover this branch.
2. Finish post-change complete unit/check/build/browser suite and characterize both new controllers plus actual App lifecycle wiring; preserve observed failures/skips rather than inheriting the old baseline result.
3. Consecutive deterministic full builds; actual all-non-OCR gzip <=92,160 B and cold <=52,241 B; same five groups/ES2022/OXC, no OCR/remote script entry into cold/SW CORE; validate chunk/ESM/SW paths and fingerprint.
4. Final source-bound performance and request-count report for cold/warm/save, not the pre-extraction 800-pair artifact. Enforce unchanged latency/CIs/request and renderer observation boundaries.
5. Immutable candidate commit, exact CI/review and traceable artifacts; no version/release claim from mutable local QA.
6. Reconcile all M3 items against final source/evidence. M4-M6 remain required for v16 completion and publication.

## Evidence hashes

- Reviewed App SHA256 `7cdb55aed9a542f06f171c1a600003bd63fd054d78acfd239650c3cdea36bc7b`; unchanged across probe.
- `probe.mjs` SHA256 `0b8a457512a807fdb90fb198112c9ab561f4d16d0087ad6261d4ceb64962f57b`.
- `RESULTS.json` SHA256 `6cac0bd75de64e20dd5da3af5f5e3f25cc514e9b157c26c41b7696d36f49e9e0`.
- Invocation: `C:\Program Files\nodejs\node.exe C:\Users\84046\AppData\Local\Temp\FundVal-m3-scope-name-race-20261025-review\probe.mjs`, cwd repository. Result file is exclusive-create; preserve it and copy the isolated script/output directory for an independent rerun rather than overwriting original evidence.

No finding above certifies current full QA, performance, CI, production or physical devices. No repository files were changed by this reviewer.
