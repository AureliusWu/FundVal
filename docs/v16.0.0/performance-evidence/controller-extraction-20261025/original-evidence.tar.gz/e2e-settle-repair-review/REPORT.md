# E2E failure diagnosis and condition-wait repair

## Observed failure

The original full E2E run had 34 PASS and 1 FAIL. `large official-only portfolio drains without overflowing the real Bridge queue` failed at its instant `allTextContents()` comparison: 105 expected `1.2000` strings versus 105 `--` placeholders. It did not fail after receiving and validating 105 official NAV responses.

All original inputs were copied, with exact byte comparison and SHA256, before editing. See `preserved-inputs.json`: old test source, complete trace ZIP, screenshot, error-context, full QA report, stdout and stderr. Originals remain in place. Trace SHA256: `2921fb74ab7274bc1a7f3ec47c77549d0f49beeadb8fa2a833d12569288e27d6`.

## Trace evidence

Times below are the trace's monotonic milliseconds, not inferred provider dates:

| Event | Time |
| --- | --- |
| Harness network-settle poll accepted true | 47,434.622–47,434.686 |
| Skeleton-count check began / completed | 47,438.506 / 49,599.871 |
| First Tencent index request started | approximately 49,583 |
| First official NAV request (`200000`) started | approximately 49,624 |
| NAV text snapshot began / returned all 105 placeholders | 49,658.307 / 49,739.380 |
| Exact-value assertion failed | 49,769.602–49,777.894 |

The network trace contains only 8 official NAV requests (`200000` through `200007`), all HTTP 200, before teardown. Requests continued after the assertion failed. Three estimate requests received the fixture's intentional 503 responses. This is direct evidence that the test sampled the in-progress refresh rather than a fully drained 105-row result. It is not evidence that the queue admitted all 105, nor evidence of an admission overflow.

`installHarness().settle` in `e2e/v16-refresh.spec.js:184–203` waits for current request objects to finish and a 500 ms gap since the last request started, then for skeletons to disappear. That observation can be true between loading the Bridge runtime and its later dispatch. It does not observe queued application work or the refresh generation's terminal state.

`js/runtime/refresh-execution.js:298–306` awaits each individual fallback and publishes each row separately. Lines 323–339 wait for all enrichment, market, security, NAV and metadata work before the single aggregate cache flush. Therefore, all 105 exact NAVs prove completion of all visible fallback rows, but do not alone prove the generation has reached its final flush.

## Date, controller and error attribution

- Fixture time remains `2026-09-29T06:30:00.000Z` plus elapsed monotonic time. NAV fixture dates remain September 25 and September 28, with latest value 1.2. Actual provider request cache-busters are around `1790663407xxx`, consistent with the fixed September 29 time. No date mismatch is shown by this failure; its date assertion was never reached.
- The trace includes a sandbox `navigator.serviceWorker` SecurityError with an anonymous init-script stack. The exact offending access is Playwright's own `serviceWorkers: 'block'` init script in `node_modules/playwright-core/lib/coreBundle.js:51296`, which reads `navigator.serviceWorker` inside the opaque Bridge frame. It is not a stack pointing to the new PWA controller. Bridge NAV requests subsequently execute successfully. The warning/error remains part of the retained evidence; it is not silently counted as zero errors.
- No PWA apply action, sync operation or cloud request explains the failure. The direct proven defect is the existing test's completion boundary. This trace alone cannot determine why Bridge dispatch was delayed, or establish that all 105 would eventually complete without running the corrected test.

## Approved changes

Only `e2e/v16-refresh.spec.js` was edited for this diagnosis:

1. Replace the one-shot read/comparison with `await expect(navs, originalMessage).toHaveText(rows.map(() => '1.2000'))`, waiting for all 105 exact values.
2. Wait for the existing single final aggregate cache write count to become exactly 1 before reading it, then retain the original exact single-write and 105-row cache checks.

All original 105-row values, dates, request count, distinct request paths, cache cardinality and zero-Gist-write assertions remain. `playwright.config.mjs` was not edited; default expect timeout stays 8,000 ms. No fixed sleep, enlarged timeout, retry, dropped assertion or production change was added.

Syntax check exited 0. A read-only source comparison proved that only these two condition waits and explanatory comments changed after line-ending normalization. Final test source: 47,837 B, SHA256 `3b52d3d56a5b2a3166bfab5dc4e8fbfdc35dc0e224c84daecce8bbdd5cc86431`. The final verification output is the terminal tool result with chunk `fc3447`; no separate native receipt is invented.

No E2E rerun was started by this worker. Parent owns the next rebuilt full QA run, including the separate automatic-name persistence race fix. The original 34/35 outcome remains a failed run, not a pass retroactively.
