import { copyFileSync, mkdirSync, readFileSync, writeFileSync, constants } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const output = dirname(fileURLToPath(import.meta.url));
const repo = 'D:/AI项目/FundVal';
const failure = `${repo}/site/.playwright-results/v16-refresh-large-official-32855-owing-the-real-Bridge-queue`;
const qa = 'C:/Users/84046/AppData/Local/Temp/FundVal-m3-responsibility-extraction-20261023-parent/qa/e2e';
const inputs = [
  [`${repo}/e2e/v16-refresh.spec.js`, 'before/e2e/v16-refresh.spec.js'],
  ...['trace.zip', 'test-failed-1.png', 'error-context.md'].map(name => [`${failure}/${name}`, `original-failure/${name}`]),
  ...['report.json', 'e2e.stdout', 'e2e.stderr'].map(name => [`${qa}/${name}`, `original-qa/${name}`]),
];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const rows = inputs.map(([source, relative]) => {
  const destination = join(output, relative);
  const before = readFileSync(source);
  mkdirSync(dirname(destination), { recursive: true });
  copyFileSync(source, destination, constants.COPYFILE_EXCL);
  const after = readFileSync(destination);
  if (!before.equals(after)) throw new Error(`Backup mismatch: ${relative}`);
  return { source, backup: relative, bytes: before.length, sha256: hash(before) };
});
const receipt = { generatedAt: new Date().toISOString(), mode: 'copy-only; originals retained; no E2E rerun', rows };
writeFileSync(join(output, 'preserved-inputs.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(receipt, null, 2));
