# Controller extraction review and combined lifecycle test

Scope: FundVal M3 controller extraction. Reviewed `AGENTS.md`, both runtime controller files, the sync/PWA characterization tests, the PWA reference fixture, and the App integration. No production file was edited by this reviewer.

## Review result

No introduced behavior regression was identified in the two extracted controllers. An independent read-only source check exited 0 after verifying the preserved App SHA256 `17826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359` and exact normalized source matches for all 10 sync reference functions, 6 PWA reference policy functions, 3 dirty-input helpers, and the original SW registration block. The source check output exists in this thread's terminal tool result (chunk `7111ee`), not as an invented native receipt file.

The concrete coverage gap was mutual integration: the previous sync test injected an `updating` boolean, while the PWA test injected an `isSyncing` boolean. Neither alone proved that the two real controllers read each other's current state. The parent explicitly authorized one new test file to cover this gap.

## Added test

Only repository edit: `test/controller-lifecycle-v16.test.js`.

- Imports both real exported factories; uses their public methods and state readers.
- Suspends an actual sync operation and confirms PWA apply stops before drain/activation.
- Suspends actual PWA drain and confirms both sync directions return `service_worker_update_pending` before loading cloud code.
- Introduces dirty input during drain, verifies refresh restart and no activation, then verifies synchronization becomes available again.
- Verifies a settled sync permits an update and only the exact requested worker/same-origin ACK can reload, at most once across duplicate ACK/controller-change events.
- Browser IO, refresh execution and cloud adapters are synthetic. Network access is denied by the test. No real Gist, real account, native browser SW or production evidence is claimed.

## Actual execution

Command: `C:/Program Files/nodejs/node.exe --test test/controller-lifecycle-v16.test.js` from `D:/AI项目/FundVal`.

`2026-10-25T05:44:33.724Z` → `2026-10-25T05:44:34.100Z`.

Native exit 0; 4 tests passed, 0 failed, 0 skipped; stdout 514 B; stderr 0 B. Exact stdout, stderr, arguments and source hashes are preserved in `native-01.stdout.log`, `native-01.stderr.log`, and `native-01.receipt.json`. Test source before/after was identical: 9,116 B, SHA256 `d174bff98bdf9395cff18e2837056bca28cbf0547dc738f12718f3f55a786bc3`.

Full QA, build, browser E2E and performance gates remain the parent's responsibility. This targeted test does not establish M3 completion or authorize a release.
