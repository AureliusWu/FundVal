import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = 'D:/AI项目/FundVal';
const target = 'test/controller-lifecycle-v16.test.js';
const command = 'C:/Program Files/nodejs/node.exe';
const args = ['--test', target];
const hash = data => createHash('sha256').update(data).digest('hex');
const before = readFileSync(`${root}/${target}`);
const startedAt = new Date().toISOString();
const result = spawnSync(command, args, { cwd: root, timeout: 60000, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
const endedAt = new Date().toISOString();
const save = (name, value) => writeFileSync(new URL(name, import.meta.url), value, { flag: 'wx' });
save('native-01.stdout.log', result.stdout || '');
save('native-01.stderr.log', result.stderr || '');
const after = readFileSync(`${root}/${target}`);
const receipt = { command, args, cwd: root, startedAt, endedAt, nativeStatus: result.status,
  signal: result.signal, error: result.error ? { name: result.error.name, message: result.error.message } : null,
  stdoutBytes: Buffer.byteLength(result.stdout || ''), stderrBytes: Buffer.byteLength(result.stderr || ''),
  target, targetBefore: { bytes: before.length, sha256: hash(before) },
  targetAfter: { bytes: after.length, sha256: hash(after) },
  testUnchanged: before.equals(after), script: fileURLToPath(import.meta.url) };
save('native-01.receipt.json', JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
console.log(result.stdout || '');
if (result.stderr) console.error(result.stderr);
process.exitCode = result.status === 0 && before.equals(after) ? 0 : 1;
