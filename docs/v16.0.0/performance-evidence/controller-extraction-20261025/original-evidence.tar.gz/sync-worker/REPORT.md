# Sync-status extraction handoff, 2026-10-23

Worker implementation complete; parent App integration is still required. Only the new js/runtime/sync-status.js and test/sync-status-v16.test.js were edited in the repository. App/build/version/package/config/Schema3/core storage/other agents' files and archived performance evidence are untouched. Current App still equals saved app.before.js:97389B/SHA25617826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359.

## Actual extraction, not a facade-only shell

createSyncStatus owns the actual four existing mutable fields (busy,pending,debounce timer,auto-pull timer), the ten existing state/UI/orchestration function bodies, reset and the pending setter. The module is6907B/SHA256c061ca555679e990d458b08af8a1390210ab56855e3db21467b8c0b067cdb64f. It has no imports, fetch, localStorage, Gist endpoint or eager cloud client work; construction reads injected callbacks only and performs no IO.

The ten moved bodies are hasCloudConfig,renderCloudStatus,handleCloudFailure,hasPendingSync,resolveGistId,pullFromCloud,pushToCloud,scheduleAutoPush,startAutoPull,autoPullOnLoad. An AST/source test compares every body literally to the independently frozen old-App oracle, permitting only two declared substitutions: the shared PWA applying flag becomes isUpdateApplying(), and holdingsDocument?.deviceId becomes getHoldingsDocument()?.deviceId. All existing await/order/try-catch-finally, pending asymmetry, toast strings,404 handling, positive/failure return identities and timer callback behavior stay in those bodies.

No M4 state enum, retry/backoff, credential strategy, unknown automatic resend or new cloud write is added. An unverified patched response still follows the original pending/failure presentation, not a new success or retry rule. Existing canonical hashing, schema/storage checks, remote verification and lazy import/promise policies remain owned by their original App/storage/client functions.

## API and exact App wiring advice

APP_WIRING.patch.txt is an advisory apply_patch against the exact saved old App, not applied by this worker. It uses the parent's agreed syncController and pwaUpdateController instance names and leaves all ten App entries as one-line delegations. Parent must combine it with the PWA agent's patch, not apply stale overlapping ranges blindly.

Required constructor context:

```js
const syncController = createSyncStatus({
  TIMING, document,
  isUpdateApplying: () => pwaUpdateController.isUpdateApplying(),
  getHoldingsDocument: () => holdingsDocument,
  getGistToken, getGistId, setGistId, getSyncTime, setSyncTime,
  loadSyncMeta, markSyncPending, loadCloudSyncFeature, findExistingGist,
  createGistRemoteAdapter, createCloudLocalAdapter, reloadHoldingsAfterCloud,
  renderHoldingsList, refresh, showToast, nowISO,
  setTimeout, clearTimeout, setInterval, clearInterval,
});
```

The factory performs no callback invocation, so it may close over the later PWA controller; initialize both before any start/listener/user action. PWA receives isSyncing:()=>syncController.isSyncing(), never a captured Boolean. Sync reads the shared applying state through the callback above, never a copied flag. Remove the four old sync variables, not a second busy/pending owner.

| Existing App responsibility | Mapping |
| --- | --- |
| ten existing entry points | return syncController.sameName(original arguments) |
| busy reads used by PWA | syncController.isSyncing(), live |
| memory pending read | syncController.isPending(), live |
| markSyncPending first assignment | syncController.setSyncPending(true) |
| remainder of markSyncPending | keep original loadSyncMeta/canonical holdingsHash(holdings)/saveSyncMeta body in App |
| archive resetCloudState callback | syncController.resetCloudState |
| archive setSyncPending callback | syncController.setSyncPending |
| cloud/Gist feature imports and adapters | keep original lazy App loaders unchanged; inject them, no new static client import |

Use ordinary one-line Promise-returning wrappers for moved async entry points, e.g.function pushToCloud(silent,options={}) { return syncController.pushToCloud(silent,options); }, not an extra async/await layer. The moved original async method already supplies the Promise; an ordinary wrapper returns it directly and avoids introducing an additional adoption step. Sync function arities remain original (including push.length1 due its default second argument).

resetCloudState intentionally clears pending and the two timers but does not clear an active busy operation. setSyncPending stores the supplied value without coercing/persisting, matching the prior inline archive callback. isPending exposes this exact memory value; hasPendingSync independently retains the existing persisted-meta predicate. No raw token or credentials are included in the returned status API or diagnostic logs.

## Characterization evidence and preserved failures

Permanent test is22914B/SHA256679aa7a74e4e93e983ff9f3eb462928bb4f0b7991827fb87c6c8b177720cc4b5. It embeds only the ten old function bodies as a literal reference, extracted from app.before.js before module implementation. It does not load Temp, Git history, the old88MB report or old App at runtime and is usable in a fresh CI checkout with the existing dependencies. Final tests always statically import the new module; the temporary reference-only environment switch was removed, so CI cannot silently replace candidate testing with the oracle.

All native stdout/stderr and receipts are stored in this Temp:

| Stage | Native result | Scope |
| --- | --- | --- |
| reference |1;36/37PASS | preserved harness failure: fixed microtask count did not settle two identical fire-and-forget old implementations |
| reference-02 |0;37/37PASS | before module implementation; synthetic setImmediate quiescence correction only, described in ORACLE_ADDENDUM.md |
| red |1;missing module | expected absent-new-module RED, not an old business bug |
| green-01 |0;37/37PASS | new module versus unchanged literal old oracle |
| green-02 |0;41/41PASS | added exact-body movement, live PWA guard, options-access order and pending-throw identity coverage |
| green-03 |0;41/41PASS | final CI-independent test import, no reference-only bypass; stderr0 |

Final green-03 stdout3765B/SHA3a60d745dbadd5ba0506d101e8f77e07783fe0563f9bd26884f93cd98d3e9c61. Test callbacks use synthetic in-memory adapters/timers only, deny global fetch, and assert0 network attempts. Tests compare exact callback traces/return identities/final live state against the old oracle; no real Storage/GitHub/browser credentials are used.

Coverage includes early guard/token/id order, lazy-client and remote/local adapter sequence, unchanged versus changed pull rendering, persisted versus memory pending, discovery/no archive,404/401/future/upgrade/invalid/missing/truncated/other failures, unknown-style readback failure, silent404, reload failure, throws, suspended busy/reentrancy, live applying guard without cancelling the in-flight operation, late current device lookup, reset during a sync, debounce replacement/interval fire-and-forget behavior, startup pull, timestamp/missing-element UI, metadata exception identity, options getter order and double pending-attempt rejection/finally behavior.

## Parent integration gates and remaining boundaries

Parent must integrate the real instance and remove moved App algorithm bodies. This worker's new module alone does not satisfy9.1 while App continues using its old code. Parent's m3-controller-wiring-v16.test.js is not touched here; its prior4RED/1PASS remains parent evidence until actual wiring is tested.

The parent controls App/build/SW/offline source lists and grouped output: add this small module only to the existing post-integrity group, do not pull storage/cloud runtime or diagnostics into cold startup. Ensure source-mode SW/cache declarations include the new same-origin module as required by existing tooling. Keep five groups/compiler/target/dependencies/version and financial validation unchanged.

No full suite/check/build/E2E/performance was run by this worker. Direct module/body/VM characterization is not actual App/PWA/DOM/Web Locks/cloud or arbitrary monkeypatched-global equivalence. Parent integration must run the existing full gates, wiring/PWA tests, lazy graph checks, deterministic artifact/accounting and appropriate current performance qualification. The previously archived section58 PASS remains historical exact-byte evidence, not automatically inherited by this changed module graph. No bundle/gzip savings or M3 completion is claimed.

Implementation and handoff are complete; worker stops without changing App or another agent's files.
