# Before-implementation oracle harness correction

First reference-only native1:37tests/36PASS/1FAIL. Both sides used the identical frozen old App oracle. The timer test drained only a fixed5microtask turns then compared mutable snapshots; a fire-and-forget old async operation continued while the second old instance ran, creating different completion points. This is a harness failure, not old App behavior RED. Preserve reference.stdout/stderr/receipt unchanged.

Before implementing the module, change only this case to wait one synthetic Node setImmediate turn after each manually invoked fake timer callback. No real timer/network/browser behavior is introduced. It waits the already-in-memory immediate promise chain to finish; the original fire-and-forget callback and operation trace remain the objects under comparison. Save reference-02 outputs separately. Then retain absent-module RED and candidate GREEN as separate scopes; no old behavior is deleted or weakened to fit a candidate.
