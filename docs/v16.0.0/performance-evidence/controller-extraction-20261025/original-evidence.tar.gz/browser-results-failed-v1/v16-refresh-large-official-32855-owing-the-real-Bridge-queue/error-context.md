# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v16-refresh.spec.js >> large official-only portfolio drains without overflowing the real Bridge queue
- Location: e2e\v16-refresh.spec.js:358:1

# Error details

```
Error: All official fallbacks must survive parent-queue admission

expect(received).toEqual(expected) // deep equality

- Expected  - 105
+ Received  + 105

  Array [
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
-   "1.2000",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
+   "--",
  ]
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - generic [ref=e5]: 蜉蝣基金
    - generic [ref=e6]:
      - generic [ref=e7]: 15.0.2
      - emphasis [ref=e8]: 下午盘
  - generic: 下拉刷新
  - generic [ref=e10]:
    - generic [ref=e11]:
      - generic [ref=e12]: 黄金9999
      - generic [ref=e13]: "900"
      - generic [ref=e14]: +1.12%
    - generic [ref=e15]:
      - generic [ref=e16]: 上证
      - generic [ref=e17]: "10"
      - generic [ref=e18]: +1.00%
    - generic [ref=e19]:
      - generic [ref=e20]: 沪深300
      - generic [ref=e21]: "10"
      - generic [ref=e22]: +1.00%
    - generic [ref=e23]:
      - generic [ref=e24]:
        - text: 纳指100
        - generic [ref=e25]: 旧
      - generic [ref=e26]: "10"
      - generic [ref=e27]: +1.00%
    - generic [ref=e28]:
      - generic [ref=e29]:
        - text: 标普500
        - generic [ref=e30]: 旧
      - generic [ref=e31]: "10"
      - generic [ref=e32]: +1.00%
  - generic [ref=e33]: 最新可信数据 2026-09-28 · 今日估算 0/105
  - generic [ref=e34]:
    - button "可信等级优先 · 涨跌 ↓" [ref=e36] [cursor=pointer]
    - generic [ref=e37]:
      - generic [ref=e38]: 名称 / 代码
      - generic [ref=e39]: 当前显示涨跌
      - generic [ref=e40]: 显示值 / 基准净值
    - generic [ref=e41]:
      - article [ref=e42]:
        - button "合成日本基金0 仅关注 200000 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e43] [cursor=pointer]:
          - generic [ref=e44]:
            - generic [ref=e45]:
              - generic [ref=e46]: 合成日本基金0 仅关注
              - generic [ref=e47]: 200000 · 最新正式净值 2026-09-28
            - generic [ref=e48]:
              - generic [ref=e49]: +0.84%
              - generic [ref=e50]:
                - generic [ref=e51]: 最新净值涨跌
                - generic [ref=e52]: ·
                - generic [ref=e53]: 2026-09-28
              - generic [ref=e54]:
                - generic [ref=e55]: 正式净值
                - generic [ref=e56]: 基金公司已公布
            - generic [ref=e57]: 1.20001.1900
      - article [ref=e58]:
        - button "合成日本基金1 仅关注 200001 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e59] [cursor=pointer]:
          - generic [ref=e60]:
            - generic [ref=e61]:
              - generic [ref=e62]: 合成日本基金1 仅关注
              - generic [ref=e63]: 200001 · 最新正式净值 2026-09-28
            - generic [ref=e64]:
              - generic [ref=e65]: +0.84%
              - generic [ref=e66]:
                - generic [ref=e67]: 最新净值涨跌
                - generic [ref=e68]: ·
                - generic [ref=e69]: 2026-09-28
              - generic [ref=e70]:
                - generic [ref=e71]: 正式净值
                - generic [ref=e72]: 基金公司已公布
            - generic [ref=e73]: 1.20001.1900
      - article [ref=e74]:
        - button "合成日本基金2 仅关注 200002 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e75] [cursor=pointer]:
          - generic [ref=e76]:
            - generic [ref=e77]:
              - generic [ref=e78]: 合成日本基金2 仅关注
              - generic [ref=e79]: 200002 · 最新正式净值 2026-09-28
            - generic [ref=e80]:
              - generic [ref=e81]: +0.84%
              - generic [ref=e82]:
                - generic [ref=e83]: 最新净值涨跌
                - generic [ref=e84]: ·
                - generic [ref=e85]: 2026-09-28
              - generic [ref=e86]:
                - generic [ref=e87]: 正式净值
                - generic [ref=e88]: 基金公司已公布
            - generic [ref=e89]: 1.20001.1900
      - article [ref=e90]:
        - button "合成日本基金3 仅关注 200003 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e91] [cursor=pointer]:
          - generic [ref=e92]:
            - generic [ref=e93]:
              - generic [ref=e94]: 合成日本基金3 仅关注
              - generic [ref=e95]: 200003 · 最新正式净值 2026-09-28
            - generic [ref=e96]:
              - generic [ref=e97]: +0.84%
              - generic [ref=e98]:
                - generic [ref=e99]: 最新净值涨跌
                - generic [ref=e100]: ·
                - generic [ref=e101]: 2026-09-28
              - generic [ref=e102]:
                - generic [ref=e103]: 正式净值
                - generic [ref=e104]: 基金公司已公布
            - generic [ref=e105]: 1.20001.1900
      - article [ref=e106]:
        - button "合成日本基金4 仅关注 200004 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e107] [cursor=pointer]:
          - generic [ref=e108]:
            - generic [ref=e109]:
              - generic [ref=e110]: 合成日本基金4 仅关注
              - generic [ref=e111]: 200004 · 最新正式净值 2026-09-28
            - generic [ref=e112]:
              - generic [ref=e113]: +0.84%
              - generic [ref=e114]:
                - generic [ref=e115]: 最新净值涨跌
                - generic [ref=e116]: ·
                - generic [ref=e117]: 2026-09-28
              - generic [ref=e118]:
                - generic [ref=e119]: 正式净值
                - generic [ref=e120]: 基金公司已公布
            - generic [ref=e121]: 1.20001.1900
      - article [ref=e122]:
        - button "合成日本基金5 仅关注 200005 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e123] [cursor=pointer]:
          - generic [ref=e124]:
            - generic [ref=e125]:
              - generic [ref=e126]: 合成日本基金5 仅关注
              - generic [ref=e127]: 200005 · 最新正式净值 2026-09-28
            - generic [ref=e128]:
              - generic [ref=e129]: +0.84%
              - generic [ref=e130]:
                - generic [ref=e131]: 最新净值涨跌
                - generic [ref=e132]: ·
                - generic [ref=e133]: 2026-09-28
              - generic [ref=e134]:
                - generic [ref=e135]: 正式净值
                - generic [ref=e136]: 基金公司已公布
            - generic [ref=e137]: 1.20001.1900
      - article [ref=e138]:
        - button "合成日本基金6 仅关注 200006 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e139] [cursor=pointer]:
          - generic [ref=e140]:
            - generic [ref=e141]:
              - generic [ref=e142]: 合成日本基金6 仅关注
              - generic [ref=e143]: 200006 · 最新正式净值 2026-09-28
            - generic [ref=e144]:
              - generic [ref=e145]: +0.84%
              - generic [ref=e146]:
                - generic [ref=e147]: 最新净值涨跌
                - generic [ref=e148]: ·
                - generic [ref=e149]: 2026-09-28
              - generic [ref=e150]:
                - generic [ref=e151]: 正式净值
                - generic [ref=e152]: 基金公司已公布
            - generic [ref=e153]: 1.20001.1900
      - article [ref=e154]:
        - button "合成日本基金7 仅关注 200007 · 最新正式净值 2026-09-28 +0.84% 最新净值涨跌 2026-09-28 正式净值 基金公司已公布 1.20001.1900" [ref=e155] [cursor=pointer]:
          - generic [ref=e156]:
            - generic [ref=e157]:
              - generic [ref=e158]: 合成日本基金7 仅关注
              - generic [ref=e159]: 200007 · 最新正式净值 2026-09-28
            - generic [ref=e160]:
              - generic [ref=e161]: +0.84%
              - generic [ref=e162]:
                - generic [ref=e163]: 最新净值涨跌
                - generic [ref=e164]: ·
                - generic [ref=e165]: 2026-09-28
              - generic [ref=e166]:
                - generic [ref=e167]: 正式净值
                - generic [ref=e168]: 基金公司已公布
            - generic [ref=e169]: 1.20001.1900
      - article [ref=e170]:
        - button "合成日本基金8 仅关注 200008 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e171] [cursor=pointer]:
          - generic [ref=e172]:
            - generic [ref=e173]:
              - generic [ref=e174]: 合成日本基金8 仅关注
              - generic [ref=e175]: 200008 · 最新正式净值 待更新
            - generic [ref=e176]:
              - generic [ref=e177]: "--"
              - generic [ref=e178]:
                - generic [ref=e179]: 暂不可估值
                - generic [ref=e180]: ·
                - generic [ref=e181]: "--"
              - generic [ref=e182]:
                - generic [ref=e183]: 暂不可用
                - generic [ref=e184]: 无可用数据源
            - generic [ref=e185]: "----"
      - article [ref=e186]:
        - button "合成日本基金9 仅关注 200009 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e187] [cursor=pointer]:
          - generic [ref=e188]:
            - generic [ref=e189]:
              - generic [ref=e190]: 合成日本基金9 仅关注
              - generic [ref=e191]: 200009 · 最新正式净值 待更新
            - generic [ref=e192]:
              - generic [ref=e193]: "--"
              - generic [ref=e194]:
                - generic [ref=e195]: 暂不可估值
                - generic [ref=e196]: ·
                - generic [ref=e197]: "--"
              - generic [ref=e198]:
                - generic [ref=e199]: 暂不可用
                - generic [ref=e200]: 无可用数据源
            - generic [ref=e201]: "----"
      - article [ref=e202]:
        - button "合成日本基金10 仅关注 200010 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e203] [cursor=pointer]:
          - generic [ref=e204]:
            - generic [ref=e205]:
              - generic [ref=e206]: 合成日本基金10 仅关注
              - generic [ref=e207]: 200010 · 最新正式净值 待更新
            - generic [ref=e208]:
              - generic [ref=e209]: "--"
              - generic [ref=e210]:
                - generic [ref=e211]: 暂不可估值
                - generic [ref=e212]: ·
                - generic [ref=e213]: "--"
              - generic [ref=e214]:
                - generic [ref=e215]: 暂不可用
                - generic [ref=e216]: 无可用数据源
            - generic [ref=e217]: "----"
      - article [ref=e218]:
        - button "合成日本基金11 仅关注 200011 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e219] [cursor=pointer]:
          - generic [ref=e220]:
            - generic [ref=e221]:
              - generic [ref=e222]: 合成日本基金11 仅关注
              - generic [ref=e223]: 200011 · 最新正式净值 待更新
            - generic [ref=e224]:
              - generic [ref=e225]: "--"
              - generic [ref=e226]:
                - generic [ref=e227]: 暂不可估值
                - generic [ref=e228]: ·
                - generic [ref=e229]: "--"
              - generic [ref=e230]:
                - generic [ref=e231]: 暂不可用
                - generic [ref=e232]: 无可用数据源
            - generic [ref=e233]: "----"
      - article [ref=e234]:
        - button "合成日本基金12 仅关注 200012 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e235] [cursor=pointer]:
          - generic [ref=e236]:
            - generic [ref=e237]:
              - generic [ref=e238]: 合成日本基金12 仅关注
              - generic [ref=e239]: 200012 · 最新正式净值 待更新
            - generic [ref=e240]:
              - generic [ref=e241]: "--"
              - generic [ref=e242]:
                - generic [ref=e243]: 暂不可估值
                - generic [ref=e244]: ·
                - generic [ref=e245]: "--"
              - generic [ref=e246]:
                - generic [ref=e247]: 暂不可用
                - generic [ref=e248]: 无可用数据源
            - generic [ref=e249]: "----"
      - article [ref=e250]:
        - button "合成日本基金13 仅关注 200013 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e251] [cursor=pointer]:
          - generic [ref=e252]:
            - generic [ref=e253]:
              - generic [ref=e254]: 合成日本基金13 仅关注
              - generic [ref=e255]: 200013 · 最新正式净值 待更新
            - generic [ref=e256]:
              - generic [ref=e257]: "--"
              - generic [ref=e258]:
                - generic [ref=e259]: 暂不可估值
                - generic [ref=e260]: ·
                - generic [ref=e261]: "--"
              - generic [ref=e262]:
                - generic [ref=e263]: 暂不可用
                - generic [ref=e264]: 无可用数据源
            - generic [ref=e265]: "----"
      - article [ref=e266]:
        - button "合成日本基金14 仅关注 200014 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e267] [cursor=pointer]:
          - generic [ref=e268]:
            - generic [ref=e269]:
              - generic [ref=e270]: 合成日本基金14 仅关注
              - generic [ref=e271]: 200014 · 最新正式净值 待更新
            - generic [ref=e272]:
              - generic [ref=e273]: "--"
              - generic [ref=e274]:
                - generic [ref=e275]: 暂不可估值
                - generic [ref=e276]: ·
                - generic [ref=e277]: "--"
              - generic [ref=e278]:
                - generic [ref=e279]: 暂不可用
                - generic [ref=e280]: 无可用数据源
            - generic [ref=e281]: "----"
      - article [ref=e282]:
        - button "合成日本基金15 仅关注 200015 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e283] [cursor=pointer]:
          - generic [ref=e284]:
            - generic [ref=e285]:
              - generic [ref=e286]: 合成日本基金15 仅关注
              - generic [ref=e287]: 200015 · 最新正式净值 待更新
            - generic [ref=e288]:
              - generic [ref=e289]: "--"
              - generic [ref=e290]:
                - generic [ref=e291]: 暂不可估值
                - generic [ref=e292]: ·
                - generic [ref=e293]: "--"
              - generic [ref=e294]:
                - generic [ref=e295]: 暂不可用
                - generic [ref=e296]: 无可用数据源
            - generic [ref=e297]: "----"
      - article [ref=e298]:
        - button "合成日本基金16 仅关注 200016 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e299] [cursor=pointer]:
          - generic [ref=e300]:
            - generic [ref=e301]:
              - generic [ref=e302]: 合成日本基金16 仅关注
              - generic [ref=e303]: 200016 · 最新正式净值 待更新
            - generic [ref=e304]:
              - generic [ref=e305]: "--"
              - generic [ref=e306]:
                - generic [ref=e307]: 暂不可估值
                - generic [ref=e308]: ·
                - generic [ref=e309]: "--"
              - generic [ref=e310]:
                - generic [ref=e311]: 暂不可用
                - generic [ref=e312]: 无可用数据源
            - generic [ref=e313]: "----"
      - article [ref=e314]:
        - button "合成日本基金17 仅关注 200017 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e315] [cursor=pointer]:
          - generic [ref=e316]:
            - generic [ref=e317]:
              - generic [ref=e318]: 合成日本基金17 仅关注
              - generic [ref=e319]: 200017 · 最新正式净值 待更新
            - generic [ref=e320]:
              - generic [ref=e321]: "--"
              - generic [ref=e322]:
                - generic [ref=e323]: 暂不可估值
                - generic [ref=e324]: ·
                - generic [ref=e325]: "--"
              - generic [ref=e326]:
                - generic [ref=e327]: 暂不可用
                - generic [ref=e328]: 无可用数据源
            - generic [ref=e329]: "----"
      - article [ref=e330]:
        - button "合成日本基金18 仅关注 200018 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e331] [cursor=pointer]:
          - generic [ref=e332]:
            - generic [ref=e333]:
              - generic [ref=e334]: 合成日本基金18 仅关注
              - generic [ref=e335]: 200018 · 最新正式净值 待更新
            - generic [ref=e336]:
              - generic [ref=e337]: "--"
              - generic [ref=e338]:
                - generic [ref=e339]: 暂不可估值
                - generic [ref=e340]: ·
                - generic [ref=e341]: "--"
              - generic [ref=e342]:
                - generic [ref=e343]: 暂不可用
                - generic [ref=e344]: 无可用数据源
            - generic [ref=e345]: "----"
      - article [ref=e346]:
        - button "合成日本基金19 仅关注 200019 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e347] [cursor=pointer]:
          - generic [ref=e348]:
            - generic [ref=e349]:
              - generic [ref=e350]: 合成日本基金19 仅关注
              - generic [ref=e351]: 200019 · 最新正式净值 待更新
            - generic [ref=e352]:
              - generic [ref=e353]: "--"
              - generic [ref=e354]:
                - generic [ref=e355]: 暂不可估值
                - generic [ref=e356]: ·
                - generic [ref=e357]: "--"
              - generic [ref=e358]:
                - generic [ref=e359]: 暂不可用
                - generic [ref=e360]: 无可用数据源
            - generic [ref=e361]: "----"
      - article [ref=e362]:
        - button "合成日本基金20 仅关注 200020 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e363] [cursor=pointer]:
          - generic [ref=e364]:
            - generic [ref=e365]:
              - generic [ref=e366]: 合成日本基金20 仅关注
              - generic [ref=e367]: 200020 · 最新正式净值 待更新
            - generic [ref=e368]:
              - generic [ref=e369]: "--"
              - generic [ref=e370]:
                - generic [ref=e371]: 暂不可估值
                - generic [ref=e372]: ·
                - generic [ref=e373]: "--"
              - generic [ref=e374]:
                - generic [ref=e375]: 暂不可用
                - generic [ref=e376]: 无可用数据源
            - generic [ref=e377]: "----"
      - article [ref=e378]:
        - button "合成日本基金21 仅关注 200021 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e379] [cursor=pointer]:
          - generic [ref=e380]:
            - generic [ref=e381]:
              - generic [ref=e382]: 合成日本基金21 仅关注
              - generic [ref=e383]: 200021 · 最新正式净值 待更新
            - generic [ref=e384]:
              - generic [ref=e385]: "--"
              - generic [ref=e386]:
                - generic [ref=e387]: 暂不可估值
                - generic [ref=e388]: ·
                - generic [ref=e389]: "--"
              - generic [ref=e390]:
                - generic [ref=e391]: 暂不可用
                - generic [ref=e392]: 无可用数据源
            - generic [ref=e393]: "----"
      - article [ref=e394]:
        - button "合成日本基金22 仅关注 200022 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e395] [cursor=pointer]:
          - generic [ref=e396]:
            - generic [ref=e397]:
              - generic [ref=e398]: 合成日本基金22 仅关注
              - generic [ref=e399]: 200022 · 最新正式净值 待更新
            - generic [ref=e400]:
              - generic [ref=e401]: "--"
              - generic [ref=e402]:
                - generic [ref=e403]: 暂不可估值
                - generic [ref=e404]: ·
                - generic [ref=e405]: "--"
              - generic [ref=e406]:
                - generic [ref=e407]: 暂不可用
                - generic [ref=e408]: 无可用数据源
            - generic [ref=e409]: "----"
      - article [ref=e410]:
        - button "合成日本基金23 仅关注 200023 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e411] [cursor=pointer]:
          - generic [ref=e412]:
            - generic [ref=e413]:
              - generic [ref=e414]: 合成日本基金23 仅关注
              - generic [ref=e415]: 200023 · 最新正式净值 待更新
            - generic [ref=e416]:
              - generic [ref=e417]: "--"
              - generic [ref=e418]:
                - generic [ref=e419]: 暂不可估值
                - generic [ref=e420]: ·
                - generic [ref=e421]: "--"
              - generic [ref=e422]:
                - generic [ref=e423]: 暂不可用
                - generic [ref=e424]: 无可用数据源
            - generic [ref=e425]: "----"
      - article [ref=e426]:
        - button "合成日本基金24 仅关注 200024 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e427] [cursor=pointer]:
          - generic [ref=e428]:
            - generic [ref=e429]:
              - generic [ref=e430]: 合成日本基金24 仅关注
              - generic [ref=e431]: 200024 · 最新正式净值 待更新
            - generic [ref=e432]:
              - generic [ref=e433]: "--"
              - generic [ref=e434]:
                - generic [ref=e435]: 暂不可估值
                - generic [ref=e436]: ·
                - generic [ref=e437]: "--"
              - generic [ref=e438]:
                - generic [ref=e439]: 暂不可用
                - generic [ref=e440]: 无可用数据源
            - generic [ref=e441]: "----"
      - article [ref=e442]:
        - button "合成日本基金25 仅关注 200025 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e443] [cursor=pointer]:
          - generic [ref=e444]:
            - generic [ref=e445]:
              - generic [ref=e446]: 合成日本基金25 仅关注
              - generic [ref=e447]: 200025 · 最新正式净值 待更新
            - generic [ref=e448]:
              - generic [ref=e449]: "--"
              - generic [ref=e450]:
                - generic [ref=e451]: 暂不可估值
                - generic [ref=e452]: ·
                - generic [ref=e453]: "--"
              - generic [ref=e454]:
                - generic [ref=e455]: 暂不可用
                - generic [ref=e456]: 无可用数据源
            - generic [ref=e457]: "----"
      - article [ref=e458]:
        - button "合成日本基金26 仅关注 200026 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e459] [cursor=pointer]:
          - generic [ref=e460]:
            - generic [ref=e461]:
              - generic [ref=e462]: 合成日本基金26 仅关注
              - generic [ref=e463]: 200026 · 最新正式净值 待更新
            - generic [ref=e464]:
              - generic [ref=e465]: "--"
              - generic [ref=e466]:
                - generic [ref=e467]: 暂不可估值
                - generic [ref=e468]: ·
                - generic [ref=e469]: "--"
              - generic [ref=e470]:
                - generic [ref=e471]: 暂不可用
                - generic [ref=e472]: 无可用数据源
            - generic [ref=e473]: "----"
      - article [ref=e474]:
        - button "合成日本基金27 仅关注 200027 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e475] [cursor=pointer]:
          - generic [ref=e476]:
            - generic [ref=e477]:
              - generic [ref=e478]: 合成日本基金27 仅关注
              - generic [ref=e479]: 200027 · 最新正式净值 待更新
            - generic [ref=e480]:
              - generic [ref=e481]: "--"
              - generic [ref=e482]:
                - generic [ref=e483]: 暂不可估值
                - generic [ref=e484]: ·
                - generic [ref=e485]: "--"
              - generic [ref=e486]:
                - generic [ref=e487]: 暂不可用
                - generic [ref=e488]: 无可用数据源
            - generic [ref=e489]: "----"
      - article [ref=e490]:
        - button "合成日本基金28 仅关注 200028 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e491] [cursor=pointer]:
          - generic [ref=e492]:
            - generic [ref=e493]:
              - generic [ref=e494]: 合成日本基金28 仅关注
              - generic [ref=e495]: 200028 · 最新正式净值 待更新
            - generic [ref=e496]:
              - generic [ref=e497]: "--"
              - generic [ref=e498]:
                - generic [ref=e499]: 暂不可估值
                - generic [ref=e500]: ·
                - generic [ref=e501]: "--"
              - generic [ref=e502]:
                - generic [ref=e503]: 暂不可用
                - generic [ref=e504]: 无可用数据源
            - generic [ref=e505]: "----"
      - article [ref=e506]:
        - button "合成日本基金29 仅关注 200029 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e507] [cursor=pointer]:
          - generic [ref=e508]:
            - generic [ref=e509]:
              - generic [ref=e510]: 合成日本基金29 仅关注
              - generic [ref=e511]: 200029 · 最新正式净值 待更新
            - generic [ref=e512]:
              - generic [ref=e513]: "--"
              - generic [ref=e514]:
                - generic [ref=e515]: 暂不可估值
                - generic [ref=e516]: ·
                - generic [ref=e517]: "--"
              - generic [ref=e518]:
                - generic [ref=e519]: 暂不可用
                - generic [ref=e520]: 无可用数据源
            - generic [ref=e521]: "----"
      - article [ref=e522]:
        - button "合成日本基金30 仅关注 200030 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e523] [cursor=pointer]:
          - generic [ref=e524]:
            - generic [ref=e525]:
              - generic [ref=e526]: 合成日本基金30 仅关注
              - generic [ref=e527]: 200030 · 最新正式净值 待更新
            - generic [ref=e528]:
              - generic [ref=e529]: "--"
              - generic [ref=e530]:
                - generic [ref=e531]: 暂不可估值
                - generic [ref=e532]: ·
                - generic [ref=e533]: "--"
              - generic [ref=e534]:
                - generic [ref=e535]: 暂不可用
                - generic [ref=e536]: 无可用数据源
            - generic [ref=e537]: "----"
      - article [ref=e538]:
        - button "合成日本基金31 仅关注 200031 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e539] [cursor=pointer]:
          - generic [ref=e540]:
            - generic [ref=e541]:
              - generic [ref=e542]: 合成日本基金31 仅关注
              - generic [ref=e543]: 200031 · 最新正式净值 待更新
            - generic [ref=e544]:
              - generic [ref=e545]: "--"
              - generic [ref=e546]:
                - generic [ref=e547]: 暂不可估值
                - generic [ref=e548]: ·
                - generic [ref=e549]: "--"
              - generic [ref=e550]:
                - generic [ref=e551]: 暂不可用
                - generic [ref=e552]: 无可用数据源
            - generic [ref=e553]: "----"
      - article [ref=e554]:
        - button "合成日本基金32 仅关注 200032 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e555] [cursor=pointer]:
          - generic [ref=e556]:
            - generic [ref=e557]:
              - generic [ref=e558]: 合成日本基金32 仅关注
              - generic [ref=e559]: 200032 · 最新正式净值 待更新
            - generic [ref=e560]:
              - generic [ref=e561]: "--"
              - generic [ref=e562]:
                - generic [ref=e563]: 暂不可估值
                - generic [ref=e564]: ·
                - generic [ref=e565]: "--"
              - generic [ref=e566]:
                - generic [ref=e567]: 暂不可用
                - generic [ref=e568]: 无可用数据源
            - generic [ref=e569]: "----"
      - article [ref=e570]:
        - button "合成日本基金33 仅关注 200033 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e571] [cursor=pointer]:
          - generic [ref=e572]:
            - generic [ref=e573]:
              - generic [ref=e574]: 合成日本基金33 仅关注
              - generic [ref=e575]: 200033 · 最新正式净值 待更新
            - generic [ref=e576]:
              - generic [ref=e577]: "--"
              - generic [ref=e578]:
                - generic [ref=e579]: 暂不可估值
                - generic [ref=e580]: ·
                - generic [ref=e581]: "--"
              - generic [ref=e582]:
                - generic [ref=e583]: 暂不可用
                - generic [ref=e584]: 无可用数据源
            - generic [ref=e585]: "----"
      - article [ref=e586]:
        - button "合成日本基金34 仅关注 200034 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e587] [cursor=pointer]:
          - generic [ref=e588]:
            - generic [ref=e589]:
              - generic [ref=e590]: 合成日本基金34 仅关注
              - generic [ref=e591]: 200034 · 最新正式净值 待更新
            - generic [ref=e592]:
              - generic [ref=e593]: "--"
              - generic [ref=e594]:
                - generic [ref=e595]: 暂不可估值
                - generic [ref=e596]: ·
                - generic [ref=e597]: "--"
              - generic [ref=e598]:
                - generic [ref=e599]: 暂不可用
                - generic [ref=e600]: 无可用数据源
            - generic [ref=e601]: "----"
      - article [ref=e602]:
        - button "合成日本基金35 仅关注 200035 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e603] [cursor=pointer]:
          - generic [ref=e604]:
            - generic [ref=e605]:
              - generic [ref=e606]: 合成日本基金35 仅关注
              - generic [ref=e607]: 200035 · 最新正式净值 待更新
            - generic [ref=e608]:
              - generic [ref=e609]: "--"
              - generic [ref=e610]:
                - generic [ref=e611]: 暂不可估值
                - generic [ref=e612]: ·
                - generic [ref=e613]: "--"
              - generic [ref=e614]:
                - generic [ref=e615]: 暂不可用
                - generic [ref=e616]: 无可用数据源
            - generic [ref=e617]: "----"
      - article [ref=e618]:
        - button "合成日本基金36 仅关注 200036 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e619] [cursor=pointer]:
          - generic [ref=e620]:
            - generic [ref=e621]:
              - generic [ref=e622]: 合成日本基金36 仅关注
              - generic [ref=e623]: 200036 · 最新正式净值 待更新
            - generic [ref=e624]:
              - generic [ref=e625]: "--"
              - generic [ref=e626]:
                - generic [ref=e627]: 暂不可估值
                - generic [ref=e628]: ·
                - generic [ref=e629]: "--"
              - generic [ref=e630]:
                - generic [ref=e631]: 暂不可用
                - generic [ref=e632]: 无可用数据源
            - generic [ref=e633]: "----"
      - article [ref=e634]:
        - button "合成日本基金37 仅关注 200037 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e635] [cursor=pointer]:
          - generic [ref=e636]:
            - generic [ref=e637]:
              - generic [ref=e638]: 合成日本基金37 仅关注
              - generic [ref=e639]: 200037 · 最新正式净值 待更新
            - generic [ref=e640]:
              - generic [ref=e641]: "--"
              - generic [ref=e642]:
                - generic [ref=e643]: 暂不可估值
                - generic [ref=e644]: ·
                - generic [ref=e645]: "--"
              - generic [ref=e646]:
                - generic [ref=e647]: 暂不可用
                - generic [ref=e648]: 无可用数据源
            - generic [ref=e649]: "----"
      - article [ref=e650]:
        - button "合成日本基金38 仅关注 200038 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e651] [cursor=pointer]:
          - generic [ref=e652]:
            - generic [ref=e653]:
              - generic [ref=e654]: 合成日本基金38 仅关注
              - generic [ref=e655]: 200038 · 最新正式净值 待更新
            - generic [ref=e656]:
              - generic [ref=e657]: "--"
              - generic [ref=e658]:
                - generic [ref=e659]: 暂不可估值
                - generic [ref=e660]: ·
                - generic [ref=e661]: "--"
              - generic [ref=e662]:
                - generic [ref=e663]: 暂不可用
                - generic [ref=e664]: 无可用数据源
            - generic [ref=e665]: "----"
      - article [ref=e666]:
        - button "合成日本基金39 仅关注 200039 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e667] [cursor=pointer]:
          - generic [ref=e668]:
            - generic [ref=e669]:
              - generic [ref=e670]: 合成日本基金39 仅关注
              - generic [ref=e671]: 200039 · 最新正式净值 待更新
            - generic [ref=e672]:
              - generic [ref=e673]: "--"
              - generic [ref=e674]:
                - generic [ref=e675]: 暂不可估值
                - generic [ref=e676]: ·
                - generic [ref=e677]: "--"
              - generic [ref=e678]:
                - generic [ref=e679]: 暂不可用
                - generic [ref=e680]: 无可用数据源
            - generic [ref=e681]: "----"
      - article [ref=e682]:
        - button "合成日本基金40 仅关注 200040 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e683] [cursor=pointer]:
          - generic [ref=e684]:
            - generic [ref=e685]:
              - generic [ref=e686]: 合成日本基金40 仅关注
              - generic [ref=e687]: 200040 · 最新正式净值 待更新
            - generic [ref=e688]:
              - generic [ref=e689]: "--"
              - generic [ref=e690]:
                - generic [ref=e691]: 暂不可估值
                - generic [ref=e692]: ·
                - generic [ref=e693]: "--"
              - generic [ref=e694]:
                - generic [ref=e695]: 暂不可用
                - generic [ref=e696]: 无可用数据源
            - generic [ref=e697]: "----"
      - article [ref=e698]:
        - button "合成日本基金41 仅关注 200041 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e699] [cursor=pointer]:
          - generic [ref=e700]:
            - generic [ref=e701]:
              - generic [ref=e702]: 合成日本基金41 仅关注
              - generic [ref=e703]: 200041 · 最新正式净值 待更新
            - generic [ref=e704]:
              - generic [ref=e705]: "--"
              - generic [ref=e706]:
                - generic [ref=e707]: 暂不可估值
                - generic [ref=e708]: ·
                - generic [ref=e709]: "--"
              - generic [ref=e710]:
                - generic [ref=e711]: 暂不可用
                - generic [ref=e712]: 无可用数据源
            - generic [ref=e713]: "----"
      - article [ref=e714]:
        - button "合成日本基金42 仅关注 200042 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e715] [cursor=pointer]:
          - generic [ref=e716]:
            - generic [ref=e717]:
              - generic [ref=e718]: 合成日本基金42 仅关注
              - generic [ref=e719]: 200042 · 最新正式净值 待更新
            - generic [ref=e720]:
              - generic [ref=e721]: "--"
              - generic [ref=e722]:
                - generic [ref=e723]: 暂不可估值
                - generic [ref=e724]: ·
                - generic [ref=e725]: "--"
              - generic [ref=e726]:
                - generic [ref=e727]: 暂不可用
                - generic [ref=e728]: 无可用数据源
            - generic [ref=e729]: "----"
      - article [ref=e730]:
        - button "合成日本基金43 仅关注 200043 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e731] [cursor=pointer]:
          - generic [ref=e732]:
            - generic [ref=e733]:
              - generic [ref=e734]: 合成日本基金43 仅关注
              - generic [ref=e735]: 200043 · 最新正式净值 待更新
            - generic [ref=e736]:
              - generic [ref=e737]: "--"
              - generic [ref=e738]:
                - generic [ref=e739]: 暂不可估值
                - generic [ref=e740]: ·
                - generic [ref=e741]: "--"
              - generic [ref=e742]:
                - generic [ref=e743]: 暂不可用
                - generic [ref=e744]: 无可用数据源
            - generic [ref=e745]: "----"
      - article [ref=e746]:
        - button "合成日本基金44 仅关注 200044 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e747] [cursor=pointer]:
          - generic [ref=e748]:
            - generic [ref=e749]:
              - generic [ref=e750]: 合成日本基金44 仅关注
              - generic [ref=e751]: 200044 · 最新正式净值 待更新
            - generic [ref=e752]:
              - generic [ref=e753]: "--"
              - generic [ref=e754]:
                - generic [ref=e755]: 暂不可估值
                - generic [ref=e756]: ·
                - generic [ref=e757]: "--"
              - generic [ref=e758]:
                - generic [ref=e759]: 暂不可用
                - generic [ref=e760]: 无可用数据源
            - generic [ref=e761]: "----"
      - article [ref=e762]:
        - button "合成日本基金45 仅关注 200045 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e763] [cursor=pointer]:
          - generic [ref=e764]:
            - generic [ref=e765]:
              - generic [ref=e766]: 合成日本基金45 仅关注
              - generic [ref=e767]: 200045 · 最新正式净值 待更新
            - generic [ref=e768]:
              - generic [ref=e769]: "--"
              - generic [ref=e770]:
                - generic [ref=e771]: 暂不可估值
                - generic [ref=e772]: ·
                - generic [ref=e773]: "--"
              - generic [ref=e774]:
                - generic [ref=e775]: 暂不可用
                - generic [ref=e776]: 无可用数据源
            - generic [ref=e777]: "----"
      - article [ref=e778]:
        - button "合成日本基金46 仅关注 200046 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e779] [cursor=pointer]:
          - generic [ref=e780]:
            - generic [ref=e781]:
              - generic [ref=e782]: 合成日本基金46 仅关注
              - generic [ref=e783]: 200046 · 最新正式净值 待更新
            - generic [ref=e784]:
              - generic [ref=e785]: "--"
              - generic [ref=e786]:
                - generic [ref=e787]: 暂不可估值
                - generic [ref=e788]: ·
                - generic [ref=e789]: "--"
              - generic [ref=e790]:
                - generic [ref=e791]: 暂不可用
                - generic [ref=e792]: 无可用数据源
            - generic [ref=e793]: "----"
      - article [ref=e794]:
        - button "合成日本基金47 仅关注 200047 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e795] [cursor=pointer]:
          - generic [ref=e796]:
            - generic [ref=e797]:
              - generic [ref=e798]: 合成日本基金47 仅关注
              - generic [ref=e799]: 200047 · 最新正式净值 待更新
            - generic [ref=e800]:
              - generic [ref=e801]: "--"
              - generic [ref=e802]:
                - generic [ref=e803]: 暂不可估值
                - generic [ref=e804]: ·
                - generic [ref=e805]: "--"
              - generic [ref=e806]:
                - generic [ref=e807]: 暂不可用
                - generic [ref=e808]: 无可用数据源
            - generic [ref=e809]: "----"
      - article [ref=e810]:
        - button "合成日本基金48 仅关注 200048 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e811] [cursor=pointer]:
          - generic [ref=e812]:
            - generic [ref=e813]:
              - generic [ref=e814]: 合成日本基金48 仅关注
              - generic [ref=e815]: 200048 · 最新正式净值 待更新
            - generic [ref=e816]:
              - generic [ref=e817]: "--"
              - generic [ref=e818]:
                - generic [ref=e819]: 暂不可估值
                - generic [ref=e820]: ·
                - generic [ref=e821]: "--"
              - generic [ref=e822]:
                - generic [ref=e823]: 暂不可用
                - generic [ref=e824]: 无可用数据源
            - generic [ref=e825]: "----"
      - article [ref=e826]:
        - button "合成日本基金49 仅关注 200049 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e827] [cursor=pointer]:
          - generic [ref=e828]:
            - generic [ref=e829]:
              - generic [ref=e830]: 合成日本基金49 仅关注
              - generic [ref=e831]: 200049 · 最新正式净值 待更新
            - generic [ref=e832]:
              - generic [ref=e833]: "--"
              - generic [ref=e834]:
                - generic [ref=e835]: 暂不可估值
                - generic [ref=e836]: ·
                - generic [ref=e837]: "--"
              - generic [ref=e838]:
                - generic [ref=e839]: 暂不可用
                - generic [ref=e840]: 无可用数据源
            - generic [ref=e841]: "----"
      - article [ref=e842]:
        - button "合成日本基金50 仅关注 200050 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e843] [cursor=pointer]:
          - generic [ref=e844]:
            - generic [ref=e845]:
              - generic [ref=e846]: 合成日本基金50 仅关注
              - generic [ref=e847]: 200050 · 最新正式净值 待更新
            - generic [ref=e848]:
              - generic [ref=e849]: "--"
              - generic [ref=e850]:
                - generic [ref=e851]: 暂不可估值
                - generic [ref=e852]: ·
                - generic [ref=e853]: "--"
              - generic [ref=e854]:
                - generic [ref=e855]: 暂不可用
                - generic [ref=e856]: 无可用数据源
            - generic [ref=e857]: "----"
      - article [ref=e858]:
        - button "合成日本基金51 仅关注 200051 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e859] [cursor=pointer]:
          - generic [ref=e860]:
            - generic [ref=e861]:
              - generic [ref=e862]: 合成日本基金51 仅关注
              - generic [ref=e863]: 200051 · 最新正式净值 待更新
            - generic [ref=e864]:
              - generic [ref=e865]: "--"
              - generic [ref=e866]:
                - generic [ref=e867]: 暂不可估值
                - generic [ref=e868]: ·
                - generic [ref=e869]: "--"
              - generic [ref=e870]:
                - generic [ref=e871]: 暂不可用
                - generic [ref=e872]: 无可用数据源
            - generic [ref=e873]: "----"
      - article [ref=e874]:
        - button "合成日本基金52 仅关注 200052 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e875] [cursor=pointer]:
          - generic [ref=e876]:
            - generic [ref=e877]:
              - generic [ref=e878]: 合成日本基金52 仅关注
              - generic [ref=e879]: 200052 · 最新正式净值 待更新
            - generic [ref=e880]:
              - generic [ref=e881]: "--"
              - generic [ref=e882]:
                - generic [ref=e883]: 暂不可估值
                - generic [ref=e884]: ·
                - generic [ref=e885]: "--"
              - generic [ref=e886]:
                - generic [ref=e887]: 暂不可用
                - generic [ref=e888]: 无可用数据源
            - generic [ref=e889]: "----"
      - article [ref=e890]:
        - button "合成日本基金53 仅关注 200053 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e891] [cursor=pointer]:
          - generic [ref=e892]:
            - generic [ref=e893]:
              - generic [ref=e894]: 合成日本基金53 仅关注
              - generic [ref=e895]: 200053 · 最新正式净值 待更新
            - generic [ref=e896]:
              - generic [ref=e897]: "--"
              - generic [ref=e898]:
                - generic [ref=e899]: 暂不可估值
                - generic [ref=e900]: ·
                - generic [ref=e901]: "--"
              - generic [ref=e902]:
                - generic [ref=e903]: 暂不可用
                - generic [ref=e904]: 无可用数据源
            - generic [ref=e905]: "----"
      - article [ref=e906]:
        - button "合成日本基金54 仅关注 200054 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e907] [cursor=pointer]:
          - generic [ref=e908]:
            - generic [ref=e909]:
              - generic [ref=e910]: 合成日本基金54 仅关注
              - generic [ref=e911]: 200054 · 最新正式净值 待更新
            - generic [ref=e912]:
              - generic [ref=e913]: "--"
              - generic [ref=e914]:
                - generic [ref=e915]: 暂不可估值
                - generic [ref=e916]: ·
                - generic [ref=e917]: "--"
              - generic [ref=e918]:
                - generic [ref=e919]: 暂不可用
                - generic [ref=e920]: 无可用数据源
            - generic [ref=e921]: "----"
      - article [ref=e922]:
        - button "合成日本基金55 仅关注 200055 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e923] [cursor=pointer]:
          - generic [ref=e924]:
            - generic [ref=e925]:
              - generic [ref=e926]: 合成日本基金55 仅关注
              - generic [ref=e927]: 200055 · 最新正式净值 待更新
            - generic [ref=e928]:
              - generic [ref=e929]: "--"
              - generic [ref=e930]:
                - generic [ref=e931]: 暂不可估值
                - generic [ref=e932]: ·
                - generic [ref=e933]: "--"
              - generic [ref=e934]:
                - generic [ref=e935]: 暂不可用
                - generic [ref=e936]: 无可用数据源
            - generic [ref=e937]: "----"
      - article [ref=e938]:
        - button "合成日本基金56 仅关注 200056 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e939] [cursor=pointer]:
          - generic [ref=e940]:
            - generic [ref=e941]:
              - generic [ref=e942]: 合成日本基金56 仅关注
              - generic [ref=e943]: 200056 · 最新正式净值 待更新
            - generic [ref=e944]:
              - generic [ref=e945]: "--"
              - generic [ref=e946]:
                - generic [ref=e947]: 暂不可估值
                - generic [ref=e948]: ·
                - generic [ref=e949]: "--"
              - generic [ref=e950]:
                - generic [ref=e951]: 暂不可用
                - generic [ref=e952]: 无可用数据源
            - generic [ref=e953]: "----"
      - article [ref=e954]:
        - button "合成日本基金57 仅关注 200057 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e955] [cursor=pointer]:
          - generic [ref=e956]:
            - generic [ref=e957]:
              - generic [ref=e958]: 合成日本基金57 仅关注
              - generic [ref=e959]: 200057 · 最新正式净值 待更新
            - generic [ref=e960]:
              - generic [ref=e961]: "--"
              - generic [ref=e962]:
                - generic [ref=e963]: 暂不可估值
                - generic [ref=e964]: ·
                - generic [ref=e965]: "--"
              - generic [ref=e966]:
                - generic [ref=e967]: 暂不可用
                - generic [ref=e968]: 无可用数据源
            - generic [ref=e969]: "----"
      - article [ref=e970]:
        - button "合成日本基金58 仅关注 200058 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e971] [cursor=pointer]:
          - generic [ref=e972]:
            - generic [ref=e973]:
              - generic [ref=e974]: 合成日本基金58 仅关注
              - generic [ref=e975]: 200058 · 最新正式净值 待更新
            - generic [ref=e976]:
              - generic [ref=e977]: "--"
              - generic [ref=e978]:
                - generic [ref=e979]: 暂不可估值
                - generic [ref=e980]: ·
                - generic [ref=e981]: "--"
              - generic [ref=e982]:
                - generic [ref=e983]: 暂不可用
                - generic [ref=e984]: 无可用数据源
            - generic [ref=e985]: "----"
      - article [ref=e986]:
        - button "合成日本基金59 仅关注 200059 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e987] [cursor=pointer]:
          - generic [ref=e988]:
            - generic [ref=e989]:
              - generic [ref=e990]: 合成日本基金59 仅关注
              - generic [ref=e991]: 200059 · 最新正式净值 待更新
            - generic [ref=e992]:
              - generic [ref=e993]: "--"
              - generic [ref=e994]:
                - generic [ref=e995]: 暂不可估值
                - generic [ref=e996]: ·
                - generic [ref=e997]: "--"
              - generic [ref=e998]:
                - generic [ref=e999]: 暂不可用
                - generic [ref=e1000]: 无可用数据源
            - generic [ref=e1001]: "----"
      - article [ref=e1002]:
        - button "合成日本基金60 仅关注 200060 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1003] [cursor=pointer]:
          - generic [ref=e1004]:
            - generic [ref=e1005]:
              - generic [ref=e1006]: 合成日本基金60 仅关注
              - generic [ref=e1007]: 200060 · 最新正式净值 待更新
            - generic [ref=e1008]:
              - generic [ref=e1009]: "--"
              - generic [ref=e1010]:
                - generic [ref=e1011]: 暂不可估值
                - generic [ref=e1012]: ·
                - generic [ref=e1013]: "--"
              - generic [ref=e1014]:
                - generic [ref=e1015]: 暂不可用
                - generic [ref=e1016]: 无可用数据源
            - generic [ref=e1017]: "----"
      - article [ref=e1018]:
        - button "合成日本基金61 仅关注 200061 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1019] [cursor=pointer]:
          - generic [ref=e1020]:
            - generic [ref=e1021]:
              - generic [ref=e1022]: 合成日本基金61 仅关注
              - generic [ref=e1023]: 200061 · 最新正式净值 待更新
            - generic [ref=e1024]:
              - generic [ref=e1025]: "--"
              - generic [ref=e1026]:
                - generic [ref=e1027]: 暂不可估值
                - generic [ref=e1028]: ·
                - generic [ref=e1029]: "--"
              - generic [ref=e1030]:
                - generic [ref=e1031]: 暂不可用
                - generic [ref=e1032]: 无可用数据源
            - generic [ref=e1033]: "----"
      - article [ref=e1034]:
        - button "合成日本基金62 仅关注 200062 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1035] [cursor=pointer]:
          - generic [ref=e1036]:
            - generic [ref=e1037]:
              - generic [ref=e1038]: 合成日本基金62 仅关注
              - generic [ref=e1039]: 200062 · 最新正式净值 待更新
            - generic [ref=e1040]:
              - generic [ref=e1041]: "--"
              - generic [ref=e1042]:
                - generic [ref=e1043]: 暂不可估值
                - generic [ref=e1044]: ·
                - generic [ref=e1045]: "--"
              - generic [ref=e1046]:
                - generic [ref=e1047]: 暂不可用
                - generic [ref=e1048]: 无可用数据源
            - generic [ref=e1049]: "----"
      - article [ref=e1050]:
        - button "合成日本基金63 仅关注 200063 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1051] [cursor=pointer]:
          - generic [ref=e1052]:
            - generic [ref=e1053]:
              - generic [ref=e1054]: 合成日本基金63 仅关注
              - generic [ref=e1055]: 200063 · 最新正式净值 待更新
            - generic [ref=e1056]:
              - generic [ref=e1057]: "--"
              - generic [ref=e1058]:
                - generic [ref=e1059]: 暂不可估值
                - generic [ref=e1060]: ·
                - generic [ref=e1061]: "--"
              - generic [ref=e1062]:
                - generic [ref=e1063]: 暂不可用
                - generic [ref=e1064]: 无可用数据源
            - generic [ref=e1065]: "----"
      - article [ref=e1066]:
        - button "合成日本基金64 仅关注 200064 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1067] [cursor=pointer]:
          - generic [ref=e1068]:
            - generic [ref=e1069]:
              - generic [ref=e1070]: 合成日本基金64 仅关注
              - generic [ref=e1071]: 200064 · 最新正式净值 待更新
            - generic [ref=e1072]:
              - generic [ref=e1073]: "--"
              - generic [ref=e1074]:
                - generic [ref=e1075]: 暂不可估值
                - generic [ref=e1076]: ·
                - generic [ref=e1077]: "--"
              - generic [ref=e1078]:
                - generic [ref=e1079]: 暂不可用
                - generic [ref=e1080]: 无可用数据源
            - generic [ref=e1081]: "----"
      - article [ref=e1082]:
        - button "合成日本基金65 仅关注 200065 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1083] [cursor=pointer]:
          - generic [ref=e1084]:
            - generic [ref=e1085]:
              - generic [ref=e1086]: 合成日本基金65 仅关注
              - generic [ref=e1087]: 200065 · 最新正式净值 待更新
            - generic [ref=e1088]:
              - generic [ref=e1089]: "--"
              - generic [ref=e1090]:
                - generic [ref=e1091]: 暂不可估值
                - generic [ref=e1092]: ·
                - generic [ref=e1093]: "--"
              - generic [ref=e1094]:
                - generic [ref=e1095]: 暂不可用
                - generic [ref=e1096]: 无可用数据源
            - generic [ref=e1097]: "----"
      - article [ref=e1098]:
        - button "合成日本基金66 仅关注 200066 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1099] [cursor=pointer]:
          - generic [ref=e1100]:
            - generic [ref=e1101]:
              - generic [ref=e1102]: 合成日本基金66 仅关注
              - generic [ref=e1103]: 200066 · 最新正式净值 待更新
            - generic [ref=e1104]:
              - generic [ref=e1105]: "--"
              - generic [ref=e1106]:
                - generic [ref=e1107]: 暂不可估值
                - generic [ref=e1108]: ·
                - generic [ref=e1109]: "--"
              - generic [ref=e1110]:
                - generic [ref=e1111]: 暂不可用
                - generic [ref=e1112]: 无可用数据源
            - generic [ref=e1113]: "----"
      - article [ref=e1114]:
        - button "合成日本基金67 仅关注 200067 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1115] [cursor=pointer]:
          - generic [ref=e1116]:
            - generic [ref=e1117]:
              - generic [ref=e1118]: 合成日本基金67 仅关注
              - generic [ref=e1119]: 200067 · 最新正式净值 待更新
            - generic [ref=e1120]:
              - generic [ref=e1121]: "--"
              - generic [ref=e1122]:
                - generic [ref=e1123]: 暂不可估值
                - generic [ref=e1124]: ·
                - generic [ref=e1125]: "--"
              - generic [ref=e1126]:
                - generic [ref=e1127]: 暂不可用
                - generic [ref=e1128]: 无可用数据源
            - generic [ref=e1129]: "----"
      - article [ref=e1130]:
        - button "合成日本基金68 仅关注 200068 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1131] [cursor=pointer]:
          - generic [ref=e1132]:
            - generic [ref=e1133]:
              - generic [ref=e1134]: 合成日本基金68 仅关注
              - generic [ref=e1135]: 200068 · 最新正式净值 待更新
            - generic [ref=e1136]:
              - generic [ref=e1137]: "--"
              - generic [ref=e1138]:
                - generic [ref=e1139]: 暂不可估值
                - generic [ref=e1140]: ·
                - generic [ref=e1141]: "--"
              - generic [ref=e1142]:
                - generic [ref=e1143]: 暂不可用
                - generic [ref=e1144]: 无可用数据源
            - generic [ref=e1145]: "----"
      - article [ref=e1146]:
        - button "合成日本基金69 仅关注 200069 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1147] [cursor=pointer]:
          - generic [ref=e1148]:
            - generic [ref=e1149]:
              - generic [ref=e1150]: 合成日本基金69 仅关注
              - generic [ref=e1151]: 200069 · 最新正式净值 待更新
            - generic [ref=e1152]:
              - generic [ref=e1153]: "--"
              - generic [ref=e1154]:
                - generic [ref=e1155]: 暂不可估值
                - generic [ref=e1156]: ·
                - generic [ref=e1157]: "--"
              - generic [ref=e1158]:
                - generic [ref=e1159]: 暂不可用
                - generic [ref=e1160]: 无可用数据源
            - generic [ref=e1161]: "----"
      - article [ref=e1162]:
        - button "合成日本基金70 仅关注 200070 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1163] [cursor=pointer]:
          - generic [ref=e1164]:
            - generic [ref=e1165]:
              - generic [ref=e1166]: 合成日本基金70 仅关注
              - generic [ref=e1167]: 200070 · 最新正式净值 待更新
            - generic [ref=e1168]:
              - generic [ref=e1169]: "--"
              - generic [ref=e1170]:
                - generic [ref=e1171]: 暂不可估值
                - generic [ref=e1172]: ·
                - generic [ref=e1173]: "--"
              - generic [ref=e1174]:
                - generic [ref=e1175]: 暂不可用
                - generic [ref=e1176]: 无可用数据源
            - generic [ref=e1177]: "----"
      - article [ref=e1178]:
        - button "合成日本基金71 仅关注 200071 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1179] [cursor=pointer]:
          - generic [ref=e1180]:
            - generic [ref=e1181]:
              - generic [ref=e1182]: 合成日本基金71 仅关注
              - generic [ref=e1183]: 200071 · 最新正式净值 待更新
            - generic [ref=e1184]:
              - generic [ref=e1185]: "--"
              - generic [ref=e1186]:
                - generic [ref=e1187]: 暂不可估值
                - generic [ref=e1188]: ·
                - generic [ref=e1189]: "--"
              - generic [ref=e1190]:
                - generic [ref=e1191]: 暂不可用
                - generic [ref=e1192]: 无可用数据源
            - generic [ref=e1193]: "----"
      - article [ref=e1194]:
        - button "合成日本基金72 仅关注 200072 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1195] [cursor=pointer]:
          - generic [ref=e1196]:
            - generic [ref=e1197]:
              - generic [ref=e1198]: 合成日本基金72 仅关注
              - generic [ref=e1199]: 200072 · 最新正式净值 待更新
            - generic [ref=e1200]:
              - generic [ref=e1201]: "--"
              - generic [ref=e1202]:
                - generic [ref=e1203]: 暂不可估值
                - generic [ref=e1204]: ·
                - generic [ref=e1205]: "--"
              - generic [ref=e1206]:
                - generic [ref=e1207]: 暂不可用
                - generic [ref=e1208]: 无可用数据源
            - generic [ref=e1209]: "----"
      - article [ref=e1210]:
        - button "合成日本基金73 仅关注 200073 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1211] [cursor=pointer]:
          - generic [ref=e1212]:
            - generic [ref=e1213]:
              - generic [ref=e1214]: 合成日本基金73 仅关注
              - generic [ref=e1215]: 200073 · 最新正式净值 待更新
            - generic [ref=e1216]:
              - generic [ref=e1217]: "--"
              - generic [ref=e1218]:
                - generic [ref=e1219]: 暂不可估值
                - generic [ref=e1220]: ·
                - generic [ref=e1221]: "--"
              - generic [ref=e1222]:
                - generic [ref=e1223]: 暂不可用
                - generic [ref=e1224]: 无可用数据源
            - generic [ref=e1225]: "----"
      - article [ref=e1226]:
        - button "合成日本基金74 仅关注 200074 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1227] [cursor=pointer]:
          - generic [ref=e1228]:
            - generic [ref=e1229]:
              - generic [ref=e1230]: 合成日本基金74 仅关注
              - generic [ref=e1231]: 200074 · 最新正式净值 待更新
            - generic [ref=e1232]:
              - generic [ref=e1233]: "--"
              - generic [ref=e1234]:
                - generic [ref=e1235]: 暂不可估值
                - generic [ref=e1236]: ·
                - generic [ref=e1237]: "--"
              - generic [ref=e1238]:
                - generic [ref=e1239]: 暂不可用
                - generic [ref=e1240]: 无可用数据源
            - generic [ref=e1241]: "----"
      - article [ref=e1242]:
        - button "合成日本基金75 仅关注 200075 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1243] [cursor=pointer]:
          - generic [ref=e1244]:
            - generic [ref=e1245]:
              - generic [ref=e1246]: 合成日本基金75 仅关注
              - generic [ref=e1247]: 200075 · 最新正式净值 待更新
            - generic [ref=e1248]:
              - generic [ref=e1249]: "--"
              - generic [ref=e1250]:
                - generic [ref=e1251]: 暂不可估值
                - generic [ref=e1252]: ·
                - generic [ref=e1253]: "--"
              - generic [ref=e1254]:
                - generic [ref=e1255]: 暂不可用
                - generic [ref=e1256]: 无可用数据源
            - generic [ref=e1257]: "----"
      - article [ref=e1258]:
        - button "合成日本基金76 仅关注 200076 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1259] [cursor=pointer]:
          - generic [ref=e1260]:
            - generic [ref=e1261]:
              - generic [ref=e1262]: 合成日本基金76 仅关注
              - generic [ref=e1263]: 200076 · 最新正式净值 待更新
            - generic [ref=e1264]:
              - generic [ref=e1265]: "--"
              - generic [ref=e1266]:
                - generic [ref=e1267]: 暂不可估值
                - generic [ref=e1268]: ·
                - generic [ref=e1269]: "--"
              - generic [ref=e1270]:
                - generic [ref=e1271]: 暂不可用
                - generic [ref=e1272]: 无可用数据源
            - generic [ref=e1273]: "----"
      - article [ref=e1274]:
        - button "合成日本基金77 仅关注 200077 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1275] [cursor=pointer]:
          - generic [ref=e1276]:
            - generic [ref=e1277]:
              - generic [ref=e1278]: 合成日本基金77 仅关注
              - generic [ref=e1279]: 200077 · 最新正式净值 待更新
            - generic [ref=e1280]:
              - generic [ref=e1281]: "--"
              - generic [ref=e1282]:
                - generic [ref=e1283]: 暂不可估值
                - generic [ref=e1284]: ·
                - generic [ref=e1285]: "--"
              - generic [ref=e1286]:
                - generic [ref=e1287]: 暂不可用
                - generic [ref=e1288]: 无可用数据源
            - generic [ref=e1289]: "----"
      - article [ref=e1290]:
        - button "合成日本基金78 仅关注 200078 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1291] [cursor=pointer]:
          - generic [ref=e1292]:
            - generic [ref=e1293]:
              - generic [ref=e1294]: 合成日本基金78 仅关注
              - generic [ref=e1295]: 200078 · 最新正式净值 待更新
            - generic [ref=e1296]:
              - generic [ref=e1297]: "--"
              - generic [ref=e1298]:
                - generic [ref=e1299]: 暂不可估值
                - generic [ref=e1300]: ·
                - generic [ref=e1301]: "--"
              - generic [ref=e1302]:
                - generic [ref=e1303]: 暂不可用
                - generic [ref=e1304]: 无可用数据源
            - generic [ref=e1305]: "----"
      - article [ref=e1306]:
        - button "合成日本基金79 仅关注 200079 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1307] [cursor=pointer]:
          - generic [ref=e1308]:
            - generic [ref=e1309]:
              - generic [ref=e1310]: 合成日本基金79 仅关注
              - generic [ref=e1311]: 200079 · 最新正式净值 待更新
            - generic [ref=e1312]:
              - generic [ref=e1313]: "--"
              - generic [ref=e1314]:
                - generic [ref=e1315]: 暂不可估值
                - generic [ref=e1316]: ·
                - generic [ref=e1317]: "--"
              - generic [ref=e1318]:
                - generic [ref=e1319]: 暂不可用
                - generic [ref=e1320]: 无可用数据源
            - generic [ref=e1321]: "----"
      - article [ref=e1322]:
        - button "合成日本基金80 仅关注 200080 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1323] [cursor=pointer]:
          - generic [ref=e1324]:
            - generic [ref=e1325]:
              - generic [ref=e1326]: 合成日本基金80 仅关注
              - generic [ref=e1327]: 200080 · 最新正式净值 待更新
            - generic [ref=e1328]:
              - generic [ref=e1329]: "--"
              - generic [ref=e1330]:
                - generic [ref=e1331]: 暂不可估值
                - generic [ref=e1332]: ·
                - generic [ref=e1333]: "--"
              - generic [ref=e1334]:
                - generic [ref=e1335]: 暂不可用
                - generic [ref=e1336]: 无可用数据源
            - generic [ref=e1337]: "----"
      - article [ref=e1338]:
        - button "合成日本基金81 仅关注 200081 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1339] [cursor=pointer]:
          - generic [ref=e1340]:
            - generic [ref=e1341]:
              - generic [ref=e1342]: 合成日本基金81 仅关注
              - generic [ref=e1343]: 200081 · 最新正式净值 待更新
            - generic [ref=e1344]:
              - generic [ref=e1345]: "--"
              - generic [ref=e1346]:
                - generic [ref=e1347]: 暂不可估值
                - generic [ref=e1348]: ·
                - generic [ref=e1349]: "--"
              - generic [ref=e1350]:
                - generic [ref=e1351]: 暂不可用
                - generic [ref=e1352]: 无可用数据源
            - generic [ref=e1353]: "----"
      - article [ref=e1354]:
        - button "合成日本基金82 仅关注 200082 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1355] [cursor=pointer]:
          - generic [ref=e1356]:
            - generic [ref=e1357]:
              - generic [ref=e1358]: 合成日本基金82 仅关注
              - generic [ref=e1359]: 200082 · 最新正式净值 待更新
            - generic [ref=e1360]:
              - generic [ref=e1361]: "--"
              - generic [ref=e1362]:
                - generic [ref=e1363]: 暂不可估值
                - generic [ref=e1364]: ·
                - generic [ref=e1365]: "--"
              - generic [ref=e1366]:
                - generic [ref=e1367]: 暂不可用
                - generic [ref=e1368]: 无可用数据源
            - generic [ref=e1369]: "----"
      - article [ref=e1370]:
        - button "合成日本基金83 仅关注 200083 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1371] [cursor=pointer]:
          - generic [ref=e1372]:
            - generic [ref=e1373]:
              - generic [ref=e1374]: 合成日本基金83 仅关注
              - generic [ref=e1375]: 200083 · 最新正式净值 待更新
            - generic [ref=e1376]:
              - generic [ref=e1377]: "--"
              - generic [ref=e1378]:
                - generic [ref=e1379]: 暂不可估值
                - generic [ref=e1380]: ·
                - generic [ref=e1381]: "--"
              - generic [ref=e1382]:
                - generic [ref=e1383]: 暂不可用
                - generic [ref=e1384]: 无可用数据源
            - generic [ref=e1385]: "----"
      - article [ref=e1386]:
        - button "合成日本基金84 仅关注 200084 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1387] [cursor=pointer]:
          - generic [ref=e1388]:
            - generic [ref=e1389]:
              - generic [ref=e1390]: 合成日本基金84 仅关注
              - generic [ref=e1391]: 200084 · 最新正式净值 待更新
            - generic [ref=e1392]:
              - generic [ref=e1393]: "--"
              - generic [ref=e1394]:
                - generic [ref=e1395]: 暂不可估值
                - generic [ref=e1396]: ·
                - generic [ref=e1397]: "--"
              - generic [ref=e1398]:
                - generic [ref=e1399]: 暂不可用
                - generic [ref=e1400]: 无可用数据源
            - generic [ref=e1401]: "----"
      - article [ref=e1402]:
        - button "合成日本基金85 仅关注 200085 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1403] [cursor=pointer]:
          - generic [ref=e1404]:
            - generic [ref=e1405]:
              - generic [ref=e1406]: 合成日本基金85 仅关注
              - generic [ref=e1407]: 200085 · 最新正式净值 待更新
            - generic [ref=e1408]:
              - generic [ref=e1409]: "--"
              - generic [ref=e1410]:
                - generic [ref=e1411]: 暂不可估值
                - generic [ref=e1412]: ·
                - generic [ref=e1413]: "--"
              - generic [ref=e1414]:
                - generic [ref=e1415]: 暂不可用
                - generic [ref=e1416]: 无可用数据源
            - generic [ref=e1417]: "----"
      - article [ref=e1418]:
        - button "合成日本基金86 仅关注 200086 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1419] [cursor=pointer]:
          - generic [ref=e1420]:
            - generic [ref=e1421]:
              - generic [ref=e1422]: 合成日本基金86 仅关注
              - generic [ref=e1423]: 200086 · 最新正式净值 待更新
            - generic [ref=e1424]:
              - generic [ref=e1425]: "--"
              - generic [ref=e1426]:
                - generic [ref=e1427]: 暂不可估值
                - generic [ref=e1428]: ·
                - generic [ref=e1429]: "--"
              - generic [ref=e1430]:
                - generic [ref=e1431]: 暂不可用
                - generic [ref=e1432]: 无可用数据源
            - generic [ref=e1433]: "----"
      - article [ref=e1434]:
        - button "合成日本基金87 仅关注 200087 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1435] [cursor=pointer]:
          - generic [ref=e1436]:
            - generic [ref=e1437]:
              - generic [ref=e1438]: 合成日本基金87 仅关注
              - generic [ref=e1439]: 200087 · 最新正式净值 待更新
            - generic [ref=e1440]:
              - generic [ref=e1441]: "--"
              - generic [ref=e1442]:
                - generic [ref=e1443]: 暂不可估值
                - generic [ref=e1444]: ·
                - generic [ref=e1445]: "--"
              - generic [ref=e1446]:
                - generic [ref=e1447]: 暂不可用
                - generic [ref=e1448]: 无可用数据源
            - generic [ref=e1449]: "----"
      - article [ref=e1450]:
        - button "合成日本基金88 仅关注 200088 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1451] [cursor=pointer]:
          - generic [ref=e1452]:
            - generic [ref=e1453]:
              - generic [ref=e1454]: 合成日本基金88 仅关注
              - generic [ref=e1455]: 200088 · 最新正式净值 待更新
            - generic [ref=e1456]:
              - generic [ref=e1457]: "--"
              - generic [ref=e1458]:
                - generic [ref=e1459]: 暂不可估值
                - generic [ref=e1460]: ·
                - generic [ref=e1461]: "--"
              - generic [ref=e1462]:
                - generic [ref=e1463]: 暂不可用
                - generic [ref=e1464]: 无可用数据源
            - generic [ref=e1465]: "----"
      - article [ref=e1466]:
        - button "合成日本基金89 仅关注 200089 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1467] [cursor=pointer]:
          - generic [ref=e1468]:
            - generic [ref=e1469]:
              - generic [ref=e1470]: 合成日本基金89 仅关注
              - generic [ref=e1471]: 200089 · 最新正式净值 待更新
            - generic [ref=e1472]:
              - generic [ref=e1473]: "--"
              - generic [ref=e1474]:
                - generic [ref=e1475]: 暂不可估值
                - generic [ref=e1476]: ·
                - generic [ref=e1477]: "--"
              - generic [ref=e1478]:
                - generic [ref=e1479]: 暂不可用
                - generic [ref=e1480]: 无可用数据源
            - generic [ref=e1481]: "----"
      - article [ref=e1482]:
        - button "合成日本基金90 仅关注 200090 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1483] [cursor=pointer]:
          - generic [ref=e1484]:
            - generic [ref=e1485]:
              - generic [ref=e1486]: 合成日本基金90 仅关注
              - generic [ref=e1487]: 200090 · 最新正式净值 待更新
            - generic [ref=e1488]:
              - generic [ref=e1489]: "--"
              - generic [ref=e1490]:
                - generic [ref=e1491]: 暂不可估值
                - generic [ref=e1492]: ·
                - generic [ref=e1493]: "--"
              - generic [ref=e1494]:
                - generic [ref=e1495]: 暂不可用
                - generic [ref=e1496]: 无可用数据源
            - generic [ref=e1497]: "----"
      - article [ref=e1498]:
        - button "合成日本基金91 仅关注 200091 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1499] [cursor=pointer]:
          - generic [ref=e1500]:
            - generic [ref=e1501]:
              - generic [ref=e1502]: 合成日本基金91 仅关注
              - generic [ref=e1503]: 200091 · 最新正式净值 待更新
            - generic [ref=e1504]:
              - generic [ref=e1505]: "--"
              - generic [ref=e1506]:
                - generic [ref=e1507]: 暂不可估值
                - generic [ref=e1508]: ·
                - generic [ref=e1509]: "--"
              - generic [ref=e1510]:
                - generic [ref=e1511]: 暂不可用
                - generic [ref=e1512]: 无可用数据源
            - generic [ref=e1513]: "----"
      - article [ref=e1514]:
        - button "合成日本基金92 仅关注 200092 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1515] [cursor=pointer]:
          - generic [ref=e1516]:
            - generic [ref=e1517]:
              - generic [ref=e1518]: 合成日本基金92 仅关注
              - generic [ref=e1519]: 200092 · 最新正式净值 待更新
            - generic [ref=e1520]:
              - generic [ref=e1521]: "--"
              - generic [ref=e1522]:
                - generic [ref=e1523]: 暂不可估值
                - generic [ref=e1524]: ·
                - generic [ref=e1525]: "--"
              - generic [ref=e1526]:
                - generic [ref=e1527]: 暂不可用
                - generic [ref=e1528]: 无可用数据源
            - generic [ref=e1529]: "----"
      - article [ref=e1530]:
        - button "合成日本基金93 仅关注 200093 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1531] [cursor=pointer]:
          - generic [ref=e1532]:
            - generic [ref=e1533]:
              - generic [ref=e1534]: 合成日本基金93 仅关注
              - generic [ref=e1535]: 200093 · 最新正式净值 待更新
            - generic [ref=e1536]:
              - generic [ref=e1537]: "--"
              - generic [ref=e1538]:
                - generic [ref=e1539]: 暂不可估值
                - generic [ref=e1540]: ·
                - generic [ref=e1541]: "--"
              - generic [ref=e1542]:
                - generic [ref=e1543]: 暂不可用
                - generic [ref=e1544]: 无可用数据源
            - generic [ref=e1545]: "----"
      - article [ref=e1546]:
        - button "合成日本基金94 仅关注 200094 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1547] [cursor=pointer]:
          - generic [ref=e1548]:
            - generic [ref=e1549]:
              - generic [ref=e1550]: 合成日本基金94 仅关注
              - generic [ref=e1551]: 200094 · 最新正式净值 待更新
            - generic [ref=e1552]:
              - generic [ref=e1553]: "--"
              - generic [ref=e1554]:
                - generic [ref=e1555]: 暂不可估值
                - generic [ref=e1556]: ·
                - generic [ref=e1557]: "--"
              - generic [ref=e1558]:
                - generic [ref=e1559]: 暂不可用
                - generic [ref=e1560]: 无可用数据源
            - generic [ref=e1561]: "----"
      - article [ref=e1562]:
        - button "合成日本基金95 仅关注 200095 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1563] [cursor=pointer]:
          - generic [ref=e1564]:
            - generic [ref=e1565]:
              - generic [ref=e1566]: 合成日本基金95 仅关注
              - generic [ref=e1567]: 200095 · 最新正式净值 待更新
            - generic [ref=e1568]:
              - generic [ref=e1569]: "--"
              - generic [ref=e1570]:
                - generic [ref=e1571]: 暂不可估值
                - generic [ref=e1572]: ·
                - generic [ref=e1573]: "--"
              - generic [ref=e1574]:
                - generic [ref=e1575]: 暂不可用
                - generic [ref=e1576]: 无可用数据源
            - generic [ref=e1577]: "----"
      - article [ref=e1578]:
        - button "合成日本基金96 仅关注 200096 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1579] [cursor=pointer]:
          - generic [ref=e1580]:
            - generic [ref=e1581]:
              - generic [ref=e1582]: 合成日本基金96 仅关注
              - generic [ref=e1583]: 200096 · 最新正式净值 待更新
            - generic [ref=e1584]:
              - generic [ref=e1585]: "--"
              - generic [ref=e1586]:
                - generic [ref=e1587]: 暂不可估值
                - generic [ref=e1588]: ·
                - generic [ref=e1589]: "--"
              - generic [ref=e1590]:
                - generic [ref=e1591]: 暂不可用
                - generic [ref=e1592]: 无可用数据源
            - generic [ref=e1593]: "----"
      - article [ref=e1594]:
        - button "合成日本基金97 仅关注 200097 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1595] [cursor=pointer]:
          - generic [ref=e1596]:
            - generic [ref=e1597]:
              - generic [ref=e1598]: 合成日本基金97 仅关注
              - generic [ref=e1599]: 200097 · 最新正式净值 待更新
            - generic [ref=e1600]:
              - generic [ref=e1601]: "--"
              - generic [ref=e1602]:
                - generic [ref=e1603]: 暂不可估值
                - generic [ref=e1604]: ·
                - generic [ref=e1605]: "--"
              - generic [ref=e1606]:
                - generic [ref=e1607]: 暂不可用
                - generic [ref=e1608]: 无可用数据源
            - generic [ref=e1609]: "----"
      - article [ref=e1610]:
        - button "合成日本基金98 仅关注 200098 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1611] [cursor=pointer]:
          - generic [ref=e1612]:
            - generic [ref=e1613]:
              - generic [ref=e1614]: 合成日本基金98 仅关注
              - generic [ref=e1615]: 200098 · 最新正式净值 待更新
            - generic [ref=e1616]:
              - generic [ref=e1617]: "--"
              - generic [ref=e1618]:
                - generic [ref=e1619]: 暂不可估值
                - generic [ref=e1620]: ·
                - generic [ref=e1621]: "--"
              - generic [ref=e1622]:
                - generic [ref=e1623]: 暂不可用
                - generic [ref=e1624]: 无可用数据源
            - generic [ref=e1625]: "----"
      - article [ref=e1626]:
        - button "合成日本基金99 仅关注 200099 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1627] [cursor=pointer]:
          - generic [ref=e1628]:
            - generic [ref=e1629]:
              - generic [ref=e1630]: 合成日本基金99 仅关注
              - generic [ref=e1631]: 200099 · 最新正式净值 待更新
            - generic [ref=e1632]:
              - generic [ref=e1633]: "--"
              - generic [ref=e1634]:
                - generic [ref=e1635]: 暂不可估值
                - generic [ref=e1636]: ·
                - generic [ref=e1637]: "--"
              - generic [ref=e1638]:
                - generic [ref=e1639]: 暂不可用
                - generic [ref=e1640]: 无可用数据源
            - generic [ref=e1641]: "----"
      - article [ref=e1642]:
        - button "合成日本基金100 仅关注 200100 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1643] [cursor=pointer]:
          - generic [ref=e1644]:
            - generic [ref=e1645]:
              - generic [ref=e1646]: 合成日本基金100 仅关注
              - generic [ref=e1647]: 200100 · 最新正式净值 待更新
            - generic [ref=e1648]:
              - generic [ref=e1649]: "--"
              - generic [ref=e1650]:
                - generic [ref=e1651]: 暂不可估值
                - generic [ref=e1652]: ·
                - generic [ref=e1653]: "--"
              - generic [ref=e1654]:
                - generic [ref=e1655]: 暂不可用
                - generic [ref=e1656]: 无可用数据源
            - generic [ref=e1657]: "----"
      - article [ref=e1658]:
        - button "合成日本基金101 仅关注 200101 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1659] [cursor=pointer]:
          - generic [ref=e1660]:
            - generic [ref=e1661]:
              - generic [ref=e1662]: 合成日本基金101 仅关注
              - generic [ref=e1663]: 200101 · 最新正式净值 待更新
            - generic [ref=e1664]:
              - generic [ref=e1665]: "--"
              - generic [ref=e1666]:
                - generic [ref=e1667]: 暂不可估值
                - generic [ref=e1668]: ·
                - generic [ref=e1669]: "--"
              - generic [ref=e1670]:
                - generic [ref=e1671]: 暂不可用
                - generic [ref=e1672]: 无可用数据源
            - generic [ref=e1673]: "----"
      - article [ref=e1674]:
        - button "合成日本基金102 仅关注 200102 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1675] [cursor=pointer]:
          - generic [ref=e1676]:
            - generic [ref=e1677]:
              - generic [ref=e1678]: 合成日本基金102 仅关注
              - generic [ref=e1679]: 200102 · 最新正式净值 待更新
            - generic [ref=e1680]:
              - generic [ref=e1681]: "--"
              - generic [ref=e1682]:
                - generic [ref=e1683]: 暂不可估值
                - generic [ref=e1684]: ·
                - generic [ref=e1685]: "--"
              - generic [ref=e1686]:
                - generic [ref=e1687]: 暂不可用
                - generic [ref=e1688]: 无可用数据源
            - generic [ref=e1689]: "----"
      - article [ref=e1690]:
        - button "合成日本基金103 仅关注 200103 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1691] [cursor=pointer]:
          - generic [ref=e1692]:
            - generic [ref=e1693]:
              - generic [ref=e1694]: 合成日本基金103 仅关注
              - generic [ref=e1695]: 200103 · 最新正式净值 待更新
            - generic [ref=e1696]:
              - generic [ref=e1697]: "--"
              - generic [ref=e1698]:
                - generic [ref=e1699]: 暂不可估值
                - generic [ref=e1700]: ·
                - generic [ref=e1701]: "--"
              - generic [ref=e1702]:
                - generic [ref=e1703]: 暂不可用
                - generic [ref=e1704]: 无可用数据源
            - generic [ref=e1705]: "----"
      - article [ref=e1706]:
        - button "合成日本基金104 仅关注 200104 · 最新正式净值 待更新 -- 暂不可估值 -- 暂不可用 无可用数据源 ----" [ref=e1707] [cursor=pointer]:
          - generic [ref=e1708]:
            - generic [ref=e1709]:
              - generic [ref=e1710]: 合成日本基金104 仅关注
              - generic [ref=e1711]: 200104 · 最新正式净值 待更新
            - generic [ref=e1712]:
              - generic [ref=e1713]: "--"
              - generic [ref=e1714]:
                - generic [ref=e1715]: 暂不可估值
                - generic [ref=e1716]: ·
                - generic [ref=e1717]: "--"
              - generic [ref=e1718]:
                - generic [ref=e1719]: 暂不可用
                - generic [ref=e1720]: 无可用数据源
            - generic [ref=e1721]: "----"
  - generic [ref=e1722]:
    - button "📈 行情" [ref=e1723] [cursor=pointer]:
      - generic [ref=e1724]: 📈
      - text: 行情
    - button "⚙️ 持仓" [ref=e1725] [cursor=pointer]:
      - generic [ref=e1726]: ⚙️
      - text: 持仓
```

# Test source

```ts
  268 |   expect(settled.ledger[0].actual_change).toBeCloseTo(2, 10);
  269 |   expect(settled.ledger[0].error).toBeCloseTo(-1, 10);
  270 |   expect(settled.ledger[0].direction_correct).toBe(true);
  271 |   expect(settled.ledger[0].settled_at).toMatch(/^2026-09-30T/);
  272 |   expect(settled.fund.quote).toMatchObject({ valueKind: 'official_nav', value: 1.224, targetDate: '2026-09-28' });
  273 |   expect(harness.state.gistWrites).toEqual([]);
  274 |   expect(harness.state.requests.filter(row => row.category === 'gist')).toEqual([]);
  275 |   writeFileSync(testInfo.outputPath('actual-accuracy-lifecycle.json'), JSON.stringify({
  276 |     scope: 'synthetic real App/Bridge automatic prediction, warm dedup and next publication settlement; not real providers/devices',
  277 |     browser: browser.version(), cold, predicted, settled, noCloudWrites: true,
  278 |   }, null, 2) + '\n', { flag: 'wx' });
  279 | });
  280 | 
  281 | test('independent holdings and market models survive the real refresh, renderer and cache reload', async ({ context, page, browser }, testInfo) => {
  282 |   const row = { ...HOLDINGS[0], name: '合成沪深300指数基金' };
  283 |   const harness = await installHarness(context, { rows: [row], failEstimates: true, securityChange: 2, modelChange: 3 });
  284 |   await page.goto('/');
  285 |   await harness.settle(page);
  286 |   const cached = () => page.evaluate(key => JSON.parse(localStorage.getItem(key)).data[0], FUND_CACHE);
  287 |   await expect.poll(async () => (await cached())?.market_model_evidence?.changePct).toBe(3);
  288 |   const fund = await cached();
  289 |   expect(fund.holdings_model_evidence.fundCode).toBe(row.code);
  290 |   expect(fund.holdings_model_evidence.changePct).toBeCloseTo(1.6, 10);
  291 |   expect(fund.holdings_model_evidence.value).toBeCloseTo(1.2192, 10);
  292 |   expect(fund.holdings_model_evidence.coverage).toBe(80);
  293 |   expect(fund.market_model_evidence.value).toBeCloseTo(1.236, 10);
  294 |   expect(fund.market_model_evidence.coverage).toBe(100);
  295 |   expect(fund.quote.sourceId).toBe('market-model');
  296 |   expect(fund.quote.valueKind).toBe('model_estimate');
  297 |   expect(fund.quote.changePct).toBe(3);
  298 |   expect(fund.curr_value).toBeCloseTo(123.6, 8);
  299 |   expect(fund.today_profit).toBeCloseTo(3.6, 8);
  300 |   await expect(navValue(page)).toHaveText('1.2360');
  301 |   await page.locator(`#fund-toggle-${row.code}`).click();
  302 |   await expect(page.locator(`#fund-detail-${row.code}`)).toContainText('可用权重100.00%');
  303 |   await expect(page.locator(`#fund-detail-${row.code}`)).not.toContainText('覆盖净值80.0%');
  304 |   const identities = { quote: fund.quote, holdings: fund.holdings_model_evidence, market: fund.market_model_evidence };
  305 |   harness.state.failAll = true;
  306 |   harness.state.holdNextEstimate = true;
  307 |   await page.reload();
  308 |   await harness.ready(page);
  309 |   await expect.poll(() => Boolean(harness.state.heldEstimate)).toBe(true);
  310 |   try {
  311 |     // Hold the new primary acquisition so this observes the real cache restore,
  312 |     // not a later, legitimately different official/failed-refresh projection.
  313 |     await expect(navValue(page)).toHaveText('1.2360');
  314 |     const restored = await cached();
  315 |     expect(restored.holdings_model_evidence).toEqual(identities.holdings);
  316 |     expect(restored.market_model_evidence).toEqual(identities.market);
  317 |     expect(restored.quote.value).toBe(identities.quote.value);
  318 |     expect(restored.quote.fetchedAt).toBe(identities.quote.fetchedAt);
  319 |   } finally {
  320 |     await harness.state.heldEstimate();
  321 |     await harness.settle(page);
  322 |   }
  323 |   expect(harness.state.gistWrites).toEqual([]);
  324 |   await testInfo.attach('model-provenance-synthetic-refresh', { contentType: 'application/json', body: JSON.stringify({
  325 |     scope: 'local Chrome real app/Bridge/refresh/render/reload; synthetic providers only; not production/device proof',
  326 |     browser: browser.version(), holdings: identities.holdings, market: identities.market,
  327 |     selected: identities.quote, noCloudWrites: true,
  328 |   }) });
  329 | });
  330 | 
  331 | test('one generation shares official NAV between fallback and enrichment', async ({ context, page }) => {
  332 |   // Keep this case on official NAV: a successful holdings enrichment would
  333 |   // legitimately select today's model and make its visible quote time 14:30.
  334 |   const harness = await installHarness(context, { failEstimates: true, failHoldings: true, omitTencentCodes: ['sh000300'] });
  335 |   await page.goto('/');
  336 |   await harness.settle(page);
  337 |   await expect(navValue(page)).not.toHaveText('--');
  338 |   await expect(page.locator(`#fund-toggle-${HOLDINGS[0].code} .quote-time`)).toHaveText('2026-09-28');
  339 |   expect(harness.requests('cold', 'nav'), 'fallback and enrichment must acquire the same nav:code resource').toHaveLength(1);
  340 |   const index = name => page.locator('#index-bar-inner .index-item').filter({ hasText: name });
  341 |   await expect(index('上证').locator('.index-price')).toHaveText('10');
  342 |   await expect(index('上证').locator('.index-stale')).toHaveCount(0);
  343 |   await expect(index('沪深300').locator('.index-price')).toHaveText('--');
  344 |   for (const name of ['纳指100', '标普500']) {
  345 |     await expect(index(name).locator('.index-price')).toHaveText('10');
  346 |     await expect(index(name).locator('.index-stale')).toHaveText('旧');
  347 |   }
  348 |   const sourceTimes = await page.evaluate(key => {
  349 |     const cache = JSON.parse(localStorage.getItem(key));
  350 |     const entry = cache.refreshResources['indices:sh000001,sh000300,usINX,usNDX'];
  351 |     return entry?.payload.quotes.filter(row => row.code.startsWith('us')).map(row => row.observedAt);
  352 |   }, FUND_CACHE);
  353 |   expect(sourceTimes, 'US close timestamps must retain exchange-local conversion rather than use the refresh clock')
  354 |     .toEqual(['2026-09-29 04:00:00', '2026-09-29 04:00:00']);
  355 |   expect(harness.state.gistWrites).toEqual([]);
  356 | });
  357 | 
  358 | test('large official-only portfolio drains without overflowing the real Bridge queue', async ({ context, page }) => {
  359 |   const rows = Array.from({ length: 105 }, (_, index) => ({
  360 |     code: String(200000 + index), name: `合成日本基金${index}`, shares: 0, cost: null,
  361 |     deleted: false, ts: 1790640000000,
  362 |   }));
  363 |   const harness = await installHarness(context, { rows, failEstimates: true });
  364 |   await page.goto('/');
  365 |   await harness.settle(page);
  366 |   const navs = page.locator('#fund-list .nav-cur');
  367 |   await expect(navs).toHaveCount(rows.length);
> 368 |   expect(await navs.allTextContents(), 'All official fallbacks must survive parent-queue admission').toEqual(rows.map(() => '1.2000'));
      |                                                                                                      ^ Error: All official fallbacks must survive parent-queue admission
  369 |   const dates = page.locator('#fund-list .quote-time');
  370 |   expect(await dates.allTextContents(), 'Request completion must not turn the official NAV date into today').toEqual(rows.map(() => '2026-09-28'));
  371 |   expect(harness.requests('cold', 'nav')).toHaveLength(rows.length);
  372 |   expect(new Set(harness.requests('cold', 'nav').map(row => new URL(row.url).pathname)).size).toBe(rows.length);
  373 |   const writes = await harness.writes(page, 'cold');
  374 |   expect(writes).toHaveLength(1);
  375 |   expect(JSON.parse(writes[0].value).data).toHaveLength(rows.length);
  376 |   expect(harness.state.gistWrites).toEqual([]);
  377 | });
  378 | 
  379 | test('warm manual refresh respects stable holdings and official NAV TTL', async ({ context, page }) => {
  380 |   const harness = await installHarness(context);
  381 |   await page.goto('/');
  382 |   await harness.settle(page);
  383 |   expect(harness.requests('cold', 'holdings')).toHaveLength(1);
  384 |   expect(harness.requests('cold', 'nav')).toHaveLength(1);
  385 |   await harness.refresh(page);
  386 |   expect(harness.requests('warm', 'estimates')).toHaveLength(1);
  387 |   expect(harness.requests('warm', 'holdings'), 'ordinary force refresh must not bypass the 12-hour holdings TTL').toHaveLength(0);
  388 |   expect(harness.requests('warm', 'nav'), 'ordinary force refresh must not bypass the stable official-NAV TTL').toHaveLength(0);
  389 |   expect(harness.state.gistWrites).toEqual([]);
  390 | });
  391 | 
  392 | test('successful generation persists one aggregate fund cache and no legacy NAV/gold keys', async ({ context, page }) => {
  393 |   const harness = await installHarness(context, { rows: HOLDINGS });
  394 |   await page.goto('/');
  395 |   await harness.settle(page);
  396 |   for (const holding of HOLDINGS) await expect(navValue(page, holding.code)).not.toHaveText('--');
  397 |   const writes = await harness.writes(page, 'cold');
  398 |   expect(writes, 'primary and all enrichment commits share one aggregate cache flush').toHaveLength(1);
  399 |   const data = JSON.parse(writes[0].value).data;
  400 |   expect(data.map(row => row.code).sort()).toEqual(HOLDINGS.map(row => row.code).sort());
  401 |   const legacyWrites = await page.evaluate(() => globalThis.__refreshTestWrites.filter(row =>
  402 |     /^fuyu_nav_move_/.test(row.key) || row.key === 'fuyu_gold_cache_v2'));
  403 |   expect(legacyWrites, 'legacy NAV/gold cache entries are migration reads, not new write channels').toEqual([]);
  404 |   await harness.refresh(page);
  405 |   expect(await harness.writes(page, 'warm')).toHaveLength(1);
  406 |   expect(harness.state.gistWrites).toEqual([]);
  407 | });
  408 | 
  409 | test('two funds share one union securities batch instead of one batch per fund', async ({ context, page }) => {
  410 |   const harness = await installHarness(context, { rows: HOLDINGS });
  411 |   await page.goto('/');
  412 |   await harness.settle(page);
  413 |   expect(harness.requests('cold', 'holdings')).toHaveLength(2);
  414 |   const batches = harness.requests('cold', 'eastmoneySecurities');
  415 |   expect(batches, 'all active funds use one canonical securities union before provider batching').toHaveLength(1);
  416 |   expect(new URL(batches[0].url).searchParams.get('secids').split(',')).toHaveLength(10);
  417 |   expect(harness.state.gistWrites).toEqual([]);
  418 | });
  419 | 
  420 | test('a detail opened during refresh consumes the existing generation disclosure and quote union', async ({ context, page }) => {
  421 |   const harness = await installHarness(context, { holdFirstEstimate: true });
  422 |   await page.goto('/');
  423 |   await harness.ready(page);
  424 |   await expect.poll(() => typeof harness.state.heldEstimate).toBe('function');
  425 |   try {
  426 |     const toggle = page.locator(`#fund-toggle-${HOLDINGS[0].code}`);
  427 |     await toggle.click();
  428 |     await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  429 |     await harness.settle(page, { allowHeld: true });
  430 |     expect(harness.requests('cold', 'holdings')).toHaveLength(1);
  431 |     expect(harness.requests('cold', 'eastmoneySecurities')).toHaveLength(1);
  432 |     await harness.phase(page, 'detailWaiting');
  433 |     await harness.state.heldEstimate();
  434 |     harness.state.heldEstimate = null;
  435 |     await harness.settle(page);
  436 |     await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  437 |     await expect(page.locator('.holdings-table')).toContainText('合成股票1');
  438 |     expect(harness.requests('detailWaiting', 'holdings')).toHaveLength(0);
  439 |     expect(harness.requests('detailWaiting', 'eastmoneySecurities')).toHaveLength(0);
  440 |     expect(harness.requests('detailWaiting', 'tencent')).toHaveLength(0);
  441 |     expect(harness.state.gistWrites).toEqual([]);
  442 |   } finally {
  443 |     if (harness.state.heldEstimate) await harness.state.heldEstimate();
  444 |   }
  445 | });
  446 | 
  447 | test('all providers failing cannot renew the aggregate cache timestamp or bytes', async ({ context, page }) => {
  448 |   const harness = await installHarness(context);
  449 |   await page.goto('/');
  450 |   await harness.settle(page);
  451 |   const before = await page.evaluate(key => localStorage.getItem(key), FUND_CACHE);
  452 |   expect(before).not.toBeNull();
  453 |   harness.state.failAll = true;
  454 |   // Cache expiry is a clock rule, not an instruction to wait fifteen real minutes.
  455 |   await page.evaluate(() => { globalThis.__refreshTestClockAdvance = 15 * 60_000; });
  456 |   await harness.refresh(page, 'allFailed');
  457 |   expect(harness.requests('allFailed', 'estimates')).toHaveLength(1);
  458 |   expect(await harness.writes(page, 'allFailed'), 'failed/cached-only results must not receive a new fetchedAt/expiresAt').toEqual([]);
  459 |   expect(await page.evaluate(key => localStorage.getItem(key), FUND_CACHE)).toBe(before);
  460 |   expect(harness.state.gistWrites).toEqual([]);
  461 | });
  462 | 
  463 | test('warm details keep failed prior quotes visibly historical with their real clock, not today or zero', async ({ context, page }) => {
  464 |   const harness = await installHarness(context);
  465 |   await page.goto('/');
  466 |   await harness.settle(page);
  467 |   const toggle = page.locator(`#fund-toggle-${HOLDINGS[0].code}`);
  468 |   await toggle.click();
```