# Archive first attempt: native exit 1 retained

The parent-provided `archive.mjs` was actually executed once with Node v24.14.0. The native command exited 1 before copying payloads or creating the repository destination/stage/extraction directory. It asserted 106 selected site files, but filtering the frozen 129-row site inventory by the declared `!path.startsWith('assets/ocr/')` produced 105. The 24 excluded directory files include the manifest as well as the 23 assets counted by the OCR verification CLI.

Observed exception: `AssertionError [ERR_ASSERTION]: 105 !== 106` at archive.mjs:115:8. Tool command output chunk was b0b449. That tool result is the evidence for native exit 1; it was not originally redirected to independent stdout/stderr/native receipt files and those missing originals have not been reconstructed.

The first script and its before-head/branch/index native receipts/stdout/stderr remain untouched in this directory. A distinct a2 workspace will change only the archival expected count/check label to 105 and include this directory as original failure evidence. It must not change source/site/QA inventories, add or remove payloads to fit a count, rerun tests/builds, or rewrite this failed attempt as PASS.
