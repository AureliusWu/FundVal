# PWA controller extraction protocol — fixed before implementation

Scope: physically extract the current v15 App service-worker update state and controller responsibilities to `js/runtime/pwa-update-controller.js`. Preserve cross-tab prepare/blocked, exact activation-message source/origin authorization, stopAndDrain and dirty/sync/save rechecks, banner states, registration/updatefound/activation/controllerchange behavior, and registration execution position. No new M5 feature, global exposure, compatibility-script edit, worker/cache-policy edit, dependency/recipe/version/budget change.

Ownership: only the new runtime module and extraction-specific tests may change. App/build wiring is a precise Temp patch for parent application. A concurrent agent owns sync state. No root App edit by this agent. Prior UI audit/evidence remains unchanged.

Baseline: copied full old App bytes to app.before.js before implementation. SHA256 17826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359. Copy original page-update test before editing, run its exact 18 behavior cases against the old App first, retain stdout/stderr/native exit receipt, including failure. This supplies the pre-extraction behavioral oracle; no claim of old failure is required for pure relocation.

New module: a factory owning all SW state and policy/listeners, with explicit App-state callbacks and inert construction; start() performs original registration/listener block at original App position. Keep new ESM App action protected and old cached global legacy callback bridge unchanged. Do not introduce a new global function.

Tests: preserve all existing case assertions, adapt the harness to execute the actual factory AST with synthetic IO/clock/drain and callbacks, not a manually rewritten algorithm. Preserve dirty-form helper behavior in App. Add direct full-scenario old/new transcript comparison with a frozen pre-extraction fixture, registration timing/unsupported BC and SW/failure checks, and structural extraction checks. No weakened source/origin/draft assertions. Any instrumentation reads private state only through test-injected return getters and does not alter statements under test.

Validation here is limited to targeted Node tests. Do not run full unit/check/build/E2E/performance. Save each targeted run's stdout/stderr/native exit and preserve failures. Performance skill is read; no new byte/latency PASS may be inferred from extraction or Node behavior tests. Parent later owns actual App/build integration and complete proportional gates under original budgets.
