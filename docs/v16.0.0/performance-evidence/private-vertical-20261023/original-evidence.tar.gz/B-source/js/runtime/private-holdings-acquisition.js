import { createRequestSignal, throwIfAborted } from './request-signal.js';
import { fundDataApiUrl } from '../config.js';
import { readHoldingsAcquisition } from './private-worker-acquisition.js';

const TIMEOUT = 10000;

export async function fetchFundHoldings(code, options = {}) {
  const fundCode = String(code || '').trim();
  if (!/^\d{6}$/.test(fundCode)) throw new Error('基金代码无效');

  throwIfAborted(options.signal);
  const requestSignal = createRequestSignal(options.signal, options.timeout ?? TIMEOUT);
  try {
    const query = new URLSearchParams({ code: fundCode });
    if (options.force) query.set('_', String(Date.now()));
    const response = await fetch(`${options.api || fundDataApiUrl('holdings')}?${query}`, {
      cache: 'no-store',
      signal: requestSignal.signal,
    });
    if (!response.ok) throw new Error(`重仓代理 HTTP ${response.status}`);
    const payload = await response.json();
    const envelope = readHoldingsAcquisition(payload, { requestedCodes: [fundCode], now: options.now });
    const items = envelope.items;
    return {
      status: items.length ? (envelope.status === 'ok' ? 'ok' : 'degraded')
        : (envelope.status === 'unavailable' ? 'unavailable' : 'empty'),
      sourceStatus: envelope.status,
      wireVersion: envelope.wireVersion,
      reportDate: envelope.reportDate,
      fetchedAt: envelope.fetchedAt,
      source: envelope.source || 'sinan-holdings-proxy',
      items,
    };
  } catch (error) {
    throw requestSignal.normalizeError(error);
  } finally {
    requestSignal.cleanup();
  }
}

