import { resolveQuoteBaseNav } from '../calculator.js';
import { latestOfficialNavBase } from '../holdings-estimate.js';
import { calculateOverseasEstimate, selectOverseasModel, validateOverseasEstimatePeriod } from '../overseas-model.js';
import { normalizeQuoteDate } from './quote-contract.js';
import { isSingleMarketSession } from './market-clock.js';
import { classifyAssetKind, classifyMarketKind } from './market-session.js';
import { holdingQuoteAmounts } from './holding-quote-amounts.js';
import { buildFundQuoteCandidates, legacyFreshnessFromQuote, selectPreferredQuote } from './quote-normalizer.js';

const usableNav = value => Number.isFinite(value) && value > 0;

// Keep the spread/assignment insertion order for the one compatibility egress,
// without assembling a mutable intermediate fund for each model installer.
function sourceFields(value) {
  const fields = new Map();
  for (const key of Reflect.ownKeys(Object(value))) {
    if (Object.prototype.propertyIsEnumerable.call(value, key)) fields.set(key, value[key]);
  }
  return fields;
}

function officialBase(fields, holding = null) {
  return latestOfficialNavBase({
    source_quote: fields.get('source_quote'), latest_nav_move: fields.get('latest_nav_move'),
    est_kind: holding ? 'holdings_model' : fields.get('est_kind'),
    est_nav: holding ? holding.value : fields.get('est_nav'),
    value_date: fields.get('value_date'),
    est_time: holding ? holding.observedAt : fields.get('est_time'),
    last_nav: holding ? holding.baseNav : fields.get('last_nav'),
    nav_date: holding ? holding.baseNavDate : fields.get('nav_date'),
  });
}

function holdingResult(fields, estimate, fetchedAt) {
  if (!estimate || !estimate.available || !Number.isFinite(estimate.change)) return null;
  if (fields.get('est_realtime') === true && fields.get('est_kind') !== 'official_nav') return null;
  const official = officialBase(fields);
  const targetDate = normalizeQuoteDate(String(estimate.sourceTime || '').slice(0, 10));
  if (!official || !targetDate || !isSingleMarketSession(official.date, targetDate, fields.get('market') || 'cn')) return null;
  const reportDate = String(estimate.reportDate || '');
  const note = `按已披露十大重仓${estimate.reportDate ? `（截至${estimate.reportDate}）` : ''}的当日行情估算；覆盖净值${estimate.coverage.toFixed(1)}%，未披露资产、汇率与调仓影响为未知误差，不是基金公司官方估值`;
  const result = { value: official.nav * (1 + estimate.change / 100), changePct: estimate.change,
    baseNav: official.nav, baseNavDate: official.date, targetDate, observedAt: estimate.sourceTime,
    coverage: estimate.coverage, quoteCount: estimate.quoteCount, reportDate, note };
  const complete = normalizeQuoteDate(reportDate)
    && Number.isInteger(estimate.quoteCount) && estimate.quoteCount >= 5 && estimate.quoteCount <= 10
    && Number.isFinite(estimate.coverage) && estimate.coverage >= 50 && estimate.coverage <= 100;
  if (/^\d{6}$/.test(String(fields.get('code') || '')) && complete) result.evidence = Object.freeze({
    fundCode: fields.get('code'), value: result.value, changePct: estimate.change,
    baseNav: official.nav, baseNavDate: official.date, targetDate,
    observedAt: estimate.sourceTime, coverage: estimate.coverage,
    fetchedAt: fetchedAt ?? estimate.fetchedAt ?? fields.get('fetched_at') ?? fields.get('fetchedAt') ?? null,
    confidence: null, modelVersion: null, note, reportDate, quoteCount: estimate.quoteCount,
  });
  return result;
}

function marketResult(fields, holding, name, quotes, fetchedAt, enabled) {
  if (!enabled || (holding ? false : fields.get('est_realtime')) !== false) return null;
  const model = selectOverseasModel(String(fields.get('code') || ''), String(name || ''));
  if (!model) return null;
  const normalizedQuotes = {};
  Object.keys(quotes || {}).forEach(code => {
    const quote = quotes[code];
    if (quote) normalizedQuotes[code] = { change: quote.changePct, time: quote.sourceTime || quote.time };
  });
  const calculated = calculateOverseasEstimate(model, normalizedQuotes);
  const changePct = calculated && calculated.change;
  if (!Number.isFinite(changePct)) return null;
  const official = officialBase(fields, holding);
  if (!official) return null;
  const period = validateOverseasEstimatePeriod(model, normalizedQuotes, official.date);
  if (!period.valid || !usableNav(official.nav) || calculated.stale) return null;
  const label = calculated.modelLabel || model.label;
  const version = calculated.modelVersion || model.version || '';
  const result = { value: official.nav * (1 + changePct / 100), changePct,
    baseNav: official.nav, baseNavDate: official.date, targetDate: period.targetDate,
    observedAt: calculated.sourceTime || (holding ? holding.observedAt : fields.get('est_time')),
    modelTime: calculated.sourceTime || '', stale: Boolean(calculated.stale || !calculated.sourceTime),
    code: model.legs.map(leg => leg.code + ':' + leg.weight).join(','),
    label, coverage: calculated.usableWeight, version, quarter: model.quarter || '', confidence: calculated.confidence,
    note: label + ' · ' + version + ' · 可用权重' + Number(calculated.usableWeight).toFixed(2) + '% · 行情时间' + (calculated.sourceTime || '未知') + ' · 下一净值自建模型估算，不是基金公司官方净值' };
  if (/^\d{6}$/.test(String(fields.get('code') || ''))) result.evidence = Object.freeze({
    fundCode: fields.get('code'), value: result.value, changePct,
    baseNav: official.nav, baseNavDate: official.date, targetDate: period.targetDate,
    observedAt: calculated.sourceTime, coverage: calculated.usableWeight,
    fetchedAt: fetchedAt ?? fields.get('fetched_at') ?? fields.get('fetchedAt') ?? null,
    confidence: calculated.confidence, modelVersion: version, note: result.note, label,
    quarter: model.quarter || '', validUntil: model.valid_until || '', minimumWeight: model.min_weight,
  });
  return result;
}

function holdingFields(fields, holding) {
  if (!holding) return;
  for (const [key, value] of [
    ['last_nav', holding.baseNav], ['nav_date', holding.baseNavDate], ['est_change', holding.changePct],
    ['est_nav', holding.value], ['est_time', holding.observedAt], ['est_kind', 'holdings_model'],
    ['est_label', '重仓估算'], ['est_realtime', false], ['est_holdings_model', true],
    ['est_holdings_base_nav', holding.baseNav], ['est_holdings_base_date', holding.baseNavDate],
    ['est_holdings_target_date', holding.targetDate], ['est_holdings_coverage', holding.coverage],
    ['est_holdings_quote_count', holding.quoteCount], ['est_holdings_report_date', holding.reportDate],
    ['est_note', holding.note], ['source', 'quarterly-holdings-model'],
  ]) fields.set(key, value);
  if (holding.evidence) fields.set('holdings_model_evidence', holding.evidence);
  else if (fields.has('holdings_model_evidence')) fields.set('holdings_model_evidence', null);
}

function marketFields(fields, market) {
  if (!market) return;
  for (const [key, value] of [
    ['est_change', market.changePct], ['est_nav', market.value], ['est_model_base_nav', market.baseNav],
    ['est_model_base_date', market.baseNavDate], ['est_model_target_date', market.targetDate],
    ['est_time', market.observedAt], ['est_model_time', market.modelTime], ['est_model_stale', market.stale],
    ['est_kind', 'overseas_model'], ['est_label', '海外模型估算'], ['est_realtime', !market.stale],
    ['est_model', true], ['est_model_code', market.code], ['est_model_label', market.label],
    ['est_model_weight', market.coverage], ['est_model_version', market.version], ['est_model_quarter', market.quarter],
    ['est_confidence', market.confidence], ['est_note', market.note],
  ]) fields.set(key, value);
  if (market.evidence) fields.set('market_model_evidence', market.evidence);
}

function adoptedName(row, holding, isRealFundName) {
  return (row.status === 'ok' || row.status === 'ok_fallback') && isRealFundName(row.name, holding.code)
    ? String(row.name).trim() : '';
}

/** Internal acquired-row projection; public arbitrary-object importers stay separate. */
export function projectFund(raw, holding, quotes, isRealFundName, options = {}) {
  const enriched = Object.hasOwn(options, 'officialNavMove') || Object.hasOwn(options, 'holdingsEstimate');
  let fetchedName = enriched ? null : adoptedName(raw, holding, isRealFundName);
  const fields = sourceFields(enriched ? raw || {} : raw);
  if (options.officialNavMove) fields.set('latest_nav_move', { ...options.officialNavMove });
  const contribution = holdingResult(fields, options.holdingsEstimate, options.fetchedAt);
  if (enriched) fetchedName = adoptedName({ status: fields.get('status'), name: fields.get('name') }, holding, isRealFundName);
  const name = fetchedName || String(holding.name || '').trim() || holding.code;
  const shares = holding.shares == null ? 0 : holding.shares;
  const cost = holding.cost == null ? null : holding.cost;
  const updatedAt = Date.now();
  const fetchedAt = new Date(updatedAt).toISOString();
  const market = marketResult(fields, contribution, name, quotes || {}, fetchedAt, options.marketEnabled);

  // These assignments are the final ordered compatibility encoding, not model
  // input. Independent evidence above never reads a previous model's aliases.
  holdingFields(fields, contribution);
  fields.set('name', name);
  fields.set('shares', shares);
  fields.set('cost', cost);
  fields.set('updatedAt', updatedAt);
  marketFields(fields, market);
  const d = Object.fromEntries(fields);
  if (!usableNav(d.est_nav) && usableNav(d.last_nav) && Number.isFinite(d.est_change)) d.est_nav = d.last_nav * (1 + d.est_change / 100);
  d.market = classifyMarketKind(d.name);
  d.assetKind = classifyAssetKind(d.name, d.market);
  // Keep the strict new-slot/legacy single-slot importer and candidate-quality
  // rules as retained algorithms; a frozen persisted model is not trusted.
  d.quoteCandidates = buildFundQuoteCandidates(d, {
    fundCode: d.code, fundName: d.name, market: d.market, assetKind: d.assetKind,
    fetchedAt: new Date(d.updatedAt).toISOString(), now: d.updatedAt,
  });
  d.quote = selectPreferredQuote(d.quoteCandidates, {
    fundCode: d.code, fundName: d.name, market: d.market, assetKind: d.assetKind,
  }, { now: d.updatedAt });
  d.primary_change = d.quote.changePct == null ? NaN : d.quote.changePct;
  d.primary_nav = d.quote.value == null ? NaN : d.quote.value;
  d.primary_base_nav = resolveQuoteBaseNav(d, d.quote);
  d.primary_label = ({ official_nav: '净', model_estimate: '模', holding_lookthrough_estimate: '重仓估',
    intraday_estimate: d.quote.status === 'realtime' ? '估' : '延迟估值' })[d.quote.valueKind] || '';
  d.primary_note = d.quote.valueKind === 'official_nav'
    ? '最新公布净值涨跌：' + [d.quote.baseNavDate, d.quote.targetDate].filter(Boolean).join(' → ') : '';
  d.today_is_latest_nav = d.quote.valueKind === 'official_nav';
  Object.assign(d, holdingQuoteAmounts(d.quote, holding, d.updatedAt));
  d.display = { nav: d.quote.value, change: d.quote.changePct, kind: d.quote.valueKind,
    label: d.primary_label, stale: ['stale', 'unavailable'].includes(d.quote.status) };
  d.loading = false; d.stale = ['stale', 'unavailable'].includes(d.quote.status); d.error = null; d._cached = d.quote.sourceTier === 'cache';
  d.freshness = legacyFreshnessFromQuote(d.quote);
  return { data: d, fetchedName };
}
