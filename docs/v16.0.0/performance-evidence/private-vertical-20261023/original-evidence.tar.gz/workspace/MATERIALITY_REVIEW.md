# Actual one-screen materiality review — rejected (2026-10-23)

## Outcome and scope

**MATERIALITY_NOT_QUALIFIED; do not adopt.** A reproduced the current complete 127-file artifact exactly; B built successfully but increased all-chunk gzip by **1369 B**. Its cold reduction of 144 B does not compensate for the failed all budget. The parent stopped after this single screen: no later functional QA/equivalence/performance was run or inherited.

This review only read the existing receipts, manifests, final chunk text/import/export AST and implementation ledger. It used installed Rolldown `parseSync` as a read-only text parser, not the application or a new build/test. No new compression/ablation, flags, source edits, dependency changes or runtime execution. Only this report is added. performance-regression-check is used to keep exact artifact measurements separate from source-based causal inference; no multi-sample performance claim is made.

## Exact existing measurements

| Existing screen | A | B | Delta / decision |
| --- | ---: | ---: | --- |
| Complete site files | 127 | 136 | Different artifacts, not a byte-identical rewrite |
| App manifest chunks | 16 | 17 | One additional facade chunk |
| App raw bytes | 252331 | 256307 | +3976; **not** a gzip estimate |
| All app gzip bytes | 85969 | 87338 | **+1369**, both above 77227.7 |
| Cold app gzip bytes | 46149 | 46005 | −144, both below 52241 |
| Build native exit | 0 | 0 | Build success only |
| Budget native exit | 1 | 1 | Actual FAIL, not waived |

A complete rows SHA256: `0641039bb788b27c58c0ec0dc3d93b40cbc95bc2c51c935c105c9354c9b29d31`.
B complete rows SHA256: `e6bf67db938858368ed22c6ba13fffe76d50320a0229fcd4abb3499109d7f647`.

Existing evidence: `materiality-A-01/RESULT.json` SHA256 `e6882c944fc6ad4fbb299b5a6adb1af7396bab9543791513474dee8af8ae47b8`; `materiality-B-01/RESULT.json` SHA256 `02fd9672ea13520edb5a417aeeebd0868a656ecb9e42f71e2154b38184e385c3`. Both record `completeQa:false`, `behaviorEquivalence:false`, `performance:false`, `adopt:false`, with no failure/postflightError. Their before/after root273, installed68, site127 and Git identity remain the recorded unchanged root, not a B adoption.

Manifest identities: A `A/site/js/app-chunks.json`, 4196 B/SHA256 `c0d4a0c3ce37a763f9f9719435c81a706fbb365314a2e2a6df261e37886c30c6`; B `B/site/js/app-chunks.json`, 4476 B/SHA256 `f687ab44387ee19305edab81e4014355d10156dec5a7a994d0b05ec633acc081`.

## Where the measured chunk delta is

These are actual manifest gzip values, not allocated per-function savings.

| Emitted role | A gzip | B gzip | Delta |
| --- | ---: | ---: | ---: |
| business-runtime | 28188 | 29645 | +1457 |
| post-integrity | 35371 | 35227 | −144 |
| Original business facade | 372 | 98 | −274 |
| New private-business facade | 0 | 328 | +328 |
| All remaining app chunks combined | 22038 | 22040 | +2 |
| Total | 85969 | 87338 | +1369 |

The two B facade files jointly cost 426 gzip B versus A's single 372 B facade: **net +54 B**, not +328 B attributed as the whole increase. The small remaining +2 is the sum of emitted cloud +2, cloud-runtime +2, diagnostics −1 and gist-runtime −1; all other manifest gzip deltas are zero. Hash/import/name changes can affect compression even where raw lengths are equal. post-integrity is an explicit counterexample to treating raw delta as gzip: raw **+22** while gzip **−144**. business-runtime raw is +3946 but its measured gzip delta is +1457; the former is not used to derive the latter.

The actual relevant files are A `business-runtime-CKNPKLKh.js`, `post-integrity-Dp7m1bj2.js`, `business-features-C8uUb3CA.js`; B `business-runtime-DPSysxNf.js`, `post-integrity-DsFVWTRF.js`, `business-features-Xm4DySMs.js`, `private-business-features-xFNbo_N7.js` under each site's `js/chunks/`.

## Did the old public implementation accidentally survive twice?

The bounded final-artifact inspection finds **no evidence of a second old HTTP/parser/cache/model implementation alongside its private replacement**. It is stronger than a minified-name text search, but not a formal whole-program source-membership proof:

- A's business facade actually exports 18 public members including compose/apply and HTTP. B's original facade is now only `updateFundAccuracy`, bound to business runtime `Oe`; its 83 raw bytes / 98 gzip B contain no valuation export. B's new private facade binds estimate HTTP to `Yn`, holdings HTTP to `Zn`, projector to `or`, and executor to `Hr`. This confirms that the unchanged fixed accuracy edge did not force all old facade exports to remain.
- Actual B calls are `Yn/Zn → Gn/Kn → Wn` for fixed endpoint parsing. `Wn` has the declared private tail: generated/service late reads and capability iterable evaluation remain, but the old three returned metadata slots do not. It is not a second copy of A's old public parser tail. The private adapter `Jn` visibly performs the own-data temporary status override and restores it around Quote construction, instead of A `Ve`'s third whole-row spread.
- Across all actual chunks, the distinctive estimate rescue text, holdings HTTP error, `WORKER_PAYLOAD_INVALID`, aggregate clock error and duplicate-fund error each occur once in A and once in B. Worker kind/status Set initializer arrays also each occur once on both sides. No doubled public Worker initializer/codec pool was found. These signatures support the binding trace, but counts alone would not prove absence under arbitrary optimizer transformations.
- A's actual `it` clone/compose and `Tt` direct market alias mutator are replaced by B `tr/nr` local model results → `rr/ir` Map-field egress → `or` final projection. The distinct holdings/market explanation strings occur once per side. A has direct assignments to `est_holdings_model`, `est_holdings_base_nav`, `est_model_code` and `latest_nav_move` in those old bodies; B business runtime has none of those direct assignment signatures, using the declared Map-key encoding instead. This is consistent with retirement of the old intermediate mutator/clone bodies, not with both bodies accidentally surviving.
- B's actual cache `Er/Tr/xr` is used by `Hr` and its security path. The aggregation/error signatures appear once, and `Er` visibly retains the old active/newer/fundAcquired/row encoding algorithm. That is **retained/moved K**, not an unexpectedly duplicated codec and not a deletion saving.

The public original source files copied into site remain independently available as required; their presence as standalone compatibility sources is not evidence that every function body is included in the default app chunks. This screen's app budget counts the actual 17-chunk manifest, with the extra facade included; no new byte exclusion was introduced.

## Why the new architecture did not establish a material saving pool

Three observations are supported; finer attribution is not:

1. **Large necessary bodies remain.** The source retirement ledger was correct to keep Q2/Q3 generic candidates/importers, strict new evidence rules, R1/R2 resource validation/clean-row/Quote reconstruction and old cache/legacy NAV codec as K. The alias-heavy source adapter and its second wire validation also remain. Switching their owner/entry names is not removing their algorithmic content. Final B contains one active implementation, rather than the hoped-for retirement of a large independent legacy pool.
2. **The model/projection representation has real new code.** B contains ordered Map capture, local holding/market results, Map alias encoding and final projection, plus fixed endpoint wrappers/loaders. Business top-level function declarations rise 127→133; business `new Map` syntax sites rise 11→12. These are descriptive AST observations, not byte savings. They show new bookkeeping still present while final legacy aliases and generic Quote construction remain required. Its aggregate cost is consistent with the larger business chunk; **no ablation was run**, so it is not valid to assign the +1457 gzip B solely to Map, one helper or one algorithm.
3. **The split adds linking/facade cost.** The explicit measured facade net is +54 gzip B. Business imports more post-integrity bindings and post-integrity exports rise 36→42, as the private projector now calls shared classification/Quote/amount helpers across that boundary. This is visible binding/layout overhead, not proof of its isolated gzip amount. Relocation and changed symbol/hash distribution can affect each independent gzip stream; the cold −144 is not a removed financial algorithm or offsetting all-budget qualification.

Therefore the failed screen is not explained by an established accidental wholesale retention of the old public API pool. The intended source-call closure largely occurred, but most large rules were legitimately retained and the replacement introduced enough representation/linking code that the **actual whole artifact grew**. The one-screen experiment supplies a rejection of this candidate, not a mathematical impossibility theorem for every full pipeline architecture.

## Limits and stop

No per-module sourcemap/module-membership artifact was emitted, so this review does not claim exhaustive source-byte ownership for each minified helper, isolated gzip causation, formal semantic equivalence, runtime loading/access, public-API validation, or financial correctness of B. Static original-vs-candidate binding/signature review and the original graph gate are not E2E or performance evidence. A first inline read-only chunk-name grouping helper mishandled hashes containing `-`; it was corrected to the fixed eight-character hash suffix before the table above. No source/result was altered and no compressor/application was rerun.

Original IMPLEMENTATION.md SHA256 `166cbe9ecd263858940f7a6cff99862fc74aa04ba8b2e20e28adb417733b2cac`, B.inventory.json SHA256 `2366047c672c78065448fa715b4b74c2fccb37da55c1dddc08ef2e75d194e7a5`, STATIC_FREEZE.json SHA256 `4593be7ea5dcb9a32bb6ef8be2cb46db4fc1b37b9993ac3de9ad30ad96502f04` remain the implementation evidence; they are not rewritten into materiality PASS. Current root remains the earlier all85969/cold46149, needing 8742 integer B, 15.0.2 / M3 IN_PROGRESS / NOT_RELEASED. Stop here: rejected B, no further QA/performance, no source/flag changes or parameter sweep proposed by this review.
