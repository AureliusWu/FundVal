# Independent static review — private vertical candidate and qualification harness

日期：2026-10-23。审查者：`/root/vertical_boundary_review`。

工作目录：`C:/Users/84046/AppData/Local/Temp/FundVal-private-vertical-20261023-a1`。A 为当前 §52/54 正确性基线的 249 个实际源文件；B 为唯一私有纵切面候选。本报告只记录本代理实际做过的有限静态审查及只读读取的父级执行产物，不是候选全面语义验收。

## 1. 审查边界与操作

- 已完整阅读项目 `D:/AI项目/FundVal/AGENTS.md` 和本工作目录 `PLAN.md`、`QUALIFICATION_PROTOCOL.md`。
- 使用只读文件读取、`Get-FileHash`、`rg` 和 `git diff --no-index` 对比源码；没有执行应用模块、controller、build 或 test。
- 初期审查六个 acquisition/resource/execution/security 文件；另针对 transport 字段读取 A 的 Quote normalizer、App health/refresh 片段和字段消费者。
- 后续专门审查了 qualification controller 的未执行版本及父级修复版本。
- 最后只读读取父级一次 materiality screen 的 `RESULT.json` 和 budget receipts，没有独立重跑或重新计算整个产物。
- 本代理在本工作目录唯一新增文件是本报告；没有修改 A/B、根项目、配置、协议或 harness。

结论强度：**中间快照的有限差异审查未发现可证 P0/P1，不等于最终 B 的无 Bug、行为等价或语义 PASS。** 最终 Worker/estimate 的 SHA 已变化，不能继承中间快照的具体结论。B 已因体积门禁失败，不采用。

## 2. 实际审查的源码身份

以下路径均相对于本工作目录，SHA-256 使用小写。A 的 SHA 在报告归档前只读核对；A 不可变对照的 clean rows SHA 为 `82532f847b3cd71eaba06703b0609e75520780ecf26b9c23e9fc3d01e301795e`。

### 2.1 A 对照文件

| 文件 | SHA-256 | 实际阅读范围 |
| --- | --- | --- |
| `A/js/runtime/worker-contract.js` | `54bab1e12f3127b8d28b98185175864ea4dc420b2c862954ab542b3293aa2b44` | 与 B Worker 全部差异，并阅读完整 B 对应逻辑 |
| `A/js/eastmoney-estimate.js` | `5ed4a84b2d513c7289afd5facfe961f86ccc9d01653e72915a96c5bb5c5bd1d6` | 全部差异 |
| `A/js/fund-holdings.js` | `cf973abf1bd30dc1cf3b2f0095d66cb70a8d368c2278c6b7c2c5bfae0c8894db` | 全部差异 |
| `A/js/runtime/refresh-resource-cache.js` | `7f0103a803f83b31df0631cb3a7c53949e7f80259c909becf4eccc6ce0fb6231` | 全部差异，并阅读完整 B 对应逻辑 |
| `A/js/runtime/refresh-execution.js` | `462a76335cb145af061d2f9783f1bfaf0e93a9053ed757bbde2b45a792d76afe` | 全部差异，并阅读完整 B 对应逻辑 |
| `A/js/runtime/security-quote-batch.js` | `6a944c6f279f865409ef57587bd4d80610b8a1786f5b3f8dabb18eea4317d529` | 全部差异；不是该文件所有辅助函数的独立审计 |
| `A/js/runtime/quote-normalizer.js` | `2268033d6f6852ac6b112b7f6ee6611f3788a4936ba88556df8ca0257cf1d07a` | 第 1–236 行，重点 `normalizeEstimateQuote` 及其 freshness/diagnostic helpers |
| `A/js/app.js` | `17826050a92d14d4ff7327c275e6c04a60632b6e01d9d046f05c4554e9f84359` | 搜索字段消费者及约第 761–835 行的 health/current-generation/accuracy 片段；没有全文件审计 |

### 2.2 B 中间快照——实际静态差异结论所绑定的身份

| 文件 | 审查时 SHA-256 | 范围说明 |
| --- | --- | --- |
| `B/js/runtime/private-worker-acquisition.js` | `7ad2a06374fc5f684875bef9f95cc7779a87b50213eb529d73b265f65fb06a8a` | 首轮完整读取及与 A diff；此时主要是改名/封装私有入口 |
| 同上 | `440a40726dfe9df0964868b95f729ed5d00b220ad42bd8eb0be6381fe866572c` | 再次阅读第 180–251 行，审查 transport wrapper 移除；下节该项结论只绑定本 SHA |
| `B/js/runtime/private-estimate-acquisition.js` | `bae5a7fcec5cdf9a9e68f9a1f7b77365ea9fee5f56c8617f859840a3be5bb9e3` | 完整读取及与 A diff；尚未包含后来临时 status 投影优化 |
| `B/js/runtime/private-holdings-acquisition.js` | `3c6941911cae68ed263264590f841d2daaef3d339c98940bc99ecfd8d8599b3f` | 完整读取及与 A diff；报告前 SHA 未变 |
| `B/js/runtime/private-resource-codec.js` | `90742b7d72334a27c316e8478f0206a5dbe35ff49797cc422a13b9d7086c2969` | 完整读取及与 A diff；报告前 SHA 未变 |
| `B/js/runtime/private-refresh-execution.js` | `ef395fc49c0fd3f86c1b3f99faa90d514d11cf3b80f1aa50cc3f58d530c25c46` | 首轮完整读取；最初仍使用原 security 模块 |
| 同上 | `888b312401e9b1ec8dd914e5ee4ce2bbe5f1ee6447a884d9134735fee80f0f39` | 审查其转向私有 security 的有限差异；报告前 SHA 未变 |
| `B/js/runtime/private-security-quote-batch.js` | `200d63ff97e24b4ac78fb483ebc05915c67e4eeabc61125723eb5960c76d9c7a` | 与 A diff 仅 cache import 改向；报告前 SHA 未变 |

### 2.3 最终候选身份变化——仅核对 SHA，没有补做最终语义审查

归档前读取到：

- `B/js/runtime/private-worker-acquisition.js`：`2d5ad9c9324f13a90a7b59cebb0c3481d894df24184d2ad4126f4c06f9196caf`。
- `B/js/runtime/private-estimate-acquisition.js`：`ff50cbdbcb843426ec00dc897f73f030d37373c9e81e9ce206b9733841f0fbb5`。

Pipeline agent 曾说明其后续新增 Worker envelope tail 省略返回槽、保留原 getter/iterable 读取，以及 estimate freshly-owned 对象临时 status 投影。**本代理没有对上述最终两个 SHA 补做完整源码差异/行为审查，不能把已审 `440a…` / `bae5…` 的结果套用于它们。** 新增 fund projection、私有 barrel、最终 App 改动也未在本次源码审查范围内。

## 3. 有限源码结论

### 3.1 Worker 严格 accounting、alias、presence 和 error 边界

首轮 Worker 与 A 的主要差异是改名、两个固定 endpoint 入口和复用原 `WorkerContractError`。已读中间 SHA 的第 56–151、155–218 行保留了 wire version、own-field presence、数值/别名冲突、source/target/base 日期、future clock、模型证据、requested/returned/unavailable/accounting 和 partial semantics 的原判断。没有观察到错误类分叉或以无条件 trust marker 绕过校验。

这仅说明已读差异，没有独立执行 getter/Proxy/异常顺序对比，也不证明最终 parser。

### 3.2 两个 transport 字段的中间优化

中间 Worker SHA `440a…` 第 220–228 行将 freshly-owned `normalized.status` 改为 `normalized.source_status`，省略公开 parser 的 `transport_status`、`adapterReasonCodes` 附加包装。

静态追踪结果：

- A 的生产源码搜索没有发现这两个字段的读取消费者，只有公开 parser 的定义。
- A Quote normalizer 第 162–219 行按已列字段生成 Quote，不读取两字段。
- A App health 约第 779–803 行只统计 `status`、`source_quote.status` 等，不读取两字段。
- 私有 resource codec 的 `ROW_FIELDS` 第 13–16 行不包括两字段；第 85–93 行先做白名单选择，然后第 185–188 行才进入 cache envelope。两字段不沿该路径进入资源 JSON/UI。
- 原始输入 late spread 仍保留。对未逃逸、新建普通对象上已有 own writable `status` 赋值，不会调用原始输入的 setter。

因此该中间差异没有可证 P0/P1。但 raw transport 字段 getter/opaque 对象的精确读取/异常次数、二次规范化以及最终完整调用链仍需独立行为证据；不能只凭“消费者搜索不到”宣称全等价。

### 3.3 HTTP acquisition

已读 estimate 第 68–94 行、holdings 第 7–38 行的 code 过滤、请求参数、force、abort/timeout、fetch/JSON、错误规范化和 cleanup 与 A 原入口保持对应。Holdings 私有入口删除未调用的公开 formatter/helper，并不是删除 `validateHoldingSet` 的运行时校验；本审查没有把这类公开 legacy 辅助代码误判成丢失规则。

### 3.4 Resource/cache 与执行层

私有 codec 在已审 SHA 下与 A 原实现仅有注释/文件分离差异：

- 第 167–190 行保留 acquisition-time 与 consumption-time 的独立校验。
- 第 202–230 行保留旧 NAV 适配的原时钟及 source/TTL 约束。
- 第 234–272 行保留 aggregate 序列化、unchanged resource 不续期、staged monotonic acquisition 检查、活跃基金裁剪、null/NaN 清理等。
- 私有 execution 的已读差异没有改变 metadata lane、调用期 TTL 重验、generation/abort、half-open ownership 和单次 aggregate flush；security 改向私有副本后，副本有限 diff 仅 cache import。

大量 K 规则在这些文件中仍是复制。**不能据此计算净退休，不能用 raw 行数推断 gzip 节省，也没有依据声称架构闭包已完全缩小。**

### 3.5 未证明边界

- 最终 Worker/estimate、App/fund projector 的 getter/opaque/read/error 全边界。
- source → resource → persistence → reload → winner/period → render 的独立 A/B。
- JSON round-trip、TTL 跨越、warm metadata、失败回退不续期、单 aggregate write、独立模型 evidence 和 accuracy 生命周期。
- 完整 default production namespace/backedge 闭合；中间私有 security 仍引用原 holdings 的 `holdingQuoteCode`、原 overseas 模块常量。它们是需最终 graph/依赖分析的事项，不应在实现中途仅凭 import 将其判为 Bug。
- 任何最终候选语义 PASS、完整 QA、配对性能、生产行情真实性或可发布性。

## 4. Qualification harness 独立审查与父级修复

### 4.1 实际审查的 harness 版本

| 文件/阶段 | SHA-256 | 审查说明 |
| --- | --- | --- |
| `QUALIFICATION_PROTOCOL.md` | `bef327cb19637b5cd1b81a38b637c3d8d4ae438fadc5c1cdd58086b38a448c22` | 完整读取，归档前 SHA 不变 |
| `qualification.mjs` 首轮 | `c14f3b4b8ea71b20a4b9f3e7a61129957b16d0b57a8bf502e8d663ad9916ca23` | 完整静态读取；父级说明只做过语法检查，尚未运行 controller |
| `qualification.mjs` 第一修复版 | `fb94914c12863418dd300a63096f53ba227cc0f9a1dd1520255936c56245cdd0` | 完整静态读取，确认主要修复；当时仍未由本代理执行 |
| `qualification.mjs` 最终执行版 | `e4bbba5c9cc724c99de4835ed2a7a014b8916f79971c96af58b85847b2a37dd9` | 归档前完整分段读取并核对 SHA；含 live-child guard 和明确 delta 白名单 |

旧 harness 的 SHA 是审查时记录，不表示旧文件保留为当前文件，也不表示发生过失败构建。父级在首次 controller 执行前修复了前置问题。

### 4.2 首轮四项发现及最终可见修复

1. **预算异常退出混作真实超预算。** 旧版第 163 行将任何非零/空 exit 当成 B 不合格。最终第 87–91、216–226 行先拒 timeout/spawn error/signal/缺失 exit，解析原预算 JSON，核对实际 all/cold、固定 numerator `772277` / denominator `10` / cold `52241`，并要求原生 exit 与 `report.pass` 对应 0/1。不是靠提高预算修复。
2. **preflight/junction 等失败绕过结构化结果与后保护。** 最终第 249–259 行增加 main 外层失败结果与 failed-postflight，明确工具异常 exit2；原正常执行路径仍独立保存 failure/postflightError。
3. **只杀 npm 父进程导致构建子进程继续写入。** 最终第 55–75 行将超时清理限制为本次 spawn 进程，记录 `taskkill /PID /T /F` 原生结果及原始 stdout/stderr base64；不再把超时当预算失败。
4. **ledger/protocol 身份只在执行后检查。** 最终第 176–185、235–239 行执行前后都核对 frozen source、ledger、protocol、harness 本身与 FINAL_FREEZE；`HARNESS_FREEZE.json` 绑定自身和最终冻结记录。

### 4.3 后续发现及最终状态

- 第一修复版仍仅检查 PID 整数，无法证明该 PID 尚未退出；Node `exit` 可先于 `close`。本代理提出复用 PID 风险。最终第 51–58 行新增 `exitObserved`、`child.exitCode === null`、`child.signalCode === null`，第 66–73 行对父已退出/无 PID 明确记录终止未确认，不再向旧 PID 发 `/T`。本次实际 receipts 未发生 timeout，因此只确认静态防护存在，**没有故障注入验证此支路**。
- 首轮 B delta 仅记录、依赖人工检查。本代理指出该证据边界。最终第 153–167 行已加入无删除、仅两项 modified、固定八项 private added、build-script 仅指定 group membership 的断言；不是允许任意 flags/config/test 修改。
- 最终第 11–19 行模块初始化读取和版本断言仍先于 `main().catch`。若这里失败，不会产生 outer-failure RESULT。这是已明确的非阻断记录边界；在该阶段尚未构建或创建 junction，不能宣称所有启动失败都有结构化结果。

### 4.4 静态上成立、但不被提升为整体验收的工具边界

- 最终第 204–205 行 A 采用完整 127 文件 inventory 精确比较，另核对 16 chunks / raw252331 / all85969 / cold46149，不是只比较总包大小。
- 第 191–194 行构建显式固定 `SOURCE_DATE_EPOCH=1792046773`；版本断言固定 Node24.14.0/npm11.9.0。
- 第 119–131 行 dependency junction 核对实际相同目标，无安装/升级。
- `wx` 与唯一 `*-01` 目录保护已有输出不被自动覆盖。
- root business/site、指定68依赖、HEAD/branch/index 与 A immutable 检查独立存在。
- RESULT 显式保留 `completeQa`、`behaviorEquivalence`、`performance`、`adopt` 为 false，未将 materiality screen 等同于采用许可。

## 5. 一次 screen 的只读执行产物核对

本代理没有执行 screen。父级报告已完成一次 A/B screen；本代理随后只读解析 `materiality-A-01/RESULT.json`、`materiality-B-01/RESULT.json` 并读取两份 `budget.receipt.json`，观察到：

| 项目 | A | B |
| --- | --- | --- |
| status | `EXACT_CURRENT_A_BUILD_MATCH` | `MATERIALITY_NOT_QUALIFIED` |
| site inventory rows | 127 | 136 |
| app chunks | 16 | 17 |
| app raw bytes | 252331 | 256307 |
| all app gzip bytes | 85969 | 87338 |
| cold app gzip bytes | 46149 | 46005 |
| 原预算 native exit | 1 | 1 |
| budget signal / spawnError / timedOut | null / null / false | null / null / false |
| RESULT failure / postflightError | null / null | null / null |
| QA / equivalence / performance / adopt | 均 false | 均 false |

这不是 B 的可接受压缩结果：all gzip 比 A 增加1369 B，虽 cold 减少144 B，仍不能抵消总包失败。固定有理上限仍为77227.7 B（整数最多77227 B），B 需要至少再减少10111个整数B才满足该体积上限。本报告不宣称实际根目录 inventory 已由本代理重新验证；所读取父级 RESULT 的 before/after 均记录 root273、site127、installed68 与相同 HEAD/branch/index，且 postflightError 为 null。

两份预算 receipt 的读取身份：

- A：2026-10-23T02:34:48.629Z → 02:34:48.757Z；stdout358 B/SHA `e4f3b36f30fe449a85d8876669b5da2515b40fa3e37be9309bcefe25a0892c61`；stderr67 B/SHA `49a2de1f2771262e2e6425ee6bf66a07eaaf573457f59df8c937ad3135cba8e8`。
- B：2026-10-23T02:34:59.915Z → 02:35:00.056Z；stdout358 B/SHA `2cb51d59aeea316c569972dc0b216379a89d2931acbe80e8da8fd07c95f58a7c`；stderr67 B/SHA `f7eabf29befe9dd5327ca34694da61fbb961f080645b70bf3a7327ffe2848ae5`。

## 6. 最终结论与停止点

本审查的有效产物是有限静态差异证据及执行前 harness 修正建议，不是候选 semantic PASS。中间 Worker/HTTP/resource 快照未发现可证 P0/P1；最终 Worker/estimate 发生变化，未获本代理最终语义复核。完整候选还没有完整 QA、等价性或新性能验证；其一次真实 materiality screen 已失败。

**B 不采用，不发布，不继承旧性能结果，不将冷包小幅下降或中间静态审查转换为总门禁通过。** 本代理完成本文件后停止，保留源码、工具修复历史口径与失败产物供父级归档。
