import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import { lstat, mkdir, readFile, readdir, realpath, symlink, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { finished } from 'node:stream/promises';

const dir = import.meta.dirname;
const root = 'D:/AI项目/FundVal';
const expected = JSON.parse(await readFile('C:/Users/84046/AppData/Local/Temp/FundVal-accuracy-archive-20261022-parent/extract/parent/final-state.json', 'utf8'));
const snapshot = JSON.parse(await readFile(resolve(dir, 'SNAPSHOT.json'), 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const cleanRows = rows => rows.map(({path, bytes, sha256}) => ({path, bytes, sha256}));
const original = cleanRows(snapshot.files);
assert.equal(process.version, 'v24.14.0');
assert.equal(JSON.parse(await readFile('C:/Program Files/nodejs/node_modules/npm/package.json', 'utf8')).version, '11.9.0');
assert.equal(original.length, 249);
assert.equal(sha(JSON.stringify(original)), '82532f847b3cd71eaba06703b0609e75520780ecf26b9c23e9fc3d01e301795e');

async function save(path, bytes) {
  await mkdir(dirname(path), {recursive: true});
  await writeFile(path, bytes, {flag: 'wx'});
}

async function inventory(base, exclude = new Set(), part = '') {
  const rows = [];
  for (const item of await readdir(resolve(base, part), {withFileTypes: true})) {
    if (!part && exclude.has(item.name)) continue;
    const path = part ? part + '/' + item.name : item.name;
    assert.equal((await lstat(resolve(base, path))).isSymbolicLink(), false, path);
    if (item.isDirectory()) rows.push(...await inventory(base, exclude, path));
    else {
      const bytes = await readFile(resolve(base, path));
      rows.push({path, bytes: bytes.length, sha256: sha(bytes)});
    }
  }
  return rows.sort((a, b) => a.path.localeCompare(b.path));
}

async function native(out, label, command, args, cwd, envExtra = {}, timeoutMs = 240000) {
  await mkdir(out, {recursive: true});
  const stdoutPath = resolve(out, label + '.stdout');
  const stderrPath = resolve(out, label + '.stderr');
  const stdout = createWriteStream(stdoutPath, {flags: 'wx'});
  const stderr = createWriteStream(stderrPath, {flags: 'wx'});
  const startedAt = new Date().toISOString();
  const env = {...process.env, ...envExtra};
  delete env.NODE_OPTIONS;
  const child = spawn(command, args, {cwd, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe']});
  let spawnError = null, timedOut = false, timeoutTermination = null, exitObserved = false;
  child.on('error', error => {spawnError = error.message;});
  child.once('exit', () => {exitObserved = true;});
  child.stdout.pipe(stdout); child.stderr.pipe(stderr);
  const timer = setTimeout(() => {
    timedOut = true;
    if (Number.isSafeInteger(child.pid) && child.pid > 0 && !exitObserved
      && child.exitCode === null && child.signalCode === null) {
      // This PID is the live child created immediately above, never a searched
      // process or another project's server. /T includes npm's build child.
      const stopped = spawnSync('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'],
        {windowsHide: true, encoding: null, timeout: 15000});
      timeoutTermination = {command: 'taskkill.exe', args: ['/PID', String(child.pid), '/T', '/F'],
        nativeExit: stopped.status, signal: stopped.signal, error: stopped.error?.message ?? null,
        stdout: (stopped.stdout ?? Buffer.alloc(0)).toString('base64'), stderr: (stopped.stderr ?? Buffer.alloc(0)).toString('base64')};
    } else {
      timeoutTermination = {status: 'NOT_CONFIRMED_PARENT_ALREADY_EXITED_OR_NO_PID', pid: child.pid ?? null,
        exitObserved, exitCode: child.exitCode, signalCode: child.signalCode};
      // Never use an exited parent's potentially recycled PID. This is an
      // execution failure, not a sealed candidate result; release local pipe
      // handles only so the failure receipt can be written for manual audit.
      child.stdout.unpipe(stdout); child.stderr.unpipe(stderr);
      child.stdout.destroy(); child.stderr.destroy(); stdout.end(); stderr.end();
    }
  }, timeoutMs);
  const {code, signal} = await new Promise(resolveExit => child.once('close', (code, signal) => resolveExit({code, signal})));
  clearTimeout(timer);
  await Promise.all([finished(stdout), finished(stderr)]);
  const outBytes = await readFile(stdoutPath), errBytes = await readFile(stderrPath);
  const receipt = {label, command, args, cwd, envExtra, startedAt, finishedAt: new Date().toISOString(), nativeExit: code, signal, spawnError, timedOut, timeoutTermination,
    stdout: {bytes: outBytes.length, sha256: sha(outBytes)}, stderr: {bytes: errBytes.length, sha256: sha(errBytes)}};
  await save(resolve(out, label + '.receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  process.stdout.write(JSON.stringify({label, nativeExit: code, stdoutBytes: outBytes.length, stderrBytes: errBytes.length}) + '\n');
  return {receipt, stdout: outBytes, stderr: errBytes};
}

function normalExit(receipt) {
  assert.equal(receipt.timedOut, false, receipt.label + ' timeout');
  assert.equal(receipt.spawnError, null, receipt.label + ' spawn');
  assert.equal(receipt.signal, null, receipt.label + ' signal');
  assert.ok(Number.isInteger(receipt.nativeExit), receipt.label + ' missing native exit');
}

async function protect(out, label) {
  assert.deepEqual(await inventory(root, new Set(['.git', 'node_modules', 'site', 'Temp', '.claude', 'docs'])), expected.noDocs, 'root business inputs');
  assert.deepEqual(await inventory(resolve(root, 'site')), expected.site, 'root site');
  for (const row of expected.installed) {
    const bytes = await readFile(resolve(root, 'node_modules', row.path));
    assert.equal(bytes.length, row.bytes, row.path);
    assert.equal(sha(bytes), row.sha256, row.path);
  }
  const document = expected.rows.find(row => row.path === 'docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');
  assert.equal(sha(await readFile(resolve(root, document.path))), document.sha256);
  for (const [tag, args, value] of [
    ['head', ['rev-parse', 'HEAD'], expected.head],
    ['branch', ['branch', '--show-current'], expected.branch],
    ['index', ['diff', '--cached', '--binary'], expected.indexSha256],
  ]) {
    const result = await native(out, label + '-' + tag, 'git', ['-C', root, ...args], dir, {}, 30000);
    normalExit(result.receipt);
    assert.equal(result.receipt.nativeExit, 0);
    assert.equal(tag === 'index' ? sha(result.stdout) : result.stdout.toString().trim(), value);
  }
  assert.deepEqual(await inventory(resolve(dir, 'A'), new Set(['site', 'node_modules'])), original, 'A immutable');
  return {rootInputCount: expected.rows.length, rootInputRowsSha256: sha(JSON.stringify(expected.rows)), siteCount: expected.site.length,
    siteRowsSha256: sha(JSON.stringify(expected.site)), installedCount: expected.installed.length, head: expected.head, branch: expected.branch, indexSha256: expected.indexSha256};
}

async function linkDependencies(side) {
  const target = resolve(root, 'node_modules'), path = resolve(dir, side, 'node_modules');
  assert.equal(dirname(path), resolve(dir, side));
  assert.equal((await lstat(target)).isSymbolicLink(), false);
  try {
    await lstat(path);
    assert.equal((await lstat(path)).isSymbolicLink(), true, 'existing dependency link');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    await symlink(target, path, 'junction');
  }
  assert.equal((await realpath(path)).toLowerCase(), (await realpath(target)).toLowerCase());
  return {path, target: await realpath(path), kind: 'junction', installs: false};
}

async function main() {
  const mode = process.argv[2];
  assert.ok(['freeze', 'A', 'B'].includes(mode), 'freeze or A or B only');
  assert.equal(process.argv.length, 3);
  if (mode === 'freeze') {
    const out = resolve(dir, 'qualification-freeze');
    await mkdir(out);
    const before = await protect(out, 'before');
    const candidate = await inventory(resolve(dir, 'B'), new Set(['site', 'node_modules']));
    const ledger = await readFile(resolve(dir, 'IMPLEMENTATION.md'));
    const originalMap = new Map(original.map(row => [row.path, row]));
    const candidateMap = new Map(candidate.map(row => [row.path, row]));
    const delta = {added: [], modified: [], removed: []};
    for (const row of candidate) {
      const old = originalMap.get(row.path);
      if (!old) delta.added.push(row.path);
      else if (old.bytes !== row.bytes || old.sha256 !== row.sha256) delta.modified.push(row.path);
    }
    for (const row of original) if (!candidateMap.has(row.path)) delta.removed.push(row.path);
    assert.deepEqual(delta.removed, []);
    assert.deepEqual(delta.modified, ['js/app.js', 'scripts/build-site.mjs']);
    assert.deepEqual(delta.added, [
      'private-business-features', 'private-estimate-acquisition', 'private-fund-projection',
      'private-holdings-acquisition', 'private-refresh-execution', 'private-resource-codec',
      'private-security-quote-batch', 'private-worker-acquisition',
    ].map(name => 'js/runtime/' + name + '.js'));
    const originalBuild = (await readFile(resolve(dir, 'A/scripts/build-site.mjs'), 'utf8')).replaceAll('\r\n', '\n');
    const candidateBuild = (await readFile(resolve(dir, 'B/scripts/build-site.mjs'), 'utf8')).replaceAll('\r\n', '\n');
    const membership = "  'js/runtime/private-business-features.js', 'js/runtime/private-fund-projection.js',\n"
      + "  'js/runtime/private-worker-acquisition.js', 'js/runtime/private-estimate-acquisition.js',\n"
      + "  'js/runtime/private-holdings-acquisition.js', 'js/runtime/private-resource-codec.js',\n"
      + "  'js/runtime/private-refresh-execution.js', 'js/runtime/private-security-quote-batch.js',\n";
    assert.equal(candidateBuild.indexOf(membership), candidateBuild.lastIndexOf(membership));
    assert.equal(candidateBuild.replace(membership, ''), originalBuild, 'build delta only group membership');
    const after = await protect(out, 'after');
    await save(resolve(dir, 'FINAL_FREEZE.json'), JSON.stringify({schema: 1, status: 'FROZEN_FOR_MATERIALITY_ONLY', before, after,
      A: {rows: original, sha256: sha(JSON.stringify(original))}, B: {rows: candidate, sha256: sha(JSON.stringify(candidate))}, delta,
      ledger: {bytes: ledger.length, sha256: sha(ledger)}, protocolSha256: sha(await readFile(resolve(dir, 'QUALIFICATION_PROTOCOL.md')))}, null, 2) + '\n');
    await save(resolve(dir, 'HARNESS_FREEZE.json'), JSON.stringify({sha256: sha(await readFile(import.meta.filename)),
      finalFreezeSha256: sha(await readFile(resolve(dir, 'FINAL_FREEZE.json')))}, null, 2) + '\n');
    return;
  }
  const freeze = JSON.parse(await readFile(resolve(dir, 'FINAL_FREEZE.json'), 'utf8'));
  const harnessFreeze = JSON.parse(await readFile(resolve(dir, 'HARNESS_FREEZE.json'), 'utf8'));
  assert.equal(sha(await readFile(import.meta.filename)), harnessFreeze.sha256, 'harness identity');
  assert.equal(sha(await readFile(resolve(dir, 'FINAL_FREEZE.json'))), harnessFreeze.finalFreezeSha256);
  assert.equal(sha(await readFile(resolve(dir, 'IMPLEMENTATION.md'))), freeze.ledger.sha256);
  assert.equal(sha(await readFile(resolve(dir, 'QUALIFICATION_PROTOCOL.md'))), freeze.protocolSha256);
  const out = resolve(dir, 'materiality-' + mode + '-01');
  await mkdir(out);
  const receipts = [], before = await protect(out, 'before');
  assert.deepEqual(await inventory(resolve(dir, 'B'), new Set(['site', 'node_modules'])), freeze.B.rows, 'B frozen');
  if (mode === 'B') {
    const control = JSON.parse(await readFile(resolve(dir, 'materiality-A-01/RESULT.json'), 'utf8'));
    assert.equal(control.status, 'EXACT_CURRENT_A_BUILD_MATCH');
  }
  const dependencies = await linkDependencies(mode);
  const cwd = resolve(dir, mode), epoch = {SOURCE_DATE_EPOCH: '1792046773'};
  let status = 'EXECUTION_FAILURE', artifact = null, failure = null;
  try {
    const result = await native(out, 'build', process.execPath, ['C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js', 'run', 'build'], cwd, epoch);
    receipts.push(result.receipt);
    normalExit(result.receipt);
    assert.equal(result.receipt.nativeExit, 0, 'build native exit');
    const rows = await inventory(resolve(cwd, 'site'));
    await save(resolve(out, 'site.inventory.json'), JSON.stringify(rows, null, 2) + '\n');
    const manifest = JSON.parse(await readFile(resolve(cwd, 'site/js/app-chunks.json'), 'utf8'));
    const counts = {chunks: manifest.chunks.length, raw: manifest.chunks.reduce((n, row) => n + row.bytes, 0), all: manifest.chunks.reduce((n, row) => n + row.gzipBytes, 0), cold: manifest.chunks.filter(row => row.role === 'cold').reduce((n, row) => n + row.gzipBytes, 0)};
    artifact = {rows, rowsSha256: sha(JSON.stringify(rows)), ...counts};
    if (mode === 'A') {
      assert.deepEqual(rows, expected.site, 'A complete current artifact');
      assert.deepEqual(counts, {chunks: 16, raw: 252331, all: 85969, cold: 46149});
      status = 'EXACT_CURRENT_A_BUILD_MATCH';
    }
    for (const [label, args] of [
      ['chunks', ['--verify-app-chunks-directory', 'site']],
      ['graph', ['--verify-app-module-graph', 'site']],
      ['fingerprint', ['--directory', 'site']],
      ['budget', ['--assert-app-bundle-budget', 'site']],
    ]) {
      const gate = await native(out, label, process.execPath, ['scripts/release-fingerprint.mjs', ...args], cwd);
      receipts.push(gate.receipt);
      normalExit(gate.receipt);
      if (label !== 'budget') assert.equal(gate.receipt.nativeExit, 0, label);
      else {
        const report = JSON.parse(gate.stdout.toString());
        assert.equal(report.actualAllNonOcrGzipBytes, counts.all);
        assert.equal(report.actualColdStartGzipBytes, counts.cold);
        assert.equal(report.allBudgetNumerator, 772277);
        assert.equal(report.allBudgetDenominator, 10);
        assert.equal(report.coldBudgetBytes, 52241);
        assert.equal(report.pass, counts.all * 10 <= 772277 && counts.cold <= 52241);
        assert.equal(gate.receipt.nativeExit, report.pass ? 0 : 1, 'actual budget native exit');
        if (mode === 'B') status = report.pass ? 'MATERIALITY_PASS_ONLY' : 'MATERIALITY_NOT_QUALIFIED';
        else assert.equal(report.pass, false, 'fixed current A budget must fail');
      }
    }
  } catch (error) { failure = {message: error.message, stack: error.stack}; }
  let after = null, postflightError = null;
  try {
    after = await protect(out, 'after');
    assert.deepEqual(await inventory(resolve(dir, 'B'), new Set(['site', 'node_modules'])), freeze.B.rows, 'B unchanged after execution');
    assert.equal(sha(await readFile(resolve(dir, 'IMPLEMENTATION.md'))), freeze.ledger.sha256);
    assert.equal(sha(await readFile(resolve(dir, 'QUALIFICATION_PROTOCOL.md'))), freeze.protocolSha256);
    assert.equal(sha(await readFile(import.meta.filename)), harnessFreeze.sha256);
    assert.equal(sha(await readFile(resolve(dir, 'FINAL_FREEZE.json'))), harnessFreeze.finalFreezeSha256);
  } catch (error) {postflightError = {message: error.message, stack: error.stack};}
  if (failure || postflightError) status = 'EXECUTION_FAILURE';
  await save(resolve(out, 'RESULT.json'), JSON.stringify({schema: 1, side: mode, status, before, after, dependencies, artifact, receipts, failure, postflightError,
    completeQa: false, behaviorEquivalence: false, performance: false, adopt: false}, null, 2) + '\n');
  process.stdout.write(JSON.stringify({side: mode, status, artifact: artifact && {rows: artifact.rows.length, rowsSha256: artifact.rowsSha256, chunks: artifact.chunks, raw: artifact.raw, all: artifact.all, cold: artifact.cold}, failure, postflightError}) + '\n');
  if (status === 'EXECUTION_FAILURE') process.exitCode = 2;
  else if (status === 'MATERIALITY_NOT_QUALIFIED') process.exitCode = 1;
}

await main().catch(async error => {
  const out = resolve(dir, 'qualification-' + String(process.argv[2]).replace(/[^A-Za-z0-9_-]/g, '') + '-outer-failure-01');
  await mkdir(out);
  let postflight = null, postflightError = null;
  try { postflight = await protect(out, 'failed-postflight'); }
  catch (afterError) { postflightError = {message: afterError.message, stack: afterError.stack}; }
  await save(resolve(out, 'RESULT.json'), JSON.stringify({status: 'EXECUTION_FAILURE', error: {message: error.message, stack: error.stack},
    postflight, postflightError, completeQa: false, adopt: false}, null, 2) + '\n');
  process.stderr.write(error.stack + '\n');
  process.exitCode = 2;
});
