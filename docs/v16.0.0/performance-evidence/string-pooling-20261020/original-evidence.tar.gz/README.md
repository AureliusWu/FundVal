# FundVal M3 private value-string pool: rejected offline prequalification

Status: **NOT ADOPTED / NO ROOT EDITS / NO VITE BUILD / NOT RELEASED**.

Business source checkpoint: `170fd3eadc6da02750882f8a542904ee2358d0d9`. The original product remains all gzip **80,494 B**, cold gzip **42,985 B**, raw **235,647 B**. The original all-gzip ceiling **77,227.7 B** is unchanged.

## Result and stop decision

One fixed pooling algorithm, three predetermined paired rounds. No threshold, alias-order, source-scope or per-chunk gzip selection was adjusted after measurement.

| Variant | All gzip B | Cold gzip B | Raw B |
| --- | ---: | ---: | ---: |
| Original OXC bytes | 80,494 | 42,985 | 235,647 |
| Private const string pool | 81,135 | 43,337 | 228,068 |
| Delta | **+641** | **+352** | **-7,579** |

The pool contains 153 groups and replaces 1,117 complete value nodes. Although raw code is smaller, the actual sum of per-chunk default gzip is larger. Stop here and do not adopt or tune this candidate. No Vite integration, output rehash, full runtime qualification or latency sampling was attempted.

The six valid sample order is baseline/pool, pool/baseline, baseline/pool. Each side repeats its exact bytes and measurement fingerprint three times. Six sets of 16 actual chunk texts are retained: **96 chunk files**, plus six measurement JSON files. These are repeated deterministic artifact measurements, not six full application executions or independent user-performance samples.

## Protocol chronology and the initial tool failure

1. `protocol-v1.json` was written before candidate scanning, conversion or measurement. Its scope already included ordinary string `Literal` nodes and an entire untagged, zero-expression, single-quasi `TemplateLiteral` with string cooked value. It did not split or rewrite interpolated/template raw contents.
2. The first `probe-v1.mjs.txt` run proved the actual static graph was a DAG and found no direct eval/with. Its bare-identifier substitutions then failed Acorn reparsing: `Unexpected token (2:38307)`, position 39894. **Zero gzip/link measurement samples had run.**
3. The real original syntax includes `return` followed immediately by a static template containing `Notification`, then `in window`. A bare identifier can fuse with both adjacent keyword tokens. This was a conversion-tool correctness defect, not a product parse failure or evidence that pooling is generally impossible.
4. Root explicitly approved exactly one fixed lexical correctness repair before any valid measurement: replace each complete value with **`(alias)`**, count the two parentheses bytes in every occurrence's raw-saving estimate, and add newline separators around the new const declaration so a directive without an explicit semicolon remains separated. The same scope, count/size/positive-saving thresholds, alias enumeration and single pooling design were retained.
5. `protocol.json` and `probe.mjs` are that v2. The v2 protocol retains the inherited `stateAtCreation` text as the **original plan's v1 preregistration fact**. It does **not** mean the v2 file itself predated the v1 scan/failure. Its `correctnessCorrection` field records the actual sequence. Do not edit the historical protocol field to imply a first-pass success.
6. The corrected v2 passed candidate parsing/AST validation, then ran the complete six predetermined measurements. The failed v1 run is not part of those six.

`failure-v1.json` records the actual command error and zero-measurement phase, with hashes of all three original v1 files. The original failure's candidate text was not saved by v1 before parsing; this missing artifact is disclosed, not retrospectively recreated. Full process stdout/stderr was not separately captured as a log file. The command outputs remain in the task tool record; no standalone raw log is claimed. V2 saves each complete candidate text before reparsing.

## Exact finite scope

- Actual input: the 16 existing OXC chunks, initially checked against the original manifest byte lengths and SHA256.
- Static graph precondition: 16 nodes / 18 static edges, DAG. Native static-link evidence does not prove runtime ordering.
- Stop on direct eval/with, hashbang, unexpected export-all surface or an encountered source-dependent literal-as-callee boundary.
- Eligible values: ordinary string `Literal`, or a complete untagged static `TemplateLiteral` with exactly one string cooked quasi and no expressions; grouping uses exact decoded value.
- Skip directive values, every static/dynamic import or reexport source, import/export specifier names, all noncomputed object/method/class keys, tagged-template subtrees, interpolated template quasis, and regex literals.
- Each eligible original node must be at least 6 UTF-8 bytes, a decoded-value group must occur at least 3 times, and the conservative raw-saving estimate must be positive. The estimate includes `(alias)` cost and a separate newline-delimited declaration per group; the actual output combines accepted groups into one const declaration.
- Aliases are fixed increasing-length enumeration over `abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$_`, skipping all original `Identifier`/`PrivateIdentifier` names throughout each chunk and all reserved words. Group order is first source occurrence; an alias is reserved only for an accepted group.
- The const declaration is not exported. It is initialized after the original directive prologue and before other original statements; original statement order is retained.

## Qualification actually performed

Before any valid measurement, v2 reparsed ES2022, checked every new initializer's decoded value, checked each alias at its exact expected original AST structural position, removed only the introduced declaration, restored those original nodes and required all remaining AST structure to match. Only source positions were ignored; original regex patterns, template raw, syntax and original literal raw properties were retained. Explicit static export-name sets were unchanged.

All six sets passed actual final-code literal-import/cold-partition checks and native static ESM binding linking. The linker did not evaluate supplied modules. The records explicitly keep `evaluated:false`, `startupOrderVerified:false` and `dynamicNamespaceMembersVerified:false`.

This is not a proof of arbitrary source reflection, error-stack identity, eager string-binding CPU/memory cost, full API/DOM behavior, physical-device behavior, PWA updates or user-visible latency. The new eager const initialization is an intentional code change whose full runtime effects were not qualified.

The existing already-hashed chunk paths were retained **only as offline identifiers**. The pooled bytes therefore do not constitute deployable content-hash paths or a real Vite candidate. No deployment content hash, Pages artifact or new Service Worker inventory was generated. The original manifest partition is used for graph comparison, not as a claim that pooled bytes satisfy the original byte hashes.

## Inputs and independent read-only checks

`summary.before` and `summary.after` match for the complete 73-file project JS inventory, complete 127-file/92,507,677-byte product site inventory, build recipe bytes and graph-verifier tool bytes. They do not claim that unrelated concurrent tool/document work was absent.

`input-app-chunks.json` was copied from the unchanged product **after measurement** for archiving. Its bytes match `summary.manifestSha256` (`f0f72a2d088bb1a015cc658a317953fcf45637aa0e99cfa58ae4cffa2faf958e`). This is an after-the-fact exact copy of the proven unchanged input, not a newly generated or edited product manifest.

The owner re-read all 96 actual chunks and checked their lengths, SHA256 and default gzip against all six measurement reports; all 16 prequalification texts match every pooled round. A separate reviewer independently repeated that byte inventory, source-position AST restoration, context exclusion, thresholds, alias-order and raw-estimate checks for all 153 groups/1,117 occurrences. Neither read-only review reran conversion, Vite, a JS minifier, native linking, application evaluation or a new experiment.

## Fixed archive contents

- `README.md`: this explanation and chronology.
- `protocol-v1.json`, `probe-v1.mjs.txt`, `prerequisites.json`: untouched original protocol/tool/prerequisites.
- `failure-v1.json`: actual initial syntax failure facts and original hashes; not a fabricated complete stderr capture.
- `protocol.json`, `probe.mjs`, `prerequisites-v2.json`: approved fixed v2 protocol/tool, original static graph and input inventories.
- `input-app-chunks.json`: exact input manifest bytes, copied after measurement as disclosed above.
- `transformations.json`: all 153 accepted groups, decoded static values, aliases, source positions, original node texts and conservative estimates.
- `qualification-candidates/`: all 16 complete pooled texts saved before their parsing checks, including unchanged chunks.
- `artifacts/1-baseline/`, `artifacts/1-pooled/`, `artifacts/2-pooled/`, `artifacts/2-baseline/`, `artifacts/3-baseline/`, `artifacts/3-pooled/`: **96 actual chunk files** and six `measurement.json` reports.
- `summary.json`: full six measurements, input inventories, fixed protocol, transformation receipts, final graph/link reports and rejection result.

External existing tools are referenced by the probe: Acorn from the pre-existing isolated minifier directory and the project's `scripts/app-module-graph.mjs` with the exact SHA recorded in the inventories. No dependency installation occurred for this experiment. This directory is not presented as a self-contained npm runtime.

Replay requires a fresh outside-repository directory, frozen inputs/tool dependencies and newly named results. Do not run the probe in this historical evidence directory or overwrite the original files. The fixed positive-raw-saving filter must not be replaced with per-chunk gzip cherry-picking to reclassify this rejected result.
