import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { dirname, resolve, relative, posix } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { gzipSync } from 'node:zlib';

const directory = dirname(fileURLToPath(import.meta.url));
const root = 'D:/AI项目/FundVal';
const { parse } = await import(pathToFileURL('C:/Users/84046/AppData/Local/Temp/fundval-m3-minifier-5806c73ce04e4538992a1f6a39f21444/node_modules/acorn/dist/acorn.mjs'));
const { verifyAppModuleGraph } = await import(pathToFileURL(resolve(root, 'scripts/app-module-graph.mjs')));
const protocolBytes = await readFile(resolve(directory, 'protocol.json'));
const protocol = JSON.parse(protocolBytes);
assert.equal(protocol.stateAtCreation, 'PREDECLARED_BEFORE_CANDIDATE_SCAN_TRANSFORM_OR_MEASUREMENT');
assert.equal(protocol.toolCorrectnessVersion, 2);
assert.deepEqual(protocol.order, [['baseline', 'pooled'], ['pooled', 'baseline'], ['baseline', 'pooled']]);
const sha = value => createHash('sha256').update(value).digest('hex');
const manifestBytes = await readFile(resolve(root, 'site/js/app-chunks.json'));
const manifest = JSON.parse(manifestBytes);
const options = { ecmaVersion: 2022, sourceType: 'module' };
const sourceModules = [];
for (const row of manifest.chunks) {
  const bytes = await readFile(resolve(root, 'site', row.path));
  assert.equal(bytes.length, row.bytes);
  assert.equal(sha(bytes), row.sha256);
  sourceModules.push({ path: row.path, code: new TextDecoder('utf-8', { fatal: true }).decode(bytes), row });
}
assert.equal(sourceModules.length, 16);

async function inventory(base) {
  const files = [];
  async function visit(dir) {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const target = resolve(dir, entry.name);
      if (entry.isDirectory()) await visit(target);
      else if (entry.isFile()) {
        const bytes = await readFile(target);
        files.push({ path: relative(base, target).replaceAll('\\', '/'), bytes: bytes.length, sha256: sha(bytes) });
      } else throw Error('Unexpected inventory entry');
    }
  }
  await visit(base);
  files.sort((a, b) => a.path.localeCompare(b.path));
  return { files: files.length, bytes: files.reduce((sum, file) => sum + file.bytes, 0), sha256: sha(JSON.stringify(files)) };
}
const before = { js: await inventory(resolve(root, 'js')), site: await inventory(resolve(root, 'site')),
  builderSha256: sha(await readFile(resolve(root, 'scripts/build-site.mjs'))),
  graphToolSha256: sha(await readFile(resolve(root, 'scripts/app-module-graph.mjs'))) };

function walk(node, visit, trail = [], ancestors = []) {
  if (!node || typeof node !== 'object') return;
  if (typeof node.type === 'string') visit(node, trail, ancestors);
  for (const [key, value] of Object.entries(node)) {
    if (['start', 'end', 'loc', 'range', 'raw'].includes(key)) continue;
    if (Array.isArray(value)) value.forEach((child, index) => walk(child, visit, [...trail, key, index], [...ancestors, { node, key }]));
    else if (value && typeof value === 'object') walk(value, visit, [...trail, key], [...ancestors, { node, key }]);
  }
}
function valueOf(node) {
  if (node?.type === 'Literal' && typeof node.value === 'string') return node.value;
  if (node?.type === 'TemplateLiteral' && node.expressions.length === 0 && node.quasis.length === 1
    && typeof node.quasis[0].value.cooked === 'string') return node.quasis[0].value.cooked;
  return null;
}
function exportNames(ast) {
  const names = [];
  for (const node of ast.body) {
    if (node.type === 'ExportDefaultDeclaration') names.push('default');
    if (node.type === 'ExportAllDeclaration') throw Error('Unexpected export-all surface');
    if (node.type !== 'ExportNamedDeclaration') continue;
    for (const specifier of node.specifiers) names.push(specifier.exported.name ?? specifier.exported.value);
    if (node.declaration) {
      if (['FunctionDeclaration', 'ClassDeclaration'].includes(node.declaration.type)) names.push(node.declaration.id.name);
      else if (node.declaration.type === 'VariableDeclaration') {
        for (const d of node.declaration.declarations) { assert.equal(d.id.type, 'Identifier'); names.push(d.id.name); }
      } else throw Error('Unexpected export declaration');
    }
  }
  return names.sort();
}
function dependency(specifier, owner) {
  assert.equal(typeof specifier, 'string');
  assert.match(specifier, /^\.\.?\//);
  const target = posix.normalize(posix.join(posix.dirname(owner), specifier));
  assert.ok(sourceModules.some(module => module.path === target));
  return target;
}
const parsed = new Map();
const staticGraph = [];
for (const module of sourceModules) {
  assert.equal(module.code.startsWith('#!'), false, 'Hashbang unsupported');
  const ast = parse(module.code, options), edges = new Set();
  walk(ast, node => {
    if (node.type === 'WithStatement' || node.type === 'CallExpression' && node.callee.type === 'Identifier' && node.callee.name === 'eval') {
      throw Error('Direct eval/with is not permitted');
    }
    if (['ImportDeclaration', 'ExportNamedDeclaration', 'ExportAllDeclaration'].includes(node.type) && node.source) edges.add(dependency(node.source.value, module.path));
  });
  exportNames(ast);
  parsed.set(module.path, ast);
  staticGraph.push({ path: module.path, imports: [...edges].sort() });
}
const graphMap = new Map(staticGraph.map(row => [row.path, row.imports]));
const states = new Map(), topologicalDependenciesFirst = [];
function visitDag(path, trail = []) {
  if (states.get(path) === 1) throw Error('STATIC_CYCLE_STOP: ' + [...trail, path].join(' -> '));
  if (states.get(path) === 2) return;
  states.set(path, 1);
  for (const next of graphMap.get(path)) visitDag(next, [...trail, path]);
  states.set(path, 2); topologicalDependenciesFirst.push(path);
}
for (const module of sourceModules) visitDag(module.path);
await writeFile(resolve(directory, 'prerequisites-v2.json'), JSON.stringify({ protocolSha256: sha(protocolBytes), inputManifestSha256: sha(manifestBytes),
  staticDag: true, directEvalOrWith: false, staticEdges: staticGraph.reduce((sum, row) => sum + row.imports.length, 0),
  staticGraph, topologicalDependenciesFirst, before }, null, 2) + '\n', { flag: 'wx' });

const alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$_';
const reserved = new Set('await break case catch class const continue debugger default delete do else enum export extends false finally for function if implements import in instanceof interface let new null package private protected public return static super switch this throw true try typeof var void while with yield eval arguments'.split(' '));
function* aliases() {
  for (let length = 1; ; length++) {
    const digits = Array(length).fill(0);
    for (;;) {
      yield digits.map(index => alphabet[index]).join('');
      let i = length - 1;
      while (i >= 0 && ++digits[i] === alphabet.length) { digits[i] = 0; i--; }
      if (i < 0) break;
    }
  }
}
function excluded(node, ancestors) {
  if (ancestors.some(({ node }) => node.type === 'TaggedTemplateExpression')) return true;
  if (ancestors.some(({ node, key }) => ['ImportDeclaration', 'ImportExpression', 'ExportNamedDeclaration', 'ExportAllDeclaration'].includes(node.type) && key === 'source')) return true;
  if (ancestors.some(({ node }) => ['ImportSpecifier', 'ImportDefaultSpecifier', 'ImportNamespaceSpecifier', 'ExportSpecifier'].includes(node.type))) return true;
  const last = ancestors.at(-1);
  if (last?.node.type === 'ExpressionStatement' && typeof last.node.directive === 'string') return true;
  if (last && last.key === 'key' && ['Property', 'MethodDefinition', 'PropertyDefinition'].includes(last.node.type) && !last.node.computed) return true;
  return false;
}
function canonical(value) {
  if (typeof value === 'bigint') return { bigintValue: String(value) };
  if (Array.isArray(value)) return value.map(canonical);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'range'].includes(key))
    .sort(([a], [b]) => a.localeCompare(b)).map(([key, child]) => [key, canonical(child)]));
}
const candidateModules = [], transformations = [];
for (const module of sourceModules) {
  const ast = parsed.get(module.path), used = new Set(), occurrences = [];
  walk(ast, (node, trail, ancestors) => {
    if (['Identifier', 'PrivateIdentifier'].includes(node.type)) used.add(node.name);
    const value = valueOf(node);
    if (value === null || excluded(node, ancestors)) return;
    const text = module.code.slice(node.start, node.end);
    if (Buffer.byteLength(text) < 6) return;
    const last = ancestors.at(-1);
    if (last && ['CallExpression', 'NewExpression', 'TaggedTemplateExpression'].includes(last.node.type) && ['callee', 'tag'].includes(last.key)) {
      throw Error('Literal-as-callee source-dependent error boundary encountered; stop rather than expand scope');
    }
    occurrences.push({ node, trail, start: node.start, end: node.end, value, text, bytes: Buffer.byteLength(text) });
  });
  occurrences.sort((a, b) => a.start - b.start);
  const groups = new Map();
  for (const occurrence of occurrences) { if (!groups.has(occurrence.value)) groups.set(occurrence.value, []); groups.get(occurrence.value).push(occurrence); }
  const names = aliases(), accepted = [];
  let proposed;
  for (const [value, rows] of groups) {
    if (rows.length < 3) continue;
    if (!proposed) { do { proposed = names.next().value; } while (used.has(proposed) || reserved.has(proposed)); }
    const estimate = rows.reduce((sum, row) => sum + row.bytes, 0) - rows.length * (Buffer.byteLength(proposed) + 2)
      - Buffer.byteLength(`\nconst ${proposed}=${rows[0].text};\n`);
    if (estimate <= 0) continue;
    accepted.push({ alias: proposed, value, initializer: rows[0].text, estimatedSeparateRawSavings: estimate, occurrences: rows });
    used.add(proposed); proposed = null;
  }
  const replacements = accepted.flatMap(group => group.occurrences.map(row => ({ ...row, alias: group.alias }))).sort((a, b) => b.start - a.start);
  let candidate = module.code;
  for (const row of replacements) candidate = candidate.slice(0, row.start) + `(${row.alias})` + candidate.slice(row.end);
  let insertionIndex = 0;
  while (insertionIndex < ast.body.length && ast.body[insertionIndex].type === 'ExpressionStatement' && typeof ast.body[insertionIndex].directive === 'string') insertionIndex++;
  const insertionOffset = insertionIndex ? ast.body[insertionIndex - 1].end : 0;
  const declaration = accepted.length ? '\nconst ' + accepted.map(group => `${group.alias}=${group.initializer}`).join(',') + ';\n' : '';
  candidate = candidate.slice(0, insertionOffset) + declaration + candidate.slice(insertionOffset);
  const candidateTarget = resolve(directory, 'qualification-candidates', module.path);
  await mkdir(dirname(candidateTarget), { recursive: true });
  await writeFile(candidateTarget, candidate, { flag: 'wx' });
  const candidateAst = parse(candidate, options);
  assert.deepEqual(exportNames(candidateAst), exportNames(ast));
  if (accepted.length) {
    const [added] = candidateAst.body.splice(insertionIndex, 1);
    assert.equal(added.type, 'VariableDeclaration'); assert.equal(added.kind, 'const');
    assert.equal(added.declarations.length, accepted.length);
    for (let i = 0; i < accepted.length; i++) {
      assert.equal(added.declarations[i].id.type, 'Identifier');
      assert.equal(added.declarations[i].id.name, accepted[i].alias);
      assert.equal(valueOf(added.declarations[i].init), accepted[i].value);
    }
    for (const row of replacements) {
      let owner = candidateAst;
      for (const key of row.trail.slice(0, -1)) owner = owner[key];
      const key = row.trail.at(-1), replacement = owner[key];
      assert.equal(replacement.type, 'Identifier'); assert.equal(replacement.name, row.alias);
      owner[key] = row.node;
    }
  }
  assert.deepEqual(canonical(candidateAst), canonical(ast), module.path + ': unexpected structural AST change');
  candidateModules.push({ path: module.path, code: candidate });
  transformations.push({ path: module.path, eligibleValueOccurrences: occurrences.length, repeatedGroups: [...groups.values()].filter(rows => rows.length >= 3).length,
    acceptedGroups: accepted.length, replacementCount: replacements.length, declarationBytes: Buffer.byteLength(declaration), insertionIndex,
    astPositionRestorationVerified: true, namespaceExportNamesUnchanged: true,
    groups: accepted.map(group => ({ alias: group.alias, decodedValue: group.value, initializer: group.initializer, estimatedSeparateRawSavings: group.estimatedSeparateRawSavings,
      occurrences: group.occurrences.map(row => ({ start: row.start, end: row.end, trail: row.trail, originalType: row.node.type, originalText: row.text })) })) });
}
if (!transformations.some(row => row.acceptedGroups)) {
  await writeFile(resolve(directory, 'stopped.json'), JSON.stringify({ reason: 'NO_ELIGIBLE_POSITIVE_RAW_SAVINGS_GROUP', transformations, adoption: false }, null, 2) + '\n', { flag: 'wx' });
  process.stdout.write('STOP: no eligible groups; no pooled measurements\n');
  process.exit(0);
}
await writeFile(resolve(directory, 'transformations.json'), JSON.stringify(transformations, null, 2) + '\n', { flag: 'wx' });
const variants = { baseline: sourceModules.map(({ path, code }) => ({ path, code })), pooled: candidateModules };
const runs = [];
for (let round = 0; round < protocol.order.length; round++) for (const variant of protocol.order[round]) {
  const modules = variants[variant], measurements = [];
  for (const module of modules) {
    const bytes = Buffer.from(module.code), row = manifest.chunks.find(row => row.path === module.path);
    const target = resolve(directory, 'artifacts', `${round + 1}-${variant}`, module.path);
    await mkdir(dirname(target), { recursive: true }); await writeFile(target, bytes, { flag: 'wx' });
    measurements.push({ path: module.path, role: row.role, bytes: bytes.length, gzipBytes: gzipSync(bytes).length, sha256: sha(bytes) });
  }
  const graph = await verifyAppModuleGraph(manifest, modules);
  const record = { round: round + 1, variant, chunkCount: measurements.length,
    allGzipBytes: measurements.reduce((sum, row) => sum + row.gzipBytes, 0),
    coldGzipBytes: measurements.filter(row => row.role === 'cold').reduce((sum, row) => sum + row.gzipBytes, 0),
    rawBytes: measurements.reduce((sum, row) => sum + row.bytes, 0), fingerprint: sha(JSON.stringify(measurements)), graph, measurements };
  if (variant === 'baseline') assert.deepEqual({ chunks: record.chunkCount, allGzipBytes: record.allGzipBytes, coldGzipBytes: record.coldGzipBytes, rawBytes: record.rawBytes }, protocol.expectedBaseline);
  runs.push(record);
  await writeFile(resolve(directory, 'artifacts', `${round + 1}-${variant}`, 'measurement.json'), JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
  process.stdout.write(JSON.stringify({ round: record.round, variant, all: record.allGzipBytes, cold: record.coldGzipBytes, raw: record.rawBytes }) + '\n');
}
for (const variant of Object.keys(variants)) assert.equal(new Set(runs.filter(run => run.variant === variant).map(run => run.fingerprint)).size, 1);
const after = { js: await inventory(resolve(root, 'js')), site: await inventory(resolve(root, 'site')),
  builderSha256: sha(await readFile(resolve(root, 'scripts/build-site.mjs'))),
  graphToolSha256: sha(await readFile(resolve(root, 'scripts/app-module-graph.mjs'))) };
assert.deepEqual(after, before);
assert.equal((await readFile(resolve(root, 'site/js/app-chunks.json'))).equals(manifestBytes), true);
const baseline = runs.find(run => run.variant === 'baseline'), pooled = runs.find(run => run.variant === 'pooled');
const result = { schema: 1, protocol, protocolSha256: sha(protocolBytes), manifestSha256: sha(manifestBytes), before, after,
  staticDag: true, transformations, runs, delta: { allGzipBytes: pooled.allGzipBytes - baseline.allGzipBytes,
    coldGzipBytes: pooled.coldGzipBytes - baseline.coldGzipBytes, rawBytes: pooled.rawBytes - baseline.rawBytes },
  adoption: false, qualification: 'Offline old-path source-position AST/value/export checks and native static linking only. No Vite/minifier/app evaluation/full runtime or latency qualification.' };
await writeFile(resolve(directory, 'summary.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ pooledGroups: transformations.reduce((sum, row) => sum + row.acceptedGroups, 0),
  replacements: transformations.reduce((sum, row) => sum + row.replacementCount, 0), delta: result.delta, adoption: false }) + '\n');
