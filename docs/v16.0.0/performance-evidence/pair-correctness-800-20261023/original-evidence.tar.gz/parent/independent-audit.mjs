import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { sha, inv, json, save } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';
import { summarizePairs, rendererDelta, artifactFingerprint } from 'file:///D:/AI项目/FundVal/scripts/measure-performance-pair.mjs';
const here=import.meta.dirname,root='D:/AI项目/FundVal',frozen=json(resolve(here,'FROZEN.json'));
const rawPath=resolve(root,'docs/v16.0.0/performance-evidence/m3-pair-correctness-800-20261023.json');
assert.equal(existsSync(resolve(here,'INDEPENDENT_AUDIT.json')),false);
const rawBytes=readFileSync(rawPath),report=JSON.parse(rawBytes),receipt=json(resolve(here,'RECEIPT.json')),outcome=json(resolve(here,'OUTCOME.json'));
const checks=[],check=(name,fn)=>{try{fn();checks.push({name,pass:true});}catch(e){checks.push({name,pass:false,reason:e.message});}};
check('sampler source unchanged',()=>assert.equal(sha(readFileSync(resolve(root,'scripts/measure-performance-pair.mjs'))),frozen.toolHashes['scripts/measure-performance-pair.mjs']));
check('outer native status preserved',()=>{assert.equal(receipt.error,null);assert.equal(receipt.signal,null);assert.equal(receipt.nativeExit,{PASS:0,FAIL:1,INCONCLUSIVE:2}[report.status]);});
check('outer postflight stable',()=>assert.equal(outcome.postflightError,null));
check('raw report retained hash',()=>assert.deepEqual(outcome.rawReport,{bytes:rawBytes.length,sha256:sha(rawBytes),status:report.status,observed:report.observed}));
check('fixed request parameters',()=>assert.deepEqual(report.requested,{retainedPairs:800,warmupPairs:4,bootstrap:5000,seed:160003}));
check('same immutable reference',()=>assert.equal(report.referenceSha,frozen.reference));
check('full800plus4 required, no replacement',()=>{assert.equal(report.rawPairs.length,804);assert.deepEqual(report.observed,{retainedCompletePairs:800,warmupCompletePairs:4,failedPairs:0});for(const[pairIndex,pair]of report.rawPairs.entries()){assert.equal(pair.index,pairIndex);assert.equal(pair.retained,pairIndex>=4);assert.deepEqual(pair.order,pairIndex%2?['current','reference']:['reference','current']);assert.equal(pair.failure,undefined);assert.ok(pair.reference&&pair.current&&pair.finishedAt);}});
const retained=report.rawPairs.filter(p=>p.retained&&p.reference&&p.current&&!p.failure);
let recomputed=null;
check('entire unchanged bootstrap object, no filtered timing rows',()=>{recomputed=summarizePairs(retained,{bootstrap:5000,seed:160003});assert.deepEqual(report.summary,recomputed);});
check('original function threshold metadata',()=>{const m=report.summary.method;assert.equal(m.medianLimit,1.15);assert.equal(m.p95Limit,1.20);assert.equal(m.absoluteBudgetMs,3000);assert.equal(m.stabilityLimit,0.20);assert.equal(m.minimumPairs,60);assert.equal(m.bootstrap,5000);assert.equal(m.seed,160003);});
check('current127 complete artifact exact before/after',()=>{assert.deepEqual(report.artifactsBefore.current,frozen.artifact);assert.deepEqual(report.artifactsAfter.current,frozen.artifact);});
check('reference complete artifact exact before/after',()=>assert.deepEqual(report.artifactsBefore.reference,report.artifactsAfter.reference));
check('sampler source identity exact before/after',()=>{assert.deepEqual(report.currentSourceBefore,report.currentSourceAfter);assert.equal(report.currentSourceBefore.head,frozen.head);assert.equal(report.currentSourceBefore.trackedDiffSha256,frozen.trackedDiffSha256);});
check('sampler integrity and actual same lock',()=>{assert.equal(report.integrity.status,'PASS');assert.equal(report.dependencies.resolvedLockSha256,frozen.normalizedLockSha256);});
check('browser health',()=>assert.deepEqual(report.health,{status:'PASS',pageErrors:0}));
check('network instrumentation complete',()=>assert.deepEqual(report.instrumentation,{status:'PASS'}));
check('only owned lifecycle cleanup confirmed',()=>{assert.equal(report.cleanup.length,4);for(const r of report.cleanup)assert.equal(r.status,'PASS');assert.equal(report.cleanup.filter(r=>r.resource==='ownedServer').length,2);assert.ok(report.cleanup.some(r=>r.resource==='ownedBrowser'));assert.ok(report.cleanup.some(r=>r.resource==='validatedTemporarySnapshot'));});
const aggregate={sides:0,consoleErrors:0,pageErrors:0,serviceWorkerEvents:0,requests:0,requestsByCategory:{},requestsByTransport:{},rendererStatuses:{},rendererMissingReasons:{},longTaskCount:{cold:0,warm:0},longTaskTotalMs:{cold:0,warm:0},requestBytesByTransport:{}};
for(const pair of report.rawPairs)for(const side of ['reference','current']){
  const row=pair[side];if(!row)continue;const id=`pair${pair.index}/${side}`;aggregate.sides++;aggregate.consoleErrors+=row.consoleErrors;aggregate.pageErrors+=row.pageErrors;aggregate.serviceWorkerEvents+=row.serviceWorkerEvents??0;
  check(id+'/health',()=>{assert.equal(row.pageErrors,0);assert.equal(row.networkInstrumentation.failures,0);assert.equal(row.serviceWorkerEvents,0);assert.deepEqual(row.drains.map(d=>d.reason),['beforeOwnedWarmReload','afterWarmReadiness','beforeOwnedContextClose']);for(const d of row.drains)assert.equal(d.status,'SETTLED');assert.equal(row.requests.filter(r=>r.role==='serviceWorkerScript').length,0);});
  for(const phase of ['cold','warm','save']){
    const b=row.breakdown[phase],r=b.renderer;check(id+'/'+phase+'/SW',()=>{assert.equal(b.serviceWorkers.status,'REGISTRATION_BLOCKED');assert.equal(b.serviceWorkers.controlled,false);assert.equal(b.serviceWorkers.registrations,0);});
    check(id+'/'+phase+'/renderer recomputation',()=>assert.deepEqual(rendererDelta(r.snapshots.before,r.snapshots.after,{phase:phase==='save'?'interaction':'navigation'}),r));
    aggregate.rendererStatuses[phase+'/'+r.status]=(aggregate.rendererStatuses[phase+'/'+r.status]??0)+1;
    for(const reason of Object.values(r.invalidReasons??{}))aggregate.rendererMissingReasons[reason]=(aggregate.rendererMissingReasons[reason]??0)+1;
    if(phase!=='save'){aggregate.longTaskCount[phase]+=b.longTasks.length;aggregate.longTaskTotalMs[phase]+=b.longTaskTotalMs??0;}
  }
  for(const r of row.requests){aggregate.requests++;aggregate.requestsByCategory[r.category]=(aggregate.requestsByCategory[r.category]??0)+1;aggregate.requestsByTransport[r.transport]=(aggregate.requestsByTransport[r.transport]??0)+1;
    if(r.sizes){const bytes=Object.values(r.sizes).filter(Number.isFinite).reduce((a,b)=>a+b,0);aggregate.requestBytesByTransport[r.transport]=(aggregate.requestBytesByTransport[r.transport]??0)+bytes;}
  }
  check(id+'/provider and Gist isolation',()=>{assert.equal(row.requests.some(r=>r.category==='gistWriteBlocked'),false);for(const r of row.requests)if(r.category==='externalOrProxyBlocked'||r.category==='gistReadBlocked')assert.equal(r.transport,'blocked');});
}
check('final source full274 inventory',()=>{const source=json('C:/Users/84046/AppData/Local/Temp/FundVal-budget-policy-20261023-parent/FINAL_SOURCE_V2.json');assert.deepEqual(inv(root,new Set(['.git','node_modules','site','Temp','.claude','docs'])),source.noDocs);const fixed=source.full.find(r=>r.path==='docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');assert.equal(sha(readFileSync(resolve(root,fixed.path))),fixed.sha256);});
check('final installed68 inventory',()=>{for(const r of frozen.installed){const b=readFileSync(resolve(root,'node_modules',r.path));assert.equal(b.length,r.bytes);assert.equal(sha(b),r.sha256);}});
check('final physical current artifact fingerprint',()=>{});
try{assert.deepEqual(await artifactFingerprint(resolve(root,'site')),frozen.artifact);}catch(e){checks.at(-1).pass=false;checks.at(-1).reason=e.message;}
const result={schema:1,status:checks.every(c=>c.pass)?'INDEPENDENT_AUDIT_PASS':'INDEPENDENT_AUDIT_FAIL',raw:{bytes:rawBytes.length,sha256:sha(rawBytes),status:report.status,nativeExit:receipt.nativeExit},checks,checkCount:checks.length,failed:checks.filter(c=>!c.pass),recomputedSummary:recomputed,aggregate,environment:report.environment,artifacts:report.artifactsBefore,release:false,m3Exit:false,
  limitations:['hermetic desktop Chrome only; no physical devices or real financial/production network','warm HTTP no-store reload, not warm HTTP cache','navigation renderer is post-commit PARTIAL, not full startup/OS CPU','console count is retained; equal count does not establish every root cause','internal managed reference build native logs not preserved by unmodified sampler','no exact immutable CI or later M4-M6 evidence']};
save(resolve(here,'INDEPENDENT_AUDIT.json'),JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify({status:result.status,raw:result.raw,checks:result.checkCount,failed:result.failed,summary:recomputed,aggregate})+'\n');
if(result.failed.length)process.exitCode=3;
