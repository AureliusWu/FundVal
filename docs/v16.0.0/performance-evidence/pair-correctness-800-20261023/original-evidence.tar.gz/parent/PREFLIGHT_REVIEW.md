# Independent final preflight, 2026-10-23

Verdict: READY_FOR_ONE_DECLARED_RUN / NOT_RUN. No actual launch blocker was found in the inspected frozen state. The parent may start exactly the declared managed800-pair run through the reviewed runner, provided no source/site/dependency/protocol/tool or workload change occurs after this point. This is launch readiness only, not a performance PASS, M3 exit or release.

This reviewer read the complete new protocol and run.mjs, the full prewritten independent-audit.mjs and its prelaunch coverage amendment, FROZEN.json, the actual shared helper implementation, and the performance-regression-check skill. Only read-only file/hash/Git/process inspection and a standalone JSON/hash inventory diagnostic were used. No runner, sampler, audit script, test, build, app, service or dependency installation was executed. The sole reviewer write is this requested PREFLIGHT_REVIEW.md; FROZEN, runner, protocol and project files are untouched.

## Exact actual-versus-frozen checks

Independently re-enumerated the current source and site with a separate read-only implementation, rather than trusting stored row counts. Fresh results:

| Check | Fresh observed result |
| --- | --- |
| complete selected source scope |274 rows; SHA25689bdfff42618da6b1743a61e96bf4177ba34329ea716acb73c49e3ee920cc80f; exact noDocs equality with FINAL_SOURCE_V2 plus the fixed v15 document; matches FROZEN |
| current physical site |127 rows;92,557,057B; sorted-JSON SHA2560641039bb788b27c58c0ec0dc3d93b40cbc95bc2c51c935c105c9354c9b29d31; exact equality with expected site; matches FROZEN |
| sampler artifact algorithm |2037640ce945a052ba299a2bce19afdafd61b9ef1a77e7d687c75af983ea2e6e; matches FROZEN.artifact, not confused with sorted-JSON rows SHA |
| installed explicit files |68 physically read; byte length and SHA256 all match frozen rows |
| HEAD / branch |170fd3eadc6da02750882f8a542904ee2358d0d9 /codex/v16.0.0-m3-continuation; match |
| staged diff SHA |e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855; matches |
| tracked binary diff SHA |b1c4008e0f9c427b54312fe3dc57f722bc3186bcd273aca1e77880279fbd3494; matches |
| new protocol SHA |a7823c3c37d063c54e538c0b82c15f617f64de29bdd17e6acf601c80d48a181c; matches |
| runner SHA |04cea1aa648e35139c1bfa2503944fe3151abb6f3921ac9be803e3ab35bd4c99; matches |
| original recipe review and local copy |both a2b6033d5422cedc0f58ec62b890cb271273b4010cac54a3844b5199dfe50f4a; match |
| sampler / collector |2ca754524871b72c3c41f17ec2b6052ac74e3334ad034bf522a933cd9df295d7 /8a98f57980cfcde94e4035987c974b149c80bc27b51a1ca2309d3aed9d85bdd0; match original protocol and FROZEN |

The274 source scope is the declared noDocs selection plus one fixed historical document, not a claim that every workspace/history file is part of the build. Tracked documentation is additionally bound by the tracked diff, and the new untracked protocol by its explicit hash. No symlink/non-regular path was accepted by the independent enumeration.

Additional read-only input identities captured for this review:

- FROZEN.json:ac98096d18d54996f0ebf1aad286f777afa2e1bced01f2c4e2054e01f2bb586c.
- FINAL_SOURCE_V2.json:a442123dbb37ada24cb65b9c1ab1a5aed17f174aa406fd9d2c22793ccf66cee3.
- budget BEFORE.json:6f90f1d593dae5a49b554700af539f0d79be9d14893faf1ee78ace196b7d4be1.
- shared Temp common.mjs:b991fa3b0eaa89a6789b914596f24f90fc339cf759d534d69cd5aaa887cea81d.

The common helper and inventory JSON are transitive runner inputs outside the project; do not modify them during the run. Their current implementation was read and is consistent with the reviewed uses: SHA256, sorted physical enumeration, exclusive wx evidence writes and bounded native read-only Git commands. This review does not assume hostile concurrent filesystem mutation is impossible.

## Reference, dependencies and exact launch recipe

Fresh Git/package reads confirm reference057042963a33579c624a41404a6d533dfda29768, parentc2980265d3c89f960517ced1527ba9cb85bf7c2b, tree40098290fb64d31e0c8fcc12e552b3a913b5c715 and epoch1791676800 exactly match FROZEN. The existing named local057 reference still points to that object; only the previously known c298 and057 performance refs are listed. No new ref construction/update command exists in this runner.

The reference/current normalized locks are exactly equal at db9079726ec21ffe25c4882b47c5c8d5b03a4b5ef3036a587cee9c2e2b6336dc, under the original only-root.engines omission. Declared dependencies match and all eight installed declared package versions match. Actual Nodev24.14.0/npm11.9.0 match required versions. c298 itself is not substituted as the sampling reference.

FROZEN.args and run.mjs exactly encode the protocol's command:

```text
C:\Program Files\nodejs\node.exe
D:\AI项目\FundVal\scripts\measure-performance-pair.mjs
--reference 057042963a33579c624a41404a6d533dfda29768
--pairs 800
--warmup-pairs 4
--bootstrap 5000
--seed 160003
--timeout-ms 30000
--current-site D:\AI项目\FundVal\site
--output D:\AI项目\FundVal\docs\v16.0.0\performance-evidence\m3-pair-correctness-800-20261023.json
```

The800 retained pairs/4 warmups/5000 bootstrap/160003 seed and original statistical thresholds are unchanged. Generic summarizePairs minimum60 does not replace the protocol's800 complete pairs. The protocol correctly distinguishes the original save-median gate from the unchanged sampler's additional conservative save-p95 check. No threshold, fixture, financial rule, compatibility rule or cold budget is waived. The90KiB bundle policy is independent; the sampler is not a bundle-budget CLI.

## Runner safety and actual NOT_RUN state

The runner freeze phase has produced FROZEN and raw read-only Git preflight receipts; the parent reports freeze native0. This reviewer did not rerun it. The run branch rechecks the entire state against FROZEN before spawning, requires this review, rejects an existing raw output, strips only the predeclared NODE_OPTIONS/NODE_V8_COVERAGE variables and pins SOURCE_DATE_EPOCH/FORCE_COLOR/NO_COLOR. It performs one sampler spawn with windowsHide, no automatic retry, and preserves actual stdout/stderr/native exit/signal/error plus postflight state and output identity.

The helper's wx receipts in launch-preflight, wx sampler stdout/stderr and wx LAUNCH/PID/evidence writes fail closed on reuse. This is the actual exclusive launch/evidence mechanism; it does not depend on overwriting a mutable status marker. An unsuccessful setup that creates these paths must not be quietly retried by deleting them. A new declared recovery decision would be required.

At the inspected point, raw output, LAUNCH.json, PID.json, sampler.stdout, sampler.stderr and launch-preflight do not exist. The runner contains no current build or install operation. It invokes only the unchanged sampler, whose managed mode builds the isolated reference and starts/cleans only owned servers/browser/validated Temp snapshot, never the user's4173. No Git mutation/ref command is present. Current site must remain frozen.

Point-in-time process inspection found zero relevant sampler/runner/serve-site/build-site/Playwright processes and zero additional Node --test/npm test-build-check/known compiler matches. There are18 other Node and18 Chrome-like processes; they were left untouched. This is not proof the machine is idle or future scheduling noise cannot occur. Do not run parallel project gates or browser sampling after this preflight. Parent process observation must resume the same live handle; a tool wait timeout is not justification for a second launch.

## Prewritten independent audit: inspected, not executed

Final reviewed independent-audit.mjs SHA256 is060798af7929e03fa754baab11e6dfe63ca1d0cd3f7aadf4d575c91f1fa8246c. Before launch the parent amended only its health-check coverage: exact3 ordered drain reasons plus SETTLED and zero serviceWorkerScript request roles. These strings were checked against the original sampler's actual three drain calls. Runner/FROZEN/protocol remained unchanged and raw output remained absent after that amendment. This is a pre-outcome coverage correction, not an after-result change.

Static coverage is appropriate for its declared independent evidence audit:

-804 raw rows,800 retained+4 warmups, exact indices/retained bits/order, complete sides and no replacement/failure;
-full summarizePairs object deepEqual with unchanged bootstrap5000/seed160003; no timing-value/outlier filtering;
-original threshold metadata, preserved raw hash/status/native mapping and outer postflight;
-whole current/reference before/after artifact objects, current HEAD/tracked diff, original lock and integrity;
-per-side pageerrors/instrumentation/SW events, exact drain sequence/SETTLED, zero SW script roles, per-phase controller/registration denial;
-all rendererDelta objects recomputed from saved same-document snapshots, missing reasons/statuses aggregated without changing nulls or inventing a new renderer hard gate;
-provider/Gist isolation, complete cleanup categories, final selected274 source and68 installed physical identities, and final current artifact fingerprint.

The complete-pair check is a separate required check before interpreting bootstrap replay: although the retained expression filters incomplete rows for safe replay, any missing/failing pair already makes independent audit fail; it does not permit an audit PASS on a favorable timing subset. INDEPENDENT_AUDIT_PASS means faithful evidence/consistency checks, not automatically report.status=PASS; a faithfully verified statistical FAIL must remain FAIL. Preserve the renderer/console/blocked-request/fullstartup limitations and any audit-tool native failure; do not promote navigation PARTIAL attribution or missing counters to full CPU proof.

## Decision and stop

READY for one declared run under the exact reviewed state and original cleanup/statistical boundaries. Do not inherit section48's old800 PASS or current unit/E2E success as this new experiment's result. New performance PASS/FAIL/INCONCLUSIVE, full800 completeness, health/instrumentation/integrity, independent replay and cleanup must be assessed only after the single run finishes. No CI, real financial/Gist/OCR/PWA/physical-device/production/M3-exit/release qualification is granted here.

The Git diff hash diagnostic emitted existing CRLF notices; it exited0 and produced the exact frozen binary-diff hash. No failure was hidden or converted into performance evidence. Reviewer work is complete and stops after saving this file; no sampling is launched by the reviewer.
