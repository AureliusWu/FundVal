# Private diagnostics producer/Store boundary review

2026-10-22, current FundVal dirty source. Result: **NO_QUALIFIED_TRUST_SHORTCUT**. No product implementation, build/minifier/browser/install/network/full test-suite run or version change. Two fixed synthetic code-level cases were exercised; this is not another latency measurement or production-source check.

## The proposed cut, and why it fails the present constraints

The new idea was larger than the previously excluded three-slot cell helper: retain the existing public `createRefreshDiagnosticsStore` API while introducing a page-private Store entry that could directly reuse supposedly canonical, frozen internal executor reports. In principle this might keep generic untrusted-input copying out of the default graph without deleting the public function.

The producer-to-Store relationship does not support that deletion:

- `js/runtime/refresh-execution.js:54-78` freezes fixed diagnostic objects, but does not produce the Store's canonical shape. Freezing is not the same as complete validation/canonicalization.
- `js/runtime/generation-resource-scope.js:39,85,126-127` deliberately emits sparse provider counters. On the real existing no-holdings flow the raw snapshots contain0 then2 provider keys; on the one-watch flow0 then5. The Store outputs all seven fixed provider keys, with unobserved keys as **null**, not0. Direct reuse changes the DTO field-presence contract.
- The one-watch executor's actual plan order is `estimates,indices,gold,nav,holdings,meta,securities,model-quotes`; the Store's canonical order is `estimates,nav,holdings,meta,indices,gold,securities,model-quotes`. Reusing the raw frozen array is observably different even for valid internal reports.
- `refresh-generation.js:67-132,215-240` is the single place doing own-data descriptor reads, safe integers, fixed allowlists, canonical order, copying/freezing, absent-versus-explicit-invalid compatibility and matching generation. These are not two redundant validation passes.
- Moving those checks into a producer retains the algorithm in the default graph plus introduces an adapter/brand protocol. Bypassing them based only on an AST proof of today's caller would weaken the explicitly required data validation boundary. A private name is not authorization to remove validation.
- Lifecycle/rank/high-water/late-drain behavior at `refresh-generation.js:134-213` remains essential independently of payload copying. It cannot be removed with a trusted DTO shortcut. App binds this one Store at`app.js:75,81,895,1848`; diagnostics UI is read-only, not a second Store copy.

## Actual bounded evidence

`probe.mjs` uses the actual current `RefreshCoordinator`, `executeRefreshPlan` and `createRefreshDiagnosticsStore`, not copied scheduling/normalization algorithms. Fixed time2026-09-30T06:00:00Z; clients are in-memory synthetic fixtures; global fetch refuses any network; Storage is only a stub. Six real reports are preserved in `result.v2.json`: started/resources_settled/final for each fixed case. Existing empty flow completes; one-watch has no usable primary/NAV and correctly fails with the existing all-funds-failed path. Neither outcome is omitted or relabeled as business success. Every report shows the sparse-versus-canonical provider distinction and distinct copied counter/plan/skip objects. Source plus16 actual chunk files match before/after; no root changes.

The actual minified whole Store is a single4657B raw function in `site/js/chunks/post-integrity-BTxe0zEK.js`, offsets41620–46277, SHA256`8aeeb615da24389627a56f91a604c1decb52ee2ebde7c0bf6b477328baf12cb0`. This includes all indispensable lifecycle logic and is **not** a removable pool or compressed saving. No gzip is computed or inferred from this extent. No candidate variant is built.

The first probe expected both fixtures to complete and exited1 at the assertion. That was an expectation error: `ui.primary` is explicitly null for the one-watch fixture and the old executor must fail it. Original source is preserved as`probe.v1.mjs.txt`; original full terminal assertion only exists in tool history, not a separate captured first-result JSON. v2 changes only that expected one-watch status and the output filename. No fixture, implementation, sample or threshold changes; see`V1_EXPECTATION_NOTE.md` for the exact boundary. v2 native0. This ordinary synthetic-harness correction is not a retry/filter of the unrelated800-pair performance result.

## Decision and next action

Reject this trust shortcut before implementation or a build series. It does not establish a safe byte pool under the user's unchanged-validation condition. The wider quote/evidence pipeline review is separate; it must first establish full input/output/exception/read-order compatibility and default-graph deletion, rather than treat public exports as necessarily bundled or treat a sparse internal report as canonical. This finite rejection does not prove that no optimization is possible.

Current all84187/77227.7 still fails by at least6960 integer B. Version15.0.2/M3 IN_PROGRESS and no release remain unchanged. The earlier current-source800-pairPASS is not rerun here and has not been changed.
