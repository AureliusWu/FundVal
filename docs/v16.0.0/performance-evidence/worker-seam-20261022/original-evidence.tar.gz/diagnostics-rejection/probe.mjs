import assert from 'node:assert/strict';
import { readFile,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { resolve,dirname } from 'node:path';
import { fileURLToPath,pathToFileURL } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const sha=b=>createHash('sha256').update(b).digest('hex');
const paths=['js/app.js','js/runtime/refresh-generation.js','js/runtime/refresh-runtime.js','js/runtime/refresh-execution.js','js/runtime/generation-resource-scope.js','js/runtime/refresh-plan.js','site/js/app-chunks.json'];
async function identity(){const rows=[];for(const p of paths){const b=await readFile(resolve(root,p));rows.push({path:p,bytes:b.length,sha256:sha(b)});}
 const m=JSON.parse(await readFile(resolve(root,'site/js/app-chunks.json'),'utf8'));
 for(const row of m.chunks){const b=await readFile(resolve(root,'site',row.path));assert.equal(sha(b),row.sha256);rows.push({path:'site/'+row.path,bytes:b.length,sha256:sha(b)});}return rows;}
const result={schema:1,startedAt:new Date().toISOString(),scope:'Fixed synthetic diagnostics boundary proof only; not new performance/build/production evidence',cases:[],before:await identity()};
const {executeRefreshPlan}=await import(pathToFileURL(resolve(root,'js/runtime/refresh-execution.js')));
const {RefreshCoordinator}=await import(pathToFileURL(resolve(root,'js/runtime/refresh-runtime.js')));
const {createRefreshDiagnosticsStore}=await import(pathToFileURL(resolve(root,'js/runtime/refresh-generation.js')));
const NOW=Date.parse('2026-09-30T06:00:00Z');
let forbiddenFetches=0;globalThis.fetch=async()=>{forbiddenFetches++;throw Error('No network allowed in diagnostics preflight');};
for(const [name,snapshot]of [['empty',[]],['one-synthetic-watch',[{code:'005844',name:'Synthetic Watch',shares:0,cost:null}]]]){
 const store=createRefreshDiagnosticsStore(),observations=[],writes=[];
 const c=new RefreshCoordinator({now:()=>NOW,withBuiltinSources:true,onStateChange:value=>store.observeState(value),
  execute:context=>executeRefreshPlan({context,snapshot,options:{force:false},now:()=>NOW,
   onDiagnostics:raw=>{store.observe(raw);const record=store.snapshot().current;assert.equal(record.generation,raw.generation);
    observations.push({phase:raw.phase,status:raw.status,rawProviderKeys:Object.keys(raw.counters.providers),canonicalProviderKeys:Object.keys(record.counters.providers),
     rawProviders:raw.counters.providers,canonicalProviders:record.counters.providers,rawPlanKinds:raw.plan.map(r=>r.kind),canonicalPlanKinds:record.plan.map(r=>r.kind),
     countersCopied:record.counters!==raw.counters,planCopied:record.plan!==raw.plan,skipsCopied:record.skipReasons!==raw.skipReasons,
     executionSkipsCopied:record.executionSkips!==raw.executionSkips,rawAndCanonicalCounterShapesEqual:JSON.stringify(raw.counters)===JSON.stringify(record.counters)});},
   clients:{estimates:async(_holdings,_options,_context,dispatch)=>dispatch(async()=>new Map()),nav:async()=>null,holdings:async()=>null,
    indices:async codes=>codes.map(code=>({code,price:100,changePct:0,observedAt:new Date(NOW-1000).toISOString(),status:'current'})),
    gold:async(_signal,dispatch)=>dispatch(async()=>({price:100,changePct:0,observedAt:new Date(NOW-1000).toISOString(),status:'current',cached:false})),
    models:async()=>[],eastmoney:async()=>({data:{diff:[]}}),bridge:async()=>[],normalizeTime:()=>''},
   ui:{market(){},cacheData:()=>[],holdingsHash:()=>'synthetic',complete(){},primary:()=>null,failure(){}},
   storage:{setItem(key,bytes){assert.equal(key,'fuyu_funds_cache_v1');assert.equal(typeof bytes,'string');writes.push({key,bytes:bytes.length});return false;}}
  })});
 const outcome=await c.request({trigger:'manual'});assert.equal(outcome.status,name==='empty'?'completed':'failed');
 assert.deepEqual(observations.map(r=>r.phase),['started','resources_settled','final']);
 assert.ok(observations.every(r=>r.canonicalProviderKeys.length===7&&r.countersCopied&&r.planCopied&&r.skipsCopied&&r.executionSkipsCopied));
 assert.ok(observations.some(r=>r.rawProviderKeys.length<r.canonicalProviderKeys.length));
 result.cases.push({name,outcomeStatus:outcome.status,observations,syntheticWriteAttempts:writes,storeStatus:store.snapshot().current.status});
 await c.stopAndDrain('probe-finished');
}
assert.equal(forbiddenFetches,0);result.forbiddenFetches=forbiddenFetches;
const {parseSync}=await import(pathToFileURL(createRequire(resolve(root,'package.json')).resolve('rolldown/utils')));
const manifest=JSON.parse(await readFile(resolve(root,'site/js/app-chunks.json'),'utf8')),matches=[];
for(const row of manifest.chunks){const code=await readFile(resolve(root,'site',row.path),'utf8');
 function walk(n){if(!n||typeof n!=='object')return;
  if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(n.type)){const text=code.slice(n.start,n.end);
   if(['holdings_probe_used','cache_metadata_invalid','observeState','lastCancelled'].every(marker=>text.includes(marker)))matches.push({path:row.path,start:n.start,end:n.end,rawBytes:Buffer.byteLength(text),sha256:sha(text)});}
  for(const v of Object.values(n)){if(Array.isArray(v))v.forEach(walk);else if(v&&typeof v==='object')walk(v);}}
 walk(parseSync(row.path,code).program);
}
matches.sort((a,b)=>a.rawBytes-b.rawBytes);assert.equal(matches.length,1);result.currentMinifiedWholeStore=matches[0];
result.materialityCaveat='This is the entire live Store raw extent, including indispensable lifecycle logic. It is neither a removable pool nor gzip savings.';
result.after=await identity();assert.deepEqual(result.before,result.after);
result.verdict='NO_QUALIFIED_TRUST_SHORTCUT';result.reason='Producer snapshots are not canonical Store records: provider keys are sparse, plan kind order can differ, and Store supplies validated copied frozen DTOs. Keeping checks at producer retains that algorithm; bypassing them is not allowed.';
result.finishedAt=new Date().toISOString();
await writeFile(resolve(here,'result.v2.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({verdict:result.verdict,cases:result.cases.map(c=>({name:c.name,observations:c.observations.map(o=>({phase:o.phase,rawProviders:o.rawProviderKeys.length,canonicalProviders:o.canonicalProviderKeys.length,rawPlan:o.rawPlanKinds,canonicalPlan:o.canonicalPlanKinds,shapeEqual:o.rawAndCanonicalCounterShapesEqual}))})),currentMinifiedWholeStore:result.currentMinifiedWholeStore,forbiddenFetches}));
