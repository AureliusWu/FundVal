import assert from 'node:assert/strict';
import { readFile,writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const script='Temp/m3-material-boundary-20261022-scope-review/inventory.mjs';
const startedAt=new Date().toISOString();
const r=spawnSync(process.execPath,[script],{cwd:root,encoding:'utf8',windowsHide:true,timeout:60000,maxBuffer:2000000});
const receipt={command:process.execPath,args:[script],cwd:root,startedAt,endedAt:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?.message||null,stdout:r.stdout,stderr:r.stderr};
await writeFile(resolve(here,'independent-inventory.native.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
assert.equal(r.status,0);assert.equal(r.signal,null);assert.equal(r.error,undefined);
const actual=JSON.parse(r.stdout),saved=JSON.parse(await readFile(resolve(root,'Temp/m3-material-boundary-20261022-scope-review/inventory.json'),'utf8'));
assert.deepEqual(actual,saved);assert.equal(actual.declarationValidationOutputRawPool,945);assert.equal(actual.currentChunks.length,16);
const sha=b=>createHash('sha256').update(b).digest('hex');
const result={schema:1,checkedAt:new Date().toISOString(),verdict:'INDEPENDENT_INVENTORY_EXACTLY_REPRODUCED',nativeExit:r.status,stdoutSha256:sha(r.stdout),
 scriptSha256:sha(await readFile(resolve(root,script))),manifest:actual.manifest,declarationValidationOutputRawPool:actual.declarationValidationOutputRawPool,
 caveat:'Read-only AST/source inventory only. Raw pool is neither gzip saving nor removable under full validation. No product code, test, build, minifier or browser.'};
await writeFile(resolve(here,'independent-inventory-check.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
