# Targeted API/HTTP checks — COMMANDS PREPARED, NOT EXECUTED

This is a separate finite check, not full QA, E2E, performance qualification, adoption or permission to build.

Order: A then B; exactly one invocation per side, no retry, filtering, fixture/source repair or extra test file.
Working directories:
- A: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/A
- B: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/B

Exact command (same on each side, pinned Node executable):
C:/Program Files/nodejs/node.exe --test test/worker-contract-v16.test.js test/wire-compaction-characterization-v16.test.js test/estimate-http-characterization-v16.test.js test/fund-holdings.test.js test/eastmoney-estimate.test.js test/request-signal.test.js

Per-side timeout:120000ms. Capture complete native stdout as stdout.tap and stderr separately, command/cwd/Node identity/start/end/exit/signal/timeout. Preserve original TAP and all failures/skips; never treat missing output or a skip as a pass. Check source/installed identity before/after using the same frozen inventories as the build recorder.
Do not launch a six-build window on a failing/cancelled/incomplete targeted run. Stop for parent review; this protocol does not authorize fixes.
Execute only after explicit next parent go. No invocation has run at preparation.

