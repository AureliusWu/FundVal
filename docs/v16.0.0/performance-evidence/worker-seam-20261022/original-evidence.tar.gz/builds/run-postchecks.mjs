import assert from 'node:assert/strict';
import { mkdir, readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { workspace, json, exists, writeJson, fault, captureIdentity, approve, runNative } from './auxiliary-recorder.mjs';
assert.equal(process.argv[2], '--execute-approved-postchecks', 'Prepared only; explicit parent go is required.');
const authorization = await approve('parentApprovedForPostchecks', fileURLToPath(import.meta.url),
  'postcheckRunnerSha256', 'POSTCHECK_PROTOCOL.md', 'postcheckProtocolSha256');
const buildSummary = await json(resolve(workspace, 'execution-summary.json'));
assert.equal(buildSummary.status, 'SIX_BUILDS_RECORDED'); assert.equal(buildSummary.runs.length, 6);
assert.equal(await exists(resolve(workspace, 'postchecks')), false, 'No retry/overwrite');
const initial = await captureIdentity();
assert.deepEqual(initial.sides.A.artifact, (await json(resolve(workspace, 'runs/A3/receipt.json'))).artifact);
assert.deepEqual(initial.sides.B.artifact, (await json(resolve(workspace, 'runs/B3/receipt.json'))).artifact);
const order = [['A', 'graph', '--verify-app-module-graph'], ['A', 'budget', '--assert-app-bundle-budget'],
  ['B', 'graph', '--verify-app-module-graph'], ['B', 'budget', '--assert-app-bundle-budget']];
const folder = resolve(workspace, 'postchecks'); await mkdir(folder);
await writeJson(resolve(folder, 'started.json'), { at: new Date().toISOString(), authorization, order, initial });
const summary = { status: 'RUNNING', runs: [], adopted: false, expectedExistingBudgetFailure: true };
try {
  for (const [side, kind, option] of order) {
    const label = side + '-' + kind, dir = resolve(folder, label); await mkdir(dir);
    const record = { label, side, kind, before: await captureIdentity() }; assert.deepEqual(record.before, initial);
    let fatal;
    try {
      record.native = await runNative(side, ['scripts/release-fingerprint.mjs', option, 'site'], dir, 60000);
      assert.equal(record.native.signal, null); assert.equal(record.native.timedOut, false);
      assert.equal(record.native.spawnError, null); assert.deepEqual(record.native.pipeErrors, []);
      const stdout = await readFile(record.native.stdout.path, 'utf8');
      try { record.report = JSON.parse(stdout); } catch (e) { record.reportParseError = fault(e); }
      if (kind === 'graph') record.verdict = record.native.exitCode === 0 && record.report ? 'PASS' : 'GRAPH_OR_CLI_FAIL';
      else if (record.native.exitCode === 0 && record.report?.verdict === 'PASS' && record.report.pass === true) record.verdict = 'PASS';
      else if (record.native.exitCode === 1 && record.report?.verdict === 'FAIL' && record.report.pass === false) record.verdict = 'BUDGET_FAIL';
      else record.verdict = 'CLI_FAIL';
    } catch (e) { fatal = e; record.failure = fault(e); }
    try { record.after = await captureIdentity(); assert.deepEqual(record.after, initial); }
    catch (e) { fatal ||= e; record.afterFailure = fault(e); }
    record.complete = !fatal; await writeJson(resolve(dir, 'receipt.json'), record);
    summary.runs.push({ label, complete: record.complete, native: record.native || null,
      verdict: record.verdict || null, report: record.report || null, failure: record.failure || record.afterFailure || null });
    console.log(JSON.stringify({ label, nativeExit: record.native?.exitCode ?? null, verdict: record.verdict || null }));
    if (fatal) throw fatal;
  }
  summary.status = 'POSTCHECKS_RECORDED';
  summary.graphPass = summary.runs.filter(r => r.label.endsWith('-graph')).every(r => r.verdict === 'PASS');
  summary.budgetPass = summary.runs.filter(r => r.label.endsWith('-budget')).every(r => r.verdict === 'PASS');
  summary.cliFailures = summary.runs.filter(r => ['GRAPH_OR_CLI_FAIL', 'CLI_FAIL'].includes(r.verdict)).map(r => r.label);
  if (!summary.graphPass || summary.cliFailures.length) process.exitCode = 1;
} catch (e) { summary.status = 'STOPPED_IDENTITY_OR_NATIVE_FAILURE_NO_RETRY'; summary.failure = fault(e); process.exitCode = 1; }
finally { summary.finishedAt = new Date().toISOString(); summary.unattempted = order.slice(summary.runs.length).map(([s, k]) => s + '-' + k); await writeJson(resolve(folder, 'summary.json'), summary); }

