import { readFileSync,writeFileSync,readdirSync,lstatSync } from 'node:fs';
import { resolve,relative } from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { gzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
const dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex');
if(process.argv[2]!=='--child'){
 const startedAt=new Date().toISOString(),args=[import.meta.filename,'--child'];
 const r=spawnSync(process.execPath,args,{cwd:dir,windowsHide:true,encoding:null,timeout:60000,maxBuffer:2_000_000});
 const stdout=r.stdout??Buffer.alloc(0),stderr=r.stderr??Buffer.alloc(0);
 for(const [kind,b]of [['stdout',stdout],['stderr',stderr]])writeFileSync(resolve(dir,'builds-parent.'+kind),b,{flag:'wx'});
 const native={startedAt,endedAt:new Date().toISOString(),command:process.execPath,args,scriptSha256:sha(readFileSync(import.meta.filename)),exitCode:r.status,signal:r.signal,error:r.error?.message??null,stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}};
 writeFileSync(resolve(dir,'builds-parent.native.json'),JSON.stringify(native,null,2)+'\n',{flag:'wx'});
 console.log(stdout.toString('utf8').trim());console.log(JSON.stringify(native));process.exitCode=r.status??98;
}else{
 const w='C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2';
 const json=p=>JSON.parse(readFileSync(p,'utf8')),checks=[],allArtifacts=[];
 const check=(label,fn)=>{try{fn();checks.push({label,pass:true});}catch(error){checks.push({label,pass:false,error:error.message});}};
 function files(folder,base=folder){const rows=[];for(const e of readdirSync(folder,{withFileTypes:true})){const p=resolve(folder,e.name);assert.equal(lstatSync(p).isSymbolicLink(),false);if(e.isDirectory())rows.push(...files(p,base));else{assert.ok(e.isFile());const b=readFileSync(p);rows.push({path:relative(base,p).replaceAll('\\','/'),bytes:b.length,sha256:sha(b)});}}return rows.sort((a,b)=>a.path.localeCompare(b.path,'en'));}
 const summary=json(resolve(w,'execution-summary.json')),post=json(resolve(w,'postchecks/summary.json'));
 const order=['A1','B1','B2','A2','A3','B3'];
 check('all six exact native/order/completion',()=>{assert.equal(summary.status,'SIX_BUILDS_RECORDED');assert.deepEqual(summary.runs.map(r=>r.label),order);assert.deepEqual(summary.unattempted,[]);});
 const baseline=json(resolve(w,'frozen-receipts/postflight.json'));
 for(const label of order){
  const run=resolve(w,'runs',label),receipt=json(resolve(run,'receipt.json'));
  check(label+' native/build-input-window',()=>{assert.equal(receipt.native.exitCode,0);assert.equal(receipt.native.signal,null);assert.equal(receipt.native.timedOut,false);assert.equal(receipt.native.spawnError,null);assert.deepEqual(receipt.native.pipeErrors,[]);assert.deepEqual(receipt.before,receipt.after);});
  for(const kind of ['stdout','stderr']){const b=readFileSync(resolve(run,kind+'.bin'));check(label+' complete native '+kind,()=>{assert.equal(b.length,receipt.native[kind].bytes);assert.equal(sha(b),receipt.native[kind].sha256);});}
  const site=resolve(run,'site'),rows=files(site),fingerprint=sha(rows.map(r=>r.path+'\0'+r.sha256+'\n').join(''));
  const artifact={sha256:fingerprint,files:rows,fileCount:rows.length,totalBytes:rows.reduce((a,b)=>a+b.bytes,0)};
  check(label+' EVERY retained artifact row',()=>{assert.deepEqual(artifact,receipt.artifact);assert.deepEqual(artifact,receipt.retainedArtifact);assert.equal(rows.length,127);if(label.startsWith('A'))assert.deepEqual(artifact,baseline.currentArtifact);});
  const manifest=json(resolve(site,'js/app-chunks.json'));let all=0,cold=0,raw=0;
  for(const chunk of manifest.chunks){const b=readFileSync(resolve(site,chunk.path)),gzip=gzipSync(b).length;all+=gzip;raw+=b.length;if(chunk.role==='cold')cold+=gzip;check(label+' actual gzip '+chunk.path,()=>{assert.equal(b.length,chunk.bytes);assert.equal(sha(b),chunk.sha256);assert.equal(gzip,chunk.gzipBytes);});}
  check(label+' total measured and budgets',()=>{assert.equal(manifest.chunks.length,16);assert.equal(all,receipt.measurement.allGzipBytes);assert.equal(cold,receipt.measurement.coldGzipBytes);assert.equal(raw,receipt.measurement.rawBytes);assert.equal(all,label.startsWith('A')?84187:84257);assert.equal(cold,label.startsWith('A')?44699:44702);assert.equal(receipt.measurement.allPass,false);assert.equal(receipt.measurement.coldPass,true);});
  allArtifacts.push({label,artifact,all,cold,raw});
 }
 for(const side of ['A','B']){
  const list=allArtifacts.filter(r=>r.label.startsWith(side));
  check(side+' three entire artifacts deterministic',()=>{assert.deepEqual(list[0].artifact,list[1].artifact);assert.deepEqual(list[0].artifact,list[2].artifact);});
  const t=json(resolve(w,'tests',side,'receipt.json')),b=readFileSync(resolve(w,'tests',side,'stdout.tap')),text=b.toString('utf8');
  check(side+' actual 97-test spec output/native/identity',()=>{assert.equal(t.native.exitCode,0);assert.equal(t.native.stderr.bytes,0);assert.equal(sha(b),t.native.stdout.sha256);assert.equal(b.length,t.native.stdout.bytes);assert.deepEqual(t.before,t.after);for(const [name,n]of [['tests',97],['pass',97],['fail',0],['cancelled',0],['skipped',0],['todo',0]])assert.match(text,new RegExp('^ℹ '+name+' '+n+'\\r?$','m'));assert.equal((text.match(/^✔ /gm)||[]).length,97);});
  const finalRows=files(resolve(w,side,'site'));
  check(side+' final live site equals round3',()=>assert.deepEqual(finalRows,list[2].artifact.files));
 }
 const fixed=[['A-graph',0],['A-budget',1],['B-graph',0],['B-budget',1]];
 check('postcheck exact fixed order',()=>assert.deepEqual(post.runs.map(r=>r.label),fixed.map(r=>r[0])));
 for(const [label,expected]of fixed){const r=json(resolve(w,'postchecks',label,'receipt.json'));check(label+' native/full bytes/identity/verdict',()=>{assert.equal(r.native.exitCode,expected);assert.equal(r.native.signal,null);assert.equal(r.native.timedOut,false);assert.deepEqual(r.before,r.after);for(const kind of ['stdout','stderr']){const b=readFileSync(resolve(w,'postchecks',label,kind+'.bin'));assert.equal(b.length,r.native[kind].bytes);assert.equal(sha(b),r.native[kind].sha256);}if(expected===1){assert.equal(r.report.verdict,'FAIL');assert.equal(r.report.allPass,false);assert.equal(r.report.coldPass,true);assert.equal(r.verdict,'BUDGET_FAIL');}else assert.equal(r.verdict,'PASS');});}
 check('root entire127 product unchanged',()=>assert.deepEqual(files('D:/AI项目/FundVal/site'),baseline.currentArtifact.files));
 const failures=checks.filter(r=>!r.pass),report={schema:1,status:failures.length?'FAIL':'PASS',checks,failures,totals:allArtifacts.map(({label,all,cold,raw,artifact})=>({label,all,cold,raw,wholeSha256:artifact.sha256})),candidateDelta:{all:70,cold:3},adopted:false,fullQA:'NOT_RUN',performance:'NOT_RUN',scope:'Fresh exact127 per-run and root files; complete native outputs; original build/graph/budget receipts; no SUT reexecution'};
 writeFileSync(resolve(dir,'builds-parent.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:report.status,checks:checks.length,failures,totals:report.totals,candidateDelta:report.candidateDelta,adopted:false}));process.exitCode=failures.length?1:0;
}
