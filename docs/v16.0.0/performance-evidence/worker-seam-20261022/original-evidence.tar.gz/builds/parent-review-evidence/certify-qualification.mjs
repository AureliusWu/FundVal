import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
const dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex');
if(process.argv[2]!=='--child'){
 const startedAt=new Date().toISOString(),args=[import.meta.filename,'--child'];
 const native=spawnSync(process.execPath,args,{cwd:dir,windowsHide:true,encoding:null,timeout:30000,maxBuffer:2_000_000});
 const stdout=native.stdout??Buffer.alloc(0),stderr=native.stderr??Buffer.alloc(0);
 for(const [kind,bytes]of [['stdout',stdout],['stderr',stderr]])writeFileSync(resolve(dir,'qualification-parent.'+kind),bytes,{flag:'wx'});
 const receipt={startedAt,endedAt:new Date().toISOString(),command:process.execPath,args,cwd:dir,scriptSha256:sha(readFileSync(import.meta.filename)),native:native.status,signal:native.signal,error:native.error?.message??null,stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}};
 writeFileSync(resolve(dir,'qualification-parent.native.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(stdout.toString('utf8').trim());console.log(JSON.stringify(receipt));process.exitCode=native.status??98;
}else{
 const old='C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1';
 const q='C:/Users/84046/AppData/Local/Temp/FundVal-worker-seam-qualification-20261022-a1';
 const load=p=>JSON.parse(readFileSync(p,'utf8')),checks=[];
 const check=(label,fn)=>{try{fn();checks.push({label,pass:true});}catch(error){checks.push({label,pass:false,error:error.message});}};
 const bytes=readFileSync(resolve(q,'qualification-01.json')),raw=JSON.parse(bytes);
 check('immutable raw identity',()=>{assert.equal(bytes.length,10021622);assert.equal(sha(bytes),'361cece0f65c6c4dc76b30657d7d83f1a71befe5e55db025ce565d29259afd33');});
 const stored=load(resolve(old,'baseline-01.json'));
 const cases=load(resolve(old,'cases.json'));
 const baselineSource=readFileSync(resolve(old,'baseline.mjs'),'utf8');
 const runner=baselineSource.slice(baselineSource.indexOf('function run(api,spec,control=null){'),baselineSource.indexOf('const baseline=[];'));
 check('runner exact complete module',()=>assert.equal(readFileSync(resolve(q,'runner.mjs'),'utf8'),"import { makeCase } from './cases.mjs';\n"+runner+'export { run };\n'));
 check('runner function exact hash',()=>assert.equal(sha(runner),'66fcbdd3212b4fc18830cd0f86e2b70eaea4c5f48adf7a76af02b91918d22a75'));
 check('all generic case order preserved',()=>assert.deepEqual(raw.generic.map(r=>r.spec),cases.specs));
 const casesById=new Map(stored.baseline.map(r=>[r.spec.id,r.frozen]));
 for(const r of raw.generic){
  check('generic complete old/source/candidate '+r.spec.id,()=>{assert.deepEqual(r.stored,casesById.get(r.spec.id));assert.deepEqual(r.freshOld,r.stored);assert.deepEqual(r.candidate,r.stored);assert.equal(r.candidate.expectedOutcomeMatched,true);assert.equal(r.freshOld.expectedOutcomeMatched,true);assert.equal(Object.values(r.checks).every(v=>v===true),true);});
 }
 const selections=cases.specs.filter(r=>r.operation==='sequence'||r.operation==='parse'&&r.id!=='invalid-endpoint').map(r=>({id:r.id,endpoint:r.id.startsWith('h-')?'holdings':'estimates',operation:r.operation}));
 check('fixed exact selection/order',()=>assert.deepEqual(raw.fixed.map(r=>r.selection),selections));
 for(const r of raw.fixed){
  check('fixed full equality without candidate trace filter '+r.selection.id,()=>{assert.deepEqual(r.candidateFixed,r.oldBound);assert.equal(r.candidateFixed.expectedOutcomeMatched,true);assert.equal(r.oldBound.expectedOutcomeMatched,true);assert.equal(Object.values(r.checks).every(v=>v===true),true);});
  const original=casesById.get(r.selection.id),predicate=e=>e.op==='get'&&e.path==='options'&&e.key?.kind==='string'&&e.key.value==='endpoint';
  check('old-bound independent consistency '+r.selection.id,()=>{assert.equal(original.trace.filter(predicate).length,1);assert.deepEqual(r.oldBound.trace,original.trace.filter(e=>!predicate(e)));assert.deepEqual(r.oldBound.output,original.output);assert.deepEqual(r.oldBound.error,original.error);});
 }
 for(const r of raw.negativeControls){
  const original=stored.negativeControls.find(x=>x.id===r.control.id);
  check('negative control exact '+r.control.id,()=>{assert.deepEqual(r.mutated,original.mutated);assert.equal(Object.values(r.checks).every(v=>v===true),true);});
 }
 const clocks=raw.generic.find(r=>r.spec.id==='simulated-http-changing-date');
 check('clock event traces not just count',()=>assert.deepEqual(clocks.candidate.trace.filter(e=>e.op==='clock-getTime'),clocks.freshOld.trace.filter(e=>e.op==='clock-getTime')));
 check('all constraints',()=>{assert.equal(raw.generic.length,64);assert.equal(raw.fixed.length,52);assert.equal(raw.negativeControls.length,3);assert.equal(raw.summary.invocations,235);assert.deepEqual(raw.summary.denied,{fetch:0,localStorage:0,sessionStorage:0});assert.equal(raw.failures.length,0);assert.equal(raw.summary.status,'PASS');assert.equal(raw.coverage.fullAPIInputDomain,false);assert.equal(raw.coverage.fullHTTP,false);assert.equal(raw.coverage.build,false);});
 const failures=checks.filter(r=>!r.pass),report={schema:1,status:failures.length?'FAIL':'PASS',raw:{bytes:bytes.length,sha256:sha(bytes)},checks,failures,qualificationSummary:raw.summary,scope:'Read-only independent raw comparison; no SUT reexecution, full-domain/API/build/performance/adoption claim'};
 writeFileSync(resolve(dir,'qualification-parent.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:report.status,checks:checks.length,failures,raw:report.raw,summary:raw.summary}));process.exitCode=failures.length?1:0;
}
