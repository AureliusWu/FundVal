# Parent read-only verification

2026-10-22. No SUT evaluation, build, minification, install, browser or network.
Verify the existing immutable old baseline and the single prepared same-file seam before behavior/build qualification. This is not a gzip or full-input equivalence proof.

Check the complete frozen source inventory, exact old baseline/case hashes, original native receipt/input hashes, the complete 246-member candidate path set and the frozen original snapshot, and exactly three candidate differences. Independently reconstruct the entire new worker file from original statement slices plus the declared wrappers, rather than accepting substring matches. Verify the two clients are the exact import/callee rewrites only. Run the supplied static certifier once, retaining its native output; no tests are executed by that certifier, only node --check.

Keep all original receipts and outputs unchanged. Write only new review artifacts here with exclusive creation. No root source/site/config/dependency/doc changes. Any failed check remains a failure; no candidate/source retry.
