import { readFile, readdir, writeFile } from 'node:fs/promises';
import { resolve, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';

const dir=import.meta.dirname;
const baseline='C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1';
const seam='C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351';
const candidate=resolve(seam,'candidate');
const sha=x=>createHash('sha256').update(x).digest('hex');
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const checks=[];
function check(label,fn){try{fn();checks.push({label,pass:true});}catch(error){checks.push({label,pass:false,error:error.message});}}
async function matches(path,row,label){const b=await readFile(path);check(label,()=>{assert.equal(b.length,row.bytes);assert.equal(sha(b),row.sha256);});}
async function files(root,dir=root){const rows=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=resolve(dir,e.name);if(e.isDirectory())rows.push(...await files(root,p));else if(e.isFile())rows.push(relative(root,p).replaceAll('\\','/'));else throw new Error('Unexpected link/entry '+p);}return rows.sort();}

const inv=await json(resolve(baseline,'frozen-inventory.json'));
check('baseline inventory digest',()=>assert.equal(sha(JSON.stringify(inv.files)),inv.inventorySha256));
for(const row of inv.files)for(const side of [inv.target,inv.root])await matches(resolve(side,row.path),row,side+' '+row.path);
for(const row of inv.referenceInventory)await matches(resolve(inv.root,row.path),row,'root-reference '+row.path);
const fixed={
 'baseline-01.json':'80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751',
 'cases.mjs':'f9fc6e87ed2ccf5e2c316544f333e0197c0f5c94e36d001947c467bc6065db6d',
 'cases.json':'c1ec7df0a66db3de6f756a9899b5d9c8e8b582d8a55384e08ab2fb46c553a644',
 'baseline.mjs':'39d55ca60b37e11e041584d0504abd70423120664f070455e4d645c6a22a2a0c',
};
for(const [p,expected]of Object.entries(fixed)){
 const actual=sha(await readFile(resolve(baseline,p)));
 check('immutable '+p,()=>assert.equal(actual,expected));
}
const receipts=[];
for(const name of (await readdir(resolve(baseline,'runs'))).filter(x=>x.endsWith('.receipt.json')).sort()){
 const receipt=await json(resolve(baseline,'runs',name));
 check('native '+name,()=>{assert.equal(receipt.status,0);assert.equal(receipt.signal,null);assert.equal(receipt.error,null);assert.equal(receipt.stderr.bytes,0);});
 for(const kind of ['stdout','stderr'])await matches(resolve(baseline,'runs',receipt[kind].path),receipt[kind],name+' '+kind);
 for(const row of receipt.inputs){
  await matches(resolve(baseline,'runs',name.replace('.receipt.json','.inputs'),row.path),row,name+' archived-input '+row.path);
  await matches(resolve(baseline,row.path),row,name+' retained-input '+row.path);
 }
 receipts.push({name,native:receipt.status,inputs:receipt.inputs.length});
}
const oldRaw=await json(resolve(baseline,'baseline-01.json'));
check('all original baseline matches/outcomes',()=>{assert.equal(oldRaw.baseline.length,64);assert.equal(oldRaw.summary.status,'PASS');assert.equal(oldRaw.failures.length,0);for(const row of oldRaw.baseline){assert.deepEqual(row.frozen,row.root);assert.equal(row.frozen.expectedOutcomeMatched,true);}});
check('all original negative controls',()=>{assert.equal(oldRaw.negativeControls.length,3);for(const row of oldRaw.negativeControls){assert.equal(row.detected,true);assert.equal(row.requiredDifferencesPresent,true);}});
const before=await json(resolve(seam,'before.json'));
const after=await json(resolve(seam,'after.json'));
check('exact archived and copied identities before',()=>assert.deepEqual(before.archivedSourceRows,before.candidateRows));
const expectedPaths=before.archivedSourceRows.map(r=>r.path).sort();
const snapshotPaths=await files(before.sourceRoot),candidatePaths=await files(candidate);
check('entire snapshot and candidate path sets',()=>{assert.deepEqual(snapshotPaths,expectedPaths);assert.deepEqual(candidatePaths,expectedPaths);});
const changed=[];
for(const row of before.archivedSourceRows){
 await matches(resolve(before.sourceRoot,row.path),row,'snapshot '+row.path);
 const b=await readFile(resolve(candidate,row.path));
 const current={path:row.path,bytes:b.length,sha256:sha(b)};
 if(row.bytes!==current.bytes||row.sha256!==current.sha256)changed.push(current);
 const recorded=after.afterRows.find(r=>r.path===row.path);
 check('candidate retained '+row.path,()=>assert.deepEqual(current,recorded));
}
const targets=['js/eastmoney-estimate.js','js/fund-holdings.js','js/runtime/worker-contract.js'];
check('exactly declared three changes',()=>assert.deepEqual(changed.map(r=>r.path).sort(),targets));
const oldWorker=await readFile(resolve(seam,'original-three/js/runtime/worker-contract.js'),'utf8');
const newWorker=await readFile(resolve(candidate,'js/runtime/worker-contract.js'),'utf8');
const lines=oldWorker.split('\n'),part=(a,b)=>lines.slice(a-1,b).join('\n');
const prefix=oldWorker.slice(0,oldWorker.indexOf('/** HTTP schema is independent'));
const header='function readWorkerHeader(payload, endpoint, requestedCodes, now) {\n'+part(164,182)+'\n  return { wireVersion, nowMs, status, requested };\n}';
const holdings='function readWorkerHoldingsItems(payload, wireVersion, nowMs, status, requested) {\n'+part(185,193).replace('    items = result.items;','    return result.items;')+'\n}';
const estimates='function readWorkerEstimateItems(payload, wireVersion, nowMs, status, requested) {\n'+part(195,240).replace('    items = [...rawItems, ...unavailable].map(row => {','    const items = [...rawItems, ...unavailable].map(row => {')+'\n    return items;\n}';
const tail='function finishWorkerEnvelope(payload, wireVersion, status, items) {\n'+part(242,244)+'\n}';
const generic=`/** HTTP schema is independent of the estimate-wire-v8 row fixture schema. */
export function parseWorkerEnvelope(payload, { endpoint, requestedCodes = [], now = Date.now() } = {}) {
  const { wireVersion, nowMs, status, requested } = readWorkerHeader(payload, endpoint, requestedCodes, now);
  const items = endpoint === 'holdings'
    ? readWorkerHoldingsItems(payload, wireVersion, nowMs, status, requested)
    : readWorkerEstimateItems(payload, wireVersion, nowMs, status, requested);
  return finishWorkerEnvelope(payload, wireVersion, status, items);
}`;
const specialized=(name,endpoint,items)=>`export function ${name}(payload, { requestedCodes = [], now = Date.now() } = {}) {
  const { wireVersion, nowMs, status, requested } = readWorkerHeader(payload, '${endpoint}', requestedCodes, now);
  const items = ${items}(payload, wireVersion, nowMs, status, requested);
  return finishWorkerEnvelope(payload, wireVersion, status, items);
}`;
const expectedWorker=prefix+[header,holdings,estimates,tail,generic,specialized('parseWorkerEstimateEnvelope','estimates','readWorkerEstimateItems'),specialized('parseWorkerHoldingsEnvelope','holdings','readWorkerHoldingsItems')].join('\n\n')+'\n';
check('ENTIRE worker file exact reconstruction',()=>assert.equal(newWorker,expectedWorker));
for(const [path,symbol,endpoint]of [[targets[0],'parseWorkerEstimateEnvelope','estimates'],[targets[1],'parseWorkerHoldingsEnvelope','holdings']]){
 const original=await readFile(resolve(seam,'original-three',path),'utf8');
 const actual=await readFile(resolve(candidate,path),'utf8');
 check('exact entire client '+path,()=>assert.equal(actual,original.replaceAll('parseWorkerEnvelope',symbol).replace("{ endpoint: '"+endpoint+"', requestedCodes:",'{ requestedCodes:')));
}
const native=spawnSync(process.execPath,[resolve(seam,'verify-source.mjs')],{encoding:null,windowsHide:true,maxBuffer:20_000_000,timeout:45000});
await writeFile(resolve(dir,'source-certifier.stdout'),native.stdout??Buffer.alloc(0),{flag:'wx'});
await writeFile(resolve(dir,'source-certifier.stderr'),native.stderr??Buffer.alloc(0),{flag:'wx'});
const certifier={command:process.execPath,args:[resolve(seam,'verify-source.mjs')],status:native.status,signal:native.signal,error:native.error?.message??null,stdoutBytes:native.stdout?.length??0,stdoutSha256:sha(native.stdout??Buffer.alloc(0)),stderrBytes:native.stderr?.length??0};
check('independent invocation source certifier native0',()=>{assert.equal(native.status,0);assert.equal(native.signal,null);assert.equal(native.error,undefined);assert.equal(certifier.stderrBytes,0);});
const failures=checks.filter(r=>!r.pass);
const result={schema:1,kind:'parent-independent-static-recheck',checks,failures,receipts,changed,certifier,workerReconstructionSha256:sha(expectedWorker),behavior:'NOT_RUN_BY_THIS_PROGRAM',build:'NOT_RUN',rootEdits:false,status:failures.length?'FAIL':'PASS'};
await writeFile(resolve(dir,'parent-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,checks:checks.length,failures,changed,receipts,certifier}));
process.exitCode=failures.length?1:0;
