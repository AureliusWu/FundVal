// Shared local evidence recorder only. Imports no application module.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import { lstat, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { fileURLToPath } from 'node:url';
export const workspace = dirname(fileURLToPath(import.meta.url));
export const root = 'D:/AI项目/FundVal';
export const sha = b => createHash('sha256').update(b).digest('hex');
export const json = async p => JSON.parse(await readFile(p, 'utf8'));
export const exists = p => lstat(p).then(() => true, e => { if (e.code === 'ENOENT') return false; throw e; });
export const writeJson = (p, v) => writeFile(p, JSON.stringify(v, null, 2) + '\n', { flag: 'wx' });
export const fault = e => ({ name: e?.name || 'Error', message: e?.message || String(e), code: e?.code || null });
const oldBytes = await readFile(resolve(workspace, 'frozen-receipts/postflight.json'));
const candidateBytes = await readFile(resolve(workspace, 'frozen-receipts/candidate-after.json'));
assert.equal(sha(oldBytes), '30292b08126074406fa9666c8840b980cd5a64a7d397607e3dfe5a655671b47b');
assert.equal(sha(candidateBytes), 'fac2379d28197483f973f97737d109231265788d33f7c27797c926587855e840');
const baseline = JSON.parse(oldBytes), candidate = JSON.parse(candidateBytes);
const expectedSources = { A: baseline.source.rows.filter(r => !r.path.startsWith('.codex-tmp/')), B: candidate.afterRows };
export async function inventory(base, exclude = new Set()) {
  const rows = [];
  async function walk(path = '') {
    const full = resolve(base, path), s = await lstat(full);
    assert.equal(s.isSymbolicLink(), false, 'Unexpected regular-inventory link: ' + full);
    if (s.isDirectory()) {
      for (const name of await readdir(full)) if (path || !exclude.has(name)) await walk(path ? path + '/' + name : name);
    } else { assert.ok(s.isFile()); const b = await readFile(full); rows.push({ path, bytes: b.length, sha256: sha(b) }); }
  }
  await walk(); rows.sort((a, b) => a.path.localeCompare(b.path)); return rows;
}
export async function siteInventory(base) {
  const files = await inventory(base);
  files.sort((a, b) => a.path.localeCompare(b.path, 'en'));
  return { files, fileCount: files.length, totalBytes: files.reduce((s, r) => s + r.bytes, 0),
    sha256: sha(files.map(r => r.path + '\0' + r.sha256 + '\n').join('')) };
}
function gitIdentity() {
  const result = {};
  for (const [name, args] of [['head', ['rev-parse', 'HEAD']], ['branch', ['branch', '--show-current']],
    ['index', ['diff', '--cached', '--binary']], ['tracked', ['diff', '--binary', 'HEAD', '--']], ['status', ['status', '--porcelain=v1', '-z']]]) {
    const r = spawnSync('git', args, { cwd: root, windowsHide: true, encoding: null, maxBuffer: 32 * 1024 * 1024 });
    assert.equal(r.status, 0); assert.equal(r.error, undefined); assert.equal(r.signal, null);
    result[name] = { bytes: r.stdout.length, sha256: sha(r.stdout), stderrBytes: r.stderr.length };
  }
  return result;
}
export async function captureIdentity() {
  const result = { node: process.version, executable: process.execPath, sides: {}, installedRows: [] };
  assert.equal(process.versions.node, (await json(resolve(workspace, 'A/package.json'))).engines.node);
  assert.equal(sha(await readFile(resolve(workspace, 'PROTOCOL.md'))), '3c6fb3a5fbd843debab20cdfc966535f9d24c64b11ffe05a44e7fc2d4e7cb6e7');
  for (const side of ['A', 'B']) {
    const sideRoot = resolve(workspace, side);
    assert.equal((await lstat(sideRoot)).isSymbolicLink(), false);
    assert.equal((await realpath(sideRoot)).toLowerCase(), sideRoot.toLowerCase());
    const junction = resolve(sideRoot, 'node_modules');
    assert.equal((await lstat(junction)).isSymbolicLink(), true);
    assert.equal((await realpath(junction)).toLowerCase(), resolve(root, 'node_modules').toLowerCase());
    const rows = await inventory(sideRoot, new Set(['node_modules', 'site']));
    assert.deepEqual(rows, expectedSources[side]);
    result.sides[side] = { sourceRows: rows, artifact: await exists(resolve(sideRoot, 'site')) ? await siteInventory(resolve(sideRoot, 'site')) : null };
  }
  for (const row of baseline.installed.rows) {
    const path = resolve(root, 'node_modules', row.path), s = await lstat(path);
    assert.ok(s.isFile() && !s.isSymbolicLink());
    const b = await readFile(path); result.installedRows.push({ path: row.path, bytes: b.length, sha256: sha(b) });
  }
  assert.deepEqual(result.installedRows, baseline.installed.rows);
  const rootRows = await inventory(root, new Set(['.git', 'node_modules', 'site', 'Temp', '.claude', 'docs']));
  for (const row of baseline.source.rows.filter(r => r.path === 'docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md')) {
    const b = await readFile(resolve(root, row.path)); rootRows.push({ path: row.path, bytes: b.length, sha256: sha(b) });
  }
  rootRows.sort((a, b) => a.path.localeCompare(b.path)); assert.deepEqual(rootRows, baseline.source.rows);
  result.rootSources = rootRows;
  result.rootSite = await siteInventory(resolve(root, 'site'));
  assert.deepEqual(result.rootSite, baseline.currentArtifact);
  result.rootGit = gitIdentity(); return result;
}
export async function approve(flag, scriptPath, scriptHashField, protocolFile, protocolHashField) {
  const authorization = await json(resolve(workspace, 'authorization.json'));
  assert.equal(authorization[flag], true);
  assert.equal(authorization.protocolSha256, '3c6fb3a5fbd843debab20cdfc966535f9d24c64b11ffe05a44e7fc2d4e7cb6e7');
  assert.equal(authorization[scriptHashField], sha(await readFile(scriptPath)));
  assert.equal(authorization.auxiliaryRecorderSha256, sha(await readFile(fileURLToPath(import.meta.url))));
  assert.equal(authorization[protocolHashField], sha(await readFile(resolve(workspace, protocolFile))));
  return authorization;
}
export async function runNative(side, args, directory, timeoutMs, stdoutName = 'stdout.bin') {
  const cwd = resolve(workspace, side), startedAt = new Date().toISOString();
  const stdoutPath = resolve(directory, stdoutName), stderrPath = resolve(directory, 'stderr.bin');
  const stdout = createWriteStream(stdoutPath, { flags: 'wx' }), stderr = createWriteStream(stderrPath, { flags: 'wx' });
  const child = spawn(process.execPath, args, { cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let timedOut = false, error = null;
  const timer = setTimeout(() => { timedOut = true; child.kill(); }, timeoutMs);
  const done = new Promise(resolveDone => {
    child.once('error', e => { error = fault(e); });
    child.once('close', (exitCode, signal) => resolveDone({ exitCode, signal }));
  });
  const pipes = Promise.allSettled([pipeline(child.stdout, stdout), pipeline(child.stderr, stderr)]);
  const native = await done; clearTimeout(timer);
  const pipeResults = await pipes;
  const out = await readFile(stdoutPath), err = await readFile(stderrPath);
  return { file: process.execPath, args, cwd, startedAt, endedAt: new Date().toISOString(), pid: child.pid || null,
    ...native, timedOut, spawnError: error, timeoutMs,
    pipeErrors: pipeResults.filter(r => r.status === 'rejected').map(r => fault(r.reason)),
    stdout: { path: stdoutPath, bytes: out.length, sha256: sha(out) }, stderr: { path: stderrPath, bytes: err.length, sha256: sha(err) } };
}

