# Same-file Worker seam: bounded execution result

Decision: **bounded source/API/build/graph qualification completed; NOT ADOPTED.** The enabling seam increases all gzip by70B and cold by3B. It is not a qualified 6960B net-reduction strategy or M3 exit.

## Exact candidate and frozen boundaries
Candidate source is C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/B, copied from the single prepared same-file Worker header/items/tail variant. A is the exact archived246 baseline. Original source-preparation report and exact three source hashes are in C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/SOURCE_PREPARATION.md and the frozen receipts in this workspace. No source, recorder, protocol, five groups, ES2022, OXC configuration, dependencies, application version or budgets were repaired/changed during execution.

This workspace preserves authorization.json; read-only PROTOCOL.md, TARGETED_TEST_PROTOCOL.md and POSTCHECK_PROTOCOL.md; exact recorder/helper scripts; preflight full inventories; every native command/exit/stdout/stderr; and all six complete retained127-file sites.

## Targeted A→B results
Exact command, one invocation per side:
```text
node --test test/worker-contract-v16.test.js test/wire-compaction-characterization-v16.test.js test/estimate-http-characterization-v16.test.js test/fund-holdings.test.js test/eastmoney-estimate.test.js test/request-signal.test.js
```

Both native exit0; each97 tests/97pass/0fail/0cancelled/0skip/0todo, stderr empty. Actual97 success markers and complete summary footers were independently read before builds and recorded in tests/summary-gate.json. Native Node produced **spec-format output**, not TAP syntax, despite the original capture filename stdout.tap. The command/reporter was not changed or rerun to hide that naming mismatch. Raw outputs, exact commands, timings and before/after identities are retained under tests/A and tests/B.

This is six specified API/HTTP test files, not fullQA, E2E, performance or production evidence.

## Fixed six builds and actual size
Run order was exactly A1 B1 B2 A2 A3 B3, SOURCE_DATE_EPOCH=1792046773, pinned Node24.14.0, original scripts/build-site.mjs. All six native exits0, stdout1357B each/stderr0, no warning lines observed, no retry/selection. Build command durations are recorded only as build receipts, not user-facing latency measurements.

| Actual output | A, identical in3 rounds | B, identical in3 rounds | B−A |
| --- | ---: | ---: | ---: |
| Whole-site files |127|127|0|
| Whole-site bytes |92537133|92538910|+1777|
| App chunk raw B |245170|245505|+335|
| All non-OCR gzip B |84187|84257|**+70**|
| Cold gzip B |44699|44702|**+3**|

A's original127-row inventory was reproduced exactly on all3 rounds, fingerprint4e8dddb5ce4f81992f384afd0ee552431787c6b30600a643bcb97f6a0837e4e4.
B's full127-row artifact fingerprint was83ffa4092ee6a5762dcd45b38af5ae9c2a955b9c5a05ee7eeb0ef001974b4fee on all3 rounds. The whole-site algorithm is the original path+NUL+fileSHA+LF algorithm with en sorting, not the separate sorted-JSON inventory hash.

Every per-run output file/byte/SHA and emitted16-chunk gzip was freshly recorded; retained site snapshots were checked against produced sites before any subsequent build could clean them. See runs/<label>/receipt.json, runs/<label>/site, stdout.bin and stderr.bin. execution-summary.json records all six outcomes. Each run kept full before/after source/dependency/root identities.

## Four final-site read-only CLI checks
Exact fixed order A-graph, A-budget, B-graph, B-budget, once each. No rebuild followed.

| CLI | A native | B native | Actual result |
| --- | ---: | ---: | --- |
| --verify-app-module-graph site |0|0|PASS|
| --assert-app-bundle-budget site |**1**|**1**|**BUDGET_FAIL**, preserved|

Both graph reports:16chunks/18static edges/10literal dynamic edges/6actual cold chunks; literal closure and native static bindings verified. evaluated=false, startupOrderVerified=false and dynamicNamespaceMembersVerified=false remain explicit; this is not runtime behavior or complete dynamic namespace verification.

Budget CLI actual stderr:
```text
A: App bundle exceeds all non-OCR gzip budget: 84187 > 77227.7 bytes.
B: App bundle exceeds all non-OCR gzip budget: 84257 > 77227.7 bytes.
```
Cold passes52241; all fails77227.7 in both. Candidate needs at least7030 integerB to meet the unchanged limit, versus current root's6960B gap. postchecks wrapper's completion exit0 means it successfully recorded graph successes and real budget failures; it does **not** turn either native budget1 into PASS. Complete separate receipts/raw CLI JSON/stdout/stderr are in postchecks/.

## Independent review and identity
The parent's independent final review freshly reread all127 files in each6 retained site, finalA/B sites and root site, recomputed all16 gzip measures and validated build/postcheck native output hashes plus actual97-spec summaries. Its139 checks/PASS/0failures are retained verbatim under parent-review-evidence/builds-parent.json, builds-parent.native.json and certify-builds.mjs. Those copied parent results are independent evidence, not an extra test/build invocation by this agent.

Final read-only source/installed/artifact/root identity capture completed **2026-10-22T05:27:17.303Z** and is fully saved in final-postflight.json. A/B source246 each, root frozen source270, root127-file artifact, installed68 rows and root Git head/index/tracked-diff/status matched the execution window and last postcheck. Installed68 SHA2da11b473eaff8bcaa1fef492e4b595629145b97f8c7f2ea18f4e7fb5b074e1c. No source/dependency/root mutation was observed in those explicit scopes.

**The root-doc freeze window is CLOSED after that final capture.** Parent was explicitly notified that docs archival/updates may resume; no later root Git/doc equality is required or claimed. Only this system-Temp final report/evidence inventory was written after closure.

## Stop state and next authority
No root product adoption; root remains15.0.2 with original84187B all gzip. No fullQA, E2E, performance pairs, source/provider network check, OCR engine run, package install, source repair, new variant, parameter sweep, commit/push/deployment/release or M4 advancement occurred.

This seam removes a coupling prerequisite for a possible later larger pipeline; current evidence does not qualify that larger strategy or promise a byte saving. Any further design/implementation is a new parent decision. All authorized runtime/build windows are ended; no process/monitor was left intentionally running. FINAL_INVENTORY.json inventories this workspace's complete regular evidence/source/artifact files, excluding only itself and the contents of the two separately recorded dependency junctions.

