# Fixed final-site postchecks — PREPARED ONLY

After an accepted complete A1 B1 B2 A2 A3 B3 six-build window, execute these four read-only CLI calls exactly once in this order:
1. From C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/A: node scripts/release-fingerprint.mjs --verify-app-module-graph site
2. From C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/A: node scripts/release-fingerprint.mjs --assert-app-bundle-budget site
3. From C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/B: node scripts/release-fingerprint.mjs --verify-app-module-graph site
4. From C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/B: node scripts/release-fingerprint.mjs --assert-app-bundle-budget site

Use pinned C:/Program Files/nodejs/node.exe. Timeout60000ms per command.
Confirm A/site equals A3 receipt and B/site equals B3 receipt before and after; check exact source/root/installed identities unchanged.
Retain each complete stdout/stderr, native exit/signal/error/timing, parsed CLI JSON and output SHA; no build, repair, sweep or retry.
Graph native0 is required for graph PASS. Budget native1 is the expected existing gate FAIL, not a PASS. Retain actual JSON/native exit even if the candidate unexpectedly changes the budget result; do not coerce it to expected1. A native1 lacking a valid budget FAIL JSON is a CLI/tool failure, not evidence of an ordinary budget failure.
All four read-only calls remain fixed even if a graph/budget outcome fails; stop only for timeout, spawn/pipe or identity failure and retain unattempted calls.
No execution is authorized by this file. Require next parent go and run-postchecks.mjs authorization fields. No postcheck has run at preparation.

