param([Parameter(Mandatory=$true)][string]$Workspace)
$ErrorActionPreference = 'Stop'
$workspaceRoot = [IO.Path]::GetFullPath($Workspace)
$baselineRoot = 'C:\Users\84046\AppData\Local\Temp\fundval-pair824-extract-07zGKl\measured-current-inputs'
$candidateRoot = 'C:\Users\84046\AppData\Local\Temp\fundval-worker-seam-20261022-fc680351\candidate'
$postflightPath = 'C:\Users\84046\AppData\Local\Temp\fundval-pair824-extract-07zGKl\postflight\postflight.json'
$candidateAfterPath = 'C:\Users\84046\AppData\Local\Temp\fundval-worker-seam-20261022-fc680351\after.json'
$dependencyRoot = 'D:\AI项目\FundVal\node_modules'
if (!(Get-Item -LiteralPath (Join-Path $workspaceRoot 'PROTOCOL.md')).IsReadOnly) { throw 'Protocol not read-only' }
$postflightRecord = Get-Content -LiteralPath $postflightPath -Raw -Encoding UTF8 | ConvertFrom-Json
$candidateRecord = Get-Content -LiteralPath $candidateAfterPath -Raw -Encoding UTF8 | ConvertFrom-Json
$baselineRows = @($postflightRecord.source.rows | Where-Object { !$_.path.StartsWith('.codex-tmp/', [StringComparison]::Ordinal) })
$candidateRows = @($candidateRecord.afterRows)
if ($baselineRows.Count -ne 246 -or $candidateRows.Count -ne 246) { throw 'Expected exactly archived246 per side' }
foreach ($side in @(@{Name='A';Source=$baselineRoot;Rows=$baselineRows},@{Name='B';Source=$candidateRoot;Rows=$candidateRows})) {
  $sideRoot = Join-Path $workspaceRoot $side.Name
  if (Test-Path -LiteralPath $sideRoot) { throw 'Refusing existing side' }
  New-Item -ItemType Directory -Path $sideRoot | Out-Null
  foreach ($row in $side.Rows) {
    if ([IO.Path]::IsPathRooted($row.path) -or $row.path -match '(^|/)\.\.(/|$)' -or $row.path.Contains('\')) { throw 'Unsafe relative path' }
    $sourceFile = [IO.Path]::GetFullPath((Join-Path $side.Source $row.path))
    $targetFile = [IO.Path]::GetFullPath((Join-Path $sideRoot $row.path))
    if (!$sourceFile.StartsWith($side.Source + '\',[StringComparison]::OrdinalIgnoreCase) -or !$targetFile.StartsWith($sideRoot + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Copy escaped intended root' }
    $sourceItem = Get-Item -LiteralPath $sourceFile -Force
    if (($sourceItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing source link' }
    if ($sourceItem.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $row.sha256) { throw ('Source mismatch '+$row.path) }
    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($targetFile)) -Force | Out-Null
    Copy-Item -LiteralPath $sourceFile -Destination $targetFile
    $targetItem = Get-Item -LiteralPath $targetFile
    if ($targetItem.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $row.sha256) { throw ('Copy mismatch '+$row.path) }
  }
  New-Item -ItemType Junction -Path (Join-Path $sideRoot 'node_modules') -Target $dependencyRoot | Out-Null
}
$snapshotRoot = Join-Path $workspaceRoot 'frozen-receipts'
New-Item -ItemType Directory -Path $snapshotRoot | Out-Null
Copy-Item -LiteralPath $postflightPath -Destination (Join-Path $snapshotRoot 'postflight.json')
Copy-Item -LiteralPath $candidateAfterPath -Destination (Join-Path $snapshotRoot 'candidate-after.json')
Copy-Item -LiteralPath 'C:\Users\84046\AppData\Local\Temp\fundval-worker-seam-20261022-fc680351\SOURCE_PREPARATION.md' -Destination (Join-Path $snapshotRoot 'source-preparation.md')
[ordered]@{stage='copies-and-junctions-only';workspace=$workspaceRoot;baselineCount=$baselineRows.Count;candidateCount=$candidateRows.Count;buildsExecuted=0;dependencyTarget=$dependencyRoot;postflightSha256=(Get-FileHash -LiteralPath (Join-Path $snapshotRoot 'postflight.json') -Algorithm SHA256).Hash.ToLowerInvariant();candidateAfterSha256=(Get-FileHash -LiteralPath (Join-Path $snapshotRoot 'candidate-after.json') -Algorithm SHA256).Hash.ToLowerInvariant();protocolSha256=(Get-FileHash -LiteralPath (Join-Path $workspaceRoot 'PROTOCOL.md') -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json -Depth 4

