# Frozen finite build protocol — PREPARED ONLY, NOT AUTHORIZED TO EXECUTE

Created 2026-10-22 05:11:37 UTC. Workspace C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2.
No build may execute until the parent explicitly accepts the frozen old-ledger behavior qualification and separately authorizes these exact six builds.

## Exactly one candidate and six fixed runs
- A baseline input: C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/measured-current-inputs (exact archived246, excluding24 historical .codex-tmp members).
- B candidate input: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/candidate (same246 paths; only the authorized Worker/client three-file seam).
- Copy A and B into C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-builds-20261022-a4bf3fd2/A and /B. The only links allowed in either side are node_modules directory junctions resolving exactly to D:/AI项目/FundVal/node_modules. No installation or dependency mutation.
- Fixed order: A1, B1, B2, A2, A3, B3; no warmup, retry, replacement, parameter search, filtering, mixing, or choosing a favorable round.
- Every command is the pinned Node executable with scripts/build-site.mjs in that side as cwd, SOURCE_DATE_EPOCH=1792046773. The original source script, five group sets, OXC minifier, ES2022 target, OCR builder and all config remain byte-identical to archived A.
- Existing root site must first match the exact original127 artifact rows and original artifactFingerprint SHA256 4e8dddb5ce4f81992f384afd0ee552431787c6b30600a643bcb97f6a0837e4e4. The original algorithm sorts by localeCompare(path,'en') and hashes path + NUL + fileSHA + LF; the 5b946d23 sorted-JSON SHA is a distinct inventory algorithm and cannot replace it.
- A1 must reproduce all127 original baseline members, raw245170/all84187/cold44699. The same exact baseline inventory is required for A2/A3. B1/B2/B3 must match each other on every output path/byte/SHA (not expected to match A because source files are copied into the site).
- Budgets remain all77227.7/cold52241. Seam size is observed without claiming6960B net saving or budget PASS; complete six-round reproduction is not overall M3 qualification.

## Recording and failure policy
- Capture before/after source inventories and frozen installed68 manifest/hidden-lock/native/launcher rows, per run and at the whole window. Compare root selected246 source, original rootsite127 and rootGit head/index/diff/status identity before/after; root source/site/docs must not be written by this recorder.
- Capture native child stdout/stderr directly as complete binary files, command/executable/cwd/env overrides/start/end/exit/signal/spawn error. No console truncation, maxBuffer, discarded stderr, or output-only success inference.
- Capture full site inventory every run and recompute gzip per actual chunk with Node gzipSync default settings, matching manifest bytes/SHA/gzip, exact cold/lazy partition and total. Store complete output site snapshot per run before any next build can clean that side.
- Record failures as failures and retain partial site/files/output. Stop on the first native build, identity, safety, baseline-reproduction or measurement failure. Do not retry or skip to later runs. No cleanup/delete is performed by the recorder; all sides and evidence remain for parent review.
- Child builds have one fixed15-minute timeout each; timeout kills only that child process and is retained as failure. After timeout do not launch any later round. An interrupted started marker without completion also blocks rerun.
- Final summary distinguishes native build outcome, deterministic artifact reproduction, budget result and NOT_RUN runtime/performance qualification.

## Destructive build safety
- Read original build-site.mjs: it resolves its own parent as root, validates output is exactly root/site, then recursively removes only that site. Paddle cleanup removes only root/site/assets/ocr/paddle through requirePathInsideRoot.
- Before each child spawn, recorder must independently verify that the exact side root is a real directory directly inside this new system-Temp workspace, not the real repository; script is byte-identical; side/site and every existing entry below it are regular files/directories with no symlink/junction; shared node_modules is the sole allowed link and resolves exactly to root pinned dependencies.
- The recorder itself must contain no recursive removal. Original builds may clean only the validated side/site and its contained Paddle path. Never run a build with real repository cwd/script or a computed unverified output target.
- Full output preservation requires roughly560MB plus copies; existing evidence must never be removed to make room.

## Current stage and execution guard
Preparation may copy source, create the two approved node_modules junctions, verify identities and syntax-check recorder scripts only. It must not execute a build, test, browser, network request or package installation.
The recorder requires --execute-approved-six plus an explicit authorization.json absent at preparation. It must refuse missing/mismatched protocol, behavior-ledger identity or authorization. Exact receipt fields are documented in HANDOFF.md.
Stop after parent review of protocol/recorder and preflight evidence.

