# Same-file Worker envelope seam: source-preparation handoff

Status: SOURCE_PREPARED / STATIC_SYNTAX_PASS / BEHAVIOR_NOT_RUN / NOT_ADOPTED.
Date: 2026-10-22. Parent review is the next gate. No further work is authorized by this handoff.

## Exact locations
- Candidate: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/candidate
- Frozen protocol (read-only before copying): C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/PROTOCOL.md
- Complete before inventory and copy verification: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/before.json
- Complete after inventory, all static checks, three command receipts and full native diff stdout/stderr: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/after.json
- Original raw 270-row receipt: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/original-postflight.json
- Exact original three source files: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/original-three
- Exact prepared three source files, byte-checked against candidate: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/after-three
- Mechanical copying program: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/prepare.ps1
- Read-only static source certifier (no application import/evaluation): C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/verify-source.mjs
- Exact diff text: worker-contract.js.diff, fund-holdings.js.diff, eastmoney-estimate.js.diff in this workspace. Each was reread and checked byte-for-byte against the corresponding captured git stdout in after.json.

## Frozen baseline and allowed scope
Baseline is C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/measured-current-inputs.
Original inventory is the sibling postflight/postflight.json source.rows.
Exactly the 24 historical .codex-tmp/ members were excluded; no existing archived source member was omitted. The 246 selected paths were compared to the complete snapshot file enumeration, each original source was checked for its original bytes/SHA, copied, and checked again before semantic editing.

The selected 246 source files total 12107657 B before editing. After editing there are still exactly 246 files, now 12109099 B, and exactly three changed paths. The source delta is +1442 raw B. This is not a built or gzip result.

The initial prepare.ps1 receipt has sourceBytes:null because PowerShell Measure-Object did not extract the bytes property from OrderedDictionary rows. Its complete 246 original/copy rows and successful per-file SHA checks are intact and retained without rewriting that receipt. The independent read-only Node certifier directly summed those numeric row.bytes to 12107657 B and revalidated every original snapshot file. This is a metadata-summary tooling defect, not an ignored file mismatch.

## Prepared files and final hashes
| Path | Before bytes | After bytes | After SHA256 |
| --- | ---: | ---: | --- |
| js/runtime/worker-contract.js | 16996 | 18451 | 5190e8f31f0abdf0bec66620c3f11cb8eeb9aaccd474ae246ddfc2efb0a60db2 |
| js/fund-holdings.js | 3774 | 3768 | 14468b63cb8c2131eba7edc6c33c714b998725db078e00b9836d408daad8c3ba |
| js/eastmoney-estimate.js | 4642 | 4635 | dd537fe2d1dfa1a5ef0ca11d83ed0131292f7b75e76cd6c65f45f9adf190e682 |

## Exact decomposition
All functions remain in candidate/js/runtime/worker-contract.js. There are no new production module paths or changed build grouping.

1. readWorkerHeader at candidate line 162: original parser statements 164-182 were copied byte-for-byte, then return only already-computed wireVersion, nowMs, status and requested.
2. readWorkerHoldingsItems at line 185: original branch statements 185-193 were preserved, with only items = result.items changed to return result.items.
3. readWorkerEstimateItems at line 197: original branch statements 195-240 were preserved, with only the old result assignment becoming a local const items and a final return items.
4. finishWorkerEnvelope at line 247: the original return statements 242-244 are byte-for-byte preserved. It is invoked only after item processing, so late source/fetched_at/generated_at/service_version/capabilities/report_date reads remain late.
5. Original public parseWorkerEnvelope at line 254: its signature/default destructuring is byte-identical. It calls header before endpoint selection, then the selected items helper, then tail.
6. New fixed parseWorkerEstimateEnvelope at line 262 and parseWorkerHoldingsEnvelope at line 268: each receives requestedCodes and now with the corresponding pre-existing defaults, calls header with a literal endpoint, then the correct items helper and late tail. Helpers themselves have positional parameters, with no new defaults/coercion/caching/catch.
7. The two clients changed only their worker import symbol and the corresponding parser call with the literal endpoint property removed. The caller's options.now expression remains in the same position after requestedCodes and appears no extra time. The exact old-client-to-new-client text rewrite is independently checked.

The entire prefix before the original parser—including WorkerContractError, normalizeWorkerEstimateRow, timestamp/numeric/reason helpers, imports and constants—is byte-identical. Original row spread, unknown/symbol fields, LEGACY_SUCCESS_ROW pre-normalization plus subsequent map normalization, item accounting and output key order are unchanged by the extracted source statements. These are static facts about the preparation, not a runtime equivalence result.

## Static evidence
verify-source.mjs native exit 0, 275 static source/inventory checks passed. It reads both snapshots and the candidate; it does not evaluate any application module.
- Complete original 246 snapshot files still match before identity.
- Candidate path set is exactly the original 246 path set.
- Exactly the approved three files differ; all other 243 files match before bytes/SHA.
- Header/holdings/estimates/tail source statement boundaries, public signature, client rewrite and unchanged prefix passed the exact textual checks above.
- Three git diff --no-index invocations returned native 1 as expected for differing files; complete stdout and stderr are retained in after.json.
- Node v24.14.0 (C:/Program Files/nodejs/node.exe) --check on each of the three candidate sources returned native 0, stdout empty, stderr empty. Full executable/args/exit/stdout/stderr receipts are in after.json.
- Additional readback confirmed all three .diff files exactly equal their captured stdout, and after-three exactly equals candidate source bytes.
- Protocol SHA256 2400f2088c1f4d20def1b2515f5fd530e3f9712480c4f7f8549b4d0027a5788c.

## Limits and stop point
No tests, application evaluation, builds, compression, package installation, network calls, browsers, performance pairs, source fixture mutations, commit, push, deployment, budget change, or version change were performed. Nothing in D:/AI项目/FundVal source/site/docs/dependencies was edited by this source-preparation task.

The root product remains the parent's existing 15.0.2 / 84187-B all-gzip state; no new measurement or adoption is claimed here. This same-file seam is only a potential prerequisite for a later pipeline redesign. Both endpoint clients and the direct row-normalizer caller still exist today. It does not establish a 6960-B net gzip saving, behavior qualification, M3 exit, or release.

Pending parent gate: review this exact prepared source and frozen baseline; only then authorize the frozen old-behavior ledger comparison and any further bounded qualification. Stop here.

