import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { workspace, exists, writeJson, fault, captureIdentity, approve, runNative } from './auxiliary-recorder.mjs';
assert.equal(process.argv[2], '--execute-approved-targeted-tests', 'Prepared only; explicit next parent go is required.');
const authorization = await approve('parentApprovedForTargetedTests', fileURLToPath(import.meta.url),
  'targetedTestRunnerSha256', 'TARGETED_TEST_PROTOCOL.md', 'targetedTestProtocolSha256');
assert.equal(await exists(resolve(workspace, 'tests')), false, 'No retry/overwrite of a started test window');
assert.equal(await exists(resolve(workspace, 'execution-started.json')), false, 'Targeted tests must precede the six builds');
const args = ['--test', 'test/worker-contract-v16.test.js', 'test/wire-compaction-characterization-v16.test.js',
  'test/estimate-http-characterization-v16.test.js', 'test/fund-holdings.test.js', 'test/eastmoney-estimate.test.js', 'test/request-signal.test.js'];
const initial = await captureIdentity(), folder = resolve(workspace, 'tests');
await mkdir(folder);
await writeJson(resolve(folder, 'started.json'), { at: new Date().toISOString(), authorization, args, initial });
const summary = { status: 'RUNNING', order: ['A', 'B'], args, runs: [], adopted: false, fullQA: false };
try {
  for (const side of ['A', 'B']) {
    const dir = resolve(folder, side); await mkdir(dir);
    const record = { side, before: await captureIdentity() }; assert.deepEqual(record.before, initial);
    let error;
    try {
      record.native = await runNative(side, args, dir, 120000, 'stdout.tap');
      assert.equal(record.native.exitCode, 0); assert.equal(record.native.signal, null);
      assert.equal(record.native.timedOut, false); assert.equal(record.native.spawnError, null); assert.deepEqual(record.native.pipeErrors, []);
    } catch (e) { error = e; record.failure = fault(e); }
    try { record.after = await captureIdentity(); assert.deepEqual(record.after, initial); }
    catch (e) { error ||= e; record.afterFailure = fault(e); }
    record.status = error ? 'FAIL' : 'PASS'; await writeJson(resolve(dir, 'receipt.json'), record);
    summary.runs.push({ side, status: record.status, native: record.native || null, failure: record.failure || record.afterFailure || null });
    console.log(JSON.stringify({ side, status: record.status, nativeExit: record.native?.exitCode ?? null }));
    if (error) throw error;
  }
  summary.status = 'TARGETED_NATIVE_PASS';
} catch (e) { summary.status = 'STOPPED_FAILURE_NO_RETRY'; summary.failure = fault(e); process.exitCode = 1; }
finally { summary.finishedAt = new Date().toISOString(); summary.unattempted = ['A', 'B'].slice(summary.runs.length); await writeJson(resolve(folder, 'summary.json'), summary); }

