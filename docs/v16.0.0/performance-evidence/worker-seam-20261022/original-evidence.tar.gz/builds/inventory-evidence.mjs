// One final system-Temp inventory; no root-source/Git reads after doc window closure.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { lstat, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const workspace = dirname(fileURLToPath(import.meta.url)), rows = [], junctions = [];
const sha = b => createHash('sha256').update(b).digest('hex');
async function walk(path = '') {
  if (path === 'FINAL_INVENTORY.json') return;
  const full = resolve(workspace, path), s = await lstat(full);
  if (s.isSymbolicLink()) {
    assert.ok(path === 'A/node_modules' || path === 'B/node_modules');
    const target = await realpath(full);
    assert.equal(target.toLowerCase(), resolve('D:/AI项目/FundVal/node_modules').toLowerCase());
    junctions.push({ path, kind: 'directory-junction', target, contentsExcluded: true }); return;
  }
  if (s.isDirectory()) { for (const name of await readdir(full)) await walk(path ? path + '/' + name : name); }
  else {
    assert.ok(s.isFile());
    const b = await readFile(full); rows.push({ path, bytes: b.length, sha256: sha(b) });
  }
}
await walk(); rows.sort((a, b) => a.path.localeCompare(b.path, 'en')); junctions.sort((a, b) => a.path.localeCompare(b.path, 'en'));
assert.equal(junctions.length, 2);
const body = { scope: 'all current system-Temp regular files, excluding only FINAL_INVENTORY.json and contents of recorded A/B node_modules junctions',
  rootDocWindowAlreadyClosed: true, files: rows.length, bytes: rows.reduce((s, r) => s + r.bytes, 0),
  rowsSha256: sha(JSON.stringify(rows)), junctions, rows };
if (process.argv[2] === '--write-once') {
  await writeFile(resolve(workspace, 'FINAL_INVENTORY.json'), JSON.stringify(body, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ status: 'FINAL_INVENTORY_WRITTEN', files: body.files, bytes: body.bytes, rowsSha256: body.rowsSha256, junctions: body.junctions }));
} else if (process.argv[2] === '--verify') {
  assert.deepEqual(body, JSON.parse(await readFile(resolve(workspace, 'FINAL_INVENTORY.json'), 'utf8')));
  console.log(JSON.stringify({ status: 'FINAL_INVENTORY_EXACT', files: body.files, bytes: body.bytes, rowsSha256: body.rowsSha256 }));
} else throw new Error('Use --write-once for initial receipt or --verify for a read-only later check.');

