// Prepared finite recorder. No app import; no build without explicit authorization.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { createReadStream, createWriteStream } from 'node:fs';
import { cp, lstat, mkdir, readFile, readdir, readlink, realpath, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const workspace = dirname(fileURLToPath(import.meta.url));
const root = 'D:/AI项目/FundVal';
const dependencyRoot = resolve(root, 'node_modules');
const epoch = '1792046773';
const sequence = ['A1', 'B1', 'B2', 'A2', 'A3', 'B3'];
const sourcePrepRoot = 'C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351';
const protocolSha = '3c6fb3a5fbd843debab20cdfc966535f9d24c64b11ffe05a44e7fc2d4e7cb6e7';
const expectedPostflightSha = '30292b08126074406fa9666c8840b980cd5a64a7d397607e3dfe5a655671b47b';
const expectedCandidateAfterSha = 'fac2379d28197483f973f97737d109231265788d33f7c27797c926587855e840';
const artifactAnchor = '4e8dddb5ce4f81992f384afd0ee552431787c6b30600a643bcb97f6a0837e4e4';
const sourcePrepReportSha = '575d9de4ddeb79dddc4bc945a33a98210506faf6292f54ccecd50f6e76fbf768';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const samePath = (a, b) => resolve(a).toLowerCase() === resolve(b).toLowerCase();
const exists = async path => lstat(path).then(() => true, e => { if (e.code === 'ENOENT') return false; throw e; });
const writeJson = async (path, value) => writeFile(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const fault = e => ({ name: e?.name || 'Error', message: e?.message || String(e), code: e?.code || null });
const saved = await readFile(join(workspace, 'frozen-receipts/postflight.json'));
const candidateReceipt = await readFile(join(workspace, 'frozen-receipts/candidate-after.json'));
assert.equal(sha(saved), expectedPostflightSha);
assert.equal(sha(candidateReceipt), expectedCandidateAfterSha);
const baseline = JSON.parse(saved), preparedCandidate = JSON.parse(candidateReceipt);
const sourceRows = {
  A: baseline.source.rows.filter(row => !row.path.startsWith('.codex-tmp/')),
  B: preparedCandidate.afterRows,
};
assert.equal(sourceRows.A.length, 246); assert.equal(sourceRows.B.length, 246);
const installedRows = baseline.installed.rows;
assert.equal(installedRows.length, 68);
assert.equal(baseline.currentArtifact.sha256, artifactAnchor);
assert.equal(baseline.currentArtifact.fileCount, 127);
const expectedArtifactRows = baseline.currentArtifact.files;

async function walkRegular(base, prefix = '', excludedTop = new Set()) {
  const rows = [];
  async function walk(part) {
    const full = resolve(base, part), info = await lstat(full);
    assert.equal(info.isSymbolicLink(), false, 'Unexpected link in regular inventory: ' + full);
    if (info.isDirectory()) {
      for (const name of await readdir(full)) if (part || !excludedTop.has(name)) await walk(part ? part + '/' + name : name);
    } else {
      assert.ok(info.isFile(), 'Non-regular file: ' + full);
      const bytes = await readFile(full);
      rows.push({ path: part, bytes: bytes.length, sha256: sha(bytes) });
    }
  }
  await walk(prefix); rows.sort((a, b) => a.path.localeCompare(b.path));
  return rows;
}
async function rowsAt(base, expected) {
  const rows = [];
  for (const row of expected) {
    assert.ok(!isAbsolute(row.path) && !row.path.split('/').includes('..') && !row.path.includes('\\'));
    const path = resolve(base, row.path);
    assert.ok(path.toLowerCase().startsWith(resolve(base).toLowerCase() + '\\'));
    const info = await lstat(path); assert.ok(info.isFile() && !info.isSymbolicLink());
    const bytes = await readFile(path);
    rows.push({ path: row.path, bytes: bytes.length, sha256: sha(bytes) });
  }
  assert.deepEqual(rows, expected);
  return rows;
}
// The original sampler's whole-site fingerprint algorithm, including 'en' order.
async function artifactFingerprint(directory, requireComplete = true) {
  const base = await realpath(directory), files = [];
  async function walk(prefix = '') {
    for (const entry of await readdir(resolve(base, prefix), { withFileTypes: true })) {
      const path = prefix ? prefix + '/' + entry.name : entry.name;
      if (entry.isDirectory()) await walk(path);
      else if (entry.isFile()) {
        const hash = createHash('sha256'); let bytes = 0;
        for await (const chunk of createReadStream(resolve(base, path))) { hash.update(chunk); bytes += chunk.length; }
        files.push({ path, bytes, sha256: hash.digest('hex') });
      } else throw new Error('Artifact fingerprints require regular files, without links to external data.');
    }
  }
  await walk(); files.sort((a, b) => a.path.localeCompare(b.path, 'en'));
  if (requireComplete) assert.ok(files.some(f => f.path === 'index.html') && files.some(f => f.path === 'js/app-shell.js'));
  return { sha256: sha(files.map(f => f.path + '\0' + f.sha256 + '\n').join('')), files,
    fileCount: files.length, totalBytes: files.reduce((sum, f) => sum + f.bytes, 0) };
}
async function assertBaselineArtifact() {
  const result = await artifactFingerprint(resolve(root, 'site'));
  assert.equal(result.sha256, artifactAnchor); assert.equal(result.fileCount, 127);
  assert.deepEqual(result.files, expectedArtifactRows);
  return result;
}
async function sideSafety(side) {
  assert.ok(side === 'A' || side === 'B');
  const sideRoot = resolve(workspace, side);
  assert.ok(!samePath(sideRoot, root));
  assert.ok(samePath(dirname(sideRoot), workspace));
  assert.equal((await lstat(workspace)).isSymbolicLink(), false);
  assert.equal((await lstat(sideRoot)).isSymbolicLink(), false);
  assert.ok(samePath(await realpath(sideRoot), sideRoot));
  const link = join(sideRoot, 'node_modules');
  assert.equal((await lstat(link)).isSymbolicLink(), true, 'Only approved dependency junction may be a link');
  assert.ok(samePath(await realpath(link), dependencyRoot));
  const output = resolve(sideRoot, 'site');
  assert.ok(samePath(dirname(output), sideRoot) && relative(sideRoot, output) === 'site');
  if (await exists(output)) await walkRegular(output); // Before recursive build cleanup: no links anywhere.
  return { sideRoot, output, dependencyJunction: link, dependencyTarget: await realpath(link), junctionText: await readlink(link) };
}
function rootGitIdentity() {
  const query = args => {
    const r = spawnSync('git', args, { cwd: root, encoding: null, windowsHide: true, maxBuffer: 32 * 1024 * 1024 });
    assert.equal(r.status, 0); assert.equal(r.signal, null); assert.equal(r.error, undefined);
    return { bytes: r.stdout.length, sha256: sha(r.stdout), stderrBytes: r.stderr.length };
  };
  return {
    head: query(['rev-parse', 'HEAD']),
    branch: query(['branch', '--show-current']),
    index: query(['diff', '--cached', '--binary']),
    tracked: query(['diff', '--binary', 'HEAD', '--']),
    status: query(['status', '--porcelain=v1', '-z']),
  };
}
async function captureIdentity() {
  assert.equal(sha(await readFile(join(workspace, 'PROTOCOL.md'))), protocolSha);
  assert.equal(sha(await readFile(join(sourcePrepRoot, 'SOURCE_PREPARATION.md'))), sourcePrepReportSha);
  const result = { node: process.version, executable: process.execPath, sides: {} };
  const pinned = await json(join(workspace, 'A/package.json'));
  assert.equal(process.versions.node, pinned.engines.node);
  for (const side of ['A', 'B']) {
    const safety = await sideSafety(side);
    const rows = await walkRegular(safety.sideRoot, '', new Set(['node_modules', 'site']));
    assert.deepEqual(rows, sourceRows[side]);
    result.sides[side] = { ...safety, count: rows.length, bytes: rows.reduce((s, r) => s + r.bytes, 0), sha256: sha(JSON.stringify(rows)), rows };
  }
  result.installed = { rows: await rowsAt(dependencyRoot, installedRows) };
  result.installed.count = result.installed.rows.length;
  result.installed.sha256 = sha(JSON.stringify(result.installed.rows));
  const rootRows = await walkRegular(root, '', new Set(['.git', 'node_modules', 'site', 'Temp', '.claude', 'docs']));
  rootRows.push(...await rowsAt(root, baseline.source.rows.filter(r => r.path === 'docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md')));
  rootRows.sort((a, b) => a.path.localeCompare(b.path));
  assert.deepEqual(rootRows, baseline.source.rows);
  result.rootSource = { count: rootRows.length, sha256: sha(JSON.stringify(rootRows)), rows: rootRows };
  result.rootArtifact = await assertBaselineArtifact();
  result.rootGit = rootGitIdentity();
  return result;
}
async function measureChunks(site) {
  const manifestBytes = await readFile(join(site, 'js/app-chunks.json'));
  const manifest = JSON.parse(manifestBytes);
  assert.equal(manifest.schema, 1);
  const cold = new Set(manifest.coldStart), lazy = new Set(manifest.lazy);
  assert.equal(cold.size, manifest.coldStart.length); assert.equal(lazy.size, manifest.lazy.length);
  const seen = new Set(), rows = [];
  for (const item of manifest.chunks) {
    assert.match(item.path, /^js\/(?:app-shell|chunks\/[A-Za-z0-9._-]+)\.js$/);
    assert.equal(seen.has(item.path), false); seen.add(item.path);
    assert.equal(cold.has(item.path), item.role === 'cold');
    assert.equal(lazy.has(item.path), item.role === 'lazy');
    assert.notEqual(cold.has(item.path), lazy.has(item.path));
    const bytes = await readFile(join(site, item.path));
    const gzipBytes = gzipSync(bytes).length;
    assert.equal(bytes.length, item.bytes); assert.equal(sha(bytes), item.sha256); assert.equal(gzipBytes, item.gzipBytes);
    rows.push({ path: item.path, role: item.role, bytes: bytes.length, gzipBytes, sha256: sha(bytes) });
  }
  assert.equal(seen.size, cold.size + lazy.size);
  for (const path of [...cold, ...lazy]) assert.ok(seen.has(path));
  const actualChunks = (await walkRegular(join(site, 'js/chunks'))).map(r => 'js/chunks/' + r.path).sort();
  assert.deepEqual(actualChunks, [...seen].filter(p => p.startsWith('js/chunks/')).sort());
  const allGzipBytes = rows.reduce((s, r) => s + r.gzipBytes, 0);
  const coldGzipBytes = rows.filter(r => r.role === 'cold').reduce((s, r) => s + r.gzipBytes, 0);
  return { manifestSha256: sha(manifestBytes), rows, chunks: rows.length,
    rawBytes: rows.reduce((s, r) => s + r.bytes, 0), allGzipBytes, coldGzipBytes,
    allBudget: 77227.7, coldBudget: 52241, allPass: allGzipBytes <= 77227.7, coldPass: coldGzipBytes <= 52241,
    minimumIntegerReduction: Math.max(0, Math.ceil(allGzipBytes - 77227.7)),
    partitionQualification: 'emitted manifest, original build phase checks; no independent final graph/link check in this recorder' };
}
async function nativeBuild(side, runDirectory) {
  const sideRoot = resolve(workspace, side);
  const args = ['scripts/build-site.mjs'];
  const startedAt = new Date().toISOString();
  const stdoutPath = join(runDirectory, 'stdout.bin'), stderrPath = join(runDirectory, 'stderr.bin');
  const receipt = { file: process.execPath, args, cwd: sideRoot, startedAt,
    envOverrides: { SOURCE_DATE_EPOCH: epoch }, inheritedNodeOptions: process.env.NODE_OPTIONS || null,
    timeoutMs: 900000, stdoutPath, stderrPath };
  const stdout = createWriteStream(stdoutPath, { flags: 'wx' });
  const stderr = createWriteStream(stderrPath, { flags: 'wx' });
  let timedOut = false, spawnError = null;
  const child = spawn(process.execPath, args, { cwd: sideRoot, env: { ...process.env, SOURCE_DATE_EPOCH: epoch },
    windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  receipt.pid = child.pid || null;
  const deadline = setTimeout(() => { timedOut = true; child.kill(); }, 900000);
  const closed = new Promise(resolveClose => {
    child.once('error', error => { spawnError = fault(error); });
    child.once('close', (exitCode, signal) => resolveClose({ exitCode, signal }));
  });
  const pipes = Promise.allSettled([pipeline(child.stdout, stdout), pipeline(child.stderr, stderr)]);
  const outcome = await closed; clearTimeout(deadline);
  const pipeOutcomes = await pipes;
  return { ...receipt, ...outcome, endedAt: new Date().toISOString(), timedOut, spawnError,
    pipeErrors: pipeOutcomes.filter(r => r.status === 'rejected').map(r => fault(r.reason)),
    stdout: { bytes: (await readFile(stdoutPath)).length, sha256: sha(await readFile(stdoutPath)) },
    stderr: { bytes: (await readFile(stderrPath)).length, sha256: sha(await readFile(stderrPath)) } };
}
async function preflightOnly() {
  const identity = await captureIdentity();
  const report = { status: 'PREPARED_NOT_EXECUTED', at: new Date().toISOString(), workspace,
    protocolSha256: protocolSha, recorderSha256: sha(await readFile(fileURLToPath(import.meta.url))),
    sequence, sourceDateEpoch: epoch, buildsExecuted: 0, identity };
  await writeJson(join(workspace, 'prepared-preflight.json'), report);
  console.log(JSON.stringify({ status: report.status, workspace, buildsExecuted: 0, sequence,
    baselineArtifact: identity.rootArtifact.sha256, baselineFiles: identity.rootArtifact.fileCount,
    A: identity.sides.A.sha256, B: identity.sides.B.sha256, installed68: identity.installed.sha256 }));
}
async function executeSix() {
  const authorization = await json(join(workspace, 'authorization.json'));
  assert.equal(authorization.parentApprovedForSixBuilds, true);
  assert.equal(authorization.protocolSha256, protocolSha);
  assert.equal(authorization.recorderSha256, sha(await readFile(fileURLToPath(import.meta.url))));
  assert.equal(authorization.candidateAfterReceiptSha256, expectedCandidateAfterSha);
  assert.equal(authorization.behaviorQualified, true);
  assert.ok(isAbsolute(authorization.behaviorReport));
  assert.equal(sha(await readFile(authorization.behaviorReport)), authorization.behaviorReportSha256);
  assert.equal(await exists(join(workspace, 'execution-started.json')), false, 'No rerun/retry after started marker');
  const initial = await captureIdentity();
  await writeJson(join(workspace, 'execution-started.json'), { at: new Date().toISOString(), authorization, sequence, initial });
  const summary = { status: 'RUNNING', sequence, startedAt: new Date().toISOString(), runs: [], failure: null };
  const originals = {};
  try {
    for (const label of sequence) {
      const side = label[0], runDirectory = join(workspace, 'runs', label);
      await mkdir(runDirectory, { recursive: false }); // parent runs directory created below
      const record = { label, side, startedAt: new Date().toISOString() };
      await writeJson(join(runDirectory, 'started.json'), { label, side, startedAt: record.startedAt });
      let error;
      try {
        record.before = await captureIdentity(); assert.deepEqual(record.before, initial);
        await sideSafety(side);
        console.log(JSON.stringify({ event: 'build-start', label, cwd: resolve(workspace, side) }));
        record.native = await nativeBuild(side, runDirectory);
        const site = resolve(workspace, side, 'site');
        if (await exists(site)) {
          await walkRegular(site);
          record.artifact = await artifactFingerprint(site, false);
          const retained = join(runDirectory, 'site');
          await cp(site, retained, { recursive: true, errorOnExist: true, force: false });
          record.retainedArtifact = await artifactFingerprint(retained, false);
          assert.deepEqual(record.retainedArtifact, record.artifact);
        }
        assert.equal(record.native.exitCode, 0); assert.equal(record.native.signal, null);
        assert.equal(record.native.timedOut, false); assert.equal(record.native.spawnError, null);
        assert.deepEqual(record.native.pipeErrors, []);
        record.measurement = await measureChunks(site);
        if (side === 'A') {
          assert.deepEqual(record.artifact.files, expectedArtifactRows);
          assert.equal(record.artifact.sha256, artifactAnchor);
          assert.equal(record.measurement.rawBytes, 245170);
          assert.equal(record.measurement.allGzipBytes, 84187);
          assert.equal(record.measurement.coldGzipBytes, 44699);
        }
        if (originals[side]) {
          assert.deepEqual(record.artifact, originals[side].artifact);
          assert.deepEqual(record.measurement, originals[side].measurement);
        } else originals[side] = { artifact: record.artifact, measurement: record.measurement };
      } catch (caught) { error = caught; record.failure = fault(caught); }
      try { record.after = await captureIdentity(); assert.deepEqual(record.after, initial); }
      catch (caught) { record.afterFailure = fault(caught); error ||= caught; }
      record.endedAt = new Date().toISOString(); record.status = error ? 'FAIL' : 'PASS';
      await writeJson(join(runDirectory, 'receipt.json'), record);
      summary.runs.push({ label, status: record.status, nativeExit: record.native?.exitCode ?? null,
        artifact: record.artifact?.sha256 ?? null, measurement: record.measurement || null,
        failure: record.failure || record.afterFailure || null });
      console.log(JSON.stringify({ event: 'build-end', label, status: record.status, nativeExit: record.native?.exitCode ?? null,
        allGzipBytes: record.measurement?.allGzipBytes ?? null, coldGzipBytes: record.measurement?.coldGzipBytes ?? null }));
      if (error) throw error;
    }
    summary.status = 'SIX_BUILDS_RECORDED';
    summary.deterministicA = true; summary.deterministicB = true;
    summary.baselineReproducedExact127 = true;
    summary.budget = { allLimit: 77227.7, coldLimit: 52241,
      candidateAll: originals.B.measurement.allGzipBytes, candidateCold: originals.B.measurement.coldGzipBytes,
      candidateAllPass: originals.B.measurement.allPass, candidateColdPass: originals.B.measurement.coldPass,
      allDelta: originals.B.measurement.allGzipBytes - originals.A.measurement.allGzipBytes };
  } catch (error) { summary.status = 'STOPPED_FAILURE_NO_RETRY'; summary.failure = fault(error); process.exitCode = 1; }
  finally {
    summary.finishedAt = new Date().toISOString();
    summary.unattempted = sequence.slice(summary.runs.length);
    summary.runtimeTests = 'NOT_RUN_BY_BUILD_RECORDER'; summary.performance = 'NOT_RUN'; summary.adopted = false;
    await writeJson(join(workspace, 'execution-summary.json'), summary);
    console.log(JSON.stringify({ status: summary.status, completed: summary.runs.length, unattempted: summary.unattempted, budget: summary.budget || null, adopted: false }));
  }
}
const mode = process.argv[2];
if (mode === '--preflight-only') await preflightOnly();
else if (mode === '--execute-approved-six') {
  await mkdir(join(workspace, 'runs'), { recursive: false });
  await executeSix();
} else throw new Error('Use --preflight-only. Six builds additionally require parent review and explicit authorization.json.');

