import { readFile, writeFile, mkdir, copyFile, stat } from 'node:fs/promises';
import { resolve, relative, dirname, extname } from 'node:path';
import { createHash } from 'node:crypto';
import { specs, controls } from './cases.mjs';
const root = 'D:/AI项目/FundVal', target = resolve(import.meta.dirname,'frozen');
await mkdir(target);
const roots = ['js/runtime/worker-contract.js','js/eastmoney-estimate.js','js/fund-holdings.js','test/fixtures/worker-contract-v16.js'];
const visited = new Map();
async function visit(path) {
  path = path.replaceAll('\\','/');
  if (visited.has(path)) return;
  const absolute = resolve(root,path), rel = relative(root,absolute).replaceAll('\\','/');
  if (rel.startsWith('../') || rel !== path) throw new Error(`Outside/unnormalized source ${path}`);
  const bytes = await readFile(absolute), source = bytes.toString('utf8'), imports=[];
  if (extname(path)==='.js') {
    const patterns = [/\bimport\s+(?:[^;'"]*?\s+from\s+)?['"](\.{1,2}\/[^'"]+)['"]/g,/\bexport\s+[^;'"]*?\s+from\s+['"](\.{1,2}\/[^'"]+)['"]/g];
    for (const pattern of patterns) for (const match of source.matchAll(pattern)) {
      const next = relative(root,resolve(dirname(absolute),match[1])).replaceAll('\\','/');
      if (!imports.includes(next)) imports.push(next);
    }
  }
  visited.set(path,{path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),imports});
  const destination=resolve(target,path); await mkdir(dirname(destination),{recursive:true}); await copyFile(absolute,destination);
  for (const next of imports) await visit(next);
}
for (const rootPath of roots) await visit(rootPath);
const packageBytes=await readFile(resolve(root,'package.json')); await copyFile(resolve(root,'package.json'),resolve(target,'package.json'));
visited.set('package.json',{path:'package.json',bytes:packageBytes.length,sha256:createHash('sha256').update(packageBytes).digest('hex'),imports:[]});
const references=['AGENTS.md','test/worker-contract-v16.test.js','test/estimate-http-characterization-v16.test.js'];
const referenceInventory=[];
for(const path of references){const bytes=await readFile(resolve(root,path));const destination=resolve(import.meta.dirname,'reference',path);await mkdir(dirname(destination),{recursive:true});await copyFile(resolve(root,path),destination);referenceInventory.push({path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
const files=[...visited.values()].sort((a,b)=>a.path.localeCompare(b.path));
const inventory={schema:1,root,target,roots,staticRelativeClosureOnly:true,files,referenceInventory};
inventory.inventorySha256=createHash('sha256').update(JSON.stringify(files)).digest('hex');
await writeFile(resolve(import.meta.dirname,'frozen-inventory.json'),JSON.stringify(inventory,null,2)+'\n',{flag:'wx'});
await writeFile(resolve(import.meta.dirname,'cases.json'),JSON.stringify({schema:1,specs,controls},null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({status:'FROZEN',files:files.length,bytes:files.reduce((a,b)=>a+b.bytes,0),inventorySha256:inventory.inventorySha256,cases:specs.length,controls:controls.length})+'\n');
