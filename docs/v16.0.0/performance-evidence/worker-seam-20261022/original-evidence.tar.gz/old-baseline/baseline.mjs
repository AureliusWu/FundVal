import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { specs, controls, makeCase } from './cases.mjs';
const dir=import.meta.dirname;
const declared=JSON.parse(await readFile(resolve(dir,'cases.json'),'utf8'));
if(JSON.stringify(declared.specs)!==JSON.stringify(specs)||JSON.stringify(declared.controls)!==JSON.stringify(controls))throw new Error('Fixed declarations changed after freeze');
const denied={fetch:0,localStorage:0,sessionStorage:0};
globalThis.fetch=()=>{denied.fetch++;throw new Error('NETWORK_FORBIDDEN_SYNTHETIC_PROBE');};
for(const key of ['localStorage','sessionStorage'])Object.defineProperty(globalThis,key,{configurable:true,get(){denied[key]++;throw new Error('REAL_STORAGE_FORBIDDEN_SYNTHETIC_PROBE');}});
async function apiAt(root){
  const wire=await import(pathToFileURL(resolve(root,'js/runtime/worker-contract.js')).href);
  const estimates=await import(pathToFileURL(resolve(root,'js/eastmoney-estimate.js')).href);
  const fixtures=await import(pathToFileURL(resolve(root,'test/fixtures/worker-contract-v16.js')).href);
  return {wire,estimates,fixtures};
}
const frozen=await apiAt(resolve(dir,'frozen'));
const original=await apiAt('D:/AI项目/FundVal');
function run(api,spec,control=null){
  const trace=[];let tracing=true;
  const labels=new WeakMap(),proxies=new WeakMap();
  const symbolKey=value=>Symbol.keyFor(value)===undefined?String(value):`Symbol.for(${Symbol.keyFor(value)})`;
  const keyOf=value=>typeof value==='symbol'?{kind:'symbol',value:symbolKey(value)}:{kind:'string',value:String(value)};
  const event=(kind,value)=>{if(tracing)trace.push({op:kind,value});};
  const opaqueSymbol=Symbol('synthetic opaque metadata');
  const sentinel=new TypeError('synthetic getter sentinel');
  const contractSentinel=new api.wire.WorkerContractError('WORKER_ROW_INVALID');
  const context={event,opaqueSymbol,sentinel,contractSentinel,sentinels:[sentinel,contractSentinel]};
  const input=makeCase(api.fixtures,api.wire,context,spec.id);
  function proxied(value,path){
    if(value===null||typeof value!=='object'||value instanceof Date)return value;
    if(proxies.has(value))return proxies.get(value);
    const proxy=new Proxy(value,{
      get(target,key,receiver){if(tracing)trace.push({op:'get',path,key:keyOf(key)});return proxied(Reflect.get(target,key,receiver),`${path}.${typeof key==='symbol'?symbolKey(key):String(key)}`);},
      ownKeys(target){if(tracing)trace.push({op:'ownKeys',path});return Reflect.ownKeys(target);},
      getOwnPropertyDescriptor(target,key){if(tracing)trace.push({op:'getOwnPropertyDescriptor',path,key:keyOf(key)});return Reflect.getOwnPropertyDescriptor(target,key);},
    });
    proxies.set(value,proxy);labels.set(value,path);labels.set(proxy,path);return proxy;
  }
  const payload=proxied(input.payload,'payload'),row=proxied(input.row,'row');
  const options=proxied(input.options,'options'),normalizeOptions=proxied(input.normalizeOptions,'normalizeOptions');
  let output,error=null;
  event('phase','invocation.begin');
  try{
    if(control==='eager-source')void payload.source;
    if(control==='extra-clock')Number(options.now);
    if(spec.operation==='parse')output=api.wire.parseWorkerEnvelope(payload,options);
    else if(spec.operation==='normalize')output=api.estimates.normalizeEstimateRow(row,normalizeOptions);
    else if(spec.operation==='sequence'){
      event('phase','envelope.begin');
      const envelope=api.wire.parseWorkerEnvelope(payload,options);
      event('phase','envelope.end');
      event('phase','second-validation-normalize.begin');
      output=envelope.items.map(item=>api.estimates.normalizeEstimateRow(item,{wireVersion:envelope.wireVersion,fetchedAt:envelope.fetchedAt,now:input.options.now}));
      event('phase','second-validation-normalize.end');
    } else throw new Error('Unknown declared operation');
    if(control==='drop-opaque'){delete output.opaqueEvidence;delete output[opaqueSymbol];}
    event('phase','invocation.return');
  }catch(actual){error=actual;event('phase','invocation.throw');}
  // This exact copy is the invocation trace. All descriptor/output inspection below is outside it.
  const invocationTrace=trace.map(item=>({...item,key:item.key?{...item.key}:undefined}));
  tracing=false;
  let nextId=1;const seen=new WeakMap();
  function snapshot(value){
    if(value===null)return {type:'null'};
    if(value===undefined)return {type:'undefined'};
    if(typeof value==='number')return {type:'number',value:Number.isNaN(value)?'NaN':Object.is(value,-0)?'-0':value===Infinity?'+Infinity':value===-Infinity?'-Infinity':String(value)};
    if(typeof value==='string'||typeof value==='boolean')return {type:typeof value,value};
    if(typeof value==='symbol')return {type:'symbol',value:symbolKey(value)};
    if(typeof value==='bigint')return {type:'bigint',value:String(value)};
    if(typeof value==='function')return {type:'function'};
    if(seen.has(value))return {ref:seen.get(value)};
    const id=nextId++;seen.set(value,id);
    const keys=Reflect.ownKeys(value);
    const properties=keys.map(key=>{
      const descriptor=Object.getOwnPropertyDescriptor(value,key);
      const entry={key:keyOf(key),enumerable:descriptor.enumerable,configurable:descriptor.configurable};
      if(Object.hasOwn(descriptor,'value'))Object.assign(entry,{kind:'data',writable:descriptor.writable,value:snapshot(descriptor.value)});
      else Object.assign(entry,{kind:'accessor',get:typeof descriptor.get==='function',set:typeof descriptor.set==='function'});
      return entry;
    });
    return {type:Array.isArray(value)?'array':'object',id,inputOrigin:labels.get(value)||null,frozen:Object.isFrozen(value),ownKeys:keys.map(keyOf),properties};
  }
  const errorData=error?{name:error.name,code:error.code??null,message:error.message,
    instanceofError:error instanceof Error,instanceofWorkerContractError:error instanceof api.wire.WorkerContractError,
    sentinelIdentity:context.sentinels.includes(error),ownKeys:Reflect.ownKeys(error).map(keyOf)}:null;
  const result={id:spec.id,operation:spec.operation,expected:spec.expected,trace:invocationTrace,
    output:error?null:snapshot(output),error:errorData};
  result.expectedOutcomeMatched=spec.expected==='return'?error===null:spec.expected==='sentinel'?!!errorData?.sentinelIdentity:
    errorData?.code===spec.expected&&errorData?.instanceofWorkerContractError===true;
  return result;
}
const baseline=[];
for(const spec of specs){
  const oldFrozen=run(frozen,spec),oldRoot=run(original,spec);
  const equal=JSON.stringify(oldFrozen)===JSON.stringify(oldRoot);
  baseline.push({spec,frozen:oldFrozen,root:oldRoot,independentOriginalMatch:equal});
}
const controlResults=[];
for(const control of controls){
  const spec=specs.find(item=>item.id===control.target);
  const reference=baseline.find(item=>item.spec.id===control.target).frozen;
  const mutated=run(frozen,spec,control.id);
  const differences=['trace','output','error'].filter(key=>JSON.stringify(reference[key])!==JSON.stringify(mutated[key]));
  controlResults.push({...control,detected:differences.length>0,requiredDifferencesPresent:control.expectDifferences.every(key=>differences.includes(key)),differences,reference,mutated});
}
const failures=[];
for(const row of baseline){
  if(!row.independentOriginalMatch)failures.push({id:row.spec.id,reason:'root-frozen-mismatch'});
  if(!row.frozen.expectedOutcomeMatched||!row.root.expectedOutcomeMatched)failures.push({id:row.spec.id,reason:'predeclared-outcome-mismatch',actual:row.frozen.error});
}
for(const control of controlResults)if(!control.detected||!control.requiredDifferencesPresent)failures.push({id:control.id,reason:'negative-control-not-detected-as-declared'});
if(Object.values(denied).some(value=>value!==0))failures.push({reason:'forbidden-access-attempt',denied});
const sequence=baseline.find(item=>item.spec.id==='simulated-http-changing-date').frozen;
const clockEvents=sequence.trace.filter(item=>item.op==='clock-getTime');
if(clockEvents.length!==3)failures.push({reason:'changing-date-expected-three-reads',actual:clockEvents.length});
const report={schema:1,kind:'old-implementation-read-error-baseline',caseCount:specs.length,originalInvocations:specs.length*2,
  controls:controlResults.length,controlInvocations:controlResults.length,traceSnapshotBeforeOutputInspection:true,
  coverage:{parseWorkerEnvelope:true,normalizeEstimateRow:true,parseThenNormalizeNoFetch:true,fullHTTP:false,requestSignal:false,storage:false,network:false,newParser:false,gzip:false},
  denied,baseline,negativeControls:controlResults,failures,summary:{rootFrozenMatches:baseline.filter(item=>item.independentOriginalMatch).length,
    expectedOutcomesMatched:baseline.filter(item=>item.frozen.expectedOutcomeMatched&&item.root.expectedOutcomeMatched).length,
    controlsDetected:controlResults.filter(item=>item.detected&&item.requiredDifferencesPresent).length,changingDateClockReads:clockEvents.length,status:failures.length?'FAIL':'PASS'}};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n');
const outputPath=resolve(dir,process.argv[2]||'baseline-01.json');
await writeFile(outputPath,bytes,{flag:'wx'});
process.stdout.write(JSON.stringify({path:outputPath,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),...report.summary,failures})+'\n');
process.exitCode=failures.length?1:0;
