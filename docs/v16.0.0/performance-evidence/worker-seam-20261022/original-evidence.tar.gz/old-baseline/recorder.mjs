import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync, readdirSync, copyFileSync } from 'node:fs';
import { resolve, basename } from 'node:path';
import { createHash } from 'node:crypto';
const [label, command, ...args] = process.argv.slice(2);
if (!/^[a-z0-9-]+$/.test(label || '') || !command) throw new Error('Usage: recorder LABEL COMMAND ARGS');
const root = resolve(import.meta.dirname);
const runs = resolve(root, 'runs');
mkdirSync(runs, { recursive: true });
const prefix = resolve(runs, label);
const inputDir = `${prefix}.inputs`;
mkdirSync(inputDir);
const inputs = [];
for (const name of readdirSync(root).filter(name => /\.(?:mjs|md|json)$/.test(name)).sort()) {
  const bytes = readFileSync(resolve(root, name));
  copyFileSync(resolve(root, name), resolve(inputDir, name));
  inputs.push({ path: name, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
}
const startedAt = new Date().toISOString();
const result = spawnSync(command, args, { cwd: root, encoding: null, timeout: 45000, maxBuffer: 30_000_000, windowsHide: true });
const endedAt = new Date().toISOString();
const stdout = result.stdout || Buffer.alloc(0), stderr = result.stderr || Buffer.alloc(0);
writeFileSync(`${prefix}.stdout`, stdout, { flag: 'wx' });
writeFileSync(`${prefix}.stderr`, stderr, { flag: 'wx' });
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const receipt = { label, command, args, cwd: root, startedAt, endedAt, status: result.status, signal: result.signal,
  error: result.error ? { name: result.error.name, message: result.error.message, code: result.error.code } : null,
  stdout: { path: basename(`${prefix}.stdout`), bytes: stdout.length, sha256: sha(stdout) },
  stderr: { path: basename(`${prefix}.stderr`), bytes: stderr.length, sha256: sha(stderr) }, inputs };
writeFileSync(`${prefix}.receipt.json`, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(receipt) + '\n');
process.exitCode = result.status ?? 98;
