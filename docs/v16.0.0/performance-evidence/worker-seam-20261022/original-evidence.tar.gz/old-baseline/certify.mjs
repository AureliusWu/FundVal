import { readFile,writeFile,readdir } from 'node:fs/promises';
import { resolve,relative } from 'node:path';
import { createHash } from 'node:crypto';
const dir=import.meta.dirname,sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const failures=[],receiptChecks=[];
const runs=resolve(dir,'runs');
for(const name of (await readdir(runs)).filter(name=>name.endsWith('.receipt.json')).sort()){
 const receipt=JSON.parse(await readFile(resolve(runs,name),'utf8'));
 if(receipt.status!==0||receipt.signal!==null||receipt.error!==null)failures.push({receipt:name,reason:'native-command-not-success'});
 for(const key of ['stdout','stderr']){const value=receipt[key],bytes=await readFile(resolve(runs,value.path));const match=bytes.length===value.bytes&&sha(bytes)===value.sha256;receiptChecks.push({receipt:name,member:key,match});if(!match)failures.push({receipt:name,member:key});}
 for(const input of receipt.inputs){const bytes=await readFile(resolve(runs,`${receipt.label}.inputs`,input.path));const match=bytes.length===input.bytes&&sha(bytes)===input.sha256;receiptChecks.push({receipt:name,member:input.path,match});if(!match)failures.push({receipt:name,member:input.path});}
}
const inventory=JSON.parse(await readFile(resolve(dir,'frozen-inventory.json'),'utf8')),sourceChecks=[];
for(const item of inventory.files)for(const [side,root]of [['root',inventory.root],['frozen',inventory.target]]){const bytes=await readFile(resolve(root,item.path));const match=bytes.length===item.bytes&&sha(bytes)===item.sha256;sourceChecks.push({side,path:item.path,match});if(!match)failures.push({side,path:item.path});}
for(const item of inventory.referenceInventory){const bytes=await readFile(resolve(inventory.root,item.path));const match=bytes.length===item.bytes&&sha(bytes)===item.sha256;sourceChecks.push({side:'root-reference',path:item.path,match});if(!match)failures.push({side:'root-reference',path:item.path});}
const files=[];async function walk(root){for(const entry of await readdir(root,{withFileTypes:true})){const path=resolve(root,entry.name);if(entry.isDirectory())await walk(path);else{const bytes=await readFile(path);files.push({path:relative(dir,path).replaceAll('\\','/'),bytes:bytes.length,sha256:sha(bytes)});}}}
await walk(dir);files.sort((a,b)=>a.path.localeCompare(b.path));
const canonical=Buffer.from(JSON.stringify(files));
const artifacts={schema:1,scope:'All preceding Temp files, excluding ARTIFACTS/CERTIFICATION outputs and the still-running certification command stdout/stderr/receipt',files,inventorySha256:sha(canonical)};
const artifactBytes=Buffer.from(JSON.stringify(artifacts,null,2)+'\n');await writeFile(resolve(dir,'ARTIFACTS.json'),artifactBytes,{flag:'wx'});
const certificate={schema:1,receiptChecks,sourceChecks,failures,artifactInventory:{files:files.length,inventorySha256:artifacts.inventorySha256,fileSha256:sha(artifactBytes),bytes:artifactBytes.length},status:failures.length?'FAIL':'PASS'};
const certificateBytes=Buffer.from(JSON.stringify(certificate,null,2)+'\n');await writeFile(resolve(dir,'CERTIFICATION.json'),certificateBytes,{flag:'wx'});
process.stdout.write(JSON.stringify({status:certificate.status,receiptChecks:receiptChecks.length,sourceChecks:sourceChecks.length,failures,artifactInventory:certificate.artifactInventory,certificateSha256:sha(certificateBytes),certificateBytes:certificateBytes.length})+'\n');process.exitCode=failures.length?1:0;
