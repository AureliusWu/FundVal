# 旧 Worker 实现固定读取/错误机器基线

2026-10-22；全合成数据，未实现新 parser/codec，未压缩、build、install、浏览器、全量 QA 或网络请求；未改 root/docs。系统 Temp：`C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1`。

## 结果

- 固定 **64 案例**：52 次公开 parser、11 次公开 normalize、1 次无 fetch 的 parse→normalize 时钟链。分别调用冻结副本和根目录原公开实现，共128次；完整机器快照/trace **64/64 相同**。
- 预声明返回/错误类别 **64/64 符合**：24正常返回，40预期异常（其中9个 sentinel）。所有异常原件保留，不筛掉失败输入。这不是64套手写完整预期输出断言，而是类别断言加完整原实现差分基线。
- 3个预声明控制差异全检出：提前读 source 改变 trace+error；额外 clock coercion 仅改变 trace；删除 opaque string/symbol 自有输出字段仅改变 output。未改冻结源。
- 冻结副本单侧64案例原始事件：get4803、getOwnPropertyDescriptor1677、ownKeys29；另保留 phase/getter/clock/custom sentinel 事件。调用结束先复制并关闭 trace，再按 descriptor 观察输出；序列化不会回写 invocation trace，返回 accessor 仅记 descriptor、不调用 getter。
- `fetch/localStorage/sessionStorage` 禁用守卫触发均0。未调用完整 HTTP client/request-signal；不能将无 fetch 序列称完整 HTTP 测试。

## 新冻结的关键旧行为

1. `payload.items` 的两次起始读、Array.isArray 和长度检查在 schema/status/metadata 之前。metadata-before-row 不等于 metadata-before-items；getter/oversize 多错反例已记录。
2. estimates 的 source/report 尾字段在行校验和记账之后读取，行/metadata 失败时不读尾部；fetched_at 校验的两次读取与第三次尾读保持可见。
3. `ChangingDate` 的 envelope→第二次 wire 校验→Quote 规范化恰3次 getTime。实际结果是 `status:error`、source/kind unavailable、source_status fresh、fallback_reason invalid_response、base_nav null、last_nav/est_nav NaN、source_quote unavailable，完整字段/顺序在原 JSON 中保留。
4. wire 阶段只有真实公开 WorkerContractError/ROW_INVALID 被 safe rescue；同名/code 的普通 Error 不会被 rescue。presentation 第二次 type getter 抛同一契约类错误仍以原 sentinel 身份传播。
5. opaque 可枚举 string/symbol、整数样键、不可枚举字段及 ownKeys/descriptor sentinel 均纳入；不把同值结果当作读取轨迹等价。

## 源与原件

- `frozen-inventory.json`：worker-contract 单根完整静态相对闭包7文件；加公开 estimate/holdings client、fixture及必要原 package，共14文件/101266B。静态 import 扫描针对当前已读源码语法，独立复核无漏项；不是通用JS解析器证明。
- 冻结 files 数组 canonical JSON SHA256：`11bc8844354591ff31d9213172fd1dcb6fec2918e680a3c2d10142b6541b2eb2`。
- worker-contract 原文件 SHA256：`54bab1e12f3127b8d28b98185175864ea4dc420b2c862954ab542b3293aa2b44`。
- `baseline-01.json`：4437260B，SHA256 `80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751`。含每案两侧完整结果、读取顺序、异常身份及3组完整控制对照。
- `SUMMARY.json`：64378B，SHA256 `f86b62f08e2204842935036406b5db9ffba4d44ce07a87ad22c2b79d9b7138f2`。
- `cases.mjs`：SHA256 `f9fc6e87ed2ccf5e2c316544f333e0197c0f5c94e36d001947c467bc6065db6d`；`cases.json`：SHA256 `c1ec7df0a66db3de6f756a9899b5d9c8e8b582d8a55384e08ab2fb46c553a644`。先固定再执行，没有结果后改案例。
- `baseline.mjs`：SHA256 `39d55ca60b37e11e041584d0504abd70423120664f070455e4d645c6a22a2a0c`；`stage-ledger.json`：源阶段/案例映射，明确第二次验证、safe rescue与时钟/getter顺序，不是新 parser 的实现。
- `postflight-01.json`：31项 root/frozen/package/reference 字节/SHA检查全部符合；范围不是整个 dirty 工作树全树 hash。
- `runs/`：freeze-01、baseline-01、postflight-01、summary-01完整原生 stdout/stderr/exit/time/command；均 native0、stderr空。每次命令输入脚本/协议/案例副本及hash保留在对应 `.inputs/`。此前只读 PowerShell 源检查在工具历史，不伪称其所有原始字节也在这里。
- 最终 `ARTIFACTS.json` 为本目录此前原件逐项SHA清单，`CERTIFICATION.json`为收据/输入/源哈希再核；该审计不重跑SUT。

独立子代理只读复核确认上述案例/源闭包/原始比对/trace封存/负控/安全rescue记录正确，未执行SUT或写文件，未发现阻塞性问题。首轮冻结、基线、后检、摘要均一次成功，没有失败后修case/过滤样本；初始56的设计在首次冻结/结果前依据独立审查固定增加8项，时间和原因见 PROTOCOL。

## 复用边界

`cases.mjs` 导出 specs/controls/makeCase；`baseline.mjs` 本身没有 candidateRoot 参数，也未导出 run。**不要直接 import baseline.mjs 来复用**，其顶层会再次运行并尝试写已有文件。

后续新 controller 可从不可变 baseline.mjs 的 `function run(api,spec,control=null){` 到 `const baseline=[];` 前提取原文纯runner，并在新模块仅加 makeCase import 与 export。必须另存脚本/结果，保留 runner 原文 hash，使用新的 API/root 参数，并继续拿本次冻结完整原实现作独立对照。不得改本次 baseline-01/cases 原件。本任务未启动候选运行，也未授予候选材料性资格。

## 限制

有限64案不是全输入域/完整API等价证明；未覆盖每个getter/Proxy不变量/默认选项域。错误 stack文本因路径/调用点不同不参与等价比较；name/code/message、instanceof和sentinel身份均参与。未覆盖 HTTP请求/取消/超时/Storage/真实源/生产/性能/包预算。本次为旧实现建立可复用读序/错误基线，**没有证明能省6960B，也没有让M3退出**。
