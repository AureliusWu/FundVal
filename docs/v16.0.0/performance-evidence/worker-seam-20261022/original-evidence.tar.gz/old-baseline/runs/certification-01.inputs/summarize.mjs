import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
const dir=import.meta.dirname;
const read=name=>readFile(resolve(dir,name),'utf8').then(JSON.parse);
const [report,inventory,postflight]=await Promise.all([read('baseline-01.json'),read('frozen-inventory.json'),read('postflight-01.json')]);
const stats={};
const cases=report.baseline.map(item=>{
  const value=item.frozen;
  for(const event of value.trace)stats[event.op]=(stats[event.op]||0)+1;
  return {index:item.spec.index,id:item.spec.id,operation:item.spec.operation,expected:item.spec.expected,matched:value.expectedOutcomeMatched,
    originalMatch:item.independentOriginalMatch,traceEvents:value.trace.length,error:value.error,
    clock:value.trace.map((event,index)=>({event,index})).filter(item=>item.event.op.startsWith('clock-')),
    phases:value.trace.map((event,index)=>({event,index})).filter(item=>item.event.op==='phase')};
});
function dataProperty(value,name){return value?.properties?.find(entry=>entry.key.kind==='string'&&entry.key.value===name)?.value;}
const sequence=report.baseline.find(item=>item.spec.id==='simulated-http-changing-date').frozen;
const sequenceRow=dataProperty(sequence.output,'0');
const sequenceQuote=dataProperty(sequenceRow,'source_quote');
const closureRoot='js/runtime/worker-contract.js',byPath=new Map(inventory.files.map(file=>[file.path,file]));
const closure=new Set();function visit(path){if(closure.has(path))return;closure.add(path);for(const next of byPath.get(path)?.imports||[])visit(next);}visit(closureRoot);
const controls=report.negativeControls.map(item=>({id:item.id,target:item.target,differences:item.differences,detected:item.detected,
  requiredDifferencesPresent:item.requiredDifferencesPresent,referenceError:item.reference.error,mutatedError:item.mutated.error,
  referenceTraceEvents:item.reference.trace.length,mutatedTraceEvents:item.mutated.trace.length}));
const output={schema:1,summary:report.summary,denied:report.denied,frozenFiles:inventory.files.length,frozenBytes:inventory.files.reduce((sum,file)=>sum+file.bytes,0),
  frozenInventorySha256:inventory.inventorySha256,workerContractOnlyClosure:[...closure].sort(),workerContractOnlyClosureCount:closure.size,
  eventTotalsFrozenCases:stats,cases,controls,sequence:{status:dataProperty(sequenceRow,'status'),sourceQuoteStatus:dataProperty(sequenceQuote,'status'),
    nullBase:dataProperty(sequenceRow,'base_nav'),lastNav:dataProperty(sequenceRow,'last_nav'),clock:sequence.trace.filter(item=>item.op==='clock-getTime')},
  postflight:{checks:postflight.checks.length,failures:postflight.failures},coverage:report.coverage};
const bytes=Buffer.from(JSON.stringify(output,null,2)+'\n');await writeFile(resolve(dir,'SUMMARY.json'),bytes,{flag:'wx'});
const hash=createHash('sha256').update(bytes).digest('hex');
process.stdout.write(JSON.stringify({summary:output.summary,denied:output.denied,frozenFiles:output.frozenFiles,frozenBytes:output.frozenBytes,
  frozenInventorySha256:output.frozenInventorySha256,workerContractOnlyClosureCount:closure.size,eventTotals:stats,controls,sequence:output.sequence,postflight:output.postflight,
  summaryFile:{bytes:bytes.length,sha256:hash},files:inventory.files.map(file=>({path:file.path,bytes:file.bytes,sha256:file.sha256,imports:file.imports}))})+'\n');
