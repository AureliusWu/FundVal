import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
const dir=import.meta.dirname,inventory=JSON.parse(await readFile(resolve(dir,'frozen-inventory.json'),'utf8'));
const checks=[];
for(const file of inventory.files){
  for(const [side,root]of [['root',inventory.root],['frozen',inventory.target]]){
    const bytes=await readFile(resolve(root,file.path));const sha256=createHash('sha256').update(bytes).digest('hex');
    checks.push({side,path:file.path,bytes:bytes.length,sha256,match:bytes.length===file.bytes&&sha256===file.sha256});
  }
}
for(const file of inventory.referenceInventory){const bytes=await readFile(resolve(inventory.root,file.path));checks.push({side:'root-reference',path:file.path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),match:bytes.length===file.bytes&&createHash('sha256').update(bytes).digest('hex')===file.sha256});}
const report={schema:1,checks,failures:checks.filter(item=>!item.match),scope:'Frozen closure plus package and three reference files; not whole worktree identity'};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n');await writeFile(resolve(dir,'postflight-01.json'),bytes,{flag:'wx'});
process.stdout.write(JSON.stringify({checks:checks.length,failures:report.failures.length,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')})+'\n');process.exitCode=report.failures.length?1:0;
