import { readFile,writeFile,readdir } from 'node:fs/promises';
import { resolve,relative } from 'node:path';
import { createHash } from 'node:crypto';
const dir=import.meta.dirname,sha=bytes=>createHash('sha256').update(bytes).digest('hex'),read=path=>readFile(resolve(dir,path),'utf8').then(JSON.parse);
const [prepared,qualification,postflight]=await Promise.all([read('PREPARED.json'),read('qualification-01.json'),read('source-after.json')]);
const receiptChecks=[],failures=[];
for(const name of(await readdir(resolve(dir,'runs'))).filter(name=>name.endsWith('.receipt.json')).sort()){
 const receipt=await read(`runs/${name}`);if(receipt.status!==0||receipt.signal!==null||receipt.error!==null)failures.push({receipt:name,reason:'native-status'});
 for(const key of ['stdout','stderr']){const value=receipt[key],bytes=await readFile(resolve(dir,'runs',value.path)),match=bytes.length===value.bytes&&sha(bytes)===value.sha256;receiptChecks.push({receipt:name,member:key,match});if(!match)failures.push({receipt:name,member:key});}
 for(const input of receipt.inputs){const bytes=await readFile(resolve(dir,'runs',`${receipt.label}.inputs`,input.path)),match=bytes.length===input.bytes&&sha(bytes)===input.sha256;receiptChecks.push({receipt:name,member:input.path,match});if(!match)failures.push({receipt:name,member:input.path});}
}
const generic=qualification.generic.map(item=>({id:item.spec.id,operation:item.spec.operation,expected:item.spec.expected,checks:item.checks,differences:item.differences,
 oldError:item.freshOld.error,candidateError:item.candidate.error,oldTraceEvents:item.freshOld.trace.length,candidateTraceEvents:item.candidate.trace.length}));
const fixed=qualification.fixed.map(item=>({selection:item.selection,checks:item.checks,differences:item.differences,oldError:item.oldBound.error,candidateError:item.candidateFixed.error,
 oldTraceEvents:item.oldBound.trace.length,candidateTraceEvents:item.candidateFixed.trace.length,oldOnlySanity:item.oldOnlySanity}));
function dataProperty(value,name){return value?.properties?.find(entry=>entry.key.kind==='string'&&entry.key.value===name)?.value;}
const sequence=qualification.generic.find(item=>item.spec.id==='simulated-http-changing-date'),sequenceEvidence={};
for(const side of ['freshOld','candidate']){const row=dataProperty(sequence[side].output,'0'),quote=dataProperty(row,'source_quote');sequenceEvidence[side]={status:dataProperty(row,'status'),sourceStatus:dataProperty(row,'source_status'),fallbackReason:dataProperty(row,'fallback_reason'),baseNav:dataProperty(row,'base_nav'),lastNav:dataProperty(row,'last_nav'),quoteStatus:dataProperty(quote,'status'),clock:sequence[side].trace.filter(event=>event.op==='clock-getTime')};}
const summary={schema:1,qualification:qualification.summary,runnerCheck:prepared.runnerCheck,exclusions:prepared.exclusions,generic,fixed,sequenceEvidence,
 candidateDependencyChecks:qualification.candidateDependencyChecks,postflight:postflight.checks,receiptChecks,failures:[...failures,...qualification.failures,...postflight.failures],coverage:qualification.coverage};
const bytes=Buffer.from(JSON.stringify(summary,null,2)+'\n');await writeFile(resolve(dir,'SUMMARY.json'),bytes,{flag:'wx'});
const inventory=[];async function walk(root){for(const entry of await readdir(root,{withFileTypes:true})){const path=resolve(root,entry.name);if(entry.isDirectory())await walk(path);else{const data=await readFile(path);inventory.push({path:relative(dir,path).replaceAll('\\','/'),bytes:data.length,sha256:sha(data)});}}}await walk(dir);inventory.sort((a,b)=>a.path.localeCompare(b.path));
const artifacts={schema:1,scope:'All files present before ARTIFACTS output and before this running summary command writes stdout/stderr/receipt; SUMMARY included',files:inventory,inventorySha256:sha(Buffer.from(JSON.stringify(inventory)))};
const artifactBytes=Buffer.from(JSON.stringify(artifacts,null,2)+'\n');await writeFile(resolve(dir,'ARTIFACTS.json'),artifactBytes,{flag:'wx'});
process.stdout.write(JSON.stringify({status:summary.failures.length?'FAIL':'PASS',qualification:qualification.summary,postflightChecks:postflight.checks.length,receiptChecks:receiptChecks.length,failures:summary.failures,
 summary:{bytes:bytes.length,sha256:sha(bytes)},artifactInventory:{files:inventory.length,inventorySha256:artifacts.inventorySha256,bytes:artifactBytes.length,sha256:sha(artifactBytes)}})+'\n');process.exitCode=summary.failures.length?1:0;
