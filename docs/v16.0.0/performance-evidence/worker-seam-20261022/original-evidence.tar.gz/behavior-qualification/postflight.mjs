import { readFile,writeFile,readdir } from 'node:fs/promises';
import { resolve,relative } from 'node:path';
import { createHash } from 'node:crypto';
const dir=import.meta.dirname,sha=bytes=>createHash('sha256').update(bytes).digest('hex'),before=JSON.parse(await readFile(resolve(dir,'source-before.json'),'utf8'));
async function inventoryTree(root){const files=[];async function walk(path){for(const entry of await readdir(path,{withFileTypes:true})){const absolute=resolve(path,entry.name);if(entry.isDirectory())await walk(absolute);else{const bytes=await readFile(absolute);files.push({path:relative(root,absolute).replaceAll('\\','/'),bytes:bytes.length,sha256:sha(bytes)});}}}await walk(root);files.sort((a,b)=>a.path.localeCompare(b.path));return {root,files,inventorySha256:sha(Buffer.from(JSON.stringify(files)))};}
const checks=[],after={};
for(const key of ['candidate','oldBaseline','original']){after[key]=await inventoryTree(before[key].root);checks.push({scope:key,files:after[key].files.length,match:JSON.stringify(after[key].files)===JSON.stringify(before[key].files),before:before[key].inventorySha256,after:after[key].inventorySha256});}
after.rootSelected=[];for(const entry of before.rootSelected){const bytes=await readFile(resolve('D:/AI项目/FundVal',entry.path)),value={path:entry.path,bytes:bytes.length,sha256:sha(bytes)};after.rootSelected.push(value);checks.push({scope:'root-selected',path:entry.path,match:JSON.stringify(value)===JSON.stringify(entry)});}
const immutableHelpers=['cases.mjs','cases.json','runner.mjs','PROTOCOL.md'];
const receipt=JSON.parse(await readFile(resolve(dir,'runs/qualification-01.receipt.json'),'utf8'));
for(const path of immutableHelpers){const entry=receipt.inputs.find(item=>item.path===path),bytes=await readFile(resolve(dir,path));checks.push({scope:'qualification-helper',path,match:!!entry&&bytes.length===entry.bytes&&sha(bytes)===entry.sha256});}
const report={schema:1,after,checks,failures:checks.filter(item=>!item.match),scope:'Whole candidate/source-copy and entire old baseline directory; selected14 root source/package/fixture files, not whole root worktree'};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n');await writeFile(resolve(dir,'source-after.json'),bytes,{flag:'wx'});
process.stdout.write(JSON.stringify({checks:checks.length,failures:report.failures,bytes:bytes.length,sha256:sha(bytes),sourceInventories:checks.filter(item=>item.scope!=='root-selected'&&item.scope!=='qualification-helper')})+'\n');process.exitCode=report.failures.length?1:0;
