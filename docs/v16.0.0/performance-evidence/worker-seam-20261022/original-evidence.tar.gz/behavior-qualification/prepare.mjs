import { readFile,writeFile,mkdir,copyFile,readdir } from 'node:fs/promises';
import { resolve,relative,dirname } from 'node:path';
import { createHash } from 'node:crypto';
const dir=import.meta.dirname,old='C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1',candidate='C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/candidate';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const required={'baseline.mjs':'39d55ca60b37e11e041584d0504abd70423120664f070455e4d645c6a22a2a0c','cases.mjs':'f9fc6e87ed2ccf5e2c316544f333e0197c0f5c94e36d001947c467bc6065db6d','cases.json':'c1ec7df0a66db3de6f756a9899b5d9c8e8b582d8a55384e08ab2fb46c553a644','baseline-01.json':'80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751'};
const inputChecks=[];for(const [path,expected]of Object.entries(required)){const bytes=await readFile(resolve(old,path));inputChecks.push({path,bytes:bytes.length,sha256:sha(bytes),match:sha(bytes)===expected});}
const baselineText=await readFile(resolve(old,'baseline.mjs'),'utf8');
const start=baselineText.indexOf('function run(api,spec,control=null){'),end=baselineText.indexOf('const baseline=[];',start);
if(start<0||end<0||baselineText.indexOf('function run(api,spec,control=null){',start+1)>=0)throw new Error('Ambiguous old runner extraction');
const functionText=baselineText.slice(start,end),expectedRunner=`import { makeCase } from './cases.mjs';\n${functionText}export { run };\n`,runner=await readFile(resolve(dir,'runner.mjs'),'utf8');
const runnerCheck={verbatim:runner===expectedRunner,functionBytes:Buffer.byteLength(functionText),functionSha256:sha(Buffer.from(functionText)),moduleBytes:Buffer.byteLength(runner),moduleSha256:sha(Buffer.from(runner))};
if(!runnerCheck.verbatim||inputChecks.some(item=>!item.match)){
 await writeFile(resolve(dir,'PREPARE_FAILURE.json'),JSON.stringify({inputChecks,runnerCheck},null,2)+'\n',{flag:'wx'});throw new Error('Immutable input/runner byte check failed');
}
const oldInventory=JSON.parse(await readFile(resolve(old,'frozen-inventory.json'),'utf8'));
const original=resolve(dir,'original');await mkdir(original);
const copied=[];
for(const entry of oldInventory.files){const source=resolve(old,'frozen',entry.path),destination=resolve(original,entry.path),bytes=await readFile(source);if(bytes.length!==entry.bytes||sha(bytes)!==entry.sha256)throw new Error(`Old frozen mismatch ${entry.path}`);await mkdir(dirname(destination),{recursive:true});await copyFile(source,destination);copied.push({...entry});}
for(const [source,destination]of [['cases.mjs','cases.mjs'],['cases.json','cases.json'],['baseline-01.json','reference-baseline.json']])await copyFile(resolve(old,source),resolve(dir,destination));
async function inventoryTree(root){const files=[];async function walk(path){for(const entry of await readdir(path,{withFileTypes:true})){const absolute=resolve(path,entry.name);if(entry.isDirectory())await walk(absolute);else{const bytes=await readFile(absolute);files.push({path:relative(root,absolute).replaceAll('\\','/'),bytes:bytes.length,sha256:sha(bytes)});}}}await walk(root);files.sort((a,b)=>a.path.localeCompare(b.path));return {root,files,inventorySha256:sha(Buffer.from(JSON.stringify(files)))};}
const candidateInventory=await inventoryTree(candidate),oldBaselineInventory=await inventoryTree(old),originalInventory=await inventoryTree(original);
const rootSelected=[];for(const entry of oldInventory.files){const bytes=await readFile(resolve('D:/AI项目/FundVal',entry.path));rootSelected.push({path:entry.path,bytes:bytes.length,sha256:sha(bytes)});}
const candidateFixture=candidateInventory.files.find(item=>item.path==='test/fixtures/worker-contract-v16.js'),oldFixture=copied.find(item=>item.path==='test/fixtures/worker-contract-v16.js');
if(!candidateFixture||candidateFixture.sha256!==oldFixture.sha256||candidateFixture.bytes!==oldFixture.bytes)throw new Error('Candidate fixture differs from immutable old fixture');
const cases=JSON.parse(await readFile(resolve(dir,'cases.json'),'utf8')).specs;
const fixedCases=cases.filter(spec=>spec.operation==='sequence'||spec.operation==='parse'&&spec.id!=='invalid-endpoint').map(spec=>({id:spec.id,endpoint:spec.id.startsWith('h-')?'holdings':'estimates',operation:spec.operation}));
const exclusions=cases.filter(spec=>!fixedCases.some(item=>item.id===spec.id)).map(spec=>({id:spec.id,reason:spec.operation==='normalize'?'normalize-only-no-endpoint':'caller-endpoint-invalid-not-an-input-to-fixed-entry'}));
if(cases.length!==64||fixedCases.length!==52||exclusions.length!==12)throw new Error('Fixed predeclared selection counts mismatch');
const before={schema:1,candidate:candidateInventory,oldBaseline:oldBaselineInventory,original:originalInventory,rootSelected};
await writeFile(resolve(dir,'source-before.json'),JSON.stringify(before,null,2)+'\n',{flag:'wx'});
const prepared={schema:1,old,candidate,original,inputChecks,runnerCheck,copiedFiles:copied.length,copiedBytes:copied.reduce((sum,item)=>sum+item.bytes,0),candidateFixture,oldFixture,cases:64,fixedCases,exclusions,invocations:235,
 sourceInventories:{candidate:candidateInventory.inventorySha256,oldBaseline:oldBaselineInventory.inventorySha256,original:originalInventory.inventorySha256}};
await writeFile(resolve(dir,'PREPARED.json'),JSON.stringify(prepared,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({status:'PREPARED',runnerCheck,immutableInputs:inputChecks.length,copiedFiles:copied.length,candidateFiles:candidateInventory.files.length,cases:64,fixedCases:fixedCases.length,exclusions:exclusions.length,invocations:235})+'\n');
