# Worker 同文件拆分：一次有限行为资格验证

2026-10-22；候选通过本次有限 **64/52 合成行为资格验证**。没有修改候选、root、旧基线或案例；没有 build/install/browser/网络/压缩/性能/全量 QA。

候选：`C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/candidate`。

## 固定执行与结果

协议 PROTOCOL.md 在 prepare/任何行为调用前固定；执行唯一 qualification-01，没有重试、修候选、换case或筛除失败输入。

| 组 | 对照 | 完整结果 |
| --- | --- | --- |
| generic64 | 新候选公开generic vs已存独立旧基线 | 64/64相同 |
| generic64 | 新候选公开generic vs本次fresh冻结旧公开generic | 64/64相同 |
| generic64 | 本次fresh冻结旧 vs已存旧 | 64/64相同 |
| fixed52 | 候选固定endpoint入口 vs独立冻结旧parser的literal-bound adapter | 52/52相同 |
| 原3负控 | 原文runner重现原负控结果与差异敏感性 | 3/3相同且检出 |

generic64覆盖原52 parser、11 public normalize、1无fetch parse→normalize。预声明24返回/40异常均保留；符合类别不等于64套手写完整输出断言。fixed52含39 estimates/13 holdings，有malformed/partial/accounting/sentinel等预期失败输入，并非“52有效payload”。仅排除11个normalize-only案及invalid-endpoint（固定入口不接收调用者endpoint选择）。排除清单逐项保存在PREPARED/qualification JSON，没有结果后排除。

总顶层调用235：generic两侧128 +fixed两侧104 +原负控3。每次由原factory新建独立Proxy/getter/Date。网络/真实Storage守卫尝试均0。

## 独立对照与读取顺序

- runner.mjs的function body从原不可变baseline.mjs逐字提取；prepare校验完整模块只有makeCase import/原函数/export。function原文 **5214B/SHA25666fcbdd3212b4fc18830cd0f86e2b70eaea4c5f48adf7a76af02b91918d22a75**；模块5270B/SHA256e1dc1f70eb6220e6d8260a02f53e00247dcb42e606814e483420a28873d7f21a。
- 旧完整公开parser/normalizer及完整静态相对依赖14文件从上一冻结目录逐项核hash复制到original/；不是两个新wrapper共用新core互比。候选/旧的wire、normalizer、fixture分别从各自源目录加载；fixture相同字节，3个允许改变文件之外的闭包依赖与旧源逐项相同。
- candidate WorkerContractError与独立旧class不是同一模块身份；每侧sentinel/instanceof使用各自公开wireclass。真实/伪装类safe-rescue、late presentation原sentinel传播均保留。
- fixed候选直接使用导出的专用函数；旧侧adapter按同签名先解构requestedCodes再now，随后把endpoint字面量和这两个值交给原旧generic。端点从事前固定case-ID映射选择，没有读取Proxy options.endpoint，没有额外Number(now)。
- fixed主比较是候选与旧bound的**完整未过滤结果/trace**。仅另做旧bound-vs存储旧generic的辅助sanity：输出/错误完全相同，trace只少一项原generic的options.endpoint读取。该旧对旧辅助操作不用于候选求同。
- runner在调用结束先封存/关闭trace再按descriptor观察输出。ownkey/order/属性描述符、symbols、null/undefined/NaN/-0、冻结/引用标记、error name/code/message/instanceof/sentinel身份均参与完整JSON比较；stack文本不参与。
- ChangingDate旧/候选各3次getTime，第二次wire校验仍safe rescue：实际status:error、source_status:fresh、fallback_reason:invalid_response、base_nav:null、last_nav:NaN、source_quote:unavailable。不是仅检查“没有throw”。

独立子代理只读审查了controller、原件和收据，确认无对照污染：generic64对stored+fresh旧；fixed52无候选trace过滤；源目录/错误类/sequence配套；调用数、守卫、原件hash和不变范围均正确。它没有重跑SUT或写文件。parent另有独立静态源码重构审查；本报告不把其648检查冒充本次新行为检查。

## 源身份与原始捕获

prepare-01、qualification-01、postflight-01均一次native0、stderr空；随后summary仅核收据/生成目录，不重跑SUT。完整原始stdout/stderr/native exit/time/command与输入脚本/协议副本在runs/。

source-before/source-after精确不变：候选246文件、旧基线整个目录97文件、独立旧源副本14文件，加root选定14个源/package/fixture；21项后检通过。**不是整个dirty root工作树的全树证明**。旧baseline/cases/results目录97份逐项字节/SHA未变。

- 候选全目录files数组digest：`3d8af26e759cee59db6ff189d6ccfb8263a4a2b87853afb09a560db264875764`。
- 旧基线全目录digest：`dce255c2d55b4c6a2a946a9a7c71993c4da49f58fc0d61cdd21f361468315564`。
- 独立旧源副本digest：`bbd7b8f76619acbcfca215220fc0f0c74180cc7899d614e48986a8a27340026f`。

主要入口/原件：

- `qualify.mjs`：唯一controller；`runner.mjs`原文runner；`cases.mjs/cases.json`原始64案；`PREPARED.json`固定52选择与12排除、源/runner资格。
- `qualification-01.json`：**10021622B/SHA256361cece0f65c6c4dc76b30657d7d83f1a71befe5e55db025ce565d29259afd33**；含所有generic stored/fresh旧/候选、fixed旧bound/候选完整结果及3负控。
- `reference-baseline.json`：原旧机器基线逐字副本，SHA25680792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751。
- `source-after.json`：71925B/SHA256e31d85a17b496a1a5cab1ec6e113bbd60a7f68c2e724ebf437db156d89dd681c。
- `SUMMARY.json`：有限结果/错误/读序数量/ChangingDate/源后检/原始收据核验摘要；`ARTIFACTS.json`逐项字节/SHA，scope明确不包含其自身和生成它的最后仍在运行收据。最终摘要及其SHA见runs/summary-01.stdout。

本轮没有失败运行或结果后的代码/案例修正，所有预期抛错都作为输入行为完整保留。

## 资格边界与停止

本次PASS只覆盖固定64 generic与52 fixed合成调用：不是完整API/所有输入/所有getter或默认options域证明，未运行完整HTTP/request-signal/取消/超时/Storage链。没有build或实际chunk闭包/tree-shaking/gzip/性能/CI/设备/真实金融源/生产验证，**不能宣称约6960B净减包、可采用发布或M3完成**。

按协议验证后停止；后续独立构建或更大管线设计是否继续由parent判断。本任务不改候选或root，不自动扩大范围。
