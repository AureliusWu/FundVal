import { readFile,writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { specs,controls } from './cases.mjs';
import { run } from './runner.mjs';
const dir=import.meta.dirname,sha=bytes=>createHash('sha256').update(bytes).digest('hex'),equal=(left,right)=>JSON.stringify(left)===JSON.stringify(right);
const prepared=JSON.parse(await readFile(resolve(dir,'PREPARED.json'),'utf8'));
const before=JSON.parse(await readFile(resolve(dir,'source-before.json'),'utf8'));
const storedBytes=await readFile(resolve(dir,'reference-baseline.json'));
if(sha(storedBytes)!=='80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751')throw new Error('Stored independent baseline changed');
const stored=JSON.parse(storedBytes),declared=JSON.parse(await readFile(resolve(dir,'cases.json'),'utf8'));
if(!equal(declared.specs,specs)||!equal(declared.controls,controls)||specs.length!==64)throw new Error('Original fixed case set changed');
const candidateDependencyChecks=[];
for(const entry of before.original.files){
 const candidateEntry=before.candidate.files.find(item=>item.path===entry.path);
 if(!candidateEntry)throw new Error(`Candidate closure missing ${entry.path}`);
 const allowed=['js/runtime/worker-contract.js','js/eastmoney-estimate.js','js/fund-holdings.js'].includes(entry.path);
 const bytes=await readFile(resolve(prepared.candidate,entry.path)),matchesBefore=bytes.length===candidateEntry.bytes&&sha(bytes)===candidateEntry.sha256;
 const unchangedOrAllowed=allowed||candidateEntry.bytes===entry.bytes&&candidateEntry.sha256===entry.sha256;
 candidateDependencyChecks.push({path:entry.path,allowedToDiffer:allowed,matchesBefore,unchangedOrAllowed});
 if(!matchesBefore||!unchangedOrAllowed)throw new Error(`Candidate dependency identity mismatch ${entry.path}`);
}
const denied={fetch:0,localStorage:0,sessionStorage:0};
globalThis.fetch=()=>{denied.fetch++;throw new Error('NETWORK_FORBIDDEN_SYNTHETIC_QUALIFICATION');};
for(const key of ['localStorage','sessionStorage'])Object.defineProperty(globalThis,key,{configurable:true,get(){denied[key]++;throw new Error('REAL_STORAGE_FORBIDDEN_SYNTHETIC_QUALIFICATION');}});
async function apiAt(root){
 const wire=await import(pathToFileURL(resolve(root,'js/runtime/worker-contract.js')).href);
 const estimates=await import(pathToFileURL(resolve(root,'js/eastmoney-estimate.js')).href);
 const fixtures=await import(pathToFileURL(resolve(root,'test/fixtures/worker-contract-v16.js')).href);
 return {wire,estimates,fixtures};
}
const oldApi=await apiAt(prepared.original),candidateApi=await apiAt(prepared.candidate);
if(oldApi.wire.WorkerContractError===candidateApi.wire.WorkerContractError)throw new Error('Old and candidate source modules are not independent identities');
const differences=(left,right)=>['id','operation','expected','trace','output','error','expectedOutcomeMatched'].filter(key=>!equal(left[key],right[key]));
const generic=[],failures=[];
for(const spec of specs){
 const reference=stored.baseline.find(item=>item.spec.id===spec.id).frozen;
 const freshOld=run(oldApi,spec),candidate=run(candidateApi,spec);
 const checks={freshOldMatchesStored:equal(freshOld,reference),candidateMatchesStored:equal(candidate,reference),candidateMatchesFreshOld:equal(candidate,freshOld),
  expectedOutcomesMatch:freshOld.expectedOutcomeMatched&&candidate.expectedOutcomeMatched};
 const entry={spec,checks,differences:{freshOldStored:differences(freshOld,reference),candidateStored:differences(candidate,reference),candidateFreshOld:differences(candidate,freshOld)},stored:reference,freshOld,candidate};
 generic.push(entry);if(Object.values(checks).some(value=>!value))failures.push({group:'generic',id:spec.id,checks,differences:entry.differences});
}
function oldEstimates(payload, { requestedCodes = [], now = Date.now() } = {}) {
 return oldApi.wire.parseWorkerEnvelope(payload, { endpoint: 'estimates', requestedCodes, now });
}
function oldHoldings(payload, { requestedCodes = [], now = Date.now() } = {}) {
 return oldApi.wire.parseWorkerEnvelope(payload, { endpoint: 'holdings', requestedCodes, now });
}
const fixed=[];
for(const selection of prepared.fixedCases){
 const spec=specs.find(item=>item.id===selection.id);
 const oldParser=selection.endpoint==='holdings'?oldHoldings:oldEstimates;
 const candidateParser=selection.endpoint==='holdings'?candidateApi.wire.parseWorkerHoldingsEnvelope:candidateApi.wire.parseWorkerEstimateEnvelope;
 if(typeof candidateParser!=='function')throw new Error(`Candidate fixed parser missing ${selection.endpoint}`);
 const oldBoundApi={...oldApi,wire:{...oldApi.wire,parseWorkerEnvelope:oldParser}};
 const candidateFixedApi={...candidateApi,wire:{...candidateApi.wire,parseWorkerEnvelope:candidateParser}};
 const oldBound=run(oldBoundApi,spec),candidateFixed=run(candidateFixedApi,spec);
 const reference=stored.baseline.find(item=>item.spec.id===spec.id).frozen;
 // This is only an OLD-to-OLD entry-shape sanity check, never used to normalize candidate comparison.
 const removedEndpointReads=reference.trace.filter(event=>event.op==='get'&&event.path==='options'&&event.key?.kind==='string'&&event.key.value==='endpoint');
 const oldGenericWithoutEndpoint=reference.trace.filter(event=>!(event.op==='get'&&event.path==='options'&&event.key?.kind==='string'&&event.key.value==='endpoint'));
 const checks={candidateMatchesIndependentOldBound:equal(candidateFixed,oldBound),expectedOutcomesMatch:oldBound.expectedOutcomeMatched&&candidateFixed.expectedOutcomeMatched,
  oldBoundOutputErrorMatchesStoredGeneric:equal({output:oldBound.output,error:oldBound.error,expectedOutcomeMatched:oldBound.expectedOutcomeMatched},{output:reference.output,error:reference.error,expectedOutcomeMatched:reference.expectedOutcomeMatched}),
  oldBoundTraceDiffersOnlyByOneEndpointRead:removedEndpointReads.length===1&&equal(oldBound.trace,oldGenericWithoutEndpoint)};
 const entry={selection,checks,differences:differences(candidateFixed,oldBound),oldBound,candidateFixed,oldOnlySanity:{removedEndpointReads:removedEndpointReads.length}};
 fixed.push(entry);if(Object.values(checks).some(value=>!value))failures.push({group:'fixed',id:spec.id,checks,differences:entry.differences});
}
const controlResults=[];
for(const control of controls){
 const spec=specs.find(item=>item.id===control.target),mutated=run(oldApi,spec,control.id);
 const originalControl=stored.negativeControls.find(item=>item.id===control.id),reference=generic.find(item=>item.spec.id===control.target).freshOld;
 const changes=differences(mutated,reference);
 const checks={exactStoredControlMatch:equal(mutated,originalControl.mutated),requiredDifferencesPresent:control.expectDifferences.every(key=>changes.includes(key))};
 controlResults.push({control,checks,differences:changes,mutated});if(Object.values(checks).some(value=>!value))failures.push({group:'control',id:control.id,checks});
}
if(Object.values(denied).some(value=>value!==0))failures.push({group:'forbidden-access',denied});
const clocks=generic.find(item=>item.spec.id==='simulated-http-changing-date');
const clockReads={old:clocks.freshOld.trace.filter(item=>item.op==='clock-getTime').length,candidate:clocks.candidate.trace.filter(item=>item.op==='clock-getTime').length};
if(clockReads.old!==3||clockReads.candidate!==3)failures.push({group:'clock',clockReads});
const summary={status:failures.length?'FAIL':'PASS',genericCases:generic.length,freshOldStoredMatches:generic.filter(item=>item.checks.freshOldMatchesStored).length,
 candidateStoredMatches:generic.filter(item=>item.checks.candidateMatchesStored).length,candidateFreshOldMatches:generic.filter(item=>item.checks.candidateMatchesFreshOld).length,
 fixedCases:fixed.length,fixedEstimates:fixed.filter(item=>item.selection.endpoint==='estimates').length,fixedHoldings:fixed.filter(item=>item.selection.endpoint==='holdings').length,
 fixedIndependentOldBoundMatches:fixed.filter(item=>item.checks.candidateMatchesIndependentOldBound).length,controls:controlResults.length,controlsMatched:controlResults.filter(item=>Object.values(item.checks).every(Boolean)).length,
 invocations:generic.length*2+fixed.length*2+controlResults.length,clockReads,denied,failures:failures.length};
const report={schema:1,kind:'single-bounded-worker-seam-behavior-qualification',preparedSource:prepared.sourceInventories,runnerCheck:prepared.runnerCheck,
 candidateDependencyChecks,generic,fixed,exclusions:prepared.exclusions,negativeControls:controlResults,summary,failures,
 coverage:{generic64:true,fixedEndpoint52:true,fullHTTP:false,requestSignal:false,newSourceEdits:false,build:false,gzip:false,performance:false,fullAPIInputDomain:false}};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n'),path=resolve(dir,'qualification-01.json');await writeFile(path,bytes,{flag:'wx'});
process.stdout.write(JSON.stringify({path,bytes:bytes.length,sha256:sha(bytes),summary,failures})+'\n');process.exitCode=failures.length?1:0;
