# M3 material deletion boundary: bounded independent read-only review

2026-10-22, FundVal 15.0.2, HEAD `170fd3eadc6da02750882f8a542904ee2358d0d9`.

## Decision

**No new qualified, sufficiently large closed deletion slice was found in the three bounded directions reviewed here: source-health default specialization, Bridge request/response boundaries, and the main fund renderer.** This is a bounded design result, not a proof that a larger safe redesign cannot exist. Do not start another minifier, build, or 800-pair sequence on this report alone.

The current manifest declares 16 chunks / 245170 raw B / 84187 gzip B, against the unchanged 77227.7 all limit; the integer gap remains at least 6960 B. The inventory freshly reread every current chunk and checked its actual bytes/SHA against that manifest. It did **not** recompress those chunks: all gzip figures in this report are existing manifest values, not new measurements.

## Scope and preserved boundaries

- Read the complete root `AGENTS.md`, `docs/v16.0.0/UPGRADE_PLAN.md`, M3_STATUS sections 38–48, `performance-evidence/m3-estimate-dto-review-20261015.md`, and `audit-closure-20261022/README.md`.
- Preserved the pre-existing dirty worktree. No application/source/test/config/dependency/output edits; only this new Temp folder was written with apply_patch.
- No browser, network, build, tests, package installation, minifier or gzip invocation, performance sample, push, commit, deployment, version change, or memory update.
- Kept the original five groups, ES2022, strict runtime validation, public legacy APIs, unknown-field behavior, null/zero/date/cache semantics, Schema 3, and original budget in scope as constraints, not proposed tradeoffs.
- The parent agent's diagnostics producer→Store investigation was expressly excluded to avoid duplicating work. This report also does not revive old DTO/string-pool/clock/HMS/compression sweeps or the three prior audit-closure directions.

## Reproducible inventory and limits

Files in this folder:

1. `inventory.mjs`: read-only parser/inventory. It uses the already installed `rolldown/utils` parseSync and Node built-ins. It never imports/evaluates application code or writes files.
2. `inventory.json`: exact JSON stdout of its final invocation, native exit 0. This output was saved via apply_patch, not by having the inventory write into the repository.
3. `REPORT.md`: this analysis.

Re-run from the repository: `node Temp/m3-material-boundary-20261022-scope-review/inventory.mjs`.

The program inventories named source functions by AST span, locates selected current-output function spans by unique body markers, and checks all 16 current output bytes/SHA against `site/js/app-chunks.json`. It is **not** a complete semantic equivalence checker, module-contribution allocator, arbitrary dead-code detector, graph/link checker, or bundle optimizer. Nested function spans are not independent pools and must not be added to their containing function.

Selected source identities are saved in inventory.json. Current manifest SHA256 is `dc33fea7dbac6da1fb57126653b8744a0f2fa62774fac92d4926a87921fd9ef3`. All 16 chunk bytes/SHA were checked against it. Current post-integrity is 101160 raw / declared 33921 gzip; business-runtime is 82819 raw / declared 27848 gzip. These whole-member numbers include many unrelated live responsibilities and are not deletable pools.

## A. Source-health default specialization: the apparent large module is mostly live or already cut

### Current live calls

- `js/app.js:76` constructs the closed page `RefreshCoordinator`; imports its private implementation at `:21`. `js/runtime/refresh-runtime.js:69` creates the builtin registry instead of the generic registry factory.
- `refresh-runtime.js:143–178` exposes source health/attempt/success/partial/failure/release methods to its closed contexts. Its snapshot includes the registry at `:93`.
- `app.js:764–808` actually claims the estimate source and records complete/partial/failed/aborted results. These are not a descriptor-only feature.
- `js/runtime/refresh-execution.js:201–241` and `:261–280` actually use half-open claim identities, source health, partial coverage, failure and probe release for the holdings/model branches. The `halfOpenProbeAt` comparison is a late-generation ownership boundary, not unused bookkeeping.
- `js/runtime/diagnostics-ui.js:155–162` reads source IDs, health status, failure counts and response latency from the live coordinator snapshot. Quote/cache validation also uses descriptor capabilities (`refresh-resource-cache.js:50–52`) and source tier/identity (`quote-contract.js:2`, `:162–171`).

### What a full deletion would have to close

Deleting the 18927-B source file, its health engine, or descriptor registry would require replacing every production caller above while preserving immutable snapshots, status transitions, independent registry/descriptor/array ownership, failure/abort classification, half-open claim/release identity, exact metadata normalization, callback/reentry timing and diagnostics output. Public generic APIs must still remain available unchanged, so a page-only replacement can remove a generic algorithm from the default graph only when no default quote/cache/coordinator caller still needs that same algorithm.

The existing private coordinator has already achieved the obvious split: it imports `createBuiltinSourceRegistry`, not `createSourceRegistry`. Actual chunks lack the generic factory/policy/selection body-specific markers `Source descriptors must be an array.`, `Source health policy must be an object.`, and `Source selection criteria must be an object.` The source import evidence and these output observations are consistent; no claim of an independent general tree-shaking theorem is made.

### New concrete residual pool, and why it is not a candidate

Fixed `DESCRIPTORS` still runs `.map(freezeDescriptor)` (`source-registry.js:36`). AST body-marker inventory locates exactly one current-output instance of each of:

| Source helper | Source location | Current output function / raw B |
| --- | --- | --- |
| nonEmptyText | source-registry.js:89 | post-integrity `E` / 128 |
| immutableTextList | source-registry.js:95 | post-integrity `ie` / 255 |
| freezeDescriptor | source-registry.js:144 | post-integrity `le` / 562 |

The three disjoint function bodies total **945 minified raw B**, not 945 gzip B. Further `finiteNumber`/`isRecord` helpers remain live for clock/response/health validation, and data/array freezing remains required. Merely replacing `.map(freezeDescriptor)` by trusted literals would not be equivalent to the current validation contract: `test/refresh-runtime-characterization-v16.test.js:237–255` specifically binds builtin declarations to the complete public validator and its four validation helpers. The previous tests at `:169–234` bind property order, deep freezing, array/descriptor/health/policy independence, strict boolean selection, and no extra-argument getter reads.

The health transition engine itself is not redundant validation. `test/source-health-equivalence-v16.test.js:405–466` explicitly covers success avoiding reason getters, partial reading reason only after response/timestamp validation, failure getter order, and previous-status short-circuits. `:382–403` binds error messages and unknown-source/invalid-clock precedence. No safe full-default-engine deletion is established here. Moving those checks to new wrappers would retain validation work and add adapters, not prove a deletable 7 KB gzip pool.

## B. Bridge request/response specialization: distinct inputs, not duplicate validation

### Current live calls and trust boundaries

- `js/runtime/quote-bridge-client.js:124–145` first checks `event.source` against the iframe window, then calls `validateBridgeResponse` on **incoming event.data** with the pending request ID, operation and params. A matching iframe source is not proof that untrusted JSONP-derived data has a valid schema.
- `quote-bridge-client.js:199–210` validates an outbound request before loading/posting it. This follows queued waiting/cancellation and has its own operation/abort/request-ID/error precedence. It is not the same input object or time boundary as the response.
- `js/runtime/remote-schema.js:136–169` validates outbound params/request identity; `:173–242` validates NAV/metadata or quotes; `:245–281` validates the response envelope and its expected request/operation identity.
- `js/runtime/refresh-plan.js:135–141` uses param validation for code admissibility before constructing second-phase demand. The later Bridge check also applies count/duplicate/request-envelope rules at the actual dispatch boundary. Replacing either with an unconditional trust flag would weaken a check rather than remove an already duplicated full validation.

### Complete removal boundary and constraints

To remove the generic response engine from the default graph, one would need operation-specific validators for every still-live operation (official NAV, indices, security quotes, overseas components), the same incoming envelope validation, fixed request matching, unknown-key/prototype/type/range/length/duplicate checks, error-code behavior and deep immutable output. Public APIs still need their present behavior. The specialized validators would therefore retain the substantive algorithms; wrappers alone do not close a large deletion.

`remote-schema.js:53–69` is plain-record and unknown-field enforcement; `:71–99` preserves string/finite number/request-ID error behavior; `:119–133` preserves ordered code validation and uniqueness; `:173–242` rejects invalid NAV pairs/metadata/unexpected quote identities rather than accepting a shape merely because it came from the sandbox. Missing change/timestamp fields remain null and cannot become 0 or a request-time date.

The output inventory newly confirms one official NAV validation function (`Yt`, 1417 raw B) and one response-envelope function (`Qt`, 983 raw B); the latter has two selected markers but is counted only once. These bodies are live, not removed. The script does not pretend to allocate the entire generic remote schema's gzip contribution.

The separate sandbox script's request/provider checks are not a second copy in the 16 app chunks: `scripts/build-site.mjs:279–281` copies the sandbox page/scripts as standalone site files, while `remote-schema.js` and the client are in the business group (`:44`). Removing sandbox checks would breach the explicit isolation/allowlist boundary and would not by itself subtract from the measured app-chunk all budget.

## C. Renderer/legacy display cut: one real renderer and already-dead old helpers

### Current live behavior

- `js/app.js:1373–1542` is one `renderFundList`, not two desktop/mobile business renderers. It assembles related desktop/expanded-mobile markup from the same per-fund projection.
- Before sorting/rendering it rechecks Quote freshness and recomputes current holding amounts (`:1383–1387`), deliberately later than acquisition. A quote accepted at acquisition is not permanently fresh.
- The expanded view exposes alternative model/official evidence (`:1433–1441`), current source/time/trust, real shares/cost-derived amounts, details error/loading/empty states, disclosure date, per-stock quote availability, fund metadata and fees (`:1445–1527`). These are distinct live product states, not repeated algorithm copies.
- `:1375–1377` and `:1535–1539` preserve keyboard focus across re-rendering; `:1423` binds the actual accessible toggle identity/state. A generic HTML builder must preserve escaping and the difference between trusted literal markup and untrusted labels; it cannot silently treat all interpolations as safe.

### Material boundary

The actual top-level current output function containing `fund-card-toggle` is `Z`, **6660 minified raw B**. Its nested per-fund function is 6052 B inside that same span and is **not additive**. Deleting `Z` would delete the product's main fund UI. Template/helper extraction must keep its conditions, ordering, escaping, freshness/projection and focus behavior; a replacement implementation is required. The current evidence establishes no closed obsolete 7 KB gzip renderer subtree.

There really are old display helpers still visible in source, including `preferredDailyMove` (`app.js:1079–1126`) and `isOverseasFundEstimate` (`:1060–1066`). They are not called by the current main display (`displayChangeOf:1133–1136` reads Quote only). Current chunks contain neither the old `isLatestNav` result property nor the unique old `海外非实时` label. Deleting these source functions is therefore source cleanup, not a new measured app-chunk saving. `isOverseasLikeFund` and `latestNavMoveOf` do have other actual callers (`:817`, `:1436`) and must not be removed alongside the dead helper.

## Materiality and engineering next decision

No nonempty deletion set in these three reviewed directions has met all of: closed live-call boundary, preserved contract, a removed algorithm rather than moved checks/new adapters, and a credible path to the 6960-B gzip gap. Thus this review contributes **0 B of qualified/claimable gzip saving**; it does not assert a universal mathematical 0-B optimization ceiling. The 945/1417/983/6660 values are precise AST raw body inventories, not measured gzip deltas or valid gzip upper bounds. No useful nontrivial gzip upper bound for an unimplemented wider replacement follows from this source inspection. Whole post-integrity/business chunk costs are equally not partial-rewrite upper bounds.

The normal next engineering decision is a **formal bounded redesign contract**: explicitly choose one end-to-end representation/state-machine boundary that can retire an entire currently-live implementation, enumerate all legacy/public/cache inputs and output sinks, and specify what remains once the old implementation has actually become unreachable in the default graph. That design must preserve existing validation at the relevant untrusted and time-of-use boundaries, not simply label inputs trusted. It needs characterization criteria for getter/exception/key-order/identity/copy/freeze/timing/null/zero/date/cache behavior before implementation. Only a concrete complete old-implementation deletion and replacement-cost account warrants a fixed candidate build and fresh qualification.

If no such deletion design can be agreed within the current scope, report the M3 budget gate as still open and ask the owner for the required design/scope decision. Do not default to budget waiver, remove product safeguards/features, widen this into an unbounded audit, re-run already-passing 800 pairs, or continue parameter sweeps hoping they will settle an architectural boundary. This finite review does not prove that every permitted future refactor is impossible.
