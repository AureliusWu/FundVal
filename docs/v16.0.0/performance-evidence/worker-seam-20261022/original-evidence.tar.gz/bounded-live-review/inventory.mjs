// Read-only inventory. It parses source/current built chunks, but never imports
// application modules, compresses code, builds, tests, or writes output files.
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseSync } from 'rolldown/utils';

const root = fileURLToPath(new URL('../../', import.meta.url));
const bytes = value => Buffer.byteLength(value, 'utf8');
const sha256 = value => createHash('sha256').update(value).digest('hex');
const walk = (node, visit) => {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) { for (const child of node) walk(child, visit); return; }
  if (typeof node.type === 'string') visit(node);
  for (const [key, child] of Object.entries(node)) {
    if (!['start', 'end', 'loc', 'range'].includes(key) && child && typeof child === 'object') walk(child, visit);
  }
};
const functions = (path, code) => {
  const result = [];
  walk(parseSync(path, code).program, node => {
    if (!['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.type)) return;
    const source = code.slice(node.start, node.end);
    result.push({ name: node.id?.name || '(anonymous)', start: node.start, end: node.end,
      line: code.slice(0, node.start).split('\n').length, bytes: bytes(source), source });
  });
  return result;
};

const sourcePaths = ['js/runtime/source-registry.js', 'js/runtime/refresh-runtime.js',
  'js/runtime/remote-schema.js', 'js/runtime/quote-bridge-client.js',
  'js/runtime/refresh-plan.js', 'js/runtime/refresh-resource-cache.js', 'js/app.js'];
const source = [];
for (const path of sourcePaths) {
  const data = await readFile(resolve(root, path));
  const code = data.toString('utf8');
  source.push({ path, bytes: data.length, sha256: sha256(data),
    functions: functions(path, code).filter(item => item.name !== '(anonymous)')
      .map(({ source, start, end, ...item }) => item) });
}
const manifestBytes = await readFile(resolve(root, 'site/js/app-chunks.json'));
const manifest = JSON.parse(manifestBytes);
const currentChunks = [];
const allOutputFunctions = [];
for (const item of manifest.chunks) {
  const data = await readFile(resolve(root, 'site', item.path));
  const code = data.toString('utf8');
  const hash = sha256(data);
  if (data.length !== item.bytes || hash !== item.sha256) throw new Error(`Current chunk identity mismatch: ${item.path}`);
  currentChunks.push({ path: item.path, bytes: data.length,
    manifestGzipBytes: item.gzipBytes, sha256: hash });
  allOutputFunctions.push(...functions(item.path, code).map(fn => ({ path: item.path, ...fn })));
}
const markers = ['must be a non-empty string.', 'must not be empty.',
  'Source descriptor must be an object.', 'Source descriptors must be an array.',
  'Source health policy must be an object.', 'Source selection criteria must be an object.',
  'Builtin registry selection must be boolean.', 'officialFundData points must contain the latest two NAV points',
  'failed bridge response cannot contain data', 'bridge response ok must be boolean',
  'fund-card-toggle', 'isLatestNav', '海外非实时'];
const markerFunctions = markers.map(marker => ({ marker,
  matches: allOutputFunctions.filter(item => item.source.includes(marker))
    .map(({ source, start, end, ...item }) => item) }));
const descriptorFunctions = markerFunctions.slice(0, 3).flatMap(item => item.matches);
const deduped = [...new Map(descriptorFunctions.map(item => [`${item.path}:${item.name}:${item.line}`, item])).values()];
console.log(JSON.stringify({ scope: 'read-only source/current output AST inventory; no source execution or gzip measurement',
  source, manifest: { path: 'site/js/app-chunks.json', sha256: sha256(manifestBytes),
    chunks: currentChunks.length, raw: currentChunks.reduce((sum, item) => sum + item.bytes, 0),
    gzipFromManifestOnly: currentChunks.reduce((sum, item) => sum + item.manifestGzipBytes, 0) },
  markerFunctions, declarationValidationOutputFunctions: deduped,
  declarationValidationOutputRawPool: deduped.reduce((sum, item) => sum + item.bytes, 0),
  currentChunks }, null, 2));
