# M3 complete private data pipeline: independent design review

2026-10-22; repository D:/AI项目/FundVal. Read-only design inspection. No product/source/test/config writes, no install/build/test/browser/network/provider request/minifier/compression experiment. This report is the only new file, in a new operating-system Temp directory. Existing root dirty work is preserved.

## Decision

There is a technically coherent *larger* slice, not merely a DTO/facade: a quote/evidence-first private pipeline spanning both Worker endpoints, refresh resource ingress/egress, aggregate hydration/egress, models, rendering and accuracy. It can be moved one behavior boundary at a time without a one-shot rewrite. The October 15 DTO report does not prove this wider slice impossible.

However, this review has **not identified a qualified >=6960 B net gzip deletion**. It is an architecture investigation candidate, not an implementation-ready M3 size candidate. Do not implement it or start another small-probe series under the claim that it will close the budget. The compatible replacement code below is real work and must be subtracted from gross deletion. Removing the names of old functions from the default graph is not the same as removing their algorithms.

I explicitly correct an initially over-strong premise: public business-features exports and function identities must remain available, but need not all be in the homepage's default bundle. Original modules are copied to site, and a separately statically narrowed private runtime facade can avoid importing them. Preserving the public API is not, by itself, a veto on the larger design.

## Current fixed gates

Read M3_STATUS sections 38-48, UPGRADE_PLAN sections 9 and 11, AGENTS.md in full, and the two requested review/evidence documents. Current stored manifest: all84187, cold44699; original all limit77227.7 and cold52241 unchanged. Integer all total must become <=77227, so at least6960 B must actually disappear, about8.27% of the entire present app gzip. Section48's current-source 800 pairs PASS and section46 audit0 are recorded evidence, not rerun here; a future changed candidate needs its own eligibility/QA/performance/CI.

The five existing loading groups, ES2022 target, startup migration/integrity sequence, lazy heavy features, financial/null/date/identity semantics, validation and public/persisted compatibility stay fixed. No M4/M5/M6 advance, version bump, release or deployment follows from this review.

## The complete proposed slice

The proposed internal state is an EvidenceBook, not a selected Quote DTO:

    identity + primary source evidence + latest official NAV pair
      + independent holdings-model evidence + overseas-model evidence
      + transport/diagnostic/presentation notes + compatibility extension state
      -> current-time candidate selection -> current-repository holding amounts

The extension state is necessary for legacy aggregate input; it is not a hidden second financial authority. Trusted derived values overwrite same-named opaque fields at exactly the old boundaries. A mismatch in either cached quote identity discards the entire cached financial snapshot before extension preservation.

New paths must be *closed together*:

1. Endpoint-specific holdings and estimates parsers share only truly identical primitive/metadata validation. Holdings must not import the generic estimates dispatcher. Public parseWorkerEnvelope and normalizeWorkerEstimateRow remain compatible outside the default graph.
2. A private estimates acquisition path produces evidence, not a wire alias row followed by another legacy presentation row. It keeps the envelope accounting/partial/error checks and the second temporal validation/rescue boundary. Public fetchEstimateRows and normalizeEstimateRow remain byte-/behavior-compatible via their existing public path, not switched to a weaker private type.
3. A resource codec reads the existing persisted payload.rows, checks the existing aliases/provenance/strict allowlist and emits evidence. A resource writer emits the existing legacy row format. Use-time cache validation and stage-copy validation remain; a private in-memory brand is not proof that persisted bytes stay valid.
4. An aggregate codec handles matching quote, matching source_quote and raw legacy rows, preserving the old import semantics and unknown-field behavior. It emits the same persisted v1 data[] compatibility shape, not a new schema.
5. Private lookthrough/overseas producers emit independent model evidence directly. They do not overwrite primary evidence and later recover it from legacy aliases. The official baseline chooser keeps provenance priority and immutable-primary completion-order invariance.
6. UI, accuracy and notification adapters read the evidence book/selected quote. They retain alternative-model and official-NAV notes even when a different quote wins. Holdings edits and render-time rechecks project from the *current* holdings repository and later clock.
7. There are still two aggregate-writing contexts: refresh flush can advance acquisition clocks only after real new fund acquisition; holding edit/external repository installation preserves acquisition clock/source/resources while rewriting projections/hash. They may share a codec but may not share clock policy.

A new narrow static facade must expose only these private implementation functions to App/executor. It cannot re-export the old business namespace or retain it in an escaping object. New modules stay in their corresponding existing post-integrity/business group; this is not a sixth loading group or an eager business import.

## A concrete new incremental precondition: header/items/tail split

This is a useful enabling refactor, not a DTO shortcut and not a7 KB size claim:

    common Worker envelope header
       -> estimates items/accounting parser -> late envelope result tail
       -> holdings items/accounting parser  -> late envelope result tail

Keep the original public generic dispatcher, names/defaults and error API. Default endpoint clients may statically import the corresponding specialized entry. The old business-features source/API can remain intact while App eventually imports a new narrow private facade. Splitting the dispatcher alone does not drop the estimates implementation while the default estimates client still needs it; the value is making the later row-decoder/materializer cut independently possible.

Suggested extraction ownership, subject to exact characterization before implementation:

- A common core owns WorkerContractError/reject, strict timestamp parser, row-status/reason primitives, initial payload/endpoint/items-count guard, version/status/metadata validation and requestedCodes identity validation. The old worker-contract re-exports the *same* class binding, not a second class with the same name, preserving instanceof and error.code/name/message.
- A holdings items parser owns payload.code membership, partial/degraded reason checks, unavailable/empty cardinality, validateHoldingSet, returned count and nonempty-source checks. It must never import the estimates parser or row normalizer.
- An estimates items parser owns rawItems/unavailable_items enumeration, duplicate/request identity accounting, missing-code accounting, legacy-success partial rule, per-row normalization and the final accounting.kind counts. This is intentionally endpoint-specific, not generalized with holdings under a broad mode table.
- A late result tail builds wireVersion/status/source/fetchedAt/generatedAt/serviceVersion/capabilities/reportDate/items *after* the item parser. It cannot move payload.source/fetched_at/generated_at/service_version/report_date reads into an eager header snapshot. Earlier metadata validation reads remain at their original position.
- Only the requested Set/length/format checks are truly common accounting here. Holdings count semantics and estimates unavailable/partial/accounting semantics differ. Calling all of this a shared accounting core would conceal real rules.

The exact source-level preconditions are: preserve options destructuring/default evaluation; payload record and endpoint short-circuit order; items getter/length/enumeration order; own-property decisions; Date subclass clock conversion sites; repeated fetched_at timestamp calls; generated/service/capabilities validation order; metadata-before-items errors; late output getter reads; per-row legacySuccess revalidation; ROW_INVALID-only second-validation safe rescue outside the complete-envelope failure path; and opaque own-key/symbol propagation on the public path. Do not cache reads merely because the normal HTTP JSON fixture is plain data.

The next exact validation is **a reading/error-stage differential specification**, not a minifier run: freeze the original current source; mark every extracted expression and its old phase; list strict malformed/partial/v1/v2 cases plus getters/proxies/sentinels/ChangingDate and the late-field getters; specify expected output own keys/order/NaN/null/frozen references and error identity/name/code/message. After separate approval for isolated implementation, run that frozen-old/new differential harness and existing characterization in Temp. The public generic parser must independently remain equivalent; comparing two new wrappers that both delegate the new core is not an independent control.

After that approved behavioral checkpoint, verify the actual default import graph: holdings client reaches only header/holdings/tail; estimates client reaches header/estimates/tail; no namespace retention or generic dispatcher backedge. Static source imports alone are not an actual emitted-byte proof. This establishes an honest architectural precondition for the full slice, not materiality qualification for it.

## Concrete conditional old-default-graph deletion ledger

These are functions/blocks that could stop being reachable only after the entire row-facing slice above is moved. They are *not* permission to delete the public source file or its public behavior.

| Present default live construction | What can disappear from the default graph | What a compatible replacement must still contain |
| --- | --- | --- |
| worker-contract.js:64-160 normalizeWorkerEstimateRow, especially return145-159; generic parseWorkerEnvelope:163 onward | Legacy wire alias row construction and generic endpoint branch structure, once neither private endpoint imports it | All input fields/alias conflicts/kinds/status/time/model evidence/accounting rules, metadata order, reason/error behavior; endpoint specialization is not deleting estimates validation |
| eastmoney-estimate.js:13-65 normalizeEstimateRow and its call in fetchEstimateRows | Full HTTP legacy presentation materialization and full-row spread/reparse inside private HTTP flow | Second clock validation and selective WORKER_ROW_INVALID rescue; sanitized names/type/labels/notes/status; data needed for old resource output; public behavior including getters/symbols/key order remains on public path |
| quote-normalizer.js:160-218,242-301 | Generic fresh-row alias extraction, both model-to-legacy-row wrappers, and mixed-row candidate construction | A raw-legacy aggregate importer must still implement every alias priority, kind fallback, source tier, diagnostic code, model period and candidate dedupe/selection behavior. These cannot simply vanish |
| holdings-estimate.js:156-200; fund-model-enrichment.js:12-57 | Mutation of large legacy fund rows, followed by extracting those same fields back into Quote candidates | Baseline provenance, model formula/weights/report/session/period guards, separate model notes/evidence, immutable composition and legacy output codec |
| app.js:645-714 officialFundFallback/buildFundData; tryShowCache1009+; legacy model/official helpers used by render | Legacy row as the inter-component transport and repeated extract/materialize phases | Naming/status/fallback behavior; same selected Quote, current holding amounts, render-time freshness, official/model secondary notes and compatibility egress values |
| refresh-resource-cache.js:39-93 estimateRow; rows branch of payloadFor95+ | Legacy row as the *private* acquired/staged transport | Existing persisted rows are still untrusted: the strict row/Quote allowlists, typed numeric rules, NaN/null conversion, alias tolerance, provenance/date/freshness validation remain in resource ingress/egress |
| app slimFundCache/saveCache and serializeRefreshAggregate rows loop | Two independently implemented filtering/row-projection shells could share one codec | Their outer contracts differ: edit preserves old envelope/clock; refresh active-code filter, duplicate rejection, resource acceptance, acquisition clock advancement and unknown field behavior remain distinct |

In particular, resource-cache, wire-contract and quote-contract are not three copies of one validator: wire accepts specific numeric strings and throws reason codes; resource cache requires numbers, accepts particular null/NaN placeholders with1e-7 tolerance and fails closed; Quote normalization is a separate freshness/provenance/display rule. One generic permissive validator would change security/data semantics. The private kernel must preserve those modes explicitly, not delete checks.

## Materiality: honest upper envelope and unknown net saving

No new gzip was calculated. The current manifest's business-runtime is27848 B gzip and post-integrity33921 B gzip:61769 B is the entire compressed *container* containing most of this pipeline plus large unrelated behavior. It is a gross exposure envelope, **not** a candidate saving or a defensible tight upper bound after rechunking/hash/dictionary effects. Treating all61769 as removable would delete the application. Five-group topology must remain.

The historical section16 rendered standalone gzip numbers (worker-contract4351; resource-cache4639; executor4439; security-batch3552) are only historical context. They are neither current attribution nor additive savings. Executor/security batching are mostly outside the proposed removable construction slice and must remain. The small HTTP -120 B probe also failed behavior, so contributes zero qualified saving. The old string-pool experiment reduced7579 raw while increasing gzip641: raw assignment counts cannot establish the present6960 gzip target.

What can currently be bounded with confidence is limited: **zero whole modules have been proved removable with no replacement**, and zero bytes of *qualified* net gzip saving have been established. This is not an upper bound of zero on what a future redesign could achieve. No credible candidate-specific compressed upper/lower interval exists in the current evidence. In particular, the two large compressed modules cannot be added and then discounted by an arbitrary percentage to manufacture a7 KB forecast.

The materiality risk is substantial: this wider design can eliminate old default constructors, but the old persisted shape requires a compatibility serializer and importer; every validation/freshness/model rule still runs at the same trust boundary. Thus it trades several materializations for new codecs and evidence assembly. The source deletion ledger is meaningful, but does not yet show that net compressed code loss exceeds6960 B rather than1-3 KB, zero, or a regression. Neither a guarantee nor a mathematical impossibility claim follows.

## Behavioral migration, not a one-shot rewrite

If the owner elects to investigate the whole slice, use one finite design/prototype checkpoint, not another helper/format scan:

1. Freeze the current dirty-source identity and old bundle; write the complete ingress/egress field-and-presence ledger, including raw legacy cases, default fields and opaque overrides. State the complete replacement/deletion map before any candidate implementation.
2. Characterize the two cache serializers plus raw legacy hydration, UI/accuracy secondary evidence, refresh/edit/repository/render clocks and completion-order cases. Reuse, do not weaken, existing HTTP/public characterization and resource tests. There is no behavior change in this phase.
3. Move the endpoint-independent primitives and holdings endpoint first, preserving the old public API wrappers. This is an architecture checkpoint only, not a promised size win.
4. Move legacy resource/aggregate ingress and the single shared compatibility codec while keeping output fields/order/JSON/null/NaN/clock semantics. Both old and new flows can be replay-compared in an isolated test harness; never run two live product flows or double storage writes.
5. Move model producers and UI/accuracy consumers. Only then switch the private App/executor graph and prove none of the old constructor paths remain accidentally reachable. During migration, old public modules remain testable and independently copied to site.
6. Qualify one complete candidate using the original build/gzip graph rules, cold limit, API/behavior tests, startup isolation, native binding, full QA, safety and a fresh fixed relative-performance protocol. Net all <=77227 is required. If the one complete design misses, record the rejection and stop that design; do not turn it into a parameter sweep or move to M4.

This is a serious engineering program rather than a free optimizer trick. It crosses the M2 data-trust implementation to simplify the M3 runtime but preserves its contracts; it must not silently become a new product/schema change. The architecture can be migrated incrementally, yet partial migrations are not evidence of eventual budget closure.

## Owner decision and immediate safe next step

The parent's boundary for this subtask is read-only design/no candidate implementation or builds, so **do not start step3-6 in this subtask**. This is not a verified global user ban on every Temp prototype before proving net gzip. The user allows independent verification of compression strategies with adoption only after qualification, alongside the original sequential v16 plan; treating that as requiring measured savings before any isolated experiment would be circular. This review has not qualified the full candidate.

The root agent must judge whether a bounded, behavior-preserving isolated structural experiment is already within the user's authorization, leaving every budget/API/compatibility rule intact. Ask the owner only if that experiment would materially expand the authorized scope, not merely because it is a Temp prototype or its saving is not known yet. A future isolated prototype can produce the missing net-gzip evidence; this review neither grants materiality qualification nor makes that scope decision for root.

Until a candidate actually qualifies, the honest outcome is M3 still IN_PROGRESS/all FAIL, version15.0.2 retained. Do not repeat already excluded tiny DTO/facade/string/helper probes and do not claim that no program optimization can exist. The immediate next work is the complete compatibility/deletion ledger and independent architecture review; root can then decide the authorized isolated experiment rather than treating this subtask's restriction as a new user instruction.

## Inspected evidence and limits

- AGENTS.md; docs/v16.0.0/UPGRADE_PLAN.md sections9/11; M3_STATUS.md sections38-48 (also16/29 for historical non-additive compressed attribution).
- docs/v16.0.0/performance-evidence/m3-estimate-dto-review-20261015.md; audit-closure-20261022/README.md.
- Current site/js/app-chunks.json; build-site.mjs group/copy/build logic; worker-contract, eastmoney-estimate, fund-holdings, quote-normalizer/contract/presentation, refresh-resource-cache/execution, holdings-estimate, fund-model-enrichment, accuracy and relevant App call sites.
- Existing business-features identity, HTTP characterization, resource cache and cached-fund-identity test source only. No tests rerun; no live financial trust, provider freshness, production, Gist or device qualification.
- A quick MEMORY.md search supplied repository-routing/old audit-scope context only. Current design conclusions above come from the live source/documents, not stale performance memory.
