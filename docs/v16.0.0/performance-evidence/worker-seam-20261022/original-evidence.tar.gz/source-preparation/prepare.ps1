param([Parameter(Mandatory=$true)][string]$Workspace)
$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\Users\84046\AppData\Local\Temp\fundval-pair824-extract-07zGKl\measured-current-inputs'
$rawInventory = 'C:\Users\84046\AppData\Local\Temp\fundval-pair824-extract-07zGKl\postflight\postflight.json'
$workspaceRoot = [System.IO.Path]::GetFullPath($Workspace)
$candidateRoot = Join-Path $workspaceRoot 'candidate'
$originalsRoot = Join-Path $workspaceRoot 'original-three'
if (Test-Path -LiteralPath $candidateRoot) { throw 'Refusing existing candidate' }
$protocolItem = Get-Item -LiteralPath (Join-Path $workspaceRoot 'PROTOCOL.md')
if (!$protocolItem.IsReadOnly) { throw 'Protocol must be read-only before copy' }
$originalRecord = Get-Content -LiteralPath $rawInventory -Raw -Encoding UTF8 | ConvertFrom-Json
$excluded = @($originalRecord.source.rows | Where-Object { $_.path.StartsWith('.codex-tmp/', [System.StringComparison]::Ordinal) })
$expectedRows = @($originalRecord.source.rows | Where-Object { !$_.path.StartsWith('.codex-tmp/', [System.StringComparison]::Ordinal) })
if ($expectedRows.Count -ne 246 -or $excluded.Count -ne 24) { throw 'Unexpected archived source scope' }
$actualSourcePaths = @(Get-ChildItem -LiteralPath $sourceRoot -File -Recurse -Force | ForEach-Object { [System.IO.Path]::GetRelativePath($sourceRoot, $_.FullName).Replace('\','/') } | Sort-Object)
$expectedPaths = @($expectedRows.path | Sort-Object)
if (($actualSourcePaths -join "\n") -cne ($expectedPaths -join "\n")) { throw 'Archived source has extra/missing files' }
$baselineRows = @()
foreach ($row in $expectedRows) {
  if ([System.IO.Path]::IsPathRooted($row.path) -or $row.path -match '(^|/)\.\.(/|$)' -or $row.path.Contains('\')) { throw 'Unsafe source path' }
  $sourceFile = [System.IO.Path]::GetFullPath((Join-Path $sourceRoot $row.path))
  if (!$sourceFile.StartsWith($sourceRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Source escaped root' }
  $fileItem = Get-Item -LiteralPath $sourceFile -Force
  if (($fileItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing source reparse point' }
  $hash = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($fileItem.Length -ne $row.bytes -or $hash -cne $row.sha256) { throw ('Archived source identity mismatch: ' + $row.path) }
  $baselineRows += [ordered]@{ path=$row.path; bytes=$fileItem.Length; sha256=$hash }
}
New-Item -ItemType Directory -Path $candidateRoot | Out-Null
foreach ($row in $expectedRows) {
  $sourceFile = Join-Path $sourceRoot $row.path
  $targetFile = [System.IO.Path]::GetFullPath((Join-Path $candidateRoot $row.path))
  if (!$targetFile.StartsWith($candidateRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped candidate root' }
  New-Item -ItemType Directory -Path ([System.IO.Path]::GetDirectoryName($targetFile)) -Force | Out-Null
  Copy-Item -LiteralPath $sourceFile -Destination $targetFile
}
$copyRows = @()
foreach ($row in $expectedRows) {
  $targetFile = Join-Path $candidateRoot $row.path
  $fileItem = Get-Item -LiteralPath $targetFile
  $hash = (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($fileItem.Length -ne $row.bytes -or $hash -cne $row.sha256) { throw ('Copied source identity mismatch: ' + $row.path) }
  $copyRows += [ordered]@{ path=$row.path; bytes=$fileItem.Length; sha256=$hash }
}
$three = @('js/runtime/worker-contract.js','js/fund-holdings.js','js/eastmoney-estimate.js')
foreach ($path in $three) {
  $target = Join-Path $originalsRoot $path
  New-Item -ItemType Directory -Path ([System.IO.Path]::GetDirectoryName($target)) -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $sourceRoot $path) -Destination $target
}
Copy-Item -LiteralPath $rawInventory -Destination (Join-Path $workspaceRoot 'original-postflight.json')
[ordered]@{ stage='before-semantic-edit'; sourceRoot=$sourceRoot; candidateRoot=$candidateRoot; expectedCount=246; excludedHistoricalCount=24; sourceBytes=($baselineRows | Measure-Object bytes -Sum).Sum; archivedSourceRows=$baselineRows; candidateRows=$copyRows; originalPostflightSha256=(Get-FileHash -LiteralPath $rawInventory -Algorithm SHA256).Hash.ToLowerInvariant(); protocolSha256=(Get-FileHash -LiteralPath $protocolItem.FullName -Algorithm SHA256).Hash.ToLowerInvariant(); copyVerified=$true } | ConvertTo-Json -Depth 10

