// Read-only source certification: no application evaluation and no file writes.
import { readFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const workspace = fileURLToPath(new URL('./', import.meta.url));
const candidate = join(workspace, 'candidate');
const before = JSON.parse(await readFile(join(workspace, 'before.json'), 'utf8'));
const baselineRoot = before.sourceRoot;
const sha = data => createHash('sha256').update(data).digest('hex');
const targets = ['js/runtime/worker-contract.js', 'js/fund-holdings.js', 'js/eastmoney-estimate.js'];
const checks = [];
const check = (name, condition) => {
  checks.push({ name, passed: condition === true });
  if (condition !== true) throw new Error('Static source certification failed: ' + name);
};
async function pathsUnder(root, folder = root) {
  const result = [];
  for (const entry of await readdir(folder, { withFileTypes: true })) {
    const path = join(folder, entry.name);
    if (entry.isSymbolicLink()) throw new Error('Unexpected symbolic link: ' + path);
    if (entry.isDirectory()) result.push(...await pathsUnder(root, path));
    else if (entry.isFile()) result.push(relative(root, path).replaceAll('\\', '/'));
    else throw new Error('Unexpected entry type: ' + path);
  }
  return result.sort();
}
const baselineRows = before.archivedSourceRows;
check('246 before baseline rows', baselineRows.length === 246);
check('246 before copied rows', before.candidateRows.length === 246);
check('before baseline/copy rows exactly equal', JSON.stringify(baselineRows) === JSON.stringify(before.candidateRows));
check('exact before source list', JSON.stringify(await pathsUnder(baselineRoot)) === JSON.stringify(baselineRows.map(row => row.path).sort()));
check('exact after candidate source list', JSON.stringify(await pathsUnder(candidate)) === JSON.stringify(baselineRows.map(row => row.path).sort()));
const afterRows = [];
const changed = [];
for (const row of baselineRows) {
  const baselineBytes = await readFile(join(baselineRoot, row.path));
  check('baseline retained: ' + row.path, baselineBytes.length === row.bytes && sha(baselineBytes) === row.sha256);
  const current = await readFile(join(candidate, row.path));
  const after = { path: row.path, bytes: current.length, sha256: sha(current) };
  afterRows.push(after);
  if (row.bytes !== after.bytes || row.sha256 !== after.sha256) changed.push({ path: row.path, before: row, after });
}
check('exactly the approved three sources changed', JSON.stringify(changed.map(row => row.path).sort()) === JSON.stringify([...targets].sort()));
const oldWorker = await readFile(join(workspace, 'original-three', targets[0]), 'utf8');
const newWorker = await readFile(join(candidate, targets[0]), 'utf8');
const oldLines = oldWorker.split('\n');
const segment = (first, last) => oldLines.slice(first - 1, last).join('\n');
const prefix = oldWorker.slice(0, oldWorker.indexOf('/** HTTP schema is independent'));
check('all pre-parser code byte-identical including Error class and row normalizer', newWorker.startsWith(prefix)
  && newWorker.indexOf('function readWorkerHeader(') === prefix.length);
const headerSignature = 'function readWorkerHeader(payload, endpoint, requestedCodes, now) {';
const holdingsSignature = 'function readWorkerHoldingsItems(payload, wireVersion, nowMs, status, requested) {';
const estimatesSignature = 'function readWorkerEstimateItems(payload, wireVersion, nowMs, status, requested) {';
const tailSignature = 'function finishWorkerEnvelope(payload, wireVersion, status, items) {';
const expectedHeader = headerSignature + '\n' + segment(164, 182) + '\n  return { wireVersion, nowMs, status, requested };\n}';
const expectedHoldings = holdingsSignature + '\n' + segment(185, 193).replace('    items = result.items;', '    return result.items;') + '\n}';
const expectedEstimates = estimatesSignature + '\n' + segment(195, 240).replace('    items = [...rawItems, ...unavailable].map(row => {', '    const items = [...rawItems, ...unavailable].map(row => {') + '\n    return items;\n}';
const expectedTail = tailSignature + '\n' + segment(242, 244) + '\n}';
check('header original statement slice exact', newWorker.includes(expectedHeader));
check('holdings original branch exact except return', newWorker.includes(expectedHoldings));
check('estimate original branch exact except local result and return', newWorker.includes(expectedEstimates));
check('late tail original return exact', newWorker.includes(expectedTail));
const publicSignature = oldLines[162];
check('public signature byte-identical and present once', newWorker.split(publicSignature).length === 2);
const publicStart = newWorker.indexOf(publicSignature);
const publicEnd = newWorker.indexOf('\n}\n', publicStart) + 3;
const publicBody = newWorker.slice(publicStart, publicEnd);
check('public header precedes endpoint dispatch', publicBody.indexOf('readWorkerHeader(') < publicBody.indexOf("endpoint === 'holdings'"));
check('public tail follows endpoint dispatch', publicBody.indexOf('finishWorkerEnvelope(') > publicBody.indexOf('readWorkerEstimateItems('));
check('exactly two fixed endpoint entry declarations', newWorker.includes('export function parseWorkerEstimateEnvelope(payload, { requestedCodes = [], now = Date.now() } = {}) {')
  && newWorker.includes('export function parseWorkerHoldingsEnvelope(payload, { requestedCodes = [], now = Date.now() } = {}) {'));
for (const helper of [expectedHeader, expectedHoldings, expectedEstimates, expectedTail]) {
  check('no new default/catch in helper: ' + helper.slice(0, helper.indexOf(' {')), !helper.slice(0, helper.indexOf(' {')).includes(' = ') && !/\bcatch\b/.test(helper));
}
for (const [path, entry, endpoint] of [
  [targets[1], 'parseWorkerHoldingsEnvelope', 'holdings'],
  [targets[2], 'parseWorkerEstimateEnvelope', 'estimates'],
]) {
  const original = await readFile(join(workspace, 'original-three', path), 'utf8');
  const current = await readFile(join(candidate, path), 'utf8');
  const expected = original.replaceAll('parseWorkerEnvelope', entry).replace("{ endpoint: '" + endpoint + "', requestedCodes:", '{ requestedCodes:');
  check('client contains only exact import/call fixed-entry edits: ' + path, current === expected);
  check('client options.now source count unchanged: ' + path, (original.match(/options\.now/g) || []).length === (current.match(/options\.now/g) || []).length);
}
const diffs = [];
const syntax = [];
for (const path of targets) {
  const baseline = join(workspace, 'original-three', path);
  const target = join(candidate, path);
  const diffArgs = ['diff', '--no-index', '--no-ext-diff', '--text', '--', baseline, target];
  const diff = spawnSync('git', diffArgs, { encoding: 'utf8', windowsHide: true });
  check('diff reports expected differing content: ' + path, diff.status === 1 && !diff.error);
  diffs.push({ path, executable: 'git', args: diffArgs, exitCode: diff.status, stdout: diff.stdout, stderr: diff.stderr });
  const checked = spawnSync(process.execPath, ['--check', target], { encoding: 'utf8', windowsHide: true });
  check('node --check native exit 0: ' + path, checked.status === 0 && !checked.error);
  syntax.push({ path, executable: process.execPath, args: ['--check', target], exitCode: checked.status, stdout: checked.stdout, stderr: checked.stderr });
}
const sum = rows => rows.reduce((total, row) => total + row.bytes, 0);
console.log(JSON.stringify({ stage: 'source-prepared-static-only', workspace, candidateRoot: candidate,
  node: process.version, nodeExecutable: process.execPath, baselineRoot,
  baselineRowsVerified: baselineRows.length, baselineBytes: sum(baselineRows),
  beforeSourceBytesMetadataNote: before.sourceBytes === null
    ? 'prepare.ps1 Measure-Object over OrderedDictionary emitted sourceBytes:null. Original receipt retained; direct sum of all preserved numeric row.bytes certifies the complete byte total here.'
    : null,
  beforeReceiptSha256: sha(await readFile(join(workspace, 'before.json'))),
  originalPostflightSha256: sha(await readFile(join(workspace, 'original-postflight.json'))),
  protocolSha256: sha(await readFile(join(workspace, 'PROTOCOL.md'))),
  afterCount: afterRows.length, afterBytes: sum(afterRows), afterRows, changed,
  checks, diffs, syntax, behavioralQualification: 'NOT_RUN', build: 'NOT_RUN',
  adoption: false, budgetOrVersionChanged: false }, null, 2));

