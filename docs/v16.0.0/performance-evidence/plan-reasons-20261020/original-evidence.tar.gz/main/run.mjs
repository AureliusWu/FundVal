import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const [label, expected, program, ...args] = process.argv.slice(2);
if (!/^[a-z0-9-]+$/.test(label || '')) throw new Error('Invalid label');
const cwd = 'D:/AI项目/FundVal';
const command = program === 'NODE' ? process.execPath : program;
const env = { ...process.env, SOURCE_DATE_EPOCH: '1792046773', FUNDVAL_E2E_PORT: '12443' };
const started = new Date().toISOString();
const result = spawnSync(command, args, { cwd, env, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
const record = { started, ended: new Date().toISOString(), cwd, command, args,
  env: { SOURCE_DATE_EPOCH: env.SOURCE_DATE_EPOCH, FUNDVAL_E2E_PORT: env.FUNDVAL_E2E_PORT },
  status: result.status, signal: result.signal, error: result.error?.message || null,
  stdout: result.stdout || '', stderr: result.stderr || '' };
writeFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), label + '.json'), JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(record.stdout); process.stderr.write(record.stderr);
console.log(JSON.stringify({ label, expected: Number(expected), nativeExit: result.status, matched: result.status === Number(expected) }));
process.exitCode = result.status === Number(expected) ? 0 : 1;
