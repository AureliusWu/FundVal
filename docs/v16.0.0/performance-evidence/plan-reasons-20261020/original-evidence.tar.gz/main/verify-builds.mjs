import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { readFile, readdir, lstat, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const directory = dirname(fileURLToPath(import.meta.url)), root = 'D:/AI项目/FundVal';
const sha = b => createHash('sha256').update(b).digest('hex');
async function inventory(base, selections = ['.']) {
  const rows = [];
  async function visit(path) {
    const full = resolve(base, path), info = await lstat(full);
    assert.equal(info.isSymbolicLink(), false);
    if (info.isDirectory()) for (const name of await readdir(full)) await visit(path === '.' ? name : path + '/' + name);
    else { assert.ok(info.isFile()); const b = await readFile(full); rows.push({ path: path.replaceAll('\\', '/'), bytes: b.length, sha256: sha(b) }); }
  }
  for (const path of selections) await visit(path);
  rows.sort((a, b) => a.path.localeCompare(b.path));
  return { count: rows.length, bytes: rows.reduce((sum, row) => sum + row.bytes, 0), sha256: sha(JSON.stringify(rows)), rows };
}
const selections = ['js', 'css', 'scripts', 'test', 'e2e', '.github', 'data', 'package.json', 'package-lock.json',
  'playwright.config.mjs', 'index.html', 'ocr-import.html', 'quote-bridge.html', 'manifest.json', 'sw.js', '.node-version', '.npmrc'];
const before = await inventory(root, selections);
const api = await import(pathToFileURL(resolve(root, 'scripts/release-fingerprint.mjs')));
const runs = [];
for (let round = 1; round <= 3; round++) {
  const child = spawnSync(process.execPath, [resolve(directory, 'run.mjs'), 'build-confirm-' + round, '0', 'NODE',
    'C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js', 'run', 'build'], { cwd: root, encoding: 'utf8', windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
  assert.equal(child.status, 0, child.stdout + '\n' + child.stderr);
  const site = await inventory(resolve(root, 'site'));
  const critical = await api.fingerprintReleaseDirectory(resolve(root, 'site'));
  const chunks = await api.verifyAppChunkReleaseDirectory(resolve(root, 'site'));
  const budget = api.analyzeAppChunkBudgets(chunks);
  const graph = await api.verifyAppModuleGraphReleaseDirectory(resolve(root, 'site'));
  const ocr = await api.verifyOcrReleaseDirectory(resolve(root, 'site/assets/ocr'));
  runs.push({ round, site, critical, chunks, budget, graph, ocr });
  process.stdout.write(JSON.stringify({ round, files: site.count, siteHash: site.sha256, critical, budget, graph }) + '\n');
}
for (const run of runs.slice(1)) assert.deepEqual(run.site, runs[0].site);
assert.equal(new Set(runs.map(run => run.critical)).size, 1);
const after = await inventory(root, selections); assert.deepEqual(after, before);
const manifest = JSON.parse(await readFile(resolve(root, 'site/js/app-chunks.json'), 'utf8'));
// Keep the complete non-OCR chunk bytes and manifest for independent recounts.
await mkdir(resolve(directory, 'final-app'), { recursive: true });
for (const row of runs[0].site.rows.filter(row => row.path === 'js/app-chunks.json' || row.path === 'js/app-shell.js' || row.path.startsWith('js/chunks/'))) {
  const to = resolve(directory, 'final-app', row.path); await mkdir(dirname(to), { recursive: true });
  await copyFile(resolve(root, 'site', row.path), to);
}
const report = { schema: 1, sourceDateEpoch: 1792046773, sourceBefore: before, sourceAfter: after, runs, manifest,
  baseline: { allGzipBytes: 83084, coldGzipBytes: 44386, rawBytes: 242222,
    critical: '168ae0c7659a187ce175c5d1b519fd7ffe0d5694be4239754b5be5f4a9b976f6',
    scope: 'Verified previous feature window, not a fresh paired latency baseline.' },
  productChanged: true, version: '15.0.2', relativeLatencyQualified: false, ci: 'NOT_RUN', deployed: false,
  ocrEngine: 'NOT_RUN', physicalDevices: 'NOT_RUN', financialLiveReconciliation: 'NOT_RUN' };
await writeFile(resolve(directory, 'build-verification.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
