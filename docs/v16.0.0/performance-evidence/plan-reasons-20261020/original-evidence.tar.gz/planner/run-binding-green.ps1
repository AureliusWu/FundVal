$ErrorActionPreference = 'Continue'
if ((Get-Item -LiteralPath '.').Name -ne 'FundVal') { throw 'Run from FundVal.' }
Copy-Item -LiteralPath 'test/runtime-plan-characterization-v16.test.js' -Destination 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/binding-green.test.js'
node --test --test-reporter=tap test/runtime-plan-characterization-v16.test.js 1> 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/binding-green.stdout.txt' 2> 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/binding-green.stderr.txt'
$bindingExit = $LASTEXITCODE
Get-Content -LiteralPath 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/binding-green.stdout.txt' -Encoding UTF8
Get-Content -LiteralPath 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/binding-green.stderr.txt' -Encoding UTF8
Write-Output ('exit_code=' + $bindingExit)
exit $bindingExit
