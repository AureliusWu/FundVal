$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath 'D:/AI项目/FundVal'
Copy-Item -LiteralPath 'js/runtime/refresh-plan.js' -Destination 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/planner-before.js'
Copy-Item -LiteralPath 'test/refresh-plan-reasons-v16.test.js' -Destination 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/reasons-red.test.js'
node --test --test-reporter=tap test/refresh-plan-reasons-v16.test.js 1> 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/red.stdout.txt' 2> 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/red.stderr.txt'
$reasonExit = $LASTEXITCODE
Get-Content -LiteralPath 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/red.stdout.txt' -Encoding UTF8
Get-Content -LiteralPath 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/red.stderr.txt' -Encoding UTF8
Write-Output ('exit_code=' + $reasonExit)
exit $reasonExit
