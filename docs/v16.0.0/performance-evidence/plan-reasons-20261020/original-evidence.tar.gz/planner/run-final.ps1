$ErrorActionPreference = 'Continue'
if ((Get-Item -LiteralPath '.').Name -ne 'FundVal') { throw 'Run from FundVal.' }
Copy-Item -LiteralPath 'js/runtime/refresh-plan.js' -Destination 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/planner-final.js'
Copy-Item -LiteralPath 'test/refresh-plan-reasons-v16.test.js' -Destination 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/reasons-final.test.js'
Copy-Item -LiteralPath 'test/runtime-plan-characterization-v16.test.js' -Destination 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/characterization-final.test.js'
node --test --test-reporter=tap test/refresh-plan-reasons-v16.test.js test/runtime-plan-characterization-v16.test.js test/refresh-plan-v16.test.js test/refresh-resource-policy-v16.test.js 1> 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/final.stdout.txt' 2> 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/final.stderr.txt'
$reasonExit = $LASTEXITCODE
Get-Content -LiteralPath 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/final.stdout.txt' -Encoding UTF8
Get-Content -LiteralPath 'C:/Users/84046/AppData/Local/Temp/fundval-plan-reasons-081f9ca47a714482885a7335fac36350/final.stderr.txt' -Encoding UTF8
Write-Output ('exit_code=' + $reasonExit)
exit $reasonExit
