import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const TOOLCHAIN = 'C:/Users/84046/AppData/Local/Temp/FundVal-closure-toolchain-20261022-parent';
const PARSER = 'D:/AI项目/FundVal/node_modules/rolldown/dist/utils-index.mjs';
const PARSER_SHA = 'cb4aa8944c762eb83027c98c2aac1970df2ecd3c3f1a7901ab64730061ad0ebc';
const JAR_SHA = '7dfedc111cb06024d3aa132443cd4952da415635c59342d84d96883083df853c';
const CONFIG = 'fixed-simple-es2022-none-local-v1';
const CASES = Object.freeze([
  { id: 'F01', file: 'fixtures/F01-exports.mjs', missing: [] },
  { id: 'F02', file: 'fixtures/F02-imports.mjs', missing: ['./support/dependency.mjs'] },
  { id: 'F03', file: 'fixtures/F03-live.mjs', missing: [] },
  { id: 'F04', file: 'fixtures/F04-arity-error.mjs', missing: [] },
  { id: 'F05', file: 'fixtures/F05-getter-proxy.mjs', missing: [] },
  { id: 'F06', file: 'fixtures/F06-error-order.mjs', missing: ['./support/dependency.mjs'] },
  { id: 'F07', file: 'fixtures/F07-dynamic.mjs', missing: ['./support/dynamic-target.mjs'] },
  { id: 'F08', file: 'fixtures/F08-effects.mjs', missing: ['./support/effect-first.mjs', './support/effect-second.mjs'] },
]);
const SPECIAL = value => ({ special: value });
const errorKeys = ['stack', 'message', 'name', 'code'];
const EXPECTED = Object.freeze({
  F01: { keys: ['marker', 'neverUsedInternally', 'original', 'publicFn', 'sameFn'], lengths: [3, 1, 2],
    values: [6, 8, 'u:v'], same: true, markerKeys: ['token'], marker: 'stable' },
  F02: { keys: ['add', 'exercise', 'forwardedCounter', 'token'], initialForwarded: 4, addLength: 2,
    result: { before: 4, after: 7, alias: 7, namespaceCounter: 7, tokenSame: true,
      defaultResult: 7, defaultSame: true, localCounter: 'private collision',
      errorName: 'RemoteError', errorCode: 'REMOTE', isRemote: true }, forwardedAfter: 7, token: 'dependency' },
  F03: { keys: ['replace', 'state', 'step', 'value'], initial: 0, afterFirst: 2, afterSecond: 0,
    firstResult: 2, secondResult: 0, oldSequence: [2], newSequence: ['replaced', 0],
    replaced: true, replacementSame: true, functionSame: true },
  F04: { keys: ['WireError', 'defaults', 'exposed', 'fail', 'rest'], lengths: [3, 1, 1, 0],
    values: [11, 7, [8, 2]], error: { name: 'WireError', message: 'synthetic invalid row', code: 'ROW_INVALID',
      ownKeys: [...errorKeys, 'hidden'], genuineError: true, boundClass: true, ownPrototype: true,
      hidden: { value: 'opaque', enumerable: false, writable: false, configurable: false },
      stack: { own: true, enumerable: false, writable: true, configurable: true } } },
  F05: { keys: ['callReceiver', 'exercise'], resultKeys: ['first', 'second', 'spread', 'stamp'], first: 1, second: 2,
    stamp: 1200, spreadKeys: ['ignored', 'value', 'optional', 'exactZero', 'Symbol(opaque)'],
    spreadValues: [97, 3, null, SPECIAL('-0'), SPECIAL('NaN')],
    spreadSymbolSame: true,
    spreadDescriptors: Array.from({ length: 5 }, () => ({ data: true, enumerable: true, writable: true, configurable: true })),
    trace: ['get:ignored', 'getter:ignored', 'get:value', 'getter:value:1', 'get:value', 'getter:value:2',
      'ownKeys', 'desc:ignored', 'get:ignored', 'getter:ignored', 'desc:value', 'get:value', 'getter:value:3',
      'desc:optional', 'get:optional', 'desc:exactZero', 'get:exactZero', 'desc:hidden',
      'desc:Symbol(opaque)', 'get:Symbol(opaque)', 'clock:get:Symbol(Symbol.toPrimitive)', 'clock:primitive:number'],
    receiver: { result: 11, missing: SPECIAL('undefined'), trace: ['method:get', 'call:this:true'] } },
  F06: { keys: ['RemoteError', 'validate'], cases: [
    { id: 'success', trace: ['payload:source', 'payload:row', 'clock:number', 'row:value:1', 'row:value:2'],
      result: { source: 'synthetic', value: 6, now: 90 }, resultKeys: ['source', 'value', 'now'], error: null },
    { id: 'missing-row', trace: ['payload:source', 'payload:row'], result: null, resultKeys: null,
      error: { name: 'RemoteError', message: 'row_required', code: 'REMOTE', ownKeys: errorKeys, genuineError: true, boundClass: true, sentinelSame: false } },
    { id: 'null-value', trace: ['payload:source', 'payload:row', 'clock:number', 'row:value:1'], result: null, resultKeys: null,
      error: { name: 'RemoteError', message: 'null_value', code: 'REMOTE', ownKeys: errorKeys, genuineError: true, boundClass: true, sentinelSame: false } },
    { id: 'source-throws', trace: ['payload:source'], result: null, resultKeys: null,
      error: { name: 'SourceSentinel', message: 'source sentinel', code: 'SENTINEL', ownKeys: errorKeys, genuineError: true, boundClass: false, sentinelSame: true } },
    { id: 'clock-throws', trace: ['payload:source', 'payload:row', 'clock:number'], result: null, resultKeys: null,
      error: { name: 'ClockSentinel', message: 'clock sentinel', code: 'SENTINEL', ownKeys: errorKeys, genuineError: true, boundClass: false, sentinelSame: true } },
  ] },
  F07: { keys: ['loadComputed', 'loadNamed'], lengths: [0, 1], targetKeys: ['step', 'token', 'value'],
    namespaceSame: true, objectSame: true, token: 'dynamic', initial: 0, stepResult: 1, liveAfter: 1 },
  F08: { keys: ['readOrder'], order: ['first', 'second'] },
});

const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const atom = value => value === undefined ? SPECIAL('undefined') : typeof value === 'number'
  && Number.isNaN(value) ? SPECIAL('NaN') : Object.is(value, -0) ? SPECIAL('-0') : value;
const keyName = key => typeof key === 'symbol' ? String(key) : key;
const ownKeys = value => Reflect.ownKeys(value).map(keyName);
const writeJson = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const plainError = error => ({ name: error?.name ?? null, message: error?.message ?? String(error), stack: error?.stack ?? null });

async function observe(id, world) {
  const spec = CASES.find(row => row.id === id);
  if (!spec) throw new Error('unknown fixed fixture');
  const counters = { fetch: 0, storage: 0 };
  globalThis.fetch = () => { counters.fetch++; throw new Error('fixture_fetch_denied'); };
  const denied = () => { counters.storage++; throw new Error('fixture_storage_denied'); };
  globalThis.Storage = class Storage { constructor() { denied(); } };
  for (const name of ['localStorage', 'sessionStorage']) Object.defineProperty(globalThis, name,
    { configurable: true, value: { getItem: denied, setItem: denied, removeItem: denied, clear: denied, key: denied } });
  globalThis.__closureFixtureEffects = [];
  const ns = await import(pathToFileURL(path.join(world, spec.file)).href);
  const keys = Object.keys(ns);
  let data;
  if (id === 'F01') {
    data = { keys, lengths: [ns.publicFn.length, ns.original.length, ns.neverUsedInternally.length],
      values: [ns.publicFn(1, 2, 3), ns.original(4), ns.neverUsedInternally('u', 'v')],
      same: ns.publicFn === ns.sameFn, markerKeys: Object.keys(ns.marker), marker: ns.marker.token };
  } else if (id === 'F02') {
    const initialForwarded = ns.forwardedCounter, addLength = ns.add.length, result = ns.exercise();
    data = { keys, initialForwarded, addLength, result, forwardedAfter: ns.forwardedCounter, token: ns.token.token };
  } else if (id === 'F03') {
    const initial = ns.value, old = ns.state, fn = ns.step;
    const firstResult = ns.step(2), afterFirst = ns.value, replacement = ns.replace();
    const secondResult = ns.step(-2), afterSecond = ns.value;
    data = { keys, initial, afterFirst, afterSecond, firstResult, secondResult,
      oldSequence: [...old.sequence], newSequence: [...ns.state.sequence], replaced: old !== ns.state,
      replacementSame: replacement === ns.state, functionSame: fn === ns.step };
  } else if (id === 'F04') {
    let caught;
    try { ns.fail(); } catch (error) { caught = error; }
    if (!caught) throw new Error('fixture expected a genuine error');
    const hidden = Object.getOwnPropertyDescriptor(caught, 'hidden');
    const stack = Object.getOwnPropertyDescriptor(caught, 'stack');
    data = { keys, lengths: [ns.exposed.length, ns.defaults.length, ns.rest.length, ns.fail.length],
      values: [ns.exposed(11), ns.defaults(3, undefined, 2), ns.rest(8, 9, 10)], error: {
        name: caught.name, message: caught.message, code: atom(caught.code), ownKeys: ownKeys(caught),
        genuineError: caught instanceof Error, boundClass: caught instanceof ns.WireError,
        ownPrototype: Object.getPrototypeOf(caught) === ns.WireError.prototype,
        hidden: { value: hidden?.value, enumerable: hidden?.enumerable, writable: hidden?.writable, configurable: hidden?.configurable },
        stack: { own: Boolean(stack), enumerable: stack?.enumerable, writable: stack?.writable, configurable: stack?.configurable } } };
  } else if (id === 'F05') {
    const events = [], opaque = Symbol('opaque'); let reads = 0;
    const target = {};
    Object.defineProperties(target, {
      ignored: { enumerable: true, get() { events.push('getter:ignored'); return 97; } },
      value: { enumerable: true, get() { events.push('getter:value:' + (++reads)); return reads; } },
      optional: { enumerable: true, value: null }, exactZero: { enumerable: true, value: -0 },
      hidden: { enumerable: false, value: 'hidden' },
    });
    Object.defineProperty(target, opaque, { enumerable: true, value: NaN });
    const input = new Proxy(target, {
      get(object, key, receiver) { events.push('get:' + keyName(key)); return Reflect.get(object, key, receiver); },
      ownKeys(object) { events.push('ownKeys'); return Reflect.ownKeys(object); },
      getOwnPropertyDescriptor(object, key) { events.push('desc:' + keyName(key)); return Reflect.getOwnPropertyDescriptor(object, key); },
    });
    const clock = new Proxy({ [Symbol.toPrimitive](hint) { events.push('clock:primitive:' + hint); return 1200; } },
      { get(object, key, receiver) { events.push('clock:get:' + keyName(key)); return Reflect.get(object, key, receiver); } });
    const result = ns.exercise(input, clock);
    const trace = [...events]; // Freeze observed input trace BEFORE output reflection/serialization.
    const receiverTrace = [];
    const receiver = { base: 7, get method() { receiverTrace.push('method:get'); return function(x) {
      receiverTrace.push('call:this:' + (this === receiver)); return this.base + x;
    }; } };
    const receiverResult = ns.callReceiver(receiver), missing = ns.callReceiver({ method: null });
    data = { keys, resultKeys: Object.keys(result), first: atom(result.first), second: atom(result.second), stamp: atom(result.stamp),
      spreadKeys: ownKeys(result.spread), spreadValues: Reflect.ownKeys(result.spread).map(key => atom(result.spread[key])),
      spreadSymbolSame: Reflect.ownKeys(result.spread).find(key => typeof key === 'symbol') === opaque,
      spreadDescriptors: Reflect.ownKeys(result.spread).map(key => { const descriptor = Object.getOwnPropertyDescriptor(result.spread, key);
        return { data: Object.hasOwn(descriptor, 'value'), enumerable: descriptor.enumerable,
          writable: atom(descriptor.writable), configurable: descriptor.configurable }; }), trace,
      receiver: { result: atom(receiverResult), missing: atom(missing), trace: [...receiverTrace] } };
  } else if (id === 'F06') {
    const results = [];
    for (const variant of ['success', 'missing-row', 'null-value', 'source-throws', 'clock-throws']) {
      const trace = []; let reads = 0;
      const sentinel = new TypeError(variant === 'source-throws' ? 'source sentinel' : 'clock sentinel');
      sentinel.name = variant === 'source-throws' ? 'SourceSentinel' : 'ClockSentinel'; sentinel.code = 'SENTINEL';
      const row = { get value() { trace.push('row:value:' + (++reads)); return variant === 'null-value' ? null : 4 + reads; } };
      const payload = { get source() { trace.push('payload:source'); if (variant === 'source-throws') throw sentinel; return 'synthetic'; },
        get row() { trace.push('payload:row'); return variant === 'missing-row' ? null : row; } };
      const clock = { [Symbol.toPrimitive](hint) { trace.push('clock:' + hint); if (variant === 'clock-throws') throw sentinel; return 90; } };
      let result = null, caught = null;
      try { result = ns.validate(payload, clock); } catch (error) { caught = error; }
      const frozenTrace = [...trace]; // Output/error normalization cannot add input trace events.
      results.push({ id: variant, trace: frozenTrace, result, resultKeys: result ? Object.keys(result) : null,
        error: caught ? { name: caught.name, message: caught.message, code: atom(caught.code), ownKeys: ownKeys(caught),
          genuineError: caught instanceof Error, boundClass: caught instanceof ns.RemoteError, sentinelSame: caught === sentinel } : null });
    }
    data = { keys, cases: results };
  } else if (id === 'F07') {
    const a = await ns.loadNamed(), b = await ns.loadComputed('./support/dynamic-target.mjs');
    const initial = a.value, stepResult = a.step();
    data = { keys, lengths: [ns.loadNamed.length, ns.loadComputed.length], targetKeys: Object.keys(a),
      namespaceSame: a === b, objectSame: a.token === b.token, token: a.token.token, initial, stepResult, liveAfter: b.value };
  } else if (id === 'F08') {
    data = { keys, order: ns.readOrder() };
  }
  return { ok: true, id, data, denied: { ...counters } };
}

function surface(parseSync, sourceName, source) {
  const parsed = parseSync(sourceName, source);
  assert.equal(parsed.errors.length, 0, 'AST parse errors');
  const requests = [], exports = [], dynamics = [], locations = [];
  let computed = 0;
  const externalName = node => node.name ?? node.value;
  const bindingNames = node => {
    if (!node) return [];
    if (node.type === 'Identifier') return [node.name];
    if (node.type === 'RestElement') return bindingNames(node.argument);
    if (node.type === 'AssignmentPattern') return bindingNames(node.left);
    if (node.type === 'ArrayPattern') return node.elements.flatMap(bindingNames);
    if (node.type === 'ObjectPattern') return node.properties.flatMap(property =>
      bindingNames(property.type === 'RestElement' ? property.argument : property.value));
    throw new Error('unsupported exported binding pattern: ' + node.type);
  };
  const lineAt = offset => source.slice(0, offset).split('\n').length;
  function request(node, sourceValue, kind, names) {
    requests.push({ source: sourceValue, kind, names });
    locations.push({ target: sourceValue, firstLine: lineAt(node.start), lastLine: lineAt(node.end) });
  }
  function walk(node) {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) { for (const item of node) walk(item); return; }
    if (node.type === 'ImportDeclaration') request(node, node.source.value, 'import', node.specifiers.map(spec =>
      spec.type === 'ImportDefaultSpecifier' ? 'default' : spec.type === 'ImportNamespaceSpecifier' ? '*' : externalName(spec.imported)));
    if (node.type === 'ExportNamedDeclaration') {
      if (node.declaration?.type === 'VariableDeclaration') {
        exports.push(...node.declaration.declarations.flatMap(declaration => bindingNames(declaration.id)));
      } else if (node.declaration) {
        assert.ok(['FunctionDeclaration', 'ClassDeclaration'].includes(node.declaration.type), 'supported exported declaration');
        exports.push(...bindingNames(node.declaration.id));
      }
      exports.push(...node.specifiers.map(spec => externalName(spec.exported)));
      if (node.source) request(node, node.source.value, 'reexport', node.specifiers.map(spec => externalName(spec.local)));
    }
    if (node.type === 'ExportDefaultDeclaration') exports.push('default');
    if (node.type === 'ExportAllDeclaration') throw new Error('export-star is outside fixed fixture domain');
    if (node.type === 'ImportExpression') {
      if (typeof node.source?.value === 'string') {
        dynamics.push(node.source.value);
        locations.push({ target: node.source.value, firstLine: lineAt(node.start), lastLine: lineAt(node.end) });
      } else computed++;
    }
    for (const [key, value] of Object.entries(node)) if (key !== 'parent') walk(value);
  }
  walk(parsed.program);
  // Group same-target binding requests; do not freeze legal local aliases or declaration layout.
  const bindingSets = new Map();
  for (const entry of requests) {
    if (!bindingSets.has(entry.source)) bindingSets.set(entry.source, new Set());
    for (const name of entry.names) bindingSets.get(entry.source).add(name === '*' ? 'namespace:*' : 'name:' + name);
  }
  const contract = { requestOrder: [...new Set(requests.map(entry => entry.source))],
    externalImports: [...bindingSets].map(([source, names]) => ({ source, names: [...names].sort() })),
    exports: [...exports].sort(), dynamicLiterals: [...dynamics].sort(), computedDynamicCount: computed };
  return { contract, locations, requests };
}

function manifestCheck() {
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
  assert.equal(manifest.schema, 1);
  for (const entry of manifest.files) {
    const target = path.resolve(ROOT, entry.path);
    assert.ok(target.startsWith(ROOT + path.sep), 'manifest path escapes prepared workspace');
    const bytes = fs.readFileSync(target);
    assert.equal(bytes.length, entry.bytes, 'frozen byte count: ' + entry.path);
    assert.equal(sha(bytes), entry.sha256, 'frozen SHA: ' + entry.path);
  }
  return manifest;
}

function mainArgs() {
  const options = {};
  for (let i = 2; i < process.argv.length; i += 2) {
    const key = process.argv[i], value = process.argv[i + 1];
    assert.ok(['--java', '--jar', '--run-name'].includes(key) && value && !(key in options), 'strict fixed CLI arguments');
    options[key] = value;
  }
  assert.ok(options['--java'] && options['--jar'], 'explicit absolute --java/--jar required');
  options['--run-name'] ??= 'run-01';
  assert.match(options['--run-name'], /^run-[0-9]{2}$/);
  const base = fs.realpathSync(TOOLCHAIN).toLowerCase() + path.sep;
  for (const key of ['--java', '--jar']) {
    assert.ok(path.isAbsolute(options[key]), key + ' must be absolute');
    options[key] = fs.realpathSync(options[key]);
    assert.ok(options[key].toLowerCase().startsWith(base), key + ' must stay within separate fixed toolchain Temp');
  }
  return options;
}

async function main() {
  const manifest = manifestCheck(), options = mainArgs();
  assert.equal(sha(fs.readFileSync(PARSER)), PARSER_SHA, 'pinned existing parser bytes');
  assert.equal(sha(fs.readFileSync(options['--jar'])), JAR_SHA, 'pinned shaded JAR actual SHA');
  const runDir = path.join(ROOT, options['--run-name']);
  fs.mkdirSync(runDir); // Exclusive run directory. Never overwrite/retry an old run.
  fs.mkdirSync(path.join(runDir, 'native'));
  const summary = { schema: 1, configuration: CONFIG, status: 'RUNNING',
    manifestSha256: sha(fs.readFileSync(path.join(ROOT, 'manifest.json'))),
    java: options['--java'], jar: options['--jar'], jarSha256: JAR_SHA,
    sourceFiles: manifest.files, cases: CASES.map(row => ({ id: row.id, status: 'NOT_RUN' })),
    native: [], pendingNativeStderrReview: [], stop: null, scope: 'fixed fixture prerequisite only; no product transform/build/size/adoption' };
  const env = { ...process.env };
  const cleared = ['NODE_OPTIONS', 'JAVA_TOOL_OPTIONS', 'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS'];
  for (const key of cleared) delete env[key];
  function native(label, command, args, timeout = 30_000) {
    const startedAt = new Date().toISOString();
    const result = spawnSync(command, args, { cwd: ROOT, env, shell: false, encoding: null, timeout, maxBuffer: 16 * 1024 * 1024 });
    const stdout = result.stdout ?? Buffer.alloc(0), stderr = result.stderr ?? Buffer.alloc(0);
    fs.writeFileSync(path.join(runDir, 'native', label + '.stdout'), stdout, { flag: 'wx' });
    fs.writeFileSync(path.join(runDir, 'native', label + '.stderr'), stderr, { flag: 'wx' });
    const receipt = { label, command, args, cwd: ROOT, startedAt, finishedAt: new Date().toISOString(),
      clearedEnvironmentKeys: cleared, nativeExit: result.status, signal: result.signal,
      error: result.error ? plainError(result.error) : null,
      stdout: { bytes: stdout.length, sha256: sha(stdout) }, stderr: { bytes: stderr.length, sha256: sha(stderr) } };
    writeJson(path.join(runDir, 'native', label + '.receipt.json'), receipt);
    summary.native.push(receipt);
    return { ...receipt, out: stdout.toString('utf8'), err: stderr.toString('utf8') };
  }
  const stop = (kind, message) => { const error = new Error(message); error.probeKind = kind; throw error; };
  try {
    const version = native('java-version', options['--java'], ['--version']);
    if (version.nativeExit !== 0 || version.error) stop('SETUP_OR_DRIVER_FAILURE', 'Java version invocation failed');
    const major = /^(?:openjdk|java)(?: version)?\s+"?(\d+)/m.exec(version.out + '\n' + version.err)?.[1];
    if (major !== '21') stop('SETUP_OR_DRIVER_FAILURE', 'fixed runtime must be JDK21');
    summary.javaVersionOutput = version.out + version.err;
    const { parseSync } = await import(pathToFileURL(PARSER).href);
    const original = path.join(runDir, 'original'), transformed = path.join(runDir, 'transformed');
    fs.mkdirSync(original); fs.mkdirSync(transformed);
    for (const entry of manifest.files.filter(row => row.path.startsWith('fixtures/'))) {
      for (const world of entry.path.includes('/support/') ? [original, transformed] : [original]) {
        const target = path.join(world, entry.path); fs.mkdirSync(path.dirname(target), { recursive: true });
        fs.writeFileSync(target, fs.readFileSync(path.join(ROOT, entry.path)), { flag: 'wx' });
      }
    }
    for (const spec of CASES) {
      const row = summary.cases.find(item => item.id === spec.id); row.status = 'RUNNING';
      console.log(JSON.stringify({ progress: spec.id, stage: 'original-sanity' }));
      const before = native(spec.id + '-original', process.execPath, [fileURLToPath(import.meta.url), '--observe', spec.id, original], 10_000);
      if (before.nativeExit !== 0 || before.error || before.err.length) stop('BASELINE_SETUP_FAILURE', spec.id + ' original runtime failed');
      let old;
      try { old = JSON.parse(before.out); assert.equal(old.ok, true); assert.deepEqual(old.denied, { fetch: 0, storage: 0 }); assert.deepEqual(old.data, EXPECTED[spec.id]); }
      catch (error) { row.baselineFailure = plainError(error); stop('BASELINE_SETUP_FAILURE', spec.id + ' fixed original sanity mismatch'); }
      row.original = old;
      const input = path.join(ROOT, spec.file), source = fs.readFileSync(input, 'utf8');
      const oldSurface = surface(parseSync, spec.file, source);
      row.originalSurface = oldSurface;
      const compile = native(spec.id + '-java', options['--java'], ['--class-path', options['--jar'], path.join(ROOT, 'DRIVER.java'), spec.file, input], 60_000);
      let compiled;
      try { compiled = JSON.parse(compile.out); }
      catch (error) { row.driverParseFailure = plainError(error); stop('SETUP_OR_DRIVER_FAILURE', spec.id + ' no valid driver JSON'); }
      row.compiler = compiled;
      if (compiled.status === 'SETUP_OR_DRIVER_FAILURE' || compile.nativeExit === 2 || compile.error) stop('SETUP_OR_DRIVER_FAILURE', spec.id + ' driver exception/setup failure');
      if (compiled.configuration !== CONFIG || compiled.sourceName !== spec.file) stop('SETUP_OR_DRIVER_FAILURE', 'driver identity mismatch');
      if (!compiled.success || compile.nativeExit !== 0) stop('COMPILER_REJECTION', spec.id + ' compiler rejected single ESM input');
      row.warningClassification = compiled.diagnostics.map(diagnostic => {
        const target = spec.missing.find(value => diagnostic.description === 'Failed to load module "' + value + '"');
        const validLocation = oldSurface.locations.some(location => location.target === target
          && diagnostic.line >= location.firstLine && diagnostic.line <= location.lastLine);
        const known = diagnostic.level === 'WARNING' && diagnostic.key === 'JSC_JS_MODULE_LOAD_WARNING'
          && diagnostic.sourceName === spec.file && Boolean(target) && validLocation;
        return { ...diagnostic, classification: known ? 'KNOWN_OMITTED_REAL_FIXTURE_TARGET' : 'UNEXPECTED_DIAGNOSTIC' };
      });
      if (row.warningClassification.some(item => item.classification !== 'KNOWN_OMITTED_REAL_FIXTURE_TARGET')) {
        stop('UNEXPECTED_COMPILER_DIAGNOSTIC', spec.id + ' unexpected compiler diagnostic; none suppressed');
      }
      // Source-launch javac notes are tool/setup metadata, never a JS semantic RED.
      row.nativeStderrClassification = compile.err.length ? (compiled.diagnostics.length
        ? 'COMPILER_AND_POSSIBLE_SOURCE_LAUNCH_STDERR_PENDING_MANUAL_REVIEW' : /^Note: .*(?:deprecated API|deprecation).*(?:\r?\nNote: .*)*\r?\n?$/s.test(compile.err)
          ? 'JAVA_SOURCE_LAUNCH_DEPRECATION_NOTES_RETAINED' : 'UNCLASSIFIED_JAVA_TOOL_STDERR') : 'EMPTY';
      if (row.nativeStderrClassification === 'UNCLASSIFIED_JAVA_TOOL_STDERR') stop('SETUP_OR_TOOL_DIAGNOSTIC_STOP', spec.id + ' non-JS tool stderr retained for review');
      if (row.nativeStderrClassification.endsWith('PENDING_MANUAL_REVIEW')) summary.pendingNativeStderrReview.push(spec.id + '-java');
      let newSurface;
      try { newSurface = surface(parseSync, spec.file, compiled.compiledCode); assert.deepEqual(newSurface.contract, oldSurface.contract); }
      catch (error) { row.surfaceFailure = plainError(error); stop('SURFACE_CONTRACT_FAILURE', spec.id + ' external ESM surface changed or became invalid'); }
      row.transformedSurface = newSurface;
      const output = path.join(transformed, spec.file);
      fs.mkdirSync(path.dirname(output), { recursive: true }); fs.writeFileSync(output, compiled.compiledCode, { flag: 'wx' });
      const after = native(spec.id + '-transformed', process.execPath, [fileURLToPath(import.meta.url), '--observe', spec.id, transformed], 10_000);
      if (after.nativeExit !== 0 || after.error || after.err.length) stop('TRANSFORMED_RUNTIME_FAILURE', spec.id + ' transformed runtime failed');
      try {
        const actual = JSON.parse(after.out); row.transformed = actual;
        assert.equal(actual.ok, true); assert.deepEqual(actual.denied, { fetch: 0, storage: 0 });
        assert.deepEqual(actual.data, EXPECTED[spec.id]); assert.deepEqual(actual, old);
      } catch (error) { row.behaviorFailure = plainError(error); stop('BEHAVIOR_CONTRACT_FAILURE', spec.id + ' complete fixed observation differs'); }
      row.status = 'PASS';
      writeJson(path.join(runDir, spec.id + '.json'), row);
    }
    summary.status = summary.pendingNativeStderrReview.length ? 'FIXTURE_COMPARISONS_COMPLETE_NATIVE_STDERR_REVIEW_REQUIRED' : 'FIXTURE_PREREQUISITE_PASS_ONLY';
    if (summary.pendingNativeStderrReview.length) process.exitCode = 2; // Incomplete review, not a semantic RED.
  } catch (error) {
    const active = summary.cases.find(row => row.status === 'RUNNING');
    if (active) active.status = error.probeKind ?? 'SETUP_OR_CONTROLLER_FAILURE';
    summary.status = error.probeKind ?? 'SETUP_OR_CONTROLLER_FAILURE'; summary.stop = plainError(error);
    process.exitCode = summary.status.startsWith('BASELINE') || summary.status.startsWith('SETUP') ? 2 : 1;
  } finally {
    try {
      assert.equal(sha(fs.readFileSync(path.join(ROOT, 'manifest.json'))), summary.manifestSha256, 'initial manifest bytes remain frozen');
      manifestCheck(); summary.frozenSourcesUnchanged = true;
    }
    catch (error) { summary.frozenSourcesUnchanged = false; summary.sourceIntegrityFailure = plainError(error); summary.status = 'SOURCE_INTEGRITY_FAILURE'; process.exitCode = 2; }
    writeJson(path.join(runDir, 'summary.json'), summary);
    console.log(JSON.stringify({ status: summary.status, runDir, cases: summary.cases.map(({ id, status }) => ({ id, status })), frozenSourcesUnchanged: summary.frozenSourcesUnchanged }));
  }
}

if (process.argv[2] === '--observe') {
  const [, , , id, world, ...rest] = process.argv;
  assert.equal(rest.length, 0); assert.ok(path.isAbsolute(world));
  try { console.log(JSON.stringify(await observe(id, world))); }
  catch (error) { console.error(error.stack ?? error); console.log(JSON.stringify({ ok: false, id, error: plainError(error) })); process.exitCode = 1; }
} else {
  try { await main(); }
  catch (error) { console.error(error.stack ?? error); process.exitCode = 2; }
}
