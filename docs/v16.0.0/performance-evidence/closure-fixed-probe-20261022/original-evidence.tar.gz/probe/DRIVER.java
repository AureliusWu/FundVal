import com.google.javascript.jscomp.AbstractCommandLineRunner;
import com.google.javascript.jscomp.CompilationLevel;
import com.google.javascript.jscomp.Compiler;
import com.google.javascript.jscomp.CompilerOptions;
import com.google.javascript.jscomp.DependencyOptions;
import com.google.javascript.jscomp.JSError;
import com.google.javascript.jscomp.PropertyRenamingPolicy;
import com.google.javascript.jscomp.Result;
import com.google.javascript.jscomp.SourceFile;
import com.google.javascript.jscomp.VariableRenamingPolicy;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** One immutable configuration and one input, never a target/module graph. */
public final class DRIVER {
  private static CompilerOptions fixedOptions() {
    CompilerOptions options = new CompilerOptions();
    CompilationLevel.SIMPLE_OPTIMIZATIONS.setOptionsForCompilationLevel(options);
    options.setLanguageIn(CompilerOptions.LanguageMode.ECMASCRIPT_2022);
    options.setLanguageOut(CompilerOptions.LanguageMode.ECMASCRIPT_2022);
    options.setEs6ModuleTranspilation(CompilerOptions.Es6ModuleTranspilation.NONE);
    options.setEnableModuleRewriting(false);
    options.setAllowDynamicImport(true);
    options.setDependencyOptions(DependencyOptions.none());
    options.setRenamingPolicy(VariableRenamingPolicy.LOCAL, PropertyRenamingPolicy.OFF);
    options.setAssumeGettersArePure(false);
    options.setAssumePropertiesAreStaticallyAnalyzable(false);
    options.setOptimizeCalls(false);
    options.setRewritePolyfills(false);
    options.setPreventLibraryInjection(true);
    return options;
  }

  private static Map<String, Object> diagnostic(JSError error, String level) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("level", level);
    row.put("defaultLevel", error.getDefaultLevel().toString());
    row.put("key", error.getType().key);
    row.put("description", error.getDescription());
    row.put("sourceName", error.getSourceName());
    row.put("line", error.getLineno());
    row.put("column", error.getCharno());
    return row;
  }

  private static String json(Object value) {
    if (value == null) return "null";
    if (value instanceof String text) {
      StringBuilder out = new StringBuilder("\"");
      for (int i = 0; i < text.length(); i++) {
        char c = text.charAt(i);
        switch (c) {
          case '"' -> out.append("\\\"");
          case '\\' -> out.append("\\\\");
          case '\n' -> out.append("\\n");
          case '\r' -> out.append("\\r");
          case '\t' -> out.append("\\t");
          case '\b' -> out.append("\\b");
          case '\f' -> out.append("\\f");
          default -> {
            if (c < 32 || Character.isSurrogate(c)) {
              out.append(String.format("\\u%04x", (int) c));
            } else {
              out.append(c);
            }
          }
        }
      }
      return out.append('"').toString();
    }
    if (value instanceof Boolean || value instanceof Number) return value.toString();
    if (value instanceof Map<?, ?> map) {
      List<String> entries = new ArrayList<>();
      for (Map.Entry<?, ?> entry : map.entrySet()) {
        entries.add(json(entry.getKey().toString()) + ":" + json(entry.getValue()));
      }
      return "{" + String.join(",", entries) + "}";
    }
    if (value instanceof Iterable<?> list) {
      List<String> entries = new ArrayList<>();
      for (Object item : list) entries.add(json(item));
      return "[" + String.join(",", entries) + "]";
    }
    throw new IllegalArgumentException("unsupported receipt value " + value.getClass().getName());
  }

  public static void main(String[] args) {
    Map<String, Object> receipt = new LinkedHashMap<>();
    receipt.put("schema", 1);
    receipt.put("configuration", "fixed-simple-es2022-none-local-v1");
    receipt.put("javaVersion", System.getProperty("java.version"));
    receipt.put("javaVendor", System.getProperty("java.vendor"));
    try {
      if (args.length != 2 || !args[0].matches("fixtures/F0[1-8]-[a-z-]+\\.mjs")) {
        throw new IllegalArgumentException("expected one original fixture sourceName and absolute input path");
      }
      Path input = Path.of(args[1]);
      if (!input.isAbsolute()) throw new IllegalArgumentException("input must be absolute");
      String source = Files.readString(input, StandardCharsets.UTF_8);
      receipt.put("sourceName", args[0]);
      receipt.put("inputPath", input.toRealPath().toString());
      Compiler compiler = new Compiler(System.err);
      Result result = compiler.compile(
          AbstractCommandLineRunner.getBuiltinExterns(CompilerOptions.Environment.BROWSER),
          List.of(SourceFile.fromCode(args[0], source)),
          fixedOptions());
      List<Object> diagnostics = new ArrayList<>();
      for (JSError error : result.errors) diagnostics.add(diagnostic(error, "ERROR"));
      for (JSError warning : result.warnings) diagnostics.add(diagnostic(warning, "WARNING"));
      receipt.put("status", result.success ? "COMPILED" : "COMPILER_REJECTION");
      receipt.put("success", result.success);
      receipt.put("diagnostics", diagnostics);
      receipt.put("compiledCode", result.success ? compiler.toSource() : null);
      System.out.println(json(receipt));
      if (!result.success) System.exit(1);
    } catch (Throwable error) {
      receipt.put("status", "SETUP_OR_DRIVER_FAILURE");
      receipt.put("success", false);
      receipt.put("exceptionClass", error.getClass().getName());
      receipt.put("exceptionMessage", error.getMessage());
      error.printStackTrace(System.err);
      System.out.println(json(receipt));
      System.exit(2);
    }
  }
}
