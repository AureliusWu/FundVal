class WireError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'WireError';
    this.code = code;
    Object.defineProperty(this, 'hidden', { value: 'opaque', enumerable: false });
  }
}
function exposed(a, b, c) { return a; }
function defaults(a, b = 2, c) { return a + b + (c ?? 0); }
function rest(a, ...tail) { return [a, tail.length]; }
function fail() { throw new WireError('ROW_INVALID', 'synthetic invalid row'); }
export { WireError, exposed, defaults, rest, fail };
