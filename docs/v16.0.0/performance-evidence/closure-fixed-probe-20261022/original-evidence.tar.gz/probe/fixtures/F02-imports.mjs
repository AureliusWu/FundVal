import realDefault, { counter as readCounter, bump as increment, token as importedToken, RemoteError as BoundError } from './support/dependency.mjs';
import * as remote from './support/dependency.mjs';
const counter = 'private collision';
function exercise() {
  const before = readCounter;
  const after = increment();
  const error = new BoundError('bound');
  return { before, after, alias: readCounter, namespaceCounter: remote.counter,
    tokenSame: remote.token === importedToken, defaultResult: realDefault(2, 5),
    defaultSame: realDefault === remote.default, localCounter: counter,
    errorName: error.name, errorCode: error.code, isRemote: error instanceof remote.RemoteError };
}
export { exercise, importedToken as token, realDefault as add };
export { counter as forwardedCounter } from './support/dependency.mjs';
