const marker = Object.freeze({ token: 'stable' });
function original(a, b, c) { return a + b + c; }
function publicFn(x) { return x * 2; }
function unusedStandalone(q, r) { return q + ':' + r; }
export { original as publicFn, original as sameFn, publicFn as original, marker,
  unusedStandalone as neverUsedInternally };
