let counter = 4;
const token = Object.freeze({ token: 'dependency' });
function bump() { counter += 3; return counter; }
function add(a, b) { return a + b; }
class RemoteError extends Error {
  constructor(message) { super(message); this.name = 'RemoteError'; this.code = 'REMOTE'; }
}
export default add;
export { counter, token, bump, RemoteError };
