globalThis.__closureFixtureEffects.push('first');
export const effectName = 'first';
