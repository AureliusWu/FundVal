globalThis.__closureFixtureEffects.push('second');
export const effectName = 'second';
