let value = 0;
const token = Object.freeze({ token: 'dynamic' });
function step() { return ++value; }
export { value, token, step };
