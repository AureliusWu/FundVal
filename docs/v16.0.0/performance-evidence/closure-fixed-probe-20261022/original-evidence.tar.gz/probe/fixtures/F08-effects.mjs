import './support/effect-first.mjs';
import './support/effect-second.mjs';
function readOrder() { return globalThis.__closureFixtureEffects.slice(); }
export { readOrder };
