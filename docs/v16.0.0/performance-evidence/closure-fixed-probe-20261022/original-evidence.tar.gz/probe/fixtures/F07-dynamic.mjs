function loadNamed() { return import('./support/dynamic-target.mjs'); }
function loadComputed(path) { return import(path); }
export { loadNamed, loadComputed };
