let value = 0;
let state = { sequence: [] };
function step(amount) { value += amount; state.sequence.push(value); return value; }
function replace() { state = { sequence: ['replaced'] }; return state; }
export { value, state, step, replace };
