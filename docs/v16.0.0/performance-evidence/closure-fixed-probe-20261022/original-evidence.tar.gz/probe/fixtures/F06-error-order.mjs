import { RemoteError } from './support/dependency.mjs';
function validate(payload, clock) {
  const source = payload.source;
  const row = payload.row;
  if (!row || typeof row !== 'object') throw new RemoteError('row_required');
  const now = Number(clock);
  if (row.value === null) throw new RemoteError('null_value');
  return { source, value: row.value, now };
}
export { validate, RemoteError };
