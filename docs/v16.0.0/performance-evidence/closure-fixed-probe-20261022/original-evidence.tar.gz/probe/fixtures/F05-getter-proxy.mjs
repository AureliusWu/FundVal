function exercise(input, clock) {
  const ignored = input.ignored;
  const first = input.value;
  const second = input.value;
  const spread = { ...input };
  const stamp = Number(clock);
  return { first, second, spread, stamp };
}
function callReceiver(receiver) { return receiver.method?.(4); }
export { exercise, callReceiver };
