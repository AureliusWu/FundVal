# 单次固定 Closure hybrid 前置工具验证

2026-10-22。用户已明确允许新的JS压缩策略独立验证、合格后采用；此处只建立隔离Temp工具，不修改系统Java/PATH/JAVA_HOME、项目依赖/配置/业务或发布。后续固定保守配置与fail-fast fixtures由独立probe协议约束，不是ADVANCED/flag sweep。

固定官方二进制（先前只读metadata审查已核来源；下载后实际复算，不把metadata当已下载证据）：

1. Temurin `jdk-21.0.12.1+1` Windows x64 JDK ZIP，205073461 B，SHA256 `f9d6e191ab098c0d416e7d588a24420a8621cd2f4720dab2459b8b7b2d2d8b4e`；URL `https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.12.1%2B1/OpenJDK21U-jdk_x64_windows_hotspot_21.0.12.1_1.zip`。官方release metadata见早期Java报告。只在新Temp/jdk目录解压，先tar-list检查成员路径；不调用MSI或系统包管理器。
2. Closure `v20261020` shaded JAR，14997454 B，SHA256 `7dfedc111cb06024d3aa132443cd4952da415635c59342d84d96883083df853c`；URL `https://repo.maven.apache.org/maven2/com/google/javascript/closure-compiler/v20261020/closure-compiler-v20261020.jar`。不使用旧v20261007缺失Maven坐标，不用latest。

单次下载各自独占文件，HTTP/字节上限/大小/SHA失败保留原件并停止，不自动重试。通过才解压并用绝对路径运行java/javac `-version`和Closure `--version`，每项原生stdout/stderr/exit单独保存。版本证明只代表工具可执行，不是新编译策略行为/包体/性能合格。JDK/JAR二进制不提交仓库；包许可/notice留在Temp分发原件中。

冻结当前accuracy修复后的273完整源、127site、68明确安装、Git HEAD/branch/index前后检查。固定原预算/ES2022/五加载组、所有有效性/兼容功能不变。首次fixture编译失败、warning或surface/行为不符均如实STOP，不改期望或扫参数绕过。
