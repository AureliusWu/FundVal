# 下载超时后的独立断点协议

首轮setup实际TimeoutError/native1，180秒后保留109600832 B partial ZIP；下载/JDK前提失败，不是编译策略或产品失败。原PLAN/setup/RUN_PLAN/RESULT、半成品和全部native原件不覆盖。

只改变工具传输：对同一个固定官方JDK URL单独请求`Range: bytes=109600832-`（实际文件大小先检查一致），必须HTTP206且Content-Range起点/终点/完整大小完全匹配。将原partial独占复制到新文件再追加，不修改原partial；单次600秒、无自动重试/来源切换。完整205073461 B/SHA固定f9d6e191...校验后才可解压执行。首段prefix SHA前后同。若服务端200/416、范围不符、大小/SHA或native失败则停止，不转为无条件继续。

JAR原首轮尚未请求；通过JDK校验才发起同一固定Maven JAR的首次请求（单次120秒），固定14997454 B/SHA7dfedc11...不变。只是工具传输协议修正，不修改后续SIMPLE配置、fixtures、产品规则或所有预算，不提升为压缩合格。

项目当前273完整source/127site/68安装及Git沿用首轮冻结控制重新前后验证。二进制留Temp，不提交仓库。
