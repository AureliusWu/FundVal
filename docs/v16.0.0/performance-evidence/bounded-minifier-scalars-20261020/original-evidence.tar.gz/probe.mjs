import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile, mkdir, writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {dirname, relative, resolve} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
import vm from 'node:vm';

const root = 'D:/AI项目/FundVal';
const temp = dirname(fileURLToPath(import.meta.url));
const require = createRequire(pathToFileURL(resolve(root, 'package.json')));
const {parseSync} = await import(pathToFileURL(require.resolve('rolldown/utils')));
const {build: viteBuild} = await import(pathToFileURL(require.resolve('vite')));
const {verifyAppModuleGraph} = await import(pathToFileURL(resolve(root, 'scripts/app-module-graph.mjs')));
const hash = value => createHash('sha256').update(value).digest('hex');
const read = async path => (await readFile(resolve(root, path), 'utf8')).replaceAll('\r\n', '\n');
const paths = ['js/runtime/quote-contract.js', 'js/runtime/holding-set-contract.js', 'js/runtime/quote-presentation.js',
  'js/runtime/refresh-generation.js', 'js/runtime/worker-contract.js', 'js/holdings-estimate.js'];
const originals = new Map(await Promise.all(paths.map(async path => [path, await read(path)])));
const sourceIdentity = () => Promise.all(paths.map(async path => ({path, sha256: hash(await read(path))})));
const before = await sourceIdentity();
const head = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(head, '170fd3eadc6da02750882f8a542904ee2358d0d9');
const buildSource = await read('scripts/build-site.mjs');
const buildAst = parseSync('build-site.mjs', buildSource).program;
const names = new Set(['APP_SHELL_FILENAME', 'APP_CHUNK_FILENAME', 'OCR_BUNDLE_REFERENCE', 'COLD_LAZY_MODULE',
  'STARTUP_MODULES', 'POST_INTEGRITY_MODULES', 'BUSINESS_MODULES', 'APP_CHUNK_GROUPS']);
const selected = buildAst.body.filter(node => node.type === 'VariableDeclaration' && node.declarations.some(d => names.has(d.id.name))
  || node.type === 'FunctionDeclaration' && ['modulePath', 'collectStaticChunkGraph', 'assertStartupPhaseIsolation'].includes(node.id.name));
const buildFunction = buildAst.body.find(node => node.type === 'FunctionDeclaration' && node.id.name === 'buildAppShell');
const call = buildFunction.body.body.find(node => node.type === 'VariableDeclaration' && node.declarations[0].id.name === 'result')
  .declarations[0].init.argument;
assert.equal(call.callee.name, 'viteBuild');
const recipe = vm.runInNewContext(`${selected.map(node => buildSource.slice(node.start, node.end)).join('\n')}; ({
  options: ${buildSource.slice(call.arguments[0].start, call.arguments[0].end)},
  modulePath, collectStaticChunkGraph, assertStartupPhaseIsolation,
})`, {root, relative, resolve, Set, Map});
assert.equal(recipe.options.build.write, false);
assert.equal(recipe.options.build.minify, 'oxc');
assert.equal(recipe.options.build.target, 'es2022');
assert.equal(recipe.options.build.rolldownOptions.output.codeSplitting.groups.length, 5);

function replaceOnce(source, from, to) {
  assert.equal(source.split(from).length, 2, `Expected exactly one source fragment: ${from}`);
  return source.replace(from, to);
}
function functionNode(path, source, name) {
  const parsed = parseSync(path, source);
  assert.equal(parsed.errors.length, 0);
  const matches = parsed.program.body.map(node => node.type === 'ExportNamedDeclaration' ? node.declaration : node)
    .filter(node => node?.type === 'FunctionDeclaration' && node.id.name === name);
  assert.equal(matches.length, 1, `${path}:${name}`);
  return matches[0];
}
function replaceFunction(path, source, name, replacement) {
  const node = functionNode(path, source, name);
  return source.slice(0, node.start) + replacement + source.slice(node.end);
}
const clockCode = `export function clockNormalized(value) {
  const number = value instanceof Date ? value.getTime() : Number(value);
  return Number.isFinite(number) ? number : Date.now();
}`;
const hmsCode = `export function hmsOutOfRange(parts, start) {
  return Number(parts[start]) > 23 || Number(parts[start + 1]) > 59 || Number(parts[start + 2] || 0) > 59;
}`;
function transform({clock = false, hms = false} = {}) {
  const files = new Map(originals);
  if (clock) {
    files.set('js/runtime/quote-contract.js', replaceOnce(files.get('js/runtime/quote-contract.js'),
      "  const nowNumber = now instanceof Date ? now.getTime() : Number(now);\n  const nowMs = Number.isFinite(nowNumber) ? nowNumber : Date.now();",
      '  const nowMs = clockNormalized(now);') + `\n${clockCode}\n`);
    let path = 'js/runtime/holding-set-contract.js';
    files.set(path, replaceFunction(path, replaceOnce(files.get(path),
      "import { normalizeQuoteDate, nullableNumber } from './quote-contract.js';",
      "import { normalizeQuoteDate, nullableNumber, clockNormalized } from './quote-contract.js';"),
      'contractClock', 'function contractClock(now) { return clockNormalized(now); }'));
    path = 'js/runtime/quote-presentation.js';
    files.set(path, replaceFunction(path, replaceOnce(files.get(path),
      '  normalizeConfidence,', '  clockNormalized as finiteNow,\n  normalizeConfidence,'), 'finiteNow', ''));
    path = 'js/runtime/refresh-generation.js';
    files.set(path, `import { clockNormalized as clockValue } from './quote-contract.js';\n`
      + replaceFunction(path, files.get(path), 'clockValue', ''));
  }
  if (hms) {
    let path = 'js/runtime/quote-contract.js';
    files.set(path, replaceOnce(files.get(path),
      '|| Number(parts[4]) > 23 || Number(parts[5]) > 59 || Number(parts[6] || 0) > 59',
      '|| hmsOutOfRange(parts, 4)') + `\n${hmsCode}\n`);
    path = 'js/runtime/worker-contract.js';
    files.set(path, replaceOnce(replaceOnce(files.get(path),
      "import { normalizeQuoteDate } from './quote-contract.js';",
      "import { normalizeQuoteDate, hmsOutOfRange } from './quote-contract.js';"),
      '|| Number(match[1]) > 23 || Number(match[2]) > 59 || Number(match[3] || 0) > 59',
      '|| hmsOutOfRange(match, 1)'));
    path = 'js/holdings-estimate.js';
    files.set(path, replaceOnce(replaceOnce(files.get(path),
      'import { normalizeQuoteDate, nullableNumber, parseQuoteTimestamp }',
      'import { normalizeQuoteDate, nullableNumber, parseQuoteTimestamp, hmsOutOfRange }'),
      '|| Number(match[4]) > 23 || Number(match[5]) > 59 || Number(match[6] || 0) > 59',
      '|| hmsOutOfRange(match, 4)'));
  }
  for (const [path, source] of files) assert.equal(parseSync(path, source).errors.length, 0, path);
  return files;
}

// Trace characterization is deliberately a pure primitive-slice proof, not a full app/API proof.
function observe(code, factory) {
  const trace = [], sentinel = {sentinel:true};
  const NumberProxy = new Proxy(Number, {apply(target,thisArg,values){trace.push('Number:call');return Reflect.apply(target,thisArg,values);},
    get(target,key,receiver){trace.push('Number:get:'+String(key));return Reflect.get(target,key,receiver);}});
  const DateProxy = new Proxy(Date,{get(target,key,receiver){trace.push('Date:get:'+String(key));
    if(key==='now')return ()=>{trace.push('Date.now:call');return 1792000000000;};return Reflect.get(target,key,receiver);}});
  const context = vm.createContext({Number:NumberProxy,Date:DateProxy,input:factory(trace,sentinel)});
  try {return {trace,result:vm.runInContext(code,context)(context.input)};}
  catch(error){return {trace,error:error===sentinel?'sentinel':{name:error.name,message:error.message}};}
}
const clockImpl = clockCode.replace('export ', '');
const hmsImpl = hmsCode.replace('export ', '');
const clocks = [undefined,null,true,false,0,-0,1,NaN,Infinity,-Infinity,'',' ','0',' 12 ','x','NaN','Infinity','0x10',1n,Symbol('x')].map(value=>()=>value);
clocks.push(()=>new Date(123),()=>new Date(NaN));
for(const result of [123,NaN,Infinity,'123'])clocks.push(trace=>({get [Symbol.toPrimitive](){trace.push('input:get:toPrimitive');return hint=>{trace.push('input:call:'+hint);return result;};}}));
clocks.push((trace,sentinel)=>({get [Symbol.toPrimitive](){trace.push('input:get:toPrimitive');throw sentinel;}}));
clocks.push((trace,sentinel)=>({[Symbol.toPrimitive](){trace.push('input:call:toPrimitive');throw sentinel;}}));
clocks.push((trace,sentinel)=>Object.defineProperty(new Date(123),'getTime',{get(){trace.push('input:get:getTime');throw sentinel;}}));
clocks.push(trace=>Object.defineProperty(new Date(123),'getTime',{get(){trace.push('input:get:getTime');return ()=>{trace.push('input:call:getTime');return 456;};}}));
clocks.push(()=>Object.create(null));
let clockCases = 0;
const traceExamples = [];
const traceComparisons = [];
for(const [path,name] of [['js/runtime/holding-set-contract.js','contractClock'],['js/runtime/quote-presentation.js','finiteNow'],['js/runtime/refresh-generation.js','clockValue']]) {
  const source = originals.get(path), node = functionNode(path, source, name);
  const old = `(${source.slice(node.start,node.end)})`;
  const candidate = `${clockImpl}; (${name==='contractClock'?'function contractClock(now) { return clockNormalized(now); }':'clockNormalized'})`;
  for(const factory of clocks){const a=observe(old,factory),b=observe(candidate,factory);assert.deepEqual(a,b,path);clockCases++;traceComparisons.push({kind:'clock',path,case:clockCases,old:a,candidate:b});if(traceExamples.length<4)traceExamples.push({path,...a});}
}
const inlineOld = '(function createClock(now){const nowNumber=now instanceof Date?now.getTime():Number(now);const nowMs=Number.isFinite(nowNumber)?nowNumber:Date.now();return nowMs;})';
for(const factory of clocks){const a=observe(inlineOld,factory),b=observe(`${clockImpl};clockNormalized`,factory);assert.deepEqual(a,b);clockCases++;traceComparisons.push({kind:'clock',path:'quote-contract inline clock',case:clockCases,old:a,candidate:b});}
const values = [undefined,null,false,0,-0,1,-1,23,24,59,60,NaN,Infinity,-Infinity,'','23','24','59','60',Symbol('x')];
let hmsCases = 0;
for(const start of [1,4])for(const h of values)for(const m of values)for(const s of [undefined,0,59,60,NaN,Symbol('s')]) {
  const factory = trace=>new Proxy({[start]:h,[start+1]:m,[start+2]:s},{get(t,k,r){trace.push('get:'+String(k));return Reflect.get(t,k,r);}});
  const old = `(parts=>Number(parts[${start}])>23||Number(parts[${start+1}])>59||Number(parts[${start+2}]||0)>59)`;
  const a=observe(old,factory),b=observe(`${hmsImpl};(parts=>hmsOutOfRange(parts,${start}))`,factory);assert.deepEqual(a,b);hmsCases++;traceComparisons.push({kind:'hms',start,case:hmsCases,old:a,candidate:b});
}
for(const start of [1,4])for(const throwIndex of [start,start+1,start+2]) {
  const factory=(trace,sentinel)=>new Proxy({[start]:0,[start+1]:0,[start+2]:0},{get(t,k,r){trace.push('get:'+String(k));if(k===String(throwIndex))throw sentinel;return Reflect.get(t,k,r);}});
  const old=`(parts=>Number(parts[${start}])>23||Number(parts[${start+1}])>59||Number(parts[${start+2}]||0)>59)`;
  const a=observe(old,factory),b=observe(`${hmsImpl};(parts=>hmsOutOfRange(parts,${start}))`,factory);assert.deepEqual(a,b);hmsCases++;traceComparisons.push({kind:'hms',start,throwIndex,case:hmsCases,old:a,candidate:b});
}
const scalarReplacer = (key,value) => typeof value === 'undefined' ? {scalar:'undefined'}
  : typeof value === 'number' && !Number.isFinite(value) ? {scalar:String(value)}
    : Object.is(value,-0) ? {scalar:'-0'} : value;
await writeFile(resolve(temp,'trace-comparisons.json'),JSON.stringify(traceComparisons,scalarReplacer));
await writeFile(resolve(temp,'trace-summary.json'), JSON.stringify({clockCases,hmsCases,traceExamples,
  scope:'Primitive slices only; Number/Date access/call and input Proxy/coercion order; same sentinel or name/message; stacks not compared; no full API/runtime/device proof.'},null,2));
if(process.argv.includes('--trace-only')) {process.stdout.write(JSON.stringify({clockCases,hmsCases,archivedComparisons:traceComparisons.length,buildsRun:0})+'\n');process.exit(0);}

const definitions = [['baseline',{}],['clock',{clock:true}],['hms',{hms:true}],['combined',{clock:true,hms:true}]];
const variants = new Map(definitions.map(([name, options])=>[name, transform(options)]));
for(const [name, files] of variants)for(const [path,code] of files){const target=resolve(temp,'transformed',name,path+'.txt');await mkdir(dirname(target),{recursive:true});await writeFile(target,code);}
await writeFile(resolve(temp,'recipe.txt'), buildSource.slice(call.arguments[0].start,call.arguments[0].end));
const rounds = [['baseline','clock','hms','combined'],['combined','hms','clock','baseline'],['clock','baseline','combined','hms']];
const results = [];
let baselineTopology;
for(let round=0;round<rounds.length;round++)for(const name of rounds[round]) {
  const files=variants.get(name);
  const plugin={name:'fundval-scalar-probe',enforce:'pre',transform(source,id){const path=relative(root,id.split('?')[0]).replaceAll('\\','/');if(files.has(path))return files.get(path);}};
  const started=performance.now();
  const raw=await viteBuild({...recipe.options,plugins:[plugin]});
  const outputs=Array.isArray(raw)?raw.flatMap(item=>item.output||[]):raw.output||[];
  const chunks=outputs.filter(item=>item.type==='chunk');
  const entry=chunks.filter(chunk=>chunk.isEntry);assert.equal(entry.length,1);assert.equal(entry[0].fileName,'js/app-shell.js');
  const byFile=new Map(chunks.map(chunk=>[chunk.fileName,chunk]));
  for(const chunk of chunks){assert.match(chunk.fileName,/^js\/(?:app-shell|chunks\/[A-Za-z0-9._-]+)\.js$/);for(const dep of [...chunk.imports,...chunk.dynamicImports])assert.ok(byFile.has(dep));assert.doesNotMatch(chunk.code,/assets\/ocr|paddle-local-ocr|ocr-import-page|onnx|tesseract/i);}
  const cold=recipe.collectStaticChunkGraph(byFile,[entry[0].fileName,...entry[0].dynamicImports]);
  recipe.assertStartupPhaseIsolation(byFile,entry[0],cold);
  const measurements=chunks.map(chunk=>({path:chunk.fileName,name:chunk.name,role:cold.has(chunk.fileName)?'cold':'lazy',
    bytes:Buffer.byteLength(chunk.code),gzipBytes:gzipSync(chunk.code).length,sha256:hash(chunk.code)}));
  const all=measurements.reduce((sum,c)=>sum+c.gzipBytes,0), coldBytes=measurements.filter(c=>c.role==='cold').reduce((sum,c)=>sum+c.gzipBytes,0), bytes=measurements.reduce((sum,c)=>sum+c.bytes,0);
  if(name==='baseline')assert.deepEqual({all,cold:coldBytes,bytes,count:chunks.length},{all:80494,cold:42985,bytes:235647,count:16});
  const topology=chunks.map(chunk=>({name:chunk.name,role:cold.has(chunk.fileName)?'cold':'lazy',
    modules:Object.keys(chunk.modules).map(recipe.modulePath).sort(),imports:chunk.imports.map(path=>byFile.get(path).name).sort(),dynamicImports:chunk.dynamicImports.map(path=>byFile.get(path).name).sort()})).sort((a,b)=>a.name.localeCompare(b.name));
  const topologyHash=hash(JSON.stringify(topology));if(!baselineTopology)baselineTopology=topologyHash;
  assert.equal(topologyHash,baselineTopology,'Chunk-name/role/module/import topology changed.');
  const manifest={entry:'js/app-shell.js',coldStart:[...cold].sort(),lazy:measurements.filter(c=>c.role==='lazy').map(c=>c.path).sort()};
  const graph=await verifyAppModuleGraph(manifest,chunks.map(chunk=>({path:chunk.fileName,code:chunk.code})));
  const fingerprint=hash(JSON.stringify(measurements.sort((a,b)=>a.path.localeCompare(b.path))));
  const result={round:round+1,variant:name,allGzipBytes:all,coldGzipBytes:coldBytes,rawBytes:bytes,chunkCount:chunks.length,
    fingerprint,topologyHash,graph,elapsedMs:performance.now()-started,measurements};
  results.push(result);
  const directory=resolve(temp,'artifacts',`${round+1}-${name}`);await mkdir(directory,{recursive:true});
  for(const chunk of chunks){const target=resolve(directory,chunk.fileName);await mkdir(dirname(target),{recursive:true});await writeFile(target,chunk.code);}
  await writeFile(resolve(directory,'app-chunks-summary.json'),JSON.stringify(result,null,2));
  await writeFile(resolve(temp,'results-in-progress.json'),JSON.stringify({head,results},null,2));
  process.stdout.write(JSON.stringify({round:round+1,variant:name,all,cold:coldBytes,bytes,topologyHash})+'\n');
}
for(const [name] of definitions){const runs=results.filter(r=>r.variant===name);assert.equal(runs.length,3);for(const field of ['allGzipBytes','coldGzipBytes','rawBytes','chunkCount','fingerprint','topologyHash'])assert.equal(new Set(runs.map(r=>r[field])).size,1,`${name}:${field}`);}
const after=await sourceIdentity();assert.deepEqual(after,before);
const summary={head,recipeDerivedFrom:'scripts/build-site.mjs AST',recipeSha256:hash(buildSource),sourceBefore:before,sourceAfter:after,
  scope:'Isolated Vite write:false plugin transforms only. No project source/output/config/dependency writes. Not adopted. No full API/E2E or latency qualification.',
  trace:{clockCases,hmsCases},rounds,results,
  compact:definitions.map(([name])=>{const r=results.find(r=>r.variant===name);return {variant:name,allGzipBytes:r.allGzipBytes,coldGzipBytes:r.coldGzipBytes,rawBytes:r.rawBytes,allDelta:r.allGzipBytes-80494,coldDelta:r.coldGzipBytes-42985,topologyHash:r.topologyHash};})};
await writeFile(resolve(temp,'summary.json'),JSON.stringify(summary,null,2));
process.stdout.write(JSON.stringify(summary.compact,null,2)+'\n');
