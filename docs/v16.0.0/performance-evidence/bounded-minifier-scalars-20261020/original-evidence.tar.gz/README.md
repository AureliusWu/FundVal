# FundVal M3 scalar helper probe (2026-10-20)

Status: TEMP EXPERIMENT ONLY / NOT ADOPTED / NOT RELEASED.

Source checkpoint: `170fd3eadc6da02750882f8a542904ee2358d0d9`.
Project business sources, configuration, dependencies and `site` output were not written by this probe.
The parent agent has concurrent tool/document work; this experiment does not assert a clean worktree.

## Fixed layout

- Internal helpers are additional exports of the existing post-integrity `quote-contract.js`; no new module or group.
- Clock-only: preserve public `contractClock(now)` as a same-name/arity wrapper; private `finiteNow` and `clockValue` become imports; only the identical local clock conversion in `createQuoteEnvelope` is replaced.
- The two `options.now` clock expressions in quote-normalizer are deliberately unchanged: passing `options.now` once to a helper would drop a getter access.
- HMS-only: replace only the identical upper-bound short-circuit expressions at offsets 1/4 in Worker, Quote and Tencent adapters. Original date and timezone regexes, source metadata guards, return/throw behavior and parsing remain.
- `clockNormalized` and `hmsOutOfRange` are not added to the 18-API business facade.

## Primitive trace evidence

`probe.mjs` extracts three original clock functions from the actual source AST and compares them with the shared conversion; it also compares the literal current `createQuoteEnvelope` local clock slice. There are 124 clock cases and 4,806 HMS cases. Comparisons include output, Number/Date property reads/calls, input coercion/getTime/Proxy index access, short-circuit ordering, and the identical thrown sentinel or error name/message. Error stacks are not compared.

After the 12 build probes had completed, the script received only trace archival instrumentation and a `--trace-only` switch. A second successful primitive-only run wrote all 4,930 old/candidate trace pairs to `trace-comparisons.json`. That run performed zero builds and did not alter the existing build measurements. The current script reproduces the same guarded transforms and recipes, and can rerun either traces only or the fixed 12-build experiment.

This is not a whole-API, DOM, arbitrary-exception-stack, device or latency equivalence claim.

## Artifact experiment

The Vite option expression and five grouping definitions are extracted from the actual `build-site.mjs` AST. `write:false`, OXC, ES2022 and original five groups remain. A pre-transform plugin supplies only the six temporary source strings; it does not edit project source files.

Fixed order: baseline/clock/HMS/combined; combined/HMS/clock/baseline; clock/baseline/combined/HMS. Each variant has exactly three builds. No sweep or additional build variant was run.

| Variant | All gzip B | Cold gzip B | Raw B | All delta B | Cold delta B |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline | 80,494 | 42,985 | 235,647 | 0 | 0 |
| Clock only | 80,461 | 42,982 | 235,417 | -33 | -3 |
| HMS only | 80,482 | 43,007 | 235,610 | -12 | +22 |
| Combined | 80,472 | 43,007 | 235,372 | -22 | +22 |

All rounds repeat bytes and per-variant fingerprints. All 12 builds have 16 chunks and the same module/chunk-name/role/static/dynamic dependency topology fingerprint: `cf069f8aa97c3bd64fb4052b936d807ae5bfceebb570cdbea31b4240be1b3e1b`.

Each build passes the original metadata-based startup isolation checks and the independent final-code literal-import/cold-partition/native static ESM-link verifier. No supplied module is evaluated by the linker. Equal topology does not prove source or runtime behavior equivalence.

Clock-only is the smallest measured variant in this finite set. Combined savings are not additive. None closes the original 77,227.7 B all-gzip budget, and none has full API/E2E/paired-latency qualification. No candidate has been applied to the project.

## Files

- `summary.json`: all 12 measurements, module topology digest, actual final-code graph/link results, source SHA checks.
- `recipe.txt`: exact extracted build option expression.
- `transformed/<variant>/`: all six source files for each variant, including baseline originals, as `.txt`.
- `artifacts/<round>-<variant>/`: the actual generated chunks and measurement report for every build.
- `trace-comparisons.json`: all old/candidate primitive trace pairs; non-finite/negative-zero/undefined values are explicitly tagged.
- `trace-summary.json`: counts, selected trace examples and scope limits.
- `probe.mjs`: reproducible guarded transforms, trace checks and fixed build experiment.
