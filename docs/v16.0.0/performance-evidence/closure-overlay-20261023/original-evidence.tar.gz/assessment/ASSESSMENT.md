# 单文件 Compiler 覆盖：只读可行性（2026-10-23）

结论：**原文仅加一个case、直接对现有shaded JAR javac，不可行；预声明机械重定位后，B0/B1单文件覆盖静态上条件可行，尚未编译/运行证明。** 不改任何SIMPLE选项、输入/输出ES2022或夹具，不以ESNEXT替代。本轮只新增此评估；未下载、写源码、编译、运行或改root/旧probe。

## 直接证据与完整的重定位范围

官方[pinned Compiler.java](https://github.com/google/closure-compiler/blob/v20261020/src/com/google/javascript/jscomp/Compiler.java)为172135B/SHA256 `c9d418116b88311397bc172b1bd6de34d936d00b2b0fb772831306cde8756a9e`；[rules.jarjar](https://github.com/google/closure-compiler/blob/v20261020/rules.jarjar)为457B/SHA256 `643dbb4ce1977f227decd1ec2964aab7a192fc917de7c15f0ae93459671f0f65`。规则先保留`com.google.javascript.**`、`com.google.debugging.sourcemap.**`，再重定位其他com.google依赖。[BUILD.bazel:43–83](https://github.com/google/closure-compiler/blob/v20261020/BUILD.bazel#L43-L83)确认当前artifact使用shaded uberjar，另有不同的unshaded artifact。

现有JAR只读复核：14997454B，SHA256 `7dfedc111cb06024d3aa132443cd4952da415635c59342d84d96883083df853c`。原Guava/ErrorProne类不存在；对应`com.google.javascript.jscomp.jarjar.com.google…`类存在；org.jspecify保持原包。类常量池也出现返回shaded ImmutableList的JVM描述符，故另塞原Guava不能修复覆写ABI。

**只改imports仍不完整。** 全文件有限文本扫描得到：

- 21条外部import需按官方规则机械重定位：17条Guava、3条ErrorProne annotation、1条Gson；包括4条static import。保留JavaScript/sourcemap/jspecify/JDK引用。
- :1802另有唯一非import外部FQ类型：`com.google.common.base.Supplier<String> getUniqueNameIdSupplier()`，带@Override，**也必须重定位**。其余非import的com.google引用只有应保留的jscomp package/logger/comment。未发现其他需shade的javax/org.json/org.kohsuke/org.apache.tools引用。
- 这22处引用覆盖19个不同的外部类；本地ZIP逐一确认19个目标shaded class全部存在。无Compiler本身的@AutoValue/@AutoOneOf/@Generated或AutoValue_Compiler生成要求；`-proc:none`有理由避免额外处理器，但不能预判javac成功。

因此若主代理明确把上述**21 imports+1 FQ return type**定义为共同packaging翻译，可建立B0（重定位、未补case）及B1（相同翻译，再仅补bridge case）。它们之间唯一语义源码差应为Compiler.java:3387后新增`case ECMASCRIPT_2022 -> LanguageMode.ECMASCRIPT_2022;`。这是条件可行的窄工具fork，不是官方原版JAR或已经验证的编译器。

## 包、生成类型和覆盖组

JAR保留同一`com.google.javascript.jscomp`包，包含ConformanceConfig/Requirement/serialization.TypedAst等已生成类。classpath/同AppClassLoader下的同包访问不是已知硬阻断；JAR manifest未sealed、无签名文件、无base module-info，未发现Compiler族的multi-release覆盖。并非证明所有源码/二进制私有ABI已经兼容。

不能只覆盖Compiler.class：现有JAR有**13个Compiler族class**（含匿名/内部/嵌套类）。每侧javac应收集并覆盖该源实际生成的整组`Compiler.class`/`Compiler$*.class`，保留独立目录、库存和类来源验证，禁止混用B0/B1/旧JAR的Compiler内类。字段/方法/嵌套ABI与classpath加载来源必须核查；编译器生成的字节、debug行号不预期与官方JAR逐字节相同。

## 最小有限步骤与停止线（本轮不执行）

1. 新协议固定原源码/JAR/JDK21、上述22处共同翻译和唯一case差；无未重定位依赖补装、无全源重建、无选项变化。先分别用同一JAR、`-proc:none`编译B0/B1整组；任何编译/链接/访问错误保留并停止，不连续补依赖或改其他源码。
2. classes-first并验证Compiler及所有生成内类的实际来源、ABI。独立进程反射原private mapping，全部LanguageMode的B0/B1完整结果仅允许2022从旧异常变正确parser枚举；其他差异停止。B0保持input2022失败是控制，不冒称它通过8案例。
3. B1才进入原同字节8固定夹具及原期望、warning/trace/error/alias gate；首个真正失败停止，无flagsweep/产品转换。旧controller不支持overlay classpath；若需新controller适配，只能在新Temp明确声明classpath差，原controller/fixtures/原run保持不动。旧native2不洗掉，且新工具fork结果不继承至产品/收益/M3。

## 来源与许可风险

保留源文件Apache2 header，清楚标识local packaging翻译和单case修改，分别记录上游hash、翻译hash、B0/B1差、class/JDK/JAR与运行来源；不可把overlay称为Google未修改v20261020。若归档/再分发源或class，按[同版LICENSE §4](https://github.com/google/closure-compiler/blob/v20261020/LICENSE)保留许可证、修改说明及适用NOTICE/归属；不得替换原验证JAR或失去其依赖许可材料。维护这个本地工具fork增加供应链/重现成本，语义与净gzip仍需独立证据。

状态：READ_ONLY / CONDITIONALLY_PLAUSIBLE_AFTER_EXPLICIT_PACKAGING_TRANSLATION / NOT_COMPILED / NOT_QUALIFIED。performance-regression-check只用于区分工具前提与性能测量；无收益结论。到此停止。
