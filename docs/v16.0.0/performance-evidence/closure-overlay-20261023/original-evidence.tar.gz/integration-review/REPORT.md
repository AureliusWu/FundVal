# 当前 §52/§53 hybrid 构建接入只读复核

日期：2026-10-23（Asia/Shanghai）。项目：D:/AI项目/FundVal。结论仅针对当前已安装 Vite 8.2.4 / Rolldown 1.2.5 和当前 16-chunk 产物；不是旧 A/B 产物资格的继承。

## 结论

存在合理的**哈希生成前、原构建内**接入位置，但尚无可采用的 hybrid：固定 Closure v20261020 前置在输入 ECMASCRIPT_2022 parser bridge 抛错，未产生转换结果；本审查没有运行替代配置。未来 fixture 即使通过，也须先固定真正执行的转换顺序，再验证同一候选产物。不能在既有 site 文件上二次改码、保留旧内容哈希文件名，再仅重算 manifest/SW，称为 release-correct 接入。

最小常规接入是 `renderChunk` 对非 TLA 块执行获准的 Closure pass，TLA 块不交 Closure，继续保留现有全局 OXC。**此时顺序是 Closure → OXC，不是现有 OXC 结果 → Closure。** 若主方案要求后者，下面的常规 hook 不是那个候选，必须另行明确一个哈希前的显式 minifier router；不能悄悄更换顺序。

两块 TLA 保留 OXC 路径不等于最终文件逐 byte/SHA 不变。依赖块更名会正常改写它们的 import / dynamic import / preload 路径。应约束“不向 TLA 应用 Closure，保留原 OXC 执行路径和程序语义；仅允许经构建器解释的链接重写”，不能强迫引用仍指向旧文件名。此结论不允许任意修改 TLA 算法正文。

当前 manifest/§52、§53 报告仍为 all **85969**、cold **46149**；all 上限 **77227.7**，预算未过。本次没有重测 gzip、没有收益估算，也没有证明 hybrid 足够材料性。

## 1. 实际阶段与最小切口

当前 `scripts/build-site.mjs:139–163` 的 `viteBuild({write:false})` 固定：
`minify:'oxc'`、`target:'es2022'`、ES 模块输出、原五 groups、`js/app-shell.js` 和 `js/chunks/[name]-[hash].js`。安装的 Vite 实现 `node_modules/vite/dist/node/chunks/node.js:33916–33937` 将 OXC 选项映射为 Rolldown `output.minify:true`；用户 output 最后覆盖。特别是单设 `build.minify:false` 被映射为 `"dce-only"`，不是“完全不再处理”。

Rolldown **固定 v1.2.5** 官方输出阶段图是 renderChunk → 内建 minify → augmentChunkHash → generateBundle。插件 `enforce:'post'` 不是内建 minify 后的钩子。[固定版本阶段图](https://github.com/rolldown/rolldown/blob/v1.2.5/docs/apis/plugin-api.md#output-generation-hooks)、[Vite 插件顺序](https://vite.dev/guide/api-plugin.html#plugin-ordering)

建议后续仅在明确选择该顺序时考虑以下有限接入：

1. 在原 `viteBuild` 的 output plugin/renderChunk 内，使用 AST 判断本块顶层 await；以当前冻结图核对两块 TLA / 十四块非 TLA，不靠“文件名包含 app”猜测。
2. TLA 返回不转换；非 TLA 使用已获准且被同一 fixtures 验证的单块 Closure 配置。保持 import/export 公共绑定、动态 import namespace、执行顺序以及模块元数据契约，不引入 runtime/polyfill 或重新分组。若转换确实改变依赖/exports，不能仍上报旧元数据。
3. 原 Vite/Rolldown OXC、链接器、哈希和 preload 流程继续完成；将其最终输出交给现有 build-site 的全部断言、测量和文件写入流程。不可在钩子内提前消解或手工生成哈希占位符。
4. 最终 artifact 身份、图、行为、预算分别记账，不把“有 graph PASS”提升成语义/升级/性能 PASS。

若已批准的候选意图是 **OXC → Closure14 / OXC2**，必须改为一个明确的哈希前 router 并停用后续自动 minify；`output.minify:false` 与 OXC 调用的引擎、配置、注释/输出选项等都须显式固定。当前查到的 OutputOptions 未提供按块 minify callback，不能通过 renderChunk 临时改共享 output 选项冒充支持。这个 router 如何复现原 OXC 两块路径，尚未实现或验证；本报告不宣称它已等价，也不要求现在变更参数或试跑。另一选择是承认常规 hook 的 Closure→OXC 是一个新的、顺序明确的候选，而非旧的后置文件改写。

## 2. 两块 TLA、路径与内容哈希

本次只读 AST 库存读取现有 manifest 所列 16 文件，逐文件核 bytes/SHA，全部与 manifest 相符；没有 evaluate。原命令、native0 和全行结果见 `CURRENT_AST_RECEIPT.json`。

| 当前文件 | TLA 数 | 可观察链接 |
| --- | ---: | --- |
| js/app-shell.js | 4 | static startup-pure；dynamic startup-repository / startup-migrations / app facade |
| js/chunks/post-integrity-Dp7m1bj2.js | 1 | static startup-pure；dynamic business / cloud / diagnostics 多入口 |
| 其余十四块 | 0 | 完整字面量依赖见库存 |

这两块均带 Vite preload 依赖表。非 TLA 的 startup-pure / business 等一旦改变内容及名字，引用者最终字节也可能改变。旧前置报告 `FundVal-closure-hybrid-prereq-20261022-a1/REPORT.md:136` 的“两 TLA 逐 byte/SHA 不变、静动态路径不变”是那个旧 standalone 方案的要求，**不应机械继承为新在构建内方案的最终字节条件**。应保留旧报告原文/证据，后续新协议显式区分计算正文与构建器链接映射，不能事后抹去冲突。

Rolldown 的 [hash] 包含 renderChunk 后代码及被引用块的哈希，不是简单 SHA256(file) 的前缀；`RenderedChunk` 阶段文件名可以是占位符，后续才定案。不能要求新产物沿用旧物理名字，也不能假造“文件名必须等于 manifest SHA 前几位”的条件。[OutputOptions.chunkFileNames](https://rolldown.rs/reference/Interface.OutputOptions#chunkfilenames)、[RenderedChunk](https://rolldown.rs/reference/Interface.RenderedChunk)

实际 Vite `buildImportAnalysisPlugin` 在 generateBundle 阶段，根据最终 bundle 处理 `__VITE_PRELOAD__` 并构造 `__vite__mapDeps`（安装实现约 29110–29300）。Closure pass 对这些标记/表达式的处理必须与该阶段兼容；仅“import 字面量仍存在”不足以证明 preload 表未被破坏。新 hook 不能越过 Vite 这一步自行补静态路径。正常 bundler 映射后的路径差异合法，但缺项、旧路径、失配元数据不合法。

## 3. manifest、指纹和 SW 应由现有后半段统一生成

`build-site.mjs:168–202` 基于最终 chunk 元数据核安全路径、全部依赖输出、startup phase、冷图/懒图和 OCR 隔离；`:204–238` 对最终 code 算 raw/gzip/SHA 并写 manifest；`:244–267` 更新 HTML/SW。因此 pre-hash 接入后通常不必另造一套 manifest 或手写 SW 清单。应让这些流程看见**实际最终字节与实际最终文件名**。

SW CORE 当前包含全部十六个非 OCR chunks 和 app-chunks.json，**不是只有 cold chunks**。构建器应保留这项现有行为；懒加载分组和 SW 预缓存是两个层面的规则，不能为省字节擅自合并或删 CORE 项。

`sw.js:46–67` install 用 reload 拉 CORE、保留前一版本；`:173` 的 JS 使用 stale-while-revalidate，`:230–241` miss 时 reload。已有更新 requester/版本防护也不能绕过。若改了 chunk 字节却保留同一旧 hashed URL，manifest 自洽并不能防止旧缓存被读出。新 chunk 命名、完整 CORE 和正常 SW 生成必须一起成立。

候选试验无需因此擅改 15.0.2 或发布流程；真正发布仍须经过既有版本/SW/升级规则及部署门禁。哈希正确不等于 offline/update 行为已验证。现有 deploy.yml 是下载并核验 CI candidate 后发布原字节，不会重建，不能在 deploy 阶段再追加 Closure 变换。

## 4. 现有门禁的实际证明范围

| 检查 | 能证明 | 不能升级为 |
| --- | --- | --- |
| build-site 最终元数据断言 | 原分组/phase、生成依赖集合、安全路径、cold≤52241 | all≤77227.7；真实运行或业务正确 |
| app-module-graph + native link | 所有字面量 import/export/dynamic import 可解析，图闭合、冷懒集合、静态绑定 | 执行正确、TLA 启动顺序、动态 namespace 成员或 preload 表全部正确 |
| release-fingerprint chunk 校验 | 清单与实际文件集合、bytes/SHA/gzip/角色一致 | 编译器语义等价或更新离线正确 |
| bundle budget CLI | 真实 total/cold 是否各自过线 | all FAIL 被 cold PASS 抵消 |

当前 graph 输出本来保留 `evaluated:false/startupOrderVerified:false/dynamicNamespaceMembersVerified:false`；预算输出 `importClosureVerified:false`。新候选报告必须保留这些边界，而不是只提 wrapper native0。固定 ES2022 输出目标、数据验证/异常/getter/null/0/来源时钟等原语义，也不会被上述 hash/link 检查自动证明。

## 5. 当前硬阻断与非阻断

- **真正未闭合前提**：§53 固定 v20261020 Java API 配置在 F01 original sanity 通过后，进入 `setLanguageIn(ECMASCRIPT_2022)` 的 parser bridge 抛 `IllegalStateException`；Java/controller native2，转换 F01 与 F02–F08 未运行。没有任何 hybrid 语义资格。后续因官方原因另立适配协议可以评估，但不能改写此 STOP。
- **必须先澄清**：新候选究竟 Closure→OXC，还是 OXC→Closure；以及 TLA “原 OXC 路径/正文”与最终链接字节的口径。原五组、target、预算均不是开放选择。
- **必须避免的错误实现**：后置改 site bytes 但不重走 linker/hash；仅更新 app-chunks.json；将 preload/namespace 异常归入“只改路径”；接受失败后自动回落 OXC 却仍称同一 Closure 候选。
- **构建工具链尚非正式输入**：当前 CI candidate 只显式固定 Node/npm；没有 setup-java/Closure/JAR 取得步骤。未来真正采用 Java 变换时，执行 build 的主机须有获批、固定且可验证的 JDK/JAR 来源和失败即停止机制，不能依赖本机 Temp 绝对路径或 runner 偶然预装。发布 job 只核验原字节，不应因此被强迫另装编译器。
- 不是硬阻断：正常引用重写导致两块 TLA 最终 SHA 改变；也不要求 candidate 现在升版本或全输入无限证明。未来只针对经批准的唯一完整 artifact 做有限资格和既有门禁。

## 6. 证据、读取范围和执行边界

完整读取：AGENTS.md、performance-regression-check/SKILL.md、build-site.mjs、app-module-graph.mjs、release-fingerprint.mjs、根 sw.js、package.json、§53 README/DIAGNOSIS、Temp fixed-probe-parent/PLAN.md、旧 hybrid-prereq/REPORT.md；读取 M3_STATUS §§52/53 及首部、built SW 清单、安装 Vite 输出/导入分析实现、Rolldown 输出/plugin 类型、lock pins。CI candidate build 部分/deploy verify 部分另作只读核对。非全部273源文件审计，不声称重新算完整127产物 aggregate。

| 路径（相对 D:/AI项目/FundVal） | 此轮实际 SHA256 |
| --- | --- |
| scripts/build-site.mjs | 51a4d35902ad2e6510dd3e82fea7198a12a9b722ef3098c791aeb4c8327ac9a4 |
| scripts/app-module-graph.mjs | 6647961ec3800df7a8ab3da6f3f0dfe75de3abca768f7af10f26594f9b83b678 |
| scripts/release-fingerprint.mjs | 4d99eda7af1da3c999090364926c78ea27597c4107892ae82b9894bb43a704c3 |
| sw.js | 1f904830e069679ba55020dd8fd102dae6c8f48b0343c508ee7ce1d609b5979c |
| site/sw.js | 81ba2faeae1ced4105637ad8767995013c23dad27f070e6ccaa540e9fb2b6e09 |
| site/js/app-chunks.json | c0d4a0c3ce37a763f9f9719435c81a706fbb365314a2e2a6df261e37886c30c6 |
| node_modules/vite/dist/node/chunks/node.js | 2c452d31c8ff4bf131e9e9b874037c9ac9bf2ad57b06cb9158cc2e6dab860cc0 |
| node_modules/rolldown/dist/shared/define-config-DwTNhgWB.d.mts | 6dc67ec65ed95fca799687d7bebbdd067add9297b933b5b1a0df4111ae9a09f2 |
| .github/workflows/ci.yml | 4309ba97de1624af65bff047874f4fd20b1b640c0c097a7f02f88a4a603d4d3a |
| .github/workflows/deploy.yml | 0d1a36eaea6a2721558f909da0c48d52d72277bfea425ed060c07d1b26748fdf |

唯一程序性检查是只读 AST/SHA 库存，使用当前已安装 Rolldown parseSync，不 import/evaluate 产品模块。native0 及原命令保存在邻接 receipt。无项目 build/test/业务执行/Closure 编译/压缩测量/下载/安装/浏览器；未改 root/source/site/docs/config/node_modules、未提交/推送/发布。新写入仅此独立 Temp 的报告与读取回执。技能仅影响证据分层和禁止将前提/静态检查当性能收益，不触发额外执行。

有限结论：构建内接入在架构上可行，但阶段顺序、TLA 口径和工具/行为资格仍须闭合；当前没有可发布或可计收益的 hybrid。没有证明其它压缩策略不可能。到此停止。

