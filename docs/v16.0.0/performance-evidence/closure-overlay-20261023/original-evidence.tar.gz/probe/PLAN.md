# B1 parser bridge overlay — same fixed 8-fixture prerequisite

2026-10-23，任何本目录编译/夹具运行结果之前冻结。仅准备新Temp副本；本轮作者不运行Java/夹具/构建，不下载，不改root、旧probe、旧oracle或overlay本体。主代理拥有唯一执行。当前产品仍source273/site127/installed68、15.0.2/M3 IN_PROGRESS，site行SHA `0641039bb788b27c58c0ec0dc3d93b40cbc95bc2c51c935c105c9354c9b29d31`，all85969/cold46149，原预算不变；本工具前置不转换或采用任何产品chunk。

## 原件和唯一新前提

原冻结目录：`C:/Users/84046/AppData/Local/Temp/FundVal-closure-fixed-probe-20261022-parent`，manifest SHA256 `4e8d73bfadf03c5d6fd4cd6477b95cbc0ec99a101d5d315dd92624d0bf73d6d1`。该原JAR唯一运行F01 original sanity通过，但Java解析前抛ECMASCRIPT_2022桥接异常/native2；F02–F08 NOT_RUN。旧结果永远保留，不改判、覆盖或回写。

本目录从旧15个payload复制：**DRIVER.java和全部8主夹具+4真实support共13文件逐字节相同**；只替换PLAN，并对controller作严格overlay路径/库存验证及classpath适配。`CONFIG`、`CASES`、`EXPECTED`、`observe`、AST surface、特殊number/opaque/error/clock/trace处理、原始sanity、warning分类、每步fail-fast和所有编译选项原文不变。不是新模型、参数扫描或改预期求通过。

主代理另已声明共同packaging重定位22处并修单case的B0/B1：固定v20261020 Compiler.java原SHA `c9d418116b88311397bc172b1bd6de34d936d00b2b0fb772831306cde8756a9e`；21条import+唯一FQ Supplier共同重定位，不增原包依赖；B1仅增加2022→parser2022分支。B1是本地工具fork，不是未修改官方JAR。

## 必须验证的外部overlay原件

- 唯一允许路径：`C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/B1/classes`。CLI `--overlay`必须显式、绝对、canonical path精确相同；不允许B0、其他classes、任意classpath字符串或目录内符号链接。
- 固定父收据：`C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/compile-check/RESULT.json`，25229B/SHA256 `517f52c1a27fe488ee53496fb003c40c55c5f9535cf9c0978e44ab08115fc93e`。controller要求状态`OVERLAY_COMPILE_AND_FINITE_MAPPING_PASS_ONLY`，error/postflightError均null，记录CodeSource是该B1目录，再将实际完整class库存逐项与`classes.B1`对照。
- 收据记录B0/B1各完整13个Compiler族class，与原JAR族文件名集合相同；全部16个LanguageMode映射B0同原JAR，B1仅2022不同。B1源172987B/SHA `7974acca148ffea2650f57a632372e60b68aa1f93092abef4c25e016c005485a`。controller不重编译/重做这些反射，仅校验冻结收据与其actual class bytes/SHA。
- 另有父`abi-check/RESULT.json`（6899B/SHA `6bd0772b293a2b2086b9584a1f36e419d3fc23cab4c6b20a8fca9103ed06a307`），状态`COMPILER_FAMILY_ABI_TEXT_PASS_ONLY`、error/postflightError null。它是有限ABI读审，不是优化/JS行为证明；不把本轮准备叙述成作者执行过javac/javap。
- guard在输出目录创建前、每次Java调用前和结束/失败时复核原收据hash及完整13个class库存；任何漂移按原完整性失败规则停止。新manifest自身及全部新payload也继续以前后SHA保护。

## 完全不改的编译配置与8域

DRIVER字节SHA仍`e267a700f5bd53b609b6c809d48dc1f2ef625ac7e7fe0ee28fbf2f469e110947`。仍是SIMPLE_OPTIMIZATIONS；in/out ECMASCRIPT_2022；NONE；moduleRewriting=false；allowDynamicImport=true/noalias；DependencyOptions.none；LOCAL/OFF；getter pure=false/statically analyzable property=false；optimizeCalls=false；rewritePolyfills=false/preventLibraryInjection=true；原browser externs。没有任何options字段/值变化，ESNEXT不作为替代。

顺序仍F01 export alias/collision/unused export/identity/arity；F02 default/named/namespace import+reexport；F03 live binding/reassigned object；F04 arity/genuine Error/opaque descriptor；F05 getter/proxy/spread/Symbol identity/descriptor/null/NaN/−0/clock/this/optional-call；F06原5个读序/异常sentinel子案；F07 dynamic literal/computed/namespace identity；F08真实side-effect import顺序。所有固定期望不变，real support不传入Closure、仅runtime原样加载；每次仍只编译1个输入、保留原模块文件名。original/transformed仍各独立Node进程。原件协议详见旧PLAN（13510B/SHA `e5dfbc2c7b76e8256b218258061c4a53e5f937467ba87b9ca09328eabe3aae62`），其中唯一在本新目录覆盖的工具前提是本节所述overlay。

## 执行入口、保持原样的停止线

主代理确认新manifest及自身root/site/install/Git保护之后，才可唯一运行：

`node controller.mjs --java "C:/Users/84046/AppData/Local/Temp/FundVal-closure-toolchain-20261022-parent/jdk/jdk-21.0.12.1+1/bin/java.exe" --jar "C:/Users/84046/AppData/Local/Temp/FundVal-closure-toolchain-20261022-parent/closure-compiler-v20261020.jar" --overlay "C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/B1/classes" --run-name run-01`

Java classpath唯一变化为`<B1/classes>;<same verified JAR>`，其余argv/DRIVER/fixtures不改。JAR仍实际hash验证为`7dfedc111cb06024d3aa132443cd4952da415635c59342d84d96883083df853c`；工具路径仍限制在原toolchain Temp，清除原4个options环境变量，保留每个命令完整stdout/stderr/native收据。不存在产品转换入口。

原协议完整执行顺序：original对固定字面期望sanity → 单次Java compile → 所有diagnostics → 外部ESM surface → transformed独立观测 → 完整old/new及固定expected相同。首次原始sanity/setup/编译/ESM/行为/未知warning失败即停止、后案NOT_RUN，永不改参/改case/flagsweep。错误、特殊数值、源码身份和Java/source-launch诊断分类不放宽。

所有JS warnings完整保存、不suppress。仅原先精确key/message/source/line/已声明target的missing-module warning可标KNOWN；任何其他结构化diagnostic停止。混合native stderr仍须父独立全文复核；即使8比较全完成，也按原controller返回`FIXTURE_COMPARISONS_COMPLETE_NATIVE_STDERR_REVIEW_REQUIRED`/exit2，不能自动称8/8资格；未知tool-only stderr仍setup stop。旧失败原件不可覆盖。

即使前置通过，也不证明任意ESM/输入域、import.meta/TLA/浏览器/全部API、净gzip、时延、CI或生产。后续如讨论产品hybrid仍须独立方案、原五组/ES2022/hash命名/manifest/SW、真实行为和完整产物测量；不继承旧800。到准备/冻结停止，执行归父代理。

使用performance-regression-check技能仅为保持工具前置、行为资格与收益证据分层；本目录准备没有测量结论。
