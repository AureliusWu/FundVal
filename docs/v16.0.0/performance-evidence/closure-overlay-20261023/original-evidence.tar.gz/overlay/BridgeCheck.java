import com.google.javascript.jscomp.Compiler;
import com.google.javascript.jscomp.CompilerOptions;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** Finite mapping/loader observation; no JavaScript compilation or optimiser claim. */
public final class BridgeCheck {
  private static String q(String s) {
    if (s == null) return "null";
    return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\"";
  }
  public static void main(String[] args) throws Exception {
    Compiler compiler = new Compiler((PrintStream) null);
    Method bridge = Compiler.class.getDeclaredMethod("getParserConfigLanguageMode", CompilerOptions.LanguageMode.class);
    bridge.setAccessible(true);
    List<String> rows = new ArrayList<>();
    for (CompilerOptions.LanguageMode requested : CompilerOptions.LanguageMode.values()) {
      CompilerOptions options = new CompilerOptions();
      String effective = null, mapped = null, errorClass = null, errorMessage = null, stage = "init";
      try {
        options.setLanguageIn(requested);
        effective = options.getLanguageIn().name();
        compiler.initOptions(options);
        stage = "bridge";
        mapped = ((Enum<?>) bridge.invoke(compiler, options.getLanguageIn())).name();
      } catch (Throwable error) {
        Throwable actual = error instanceof InvocationTargetException ? error.getCause() : error;
        errorClass = actual.getClass().getName(); errorMessage = actual.getMessage();
      }
      rows.add("{\"requested\":" + q(requested.name()) + ",\"effective\":" + q(effective)
          + ",\"stage\":" + q(stage) + ",\"mapped\":" + q(mapped)
          + ",\"errorClass\":" + q(errorClass) + ",\"errorMessage\":" + q(errorMessage) + "}");
    }
    System.out.println("{\"codeSource\":" + q(Compiler.class.getProtectionDomain().getCodeSource().getLocation().toString())
        + ",\"javaVersion\":" + q(System.getProperty("java.version")) + ",\"rows\":[" + String.join(",", rows) + "]}");
  }
}
