# 独立 parser bridge overlay，固定配置不变

2026-10-23，实施前。上一§53原JAR固定实验为SETUP_OR_DRIVER_FAILURE，永久保留，不改判/覆盖/重跑。用户已允许隔离验证新JS压缩策略，合格后才考虑采用；本轮只在新Temp验证有明确因果的编译器适配修复，不修改项目业务/依赖/构建/预算/目标或发布。

## 唯一新前提

固定v20261020 Compiler.java（172135 B/SHA256 c9d418116b88311397bc172b1bd6de34d936d00b2b0fb772831306cde8756a9e）的getParserConfigLanguageMode缺ECMASCRIPT_2022映射。原shaded JAR的Guava/Gson/ErrorProne命名不同，故先按同tag rules.jarjar进行**纯packaging重定位**：21条外部import和唯一非import FQ Supplier类型，同样翻译给两侧。不得添加未重定位的依赖或改变类型ABI。

- B0：机械重定位但未修bridge的官方同版Compiler.java。
- B1：与B0字节完全相同，只有switch增加 `case ECMASCRIPT_2022 -> Config.LanguageMode.ECMASCRIPT_2022;`。
- 两侧分别用既有JDK21 `javac --release 21 -proc:none -encoding UTF-8 -cp <固定shadedJAR> -d <独立classes> <该source>`。不得补更多依赖、扫flags或静默修编译错误。任一编译失败则保存输出停止。
- 每侧必须包含完整Compiler及Compiler$* class组；枚举文件集合与原JAR对应组核对，不能混用旧inner。运行classpath只在当前进程将完整overlay目录置于原JAR前，不改原JAR/PATH/JAVA_HOME。

## 先证明适配，再做原固定8组前置

反射原JAR/B0/B1的同一私有输入映射，对全部公开LanguageMode枚举逐项保存实际结果/异常及类CodeSource。B0与原JAR须全部相同，B1只允许2022由原异常变为parser2022，其他模式全部同；CodeSource须证明实际加载对应overlay。有限映射比较不是任意编译优化等价性证明。

随后在新probe目录逐字复制上轮全部8夹具/4support、固定EXPECTED/observe和原DRIVER.java，不改其任何选项（仍SIMPLE、in/out ES2022、NONE、moduleRewriting=false、LOCAL/OFF、所有getter/clock/error约束）。controller只加经class清单/SHA核验的overlay classpath；其余检查和fail-fast原样。重新冻结新manifest，所有原文件和旧manifest继续不变。首次真实编译/ESM表面/行为/未知warning失败停止，不据失败改变参数/案例/期望。既有baseline原JAR的native2不擦除。

即使8/8通过也仅为合成前置，先作完整native stderr审查；不直接采用、不宣称gzip或性能。产品候选若另行推进，须保持五分组/OXC/ES2022输出/冷懒边界、真实hash命名/manifest/SW，不能在generateBundle后改字节并保留旧hash名，也不能把TLA因依赖hash改名的literal变化当算法转换。未来完整候选需单独冻结原配方对照/行为/三构建/实际全包预算及新性能，不能继承旧800。

## 控制和范围

当前§52/53 root273完整source/127site/68明确安装/HEAD/index前后核验，原all85969/cold46149/预算77227.7和52241/版本15.0.2不变。数据输入校验、兼容、null/0、日期、Schema3/Gist/OCR/Bridge均不变。无真实用户Storage、金融源、云写入、系统时钟同步、依赖升级、commit/push/deploy。只为验证已定位的单个parser缺陷建立隔离overlay；若不成立，停止而非加大范围维护compiler fork。
