export const NOW=Date.parse('2026-09-30T06:45:00Z');
export const CODE='000002';
export const NAME='合成沪深300指数基金';
const q=(value,change,time='2026-09-30 14:43:00')=>({sourceId:'quarterly-holdings-model',valueKind:'holding_lookthrough_estimate',value,changePct:change,coverage:60,observedAt:time});
const m=(value,change,time='2026-09-30 14:44:00')=>({sourceId:'market-model',valueKind:'model_estimate',value,changePct:change,coverage:100,observedAt:time});
export const cases=Object.freeze([
 {id:'P01-dual-distinct',kind:'fresh',holdingChange:2,marketChange:3,expected:[q(1.012,1.2),m(1.03,3)],forecast:'RED'},
 {id:'P02-holdings-zero',kind:'fresh',holdingChange:0,marketChange:3,expected:[q(1,0),m(1.03,3)],forecast:'RED'},
 {id:'P03-holdings-negative',kind:'fresh',holdingChange:-2,marketChange:3,expected:[q(0.988,-1.2),m(1.03,3)],forecast:'RED'},
 {id:'P04-market-zero',kind:'fresh',holdingChange:2,marketChange:0,expected:[q(1.012,1.2),m(1,0)],forecast:'RED'},
 {id:'P05-market-negative',kind:'fresh',holdingChange:2,marketChange:-3,expected:[q(1.012,1.2),m(0.97,-3)],forecast:'RED'},
 {id:'P06-distinct-source-clocks',kind:'fresh',holdingChange:2,marketChange:3,holdingTime:'2026-09-30 14:40:00',expected:[q(1.012,1.2,'2026-09-30 14:40:00'),m(1.03,3)],forecast:'RED'},
 {id:'P07-legacy-holdings-single',kind:'legacy-holdings',expected:[q(1.012,1.2)],absentSources:['market-model'],forecast:'CONTROL'},
 {id:'P08-legacy-market-single',kind:'legacy-market',expected:[m(1.03,3)],absentSources:['quarterly-holdings-model'],forecast:'CONTROL'},
 {id:'P09-legacy-dual-no-independent-quarterly-evidence',kind:'legacy-dual',expected:[],unusableSources:['quarterly-holdings-model','market-model'],forecast:'RED'},
 {id:'P10-official-current-date-blocks',kind:'official-current',holdingChange:2,marketChange:3,expected:[],unusableSources:['quarterly-holdings-model','market-model'],selected:{valueKind:'official_nav',status:'official',value:1.1,targetDate:'2026-09-30'},forecast:'CONTROL'},
 {id:'P11-stale-baseline-blocks',kind:'stale-baseline',holdingChange:2,marketChange:3,expected:[],unusableSources:['quarterly-holdings-model','market-model'],selected:{status:'stale'},forecast:'CONTROL'},
 {id:'P12-fresh-holdings-only',kind:'fresh',holdingChange:2,marketChange:null,expected:[q(1.012,1.2)],absentSources:['market-model'],forecast:'CONTROL'},
 {id:'P13-fresh-market-only',kind:'fresh',holdingChange:null,marketChange:3,expected:[m(1.03,3)],absentSources:['quarterly-holdings-model'],forecast:'CONTROL'},
].map(item=>Object.freeze(item)));
