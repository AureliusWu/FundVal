import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {cases,NOW,CODE,NAME} from './cases.mjs';
const NativeDate=globalThis.Date,sha=b=>createHash('sha256').update(b).digest('hex');
const planPath=process.env.FUNDVAL_P1_RUN_PLAN;
if(!planPath)throw new Error('REVIEW FIRST: use approved run-red.mjs controller; no run plan supplied');
const plan=JSON.parse(await readFile(planPath,'utf8')),records=[],sourceChecks=[];
const get=path=>import(pathToFileURL(resolve(plan.root,path)).href);
async function verifySources(stage){for(const item of plan.sources){const b=await readFile(resolve(plan.root,item.path)),same=b.length===item.bytes&&sha(b)===item.sha256;sourceChecks.push({stage,path:item.path,same,sha256:sha(b)});if(!same)throw new Error('Root source changed '+item.path);}}
await verifySources('before imports');
const [holdings,model,overseas,normalizer,contract,session,freshness]=await Promise.all([get('js/holdings-estimate.js'),get('js/runtime/fund-model-enrichment.js'),get('js/overseas-model.js'),get('js/runtime/quote-normalizer.js'),get('js/runtime/quote-contract.js'),get('js/runtime/market-session.js'),get('js/freshness.js')]);
const actualConfig=JSON.parse(await readFile(resolve(plan.frozen,'data/overseas-models.json'),'utf8'));
function snapshot(value,seen=new Map()){
 if(value===null)return {type:'null'};const type=typeof value;
 if(type==='number')return {type,value:Number.isNaN(value)?'NaN':Object.is(value,-0)?'-0':Number.isFinite(value)?value:String(value)};
 if(type==='undefined')return {type};if(type==='string'||type==='boolean')return {type,value};
 if(type==='symbol'||type==='bigint')return {type,value:String(value)};
 if(type==='function')return {type,name:value.name,length:value.length};
 if(seen.has(value))return {type:'reference',id:seen.get(value)};const id=seen.size+1;seen.set(value,id);
 return {type:Array.isArray(value)?'array':'object',id,prototype:Object.getPrototypeOf(value)?.constructor?.name??null,properties:Reflect.ownKeys(value).map(key=>{const d=Object.getOwnPropertyDescriptor(value,key);return {key:typeof key==='symbol'?{symbol:String(key)}:key,enumerable:d.enumerable,configurable:d.configurable,...('value'in d?{writable:d.writable,value:snapshot(d.value,seen)}:{get:d.get?.name??null,set:d.set?.name??null})};})};
}
function jsonRecord(value){try{const text=JSON.stringify(value);return {ok:true,text,bytes:Buffer.byteLength(text),sha256:sha(Buffer.from(text))};}catch(error){return {ok:false,name:error.name,message:error.message};}}
function usable(quote){return quote&&!['stale','unavailable'].includes(quote.status);}
for(const spec of cases)test(spec.id,{concurrency:false},async()=>{
 const events=[],guard={fetch:0,localStorage:0,sessionStorage:0,configFetch:0,configJson:0},oldFetch=globalThis.fetch,storageDescriptors=Object.fromEntries(['localStorage','sessionStorage'].map(key=>[key,Object.getOwnPropertyDescriptor(globalThis,key)]));
 class Clock extends NativeDate{constructor(...args){if(!args.length)events.push({op:'new Date()',value:NOW});super(...(args.length?args:[NOW]));}static now(){events.push({op:'Date.now()',value:NOW});return NOW;}}
 let output=null,error=null;const checks=[];
 const check=(name,pass,actual,expected)=>checks.push({name,pass:Boolean(pass),actual,expected});
 const number=(name,actual,expected)=>check(name,typeof actual==='number'&&Number.isFinite(actual)&&Math.abs(actual-expected)<=1e-10,actual,expected);
 globalThis.Date=Clock;globalThis.fetch=async()=>{guard.fetch++;throw new Error('Network denied');};
 for(const key of ['localStorage','sessionStorage'])Object.defineProperty(globalThis,key,{configurable:true,get(){guard[key]++;throw new Error('Real '+key+' denied');}});
 try{
  const loadedConfig=await overseas.loadOverseasModels(async(url,options)=>{guard.configFetch++;events.push({op:'fake config fetch',url,cache:options.cache,aborted:options.signal.aborted});return {ok:true,async json(){guard.configJson++;return structuredClone(actualConfig);}};});
  const selectedModel=overseas.selectOverseasModel(CODE,NAME);
  check('setup: real rule selected',Boolean(selectedModel?.pattern==='沪深300'&&selectedModel?.legs?.length===1&&selectedModel.legs[0].code==='sh000300'&&selectedModel.legs[0].weight===100),selectedModel?.pattern,'沪深300/sh000300/100');
  check('setup: real market eligibility',freshness.classifyFundMarket(NAME)==='cn-index',freshness.classifyFundMarket(NAME),'cn-index');
  check('setup: model config fetch invoked once',guard.configFetch===1&&guard.configJson===1,[guard.configFetch,guard.configJson],[1,1]);
  if(checks.some(item=>!item.pass))throw new Error('SETUP_GUARD_FAILED: real source config/eligibility mismatch');
  const sourceQuote=contract.createQuoteEnvelope({fundCode:CODE,fundName:NAME,market:'cn',assetKind:'index_fund',valueKind:'official_nav',value:1,changePct:(1/0.99-1)*100,baseNav:0.99,baseNavDate:'2026-09-28',targetDate:'2026-09-29',officialNavDate:'2026-09-29',sourceId:'eastmoney-official-nav',sourceTier:'secondary',status:spec.kind==='stale-baseline'?'stale':'official',observedAt:'2026-09-29',fetchedAt:new Clock(NOW).toISOString(),reasonCodes:[]},{now:NOW});
  const raw={code:CODE,name:NAME,market:'cn',assetKind:'index_fund',status:'ok_official',last_nav:0.99,nav_date:'2026-09-28',est_nav:1,est_change:(1/0.99-1)*100,est_time:'2026-09-29',est_kind:'official_nav',est_realtime:false,base_nav:0.99,base_nav_date:'2026-09-28',value_date:'2026-09-29',source_quote:sourceQuote};
  const move={nav:1,prevNav:0.99,date:'2026-09-29',prevDate:'2026-09-28',change:(1/0.99-1)*100,changeAmt:0.01,fundName:NAME};
  if(spec.kind==='official-current')Object.assign(move,{nav:1.1,prevNav:1,date:'2026-09-30',prevDate:'2026-09-29',change:10,changeAmt:0.1});
  if(spec.kind==='stale-baseline')Object.assign(move,{status:'stale',stale:true,cacheState:'stale'});
  if(spec.kind==='legacy-holdings'||spec.kind==='legacy-dual')Object.assign(raw,{est_holdings_model:true,est_kind:'holdings_model',last_nav:1,nav_date:'2026-09-29',est_nav:1.012,est_change:1.2,est_time:'2026-09-30 14:43:00',est_holdings_base_nav:1,est_holdings_base_date:'2026-09-29',est_holdings_target_date:'2026-09-30',est_holdings_coverage:60,est_holdings_quote_count:6,est_holdings_report_date:'2026-06-30',est_note:'合成旧重仓说明'});
  if(spec.kind==='legacy-market'||spec.kind==='legacy-dual')Object.assign(raw,{est_model:true,est_model_stale:false,est_kind:'overseas_model',last_nav:1,nav_date:'2026-09-29',est_nav:1.03,est_change:3,est_time:'2026-09-30 14:44:00',est_model_time:'2026-09-30 14:44:00',est_model_base_nav:1,est_model_base_date:'2026-09-29',est_model_target_date:'2026-09-30',est_model_weight:100,est_model_version:'rule-v1',est_confidence:'medium',est_note:'合成旧跟踪指数代理说明'});
  const stocks=spec.holdingChange==null?null:Array.from({length:6},(_,index)=>({code:String(600001+index),name:'合成股票'+(index+1),ratio:10,market:'cn',change:spec.holdingChange,quoteTime:spec.holdingTime||'2026-09-30 14:43:00'}));
  const holdingEstimate=stocks?holdings.calculateHoldingsEstimate(stocks,{now:NOW,reportDate:'2026-06-30',requireCurrentReport:true}):null;
  if(stocks){check('setup: six legal current holdings usable',holdingEstimate.available&&holdingEstimate.coverage===60&&holdingEstimate.quoteCount===6,{available:holdingEstimate.available,coverage:holdingEstimate.coverage,count:holdingEstimate.quoteCount},{available:true,coverage:60,count:6});}
  const composed=holdings.composeFundEnrichment(raw,{officialNavMove:move,holdingsEstimate:holdingEstimate}),afterCompose=structuredClone(composed);
  const quotes=spec.marketChange==null?{}:{sh000300:{changePct:spec.marketChange,sourceTime:'2026-09-30 14:44:00'}};
  model.applyOverseasModelEstimate(composed,quotes);
  const identity={fundCode:CODE,fundName:NAME,market:session.classifyMarketKind(NAME),assetKind:session.classifyAssetKind(NAME)},quoteCandidates=normalizer.buildFundQuoteCandidates(composed,{...identity,fetchedAt:new Clock(NOW).toISOString(),now:NOW}),selected=normalizer.selectPreferredQuote(quoteCandidates,identity,{now:NOW});
  output={spec,loadedConfig,selectedModel,raw,move,stocks,holdingEstimate,afterCompose,afterApply:composed,quotes,quoteCandidates,selected};
  for(const expected of spec.expected){const matches=quoteCandidates.filter(item=>item.sourceId===expected.sourceId);check(expected.sourceId+' exactly one candidate',matches.length===1,matches.length,1);const actual=matches[0];if(!actual)continue;check(expected.sourceId+' is usable',usable(actual),actual.status,'not stale/unavailable');for(const key of ['sourceId','valueKind','observedAt'])check(expected.sourceId+' '+key,actual[key]===expected[key],actual[key],expected[key]);for(const key of ['value','changePct','coverage'])number(expected.sourceId+' '+key,actual[key],expected[key]);check(expected.sourceId+' fund identity',actual.fundCode===CODE,actual.fundCode,CODE);number(expected.sourceId+' base NAV',actual.baseNav,1);check(expected.sourceId+' base/target dates',actual.baseNavDate==='2026-09-29'&&actual.targetDate==='2026-09-30',[actual.baseNavDate,actual.targetDate],['2026-09-29','2026-09-30']);}
  for(const source of spec.absentSources||[])check(source+' absent',!quoteCandidates.some(item=>item.sourceId===source),quoteCandidates.filter(item=>item.sourceId===source),[]);
  for(const source of spec.unusableSources||[])check(source+' cannot claim usable unsupported provenance',quoteCandidates.filter(item=>item.sourceId===source).every(item=>['stale','unavailable'].includes(item.status)),quoteCandidates.filter(item=>item.sourceId===source),[]);
  for(const [key,expected]of Object.entries(spec.selected||{})){if(typeof expected==='number')number('selected '+key,selected[key],expected);else check('selected '+key,selected[key]===expected,selected[key],expected);}
 }catch(caught){error={name:caught.name,message:caught.message,code:caught.code??null,instanceofError:caught instanceof Error};}
 finally{globalThis.Date=NativeDate;globalThis.fetch=oldFetch;for(const [key,d]of Object.entries(storageDescriptors)){if(d)Object.defineProperty(globalThis,key,d);else delete globalThis[key];}}
 const frozenEvents=structuredClone(events),frozenGuard={...guard};
 check('no real fetch/storage accesses',guard.fetch===0&&guard.localStorage===0&&guard.sessionStorage===0,frozenGuard,{fetch:0,localStorage:0,sessionStorage:0});
 const failureKind=error?'SETUP_OR_SUT_EXCEPTION':checks.some(item=>!item.pass&&item.name.startsWith('setup:'))?'SETUP_GUARD_FAILURE':checks.some(item=>!item.pass)?'FINANCIAL_SOURCE_RED':'PASS';
 records.push({id:spec.id,forecast:spec.forecast,failureKind,error,checks,events:frozenEvents,guard:frozenGuard,actual:snapshot(output),json:jsonRecord(output)});
 assert.equal(error,null,'Unexpected setup/SUT exception is not credited as financial RED: '+JSON.stringify(error));
 const failures=checks.filter(item=>!item.pass);assert.equal(failures.length,0,JSON.stringify({id:spec.id,failureKind,failures}));
});
after(async()=>{
 let postflightError=null;try{await verifySources('after all tests');}catch(error){postflightError={name:error.name,message:error.message};}
 await writeFile(resolve(plan.output,'actual-results.json'),JSON.stringify({schema:1,scope:'Independent P1 source-correctness regression; not old compatibility oracle',root:plan.root,cases:cases.length,completed:records.length,records,sourceChecks,postflightError},null,2)+'\n',{flag:'wx'});
 assert.equal(postflightError,null);assert.equal(records.length,cases.length,'All fixed cases must complete, including controls after RED');
});
