import {readFileSync,writeFileSync,mkdirSync,cpSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='D:/AI项目/FundVal',dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex');
const paths=['js/holdings-estimate.js','js/runtime/fund-model-enrichment.js','js/runtime/quote-normalizer.js','js/accuracy.js','js/app.js','js/overseas-model.js','data/overseas-models.json','package.json','package-lock.json','scripts/build-site.mjs','scripts/release-fingerprint.mjs'];
const before=resolve(dir,'before');assert.equal(existsSync(before),false);mkdirSync(before);
const files=paths.map(path=>{const b=readFileSync(resolve(root,path)),target=resolve(before,path);mkdirSync(dirname(target),{recursive:true});cpSync(resolve(root,path),target,{errorOnExist:true,force:false});return{path,bytes:b.length,sha256:sha(b)};});
const natives=[];
for(const[label,args]of[['head',['rev-parse','HEAD']],['branch',['branch','--show-current']],['index',['diff','--cached','--binary']],['patch',['diff','--binary']]]){
 const r=spawnSync('git',args,{cwd:root,windowsHide:true,encoding:null,maxBuffer:8_000_000});assert.equal(r.status,0);
 const stdout=r.stdout||Buffer.alloc(0),stderr=r.stderr||Buffer.alloc(0);for(const[k,b]of[['stdout',stdout],['stderr',stderr]])writeFileSync(resolve(dir,label+'.'+k),b,{flag:'wx'});
 natives.push({label,args,exitCode:r.status,stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}});
}
const protocol='docs/v16.0.0/performance-evidence/model-provenance-fix-20261022/PROTOCOL.md';cpSync(resolve(root,protocol),resolve(dir,'PROTOCOL.md'),{errorOnExist:true,force:false});
const out={schema:1,at:new Date().toISOString(),root,files,natives,protocolSha256:sha(readFileSync(resolve(root,protocol)))};
writeFileSync(resolve(dir,'before.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({files:files.length,sourceFrozen:true,nativeChecks:natives.length}));
