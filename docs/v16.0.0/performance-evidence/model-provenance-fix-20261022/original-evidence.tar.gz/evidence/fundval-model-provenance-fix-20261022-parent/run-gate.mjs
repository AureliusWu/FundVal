import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,lstatSync,cpSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {createServer} from 'node:net';
import assert from 'node:assert/strict';
const root='D:/AI项目/FundVal',dir=import.meta.dirname,label=process.argv[2];
assert.match(label||'',/^(targeted|test|check|build|e2e|budget|graph)-\d{2}$/);
const output=resolve(dir,'gates',label);mkdirSync(resolve(dir,'gates'),{recursive:true});mkdirSync(output);
const sha=b=>createHash('sha256').update(b).digest('hex');
function inv(base,exclude=new Set(),part=''){
 const rows=[];for(const e of readdirSync(resolve(base,part),{withFileTypes:true})){
  if(!part&&exclude.has(e.name))continue;const path=part?part+'/'+e.name:e.name,p=resolve(base,path);
  assert.equal(lstatSync(p).isSymbolicLink(),false);
  if(e.isDirectory())rows.push(...inv(base,exclude,path));else{const b=readFileSync(p);rows.push({path,bytes:b.length,sha256:sha(b)});}
 }return rows.sort((a,b)=>a.path.localeCompare(b.path));
}
const before=inv(root,new Set(['.git','node_modules','site','Temp','.claude','docs']));
const sources=['js/holdings-estimate.js','js/runtime/fund-model-enrichment.js','js/runtime/quote-normalizer.js','js/app.js','js/accuracy.js','test/model-provenance-v16.test.js','test/model-consumers-v16.test.js','test/accuracy.test.js','e2e/v16-refresh.spec.js'];
for(const path of sources){const p=resolve(output,'source',path);mkdirSync(dirname(p),{recursive:true});cpSync(resolve(root,path),p,{errorOnExist:true,force:false});}
const env={...process.env,SOURCE_DATE_EPOCH:'1792046773'};
if(label.startsWith('e2e-')){
 const server=createServer();await new Promise((ok,no)=>{server.once('error',no);server.listen(0,'127.0.0.1',ok);});
 env.FUNDVAL_E2E_PORT=String(server.address().port);await new Promise((ok,no)=>server.close(error=>error?no(error):ok()));
}
const npm='C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js';
const kind=label.split('-')[0];
const args=kind==='targeted'?['--test','test/model-provenance-v16.test.js','test/model-consumers-v16.test.js','test/accuracy.test.js','test/quote-contract.test.js','test/quote-period.test.js','test/cache-fund-identity-v16.test.js']
 :kind==='budget'?['scripts/release-fingerprint.mjs','--assert-app-bundle-budget','site']
 :kind==='graph'?['scripts/release-fingerprint.mjs','--verify-app-module-graph','site']
 :[npm,...(kind==='test'?['test']:['run',kind==='e2e'?'test:e2e':kind])];
const startedAt=new Date().toISOString(),r=spawnSync(process.execPath,args,{cwd:root,windowsHide:true,encoding:null,maxBuffer:60_000_000,env});
const stdout=r.stdout||Buffer.alloc(0),stderr=r.stderr||Buffer.alloc(0);for(const[k,b]of[['stdout',stdout],['stderr',stderr]])writeFileSync(resolve(output,'native.'+k),b,{flag:'wx'});
const after=inv(root,new Set(['.git','node_modules','site','Temp','.claude','docs']));
const unchanged=JSON.stringify(before)===JSON.stringify(after);
let artifact=null;
if(kind==='build'&&r.status===0){
 const files=inv(resolve(root,'site')),manifest=JSON.parse(readFileSync(resolve(root,'site/js/app-chunks.json'),'utf8'));
 const chunks=manifest.chunks.map(row=>{const b=readFileSync(resolve(root,'site',row.path));return{...row,actualGzip:gzipSync(b).length,actualSha256:sha(b)};});
 for(const row of chunks){assert.equal(row.gzipBytes,row.actualGzip);assert.equal(row.sha256,row.actualSha256);}
 artifact={files,rowsSha256:sha(JSON.stringify(files)),allGzip:chunks.reduce((n,r)=>n+r.actualGzip,0),coldGzip:chunks.filter(r=>manifest.coldStart.includes(r.path)).reduce((n,r)=>n+r.actualGzip,0),chunks};
 for(const path of[...manifest.chunks.map(r=>r.path),'js/app-chunks.json','index.html','sw.js']){const p=resolve(output,'selected-site',path);mkdirSync(dirname(p),{recursive:true});cpSync(resolve(root,'site',path),p,{force:false,errorOnExist:true});}
}
const result={schema:1,label,command:process.execPath,args,cwd:root,startedAt,finishedAt:new Date().toISOString(),nativeExit:r.status,signal:r.signal,error:r.error?.message??null,environment:{SOURCE_DATE_EPOCH:env.SOURCE_DATE_EPOCH,...(env.FUNDVAL_E2E_PORT?{FUNDVAL_E2E_PORT:env.FUNDVAL_E2E_PORT}:{})},stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)},sourceUnchanged:unchanged,before,after,artifact};
writeFileSync(resolve(output,'receipt.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({label,nativeExit:r.status,signal:r.signal,error:result.error,stdout:result.stdout,stderr:result.stderr,sourceUnchanged:unchanged,artifact:artifact?{count:artifact.files.length,rowsSha256:artifact.rowsSha256,allGzip:artifact.allGzip,coldGzip:artifact.coldGzip}:null}));
process.stdout.write(stdout.toString().split(/\r?\n/).slice(-24).join('\n'));if(stderr.length)process.stderr.write(stderr.toString().slice(-3000));
process.exitCode=unchanged?(r.status??99):97;
