# FundVal storage structural audit, 2026-10-23

Verdict: BOUNDED_NO_NEW_MATERIAL_RETIRABLE_ALGORITHM_CLOSURE.

The requested storage/Gist/default-graph cuts do not yield a new large independent equivalent algorithm body that can be retired. This is a bounded read-only result, not proof that arbitrary whole-program optimization is impossible. No source variant, application execution, test, build, compression probe, install, configuration change, dependency change, or repository write was performed. Only this worker-owned Temp report was created. M3 remains IN_PROGRESS / 15.0.2; there is no new behavior, latency, cloud, production or admission PASS.

## Inputs and fresh verification

- Read FundVal AGENTS.md in full, observed the existing dirty Git tree, and left it intact.
- Read M3_STATUS historical exclusions, especially lines 729-745, 775, 940 and 1046, and the complete archived storage-review/README.md from docs/v16.0.0/performance-evidence/audit-closure-20261022/original-evidence.tar.gz. Did not recycle serializer/factory/push-pull/helper proposals.
- Consumed the parent's actual-original-recipe metadata: C:/Users/84046/AppData/Local/Temp/FundVal-module-attribution-20261023-parent/RESULT.json, SHA256 757beee5901d0885047aa5801283aab797411a058137b7920909c702e935fd7f. It contains 59 module rows and 16 chunks, all 85969 / cold 46149 against original budgets 77227.7 / 52241. These totals are metadata observations, not a newly executed measurement.
- Independently read/hash-verified the two relevant existing site chunks against that metadata. startup-pure-v6vu1dD4.js is 27349 raw, SHA256 7dd48635ddcf9a90188cebbb0478fbb2b8ac6f79f3f09c1a4b8b74b3ee2bcae4; cloud-BVcoxrTL.js is 18689 raw, SHA256 ad7e821f573a370ec18a5be61dc9d7c101bb507999a7deef1848c0a05d2fbda7. Existing metadata gzip is respectively 8263 and 6379, not marginal module costs or savings. startup-pure is also byte-identical to the 10-22 archived existing chunk. The cloud chunk differs from the old whole chunk, so old cloud body-size attribution is not silently promoted to a new exact body-size measurement.
- Fresh SHA256 comparisons to the archived inventory are equal for all 10 selected files: storage.js, holdings-schema.js, holdings-migration.js, holdings-repository.js, cloud-sync.js, gist-remote.js, cloud-archive-ui.js, cloud-runtime.js, gist-runtime.js and startup-repository.js. Thus the large storage algorithms and the prior concrete non-equivalence observations have not changed during later correctness work. Read current app consumers, holdings-transfer, holding-edit and OCR import transaction as well.
- Applied performance-regression-check to attribution and measurement limits only. The explicit no-test/no-build task takes precedence over its usual measurement workflow. No raw/rendered count is converted into a claimed gzip gain or a promise to close the 8742-integer-byte all gap.

## Default graph ownership

Each module below has a single row/owner in the actual current metadata. Cloud imports startup-pure rather than embedding another Schema 3 repository. These rendered lengths are pre-minification attribution, not gzip.

| Module | Owner / role | renderedLength |
| --- | --- | ---: |
| holdings-repository | startup-pure / cold | 21823 |
| holdings-migration | startup-pure / cold | 10436 |
| holdings-schema | startup-pure / cold | 7518 |
| cloud-sync | cloud / lazy | 20246 |
| cloud-archive-ui | cloud / lazy | 8760 |
| gist-remote | cloud / lazy | 5830 |

The complete existing startup-pure chunk is unchanged since the prior bounded review. Large live bodies are load, persist, recovery, legacy editing, deterministic migration and origin-aware merging; they are different responsibilities, not two retained copies of one algorithm. A large module total is not a retireable closure.

The current rendered export list does not retain schema mergeHoldingsDocuments, cloud requiresSchema3CloudUpgrade, the one-value reconcileCloudBridgePayload wrapper, Gist hasHoldingsGistFile, or storage.js's old cache/cloud/backup helpers. They remain public compatibility APIs in source. Removing their source would violate compatibility without establishing default-graph savings. This observation is supported by the actual per-module renderedExports plus current explicit production imports, not an assumption that renderedExports equals chunk exports.

## Specific closure decisions

### 1. Cloud push versus pull: not equivalent state machines

cloud-sync.js:314 and :544 share adapter validation/GET/parse/merge tokens, not a retireable complete engine. Push does a bounded backup-stability loop, a second local-persistence stability loop, PATCH, a second GET, device-target and canonical readback, a current-local reload, a possible post-PATCH merge/backup/persist, and metadata finalization. Pull does one GET, backup, origin-aware merge, optional local persist and pending comparison; it never PATCHes. The current app push/pull wrappers also differ in pending marking, error behavior, rendering and return paths (app.js:436/:478).

A callback-policy mega-engine would still contain these branches and add a policy representation; it would not retire the two algorithms as equivalent. This is the already-rejected direction at M3_STATUS:745/:940 and app common-cloud orchestration at :775, not a new proposal. Await order, number of request/load/backup/persist calls, error identities, positive-ack semantics, readback phases, post-upload edits and lock windows would all be required proof obligations for any future different design. No such candidate is justified here.

### 2. Schema normalization versus canonicalization: shared implementation, not duplicate copies

holdings-schema.js:67/:102/:139/:143/:188/:201 and cloud-sync.js:38/:50/:111/:125/:151 call the same normalizers. Removing repeated calls cannot retire that validator because external repository, transfer, edit and cloud paths still require it. makeCloudWritePayload(value,3) also intentionally returns a new mutable JSON projection, not the frozen normalized object. Its Schema 2 branch stays reachable for pull-only legacy comparison even though PATCH is V3-only. toLegacyHoldings includes note; cloud legacyHolding omits it.

Any narrower future optimization must preserve full UTF-8 canonical bytes/key order, null/0/-0, normalization and error/read order, Date/JSON built-in observations, allocation/freeze/mutability and caller non-mutation. Existing canonical tests do not constitute arbitrary getter/Date/JSON call-trace qualification. The historical canonical reconstruction was already removed; the current large normalizer is not a fresh serializer twin.

### 3. Migration versus old-tab legacy reconciliation: different trust and edit rules

holdings-migration.js:21/:34/:65 and holdings-repository.js:436 are not equivalent. Migration captures a scalar before legacyNumber validation; local reconciliation independently rereads shares for Number/typeof/String. They expose different error messages/details. Migration deterministically assigns revision 1 and stable IDs; reconciliation preserves current rows absent from input, unchanged-null-versus-old-zero semantics and missing notes, checks allowRestoreCodes, protects tombstones and increments revisions for real edits.

Sharing the loops would need policies and access schedules, not deletion of an equivalent independent algorithm. compareHoldingRecords and compareCompatibleRecords likewise deliberately order revisions/device/timestamps differently and use different fingerprints. The common strict V3 validation is already shared. The old schema identity-map merge is absent from the default product; migration's surviving small map bookkeeping is the previously recorded non-material lead, not a new large pool.

### 4. Repository transactions, recovery and backups: distinct protocols

holdings-repository.js:126/:139/:214/:248/:353 are live but not duplicated algorithms. Repository backup returns Boolean and performs one kind of rotation; cloud snapshot backup has versioned snapshot serialization, rotation readback and structured reason codes. Recovery decides finalized/not-applied/rollback/foreign-change; persist prepares a journal, verifies V3 and V1/projection state, and publishes only a committed verified document. The repeated journal-membership predicate was already measured at M3_STATUS:731 and the three-variant storage combination at :732, not a fresh whole-transaction candidate.

Future proof must preserve fresh future-schema checks, journal-owned rollback versus foreign writes, raw compare-and-swap, every Storage access/write failure and short-circuit order, recoveryRequired, backup rotation/readback and zero publication of failed candidates. No network await may move inside an origin lock. Startup/load cannot reuse a pre-lock snapshot across a concurrent edit. Shared safe-storage wrappers differ in undefined-to-null and parameter/default getter behavior and are only tiny helpers.

### 5. Gist scanning/readback and archive create: no large retained twin

gist-remote.js:54/:63 performs a first enumeration, sorted all-shard validation/limit/merge, target canonical checking, then a second late backup enumeration. The backup pass is small and has different getter/throw timing; folding it into the first scan moves backup enumeration before failures. The device hash, shard filename rule, five-page discovery with V3 preference and current-device-only PATCH are distinct algorithms without retained peers. Sorting, cap64, retained canonical/legacy files and all-shard merge cannot be deleted.

Archive POST/readback (cloud-archive-ui.js:14) resembles only the tail of sync PATCH/readback. It has a newly created id that must be retained on inconclusive verification and no original remote snapshot; it uses the same remote adapter and cloud canonical APIs already. A shared readback-result helper is at most a small token-level factoring, not retirement of a new large closure. Its late metadata lock must reread current local data so edits during POST/readback stay pending. Unknown/unverified outcomes must not be upgraded to success or automatically treated as safe resend by an equivalence refactor; no M4 synchronization feature is introduced.

### 6. Local import, edit and restore callers: independent entry policies

holdings-transfer's file import captures a whole-document CAS baseline and merges; restore validates raw primary bytes captured before waiting, future backup schema and a fallback sequence. holding-edit checks the record actually shown, cancellation/conflict and explicit tombstone restore. OCR import validates only selected baseline identities and requires its pending flag before a confirmed save. Each calls the one authoritative repository. Their outer policies cannot be collapsed as duplicate storage engines or deleted from the default graph. OCR-only transaction code is not a second default application implementation.

## Decision and evidence boundary

No new default-graph large independent algorithm closure is recommended for qualification or implementation from these cuts. In particular, do not spend another build series on the prior serializer/helper/membership/common-cloud proposals. The fresh evidence is current source identity plus actual graph ownership and current chunk identity, not a recycled old performance PASS. The prior bounded review remains applicable to these unchanged storage sources, while current all/cold totals remain the new metadata totals above.

If another area identifies a genuinely retained equivalent algorithm body, require a complete old/new public surface, bytes/error/access/call/await/lock trace protocol before any authorized same-recipe deterministic build measurements. Do not change Schema3, shards, tombstones, legacy retention, public APIs, locks, transaction/error semantics, dependencies/compiler/five groups/budgets or move data off-budget to create a PASS.
