# FundVal UI structural retirement audit — 2026-10-23

## Result

No new material, closed retirement pool was established in the requested app/DOM/editor/transfer/calculator/presentation scope. Do not create an 8 KB promise from this review. The only newly isolated fully private state retirement is `loadingDetails`, which is not material and has no measured product gzip benefit. No candidate build, test, browser/app execution, product edit, dependency operation, Git mutation, or remote write was performed. This report is the sole file written, in a new exclusive OS Temp directory.

Current source was read after the full `AGENTS.md`. `git status --short` showed existing tracked/untracked user work, including app and M3 evidence. This review preserved it; it does not claim an independently captured whole-tree before/after fingerprint under parallel work. Parent-supplied current all/cold values are 85,969 / 46,149 B and original all budget 77,227.7 B. Existing `site/js/app-chunks.json` lists those chunk measurements. No fresh build or budget command was run.

## Exclusions respected

Read the current M3 sections and `docs/v16.0.0/performance-evidence/private-vertical-20261023/README.md`. Do not repeat the rejected private routing prototype (+1,369 all gzip); do not repeat DOM ID helpers, action switches, function layout, shared formatters, or string pooling. The previous private canonical UI/summary formatter is explicitly rejected at M3_STATUS.md:644 (only -72 all / -74 cold in that historical experiment). These are historical evidence, not measurements from this review.

No minifier/dependency/target/five-group/budget change, no JS/template relocation into HTML/data, no financial-rule or feature deletion is proposed.

## Default production reachability: the large UI responsibilities remain live

The root is `index.html` -> `js/bootstrap.js`; bootstrap imports `app.js` only after repository recovery/migration/integrity. App `initActionBindings` (2125) installs the delegated click dispatcher (2099) and file change handler; app startup (2147 onward) loads holdings, cache, models, refresh, timers, notifications, and cloud polling. Dynamic import is not equivalent to unreachable: all lazy chunks remain within the all-app budget.

### Fund list and details

`refresh/startup/cache/repository install` -> `renderFundList` (1387) -> `normalizeFundQuoteFreshness` + `holdingQuoteAmounts` -> `sortFunds` + `createQuotePresentation` -> complete collapsed and expanded HTML. The expanded route is `data-action=toggle-fund` emitted at app:1436 -> click dispatcher -> `toggleFundDetail` (1229) -> lazy quote diagnostics/security features -> `fetchFundDetails` (1262). That closure includes:

- `loadFundHoldings` (1186), `holdingsCacheIsFresh` (1181), `loadFundHoldingsFeature` -> `fetchFundHoldings`;
- `fetchHoldingsQuotes` (1340) -> lazy security and holding-code APIs -> `executeDetailSecurityQuotes` -> `fetchSecurityEastmoney` (1362), `fetchSecurityBridge` (1371), `normalizeTencentQuoteTime`;
- `inferFundType` (1328), metadata/fee cache fallback (1298–1320);
- `renderQuoteDiagnostics` (1380) -> `runtime/quote-diagnostics.js` -> all quote presentation fields;
- sort, focus restoration, escaping, formats, and trust/source/period notices.

Not safely retired: active refresh does **not** guarantee each disclosure, NAV or metadata resource succeeds. `refresh-execution.js:103–138 getNav` can return null/cached NAV without publishing metadata (metadata task catches non-abort errors and only calls UI when a meta entry exists). The holdings task can return null without installing a cache. Thus the detail path must still retry missing disclosure/security data and infer missing type/fees. Awaiting `refreshCoordinator.activePromise` in `fetchFundDetails` does not establish that these per-resource caches are populated. Replacing this entire closure with planner routing would revisit the rejected private prototype, not establish a newly dead duplicate algorithm.

### Holding editor

`index.html:90–108` gives live input/save/cancel controls. `renderHoldingsList` (1581) emits edit/delete actions; `renderFundList` emits edit; dispatcher routes to `editFund` (1597), `saveFund` (1627), `cancelEdit` (1614), `delFund` (1670). The write closure is `saveHoldingEdit` (239) -> lazy `business-features.commitHoldingEdit` -> `runtime/holding-edit.js` -> `loadHoldingsRepository`, `holdingRecordFingerprint`, `saveLegacyHoldingsTransaction`, repository lock/CAS/migration. Installation returns through `installHoldingsDocument` and `reconcileActiveFundState`, then rendering/auto-push/refresh.

Draft detection is not a duplicate validation engine: `holdingEditorValue` (1875) -> `hasUnsavedHoldingEditorInput` (1880) compares the displayed string draft to the captured baseline, while save validates numeric/code domains and repository commit guards the original conflict baseline. Draft detection is consumed by edit switching and SW/beforeunload protection (1898–2024). Unifying or removing one is not a closed retirement without changing draft/conflict/update behavior.

### Export, import, restore

`index.html:127,132–134` -> dispatcher export/pick-import/restore and `imp-file` change binding -> app wrappers (305–316) -> lazy `business-features.createHoldingsTransfer` -> `runtime/holdings-transfer.js` closure. Its helpers are all live:

- export: canonical holdings document + dynamically imported `accuracy.loadAccuracy` -> Blob/object URL/download/revoke;
- import: FileReader -> JSON parse -> `parseAndMigrateHoldings` -> `mergeParsedHoldings` -> locked `persistHoldingsDocument` with expected document -> install/auto-push/render/refresh;
- restore: capture both raw repository keys before lock -> compare under lock -> parse latest V3/V1/legacy backups -> `isFutureSchema` guard -> migration -> locked persist -> install/render/auto-push/refresh.

These are different input/backup/transaction semantics, not three copies of one import engine. Restore must preserve future-schema refusal and raw CAS for a damaged local document. Import must merge rather than overwrite and refuse empty auto-overwrite. Export must keep overseas accuracy. No whole branch is unreachable or removable under preserved functionality/compatibility.

## Calculator and presentation: apparent duplicate pools are not new material savings

### Already outside the live retained closure

- `app.js:1093 preferredDailyMove`: production source search has no caller; `isOverseasFundEstimate` (1074) and `parseNav` (1070) likewise have no production caller. `latestNavMoveOf` is **not** dead: expanded list calls it at 1454; `isOverseasLikeFund` is live through accuracy scheduling.
- `calculator.js:4 normalizeFundEstimate` and `:35 chooseDisplayValue`: source consumers found are tests, not production JS. `calculateHolding` is live through `holding-quote-amounts.js`; `resolveQuoteBaseNav` is live there and in app build (691).
- Existing built `post-integrity-Dp7m1bj2.js` does not contain the unique dead preferred-move labels `海外非实时` or `下一净值海外市场模型估算`, while live labels remain. This is consistent with existing tree shaking, not a measured removal delta or a complete semantic equivalence proof. Do not count deleting this raw source as a new app-byte retirement.

### Retained calculation is not safely redundant

`holdingQuoteAmounts` (runtime/holding-quote-amounts.js:7) creates a valuation period, checks quote usability and calls `calculateHolding`; UI reads current value, total profit/rate and period-derived profit. `calculateHolding.todayProfit` is not consumed by this private caller, but its exported test/API contract remains and its simpler baseline rule is not interchangeable with `createValuationPeriod`'s cache/date/single-session policy. Specializing a private calculator merely to stop that one unused field is small, would touch financial calculation structure, and has no measured gzip benefit. Not a material candidate in this task.

### Full presentation closure is live

`createQuotePresentation` (quote-presentation.js:158) is consumed in list rendering and latest-source summary (app:1018). Its closure contains `formatQuoteDateTime`, `formatQuoteDataTime`, `timestampOf`, `chinaParts`, `dateKey`, `dateDayIndex`, `finiteNow`, `quoteConfidenceLabel`, `quoteCoverageLabel`, `quoteReasonSummary`, `modelLike`, source/market/status/reason label tables and valuation period. Collapsed list consumes headline fields; lazy diagnostics consumes the source/fetched times, status, dates, trust, model and reason fields. There is no observed large unused presentation field family whose removal retires these algorithms. Summary specialization is the previously rejected -72 B family, not a new proposal.

## Two narrowly bounded static observations, neither material

### A. Fully private state-only candidate: retire `loadingDetails`

Complete lexical reference set in app: declaration at 74; assignment null in collapsed toggle at 1237; assignment code on detail entry at 1263; comparison/reset in `finally` at 1324. No other reader, export, alias, callback publication or direct eval/Function/window publication was found in app. The final read controls only another write to the same module-private primitive. It does not currently guard reentry despite its comment.

Smallest executable candidate (not performed): remove that binding, the two assignments, and the `fetchFundDetails` try/finally shell whose only finally action is that private comparison/reset. Leave the body, abort/generation checks, await/order, renders and error propagation unchanged. Correctness obligations: prove no escaped lexical lookup; compare resolve/reject/return timing and all fetch/render/abort sequences, including concurrent detail switches and failures. Native minifier may already eliminate part/all of it; do not predict gzip from raw lines. This is state cleanup, not a new material structural engine retirement; not recommended as the M3 recovery project.

### B. Render metadata tail: no safe feature-removal recommendation

App:1525–1539 still emits setupDate/company/benchmark/sellFee/manageFee/custodyFee rows. The current wire-to-UI own-field producers are narrow: `fetchLatestNavMoveRaw` (629–636), `refresh-resource-cache.js:META_FIELDS` (11), `metadata` (28), UI metadata writer (app:961–968), and detail fallback writer (1301–1319). These do not generate those six own fields. The real post-integrity chunk nevertheless retains all six Chinese row labels. This is a narrow current-own-field reachability observation, **not** a closure proving compatibility deletion safe: objects use ordinary prototypes, tests deliberately characterize arbitrary caches/getters, and `test/app-rules-row-characterization.test.js` preserves these complete rows/read/coercion boundaries. Dropping rows would require an explicit private closed-state/domain proof and compatibility decision. It retires only small conditional row emissions, not a large repeated algorithm; no 8 KB claim is justified.

## Recommendation

Stop the UI retirement search at this bounded negative result. Do not run another helper/formatter/template rewrite or implement the tiny state cleanup as if it could close an 8,742 integer-byte deficit. If another independent review finds a genuinely large closed responsibility elsewhere, evaluate that unique candidate in an exclusive frozen A/B with original recipe and whole all-app accounting. Otherwise report the unresolved budget honestly; this review gives no basis for removing features, weakening compatibility, changing financial rules, or proceeding beyond M3.
