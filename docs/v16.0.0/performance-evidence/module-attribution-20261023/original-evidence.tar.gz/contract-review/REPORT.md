# FundVal M3 contract/date structural audit — no new large retirement pool

2026-10-23. Read-only source and existing-artifact review. No build, test, app execution, root edits, compiler experiment, budget/group/dependency change, commit, push, or deployment.

## Result

No newly identified, closed production-default algorithm can be retired in the assigned Quote/clock/session/freshness/calculator area while retaining all public APIs, input validation, cache provenance, model evidence and observable getter/error/clock behavior. In particular, this review does not offer a candidate expected to fill the current 8,742-integer-byte all-gzip gap.

This is a bounded negative result, not proof that no wider architecture can improve. No raw-to-gzip conversion, hypothetical gzip saving, or new benchmark is claimed. Current 85,969 all / 46,149 cold values are the existing M3 §52–55 receipts, not measurements rerun here.

## History deliberately not repeated

Read AGENTS.md, M3_STATUS.md, performance-evidence/README.md, and private-vertical-20261023/README.md. Relevant prior exclusions:

- §30 larger-boundary probes: quote/wire final parse-tail sharing was all −9 B / cold −4 B; including overseas tail was 0 / −3. Model envelope prefix was −9 / −8, period enum reuse −3 / −6, descriptor tuple +9 / +11. These are old helper outcomes, not current-identity results.
- §30 HTTP canonical projection retained a second wire validator yet failed ChangingDate safe-rescue behavior. It must not be revived as “already trusted canonical” optimization.
- §40: finite clock/HMS helper sharing reached only −33 B all in its old identity. Its exact-coercion traces did not authorize deleting validation.
- §55: full private vertical route's A exactly reproduced current artifacts; B was 87,338 all / 46,005 cold, +1,369 all, rejected. Its generic Quote/cache paths and public compatibility code were necessarily retained. This review does not suggest that same pipeline again.

## Closure and boundary findings

### 1. Legacy-looking session/freshness/calculator duplicates are not a production-default retirement pool

The complete `rg` inventory of JS source imports is:

- app.js imports calculator `resolveQuoteBaseNav`, freshness `classifyFundMarket` and `refreshDelayForMarkets`, and session `classifyAssetKind` / `classifyMarketKind`.
- holding-quote-amounts.js imports calculator `calculateHolding` and `resolveQuoteBaseNav`.
- refresh-plan.js imports freshness `classifyFundMarket`.
- diagnostics-ui.js imports session `classifyMarketKind`.
- market-clock.js imports session `MARKET_SESSION_REGISTRY`, `marketStateFromParts`, `normalizeMarketKind`.
- quote-normalizer.js imports session classification/normalization functions.

No JS production import consumes marketSession, refreshDelayForMarketKinds, parseChinaSourceTime, buildFreshness, normalizeFundEstimate or chooseDisplayValue. They remain public/test compatibility APIs. The old market-session Intl zonedParts is reached only from marketSession. Deleting/reimplementing those source-only APIs cannot be counted as deleting a second default production algorithm.

Existing actual chunks were read, not rebuilt. Their three `Intl.DateTimeFormat` sites are attributable to:

1. post-integrity: market-clock cached exchange formatter, includes second/h23 and formatters Map;
2. business-runtime: notification-controller's China-only daily target helper;
3. diagnostics: display formatter.

There is no second legacy market-session Intl implementation in this marker inventory. The plain string `时间异常` is not a safe liveness marker: its existing post-integrity occurrence comes from quote-presentation's “数据源时间异常”, not buildFreshness. Likewise gszzl and overseas_model occur legitimately in wire/model compatibility handling. Marker matches are only corroborating attribution, not a formal binding proof.

### 2. Date/session algorithms are already shared at the safe core boundary

- quote-contract:86 parseQuoteTimestamp calls normalizeQuoteDate:100.
- quote-normalizer imports the same normalizeQuoteDate / parseQuoteTimestamp / nextWeekdayDate; its freshness policy calls marketClock and zonedTimeParts.
- market-clock imports normalizeQuoteDate / nextWeekdayDate and consumes market-session's shared marketStateFromParts.
- holdings-estimate and overseas-model already use the market-clock zonedTimeParts formatter core; the earlier duplicated Intl constructor was already retired (§7).
- chinaDateKey calls chinaTimeParts; there is no separate calendar-date parser per consumer to remove here.

Moving these functions to a new date-core may remove an import cycle, but it would move the same live implementation rather than retire a second large algorithm. Extra facade/wrapper/exports would be new cost. No such move is proposed.

### 3. Quote envelope validation is not the same algorithm as freshness/evidence/resource validation

- createQuoteEnvelope:128 normalizes public input grammar and enums, provenance, cache timestamps, future skew, dates/model period binding, reason normalization, fetchedAt fallback, and frozen result layout. It can preserve change-only quotes and stale data. It does not require a strict acquisition shape.
- freshnessForRow:94 decides missing value/source-marked-stale/date-only/missing/expired/72h Friday carryover/model/open-market/realtime semantics using the real calendar.
- modelEvidenceQuote:247 first inspects own-data descriptors and fixed evidence fields. It rejects foreign fund identity and formula/date inconsistency, then enforces each model's coverage, quote count, disclosure/quarter validity, target date and observed/fetched clocks. It intentionally revalidates persisted evidence; the model writer is not a trust certificate.
- refresh-resource-cache estimateRow:39 demands typed canonical Quote values, registered source capability, no cache metadata, non-stale acquisition status, valid bound dates/clocks, matching legacy aliases and optional strict allowed keys. It then invokes normalizeExistingQuoteFreshness again at use time. Its null/NaN alias placeholders and 1e-7 tolerance differ from wire validation.
- createValuationPeriod validates the displayed comparison period and P/L, not raw source acquisition. Even a named official NAV may be usable while lacking a bound P/L period; stale/historical/today/session labels must remain different.

There is no one duplicate validator whose deletion preserves these distinct acceptance sets. A shared “validated core” that still performs every layer is a migration/helper extraction, not whole-algorithm retirement. A shared “trusted result” that skips any layer violates the requested rule.

### 4. The adjacent wire parser cannot replace the Quote parser

Worker timestamp:23 and Quote parseQuoteTimestamp:86 overlap only in final checked date/HMS conversion. Their contracts differ:

- Worker first uses bounded, string-only contractText and rejects markup/control characters. Quote text coerces non-strings and trims.
- Worker v2 requires T, two-digit fields, seconds and explicit Z/offset; v1 permits space/T, optional seconds, fractional seconds and optional zone. Quote China input allows one-digit month/day/hour with minutes and optional seconds; Quote zoned input requires T and two-digit calendar fields but permits missing seconds.
- Worker rejects offsets beyond 14h and a nonzero minute at ±14:00. Quote relies on the zoned grammar plus Date.parse and does not contain that separate bound.
- Worker source-time aliases must resolve to equal instants, includes a legacy holdings date exception, and emits WORKER_ALIAS_CONFLICT / WORKER_ROW_INVALID at exact boundaries. Quote parser returns null; envelope turns policy failures into stale/unavailable reason codes.

Replacing either with the other changes accepted/rejected values, coercion order or error semantics. A mode-rich common parser would retain their separate regex/policy branches and repeat the old −9-B helper direction; no large algorithm is retired.

### 5. Small live adjacent duplicate, explicitly not a material candidate

notification-controller.js:5 chinaParts / notificationDate / afterDailyTarget are live in business-runtime and overlap China civil-date projection with chinaTimeParts. It is a possible tiny standalone experiment only, not a new large pool or 8,742-B plan. Direct substitution is not yet equivalent:

- old helper constructs Intl each call and returns strings; new core uses Date arithmetic and returns numbers;
- public controller coerces `Number(now())`, checks finite, then old Intl can throw on out-of-range finite dates; chinaTimeParts instead returns null;
- check performs afterDailyTarget, notificationDate, refresh, then a fresh now() for quote eligibility. Combining/reordering readings changes observable clock/Intl traces and notification date ownership;
- weekday/14:30 threshold and lastSent date must keep China semantics, not verified trading-day/holiday semantics.

If separately authorized, closure would be exactly those three private functions plus a market-clock import; APIs and notification policy stay intact. Obligations include independent old-output/trace comparison across boundary dates, 14:29/14:30/23:59, weekends, NaN/Infinity/finite out-of-range, changing Date/Intl behaviors, exceptions, lastSent dedupe, awaited refresh and post-refresh second clock. Only real A/B build bytes could decide whether it saves anything. It should not take precedence as a material M3 fix.

## Required test obligations for any future shared-core proposal

No candidate is nominated for execution. Before any new proposal, its C/K/Z ledger must identify an actually removed live algorithm, retained boundary rules and additional representation cost. Tests must compare independent OLD and NEW public results and observable traces, not two wrappers over the same new core.

- Exact own keys/order, frozen state, null/0/-0/NaN/undefined distinctions and alias precedence/conflict/tolerance.
- Proxy ownKeys/getOwnPropertyDescriptor/get getter order/count; own-data evidence must never invoke an accessor; error identity/name/message/code and throwing/safe-rescue boundaries.
- ChangingDate/default Date.now chronology, fetched/observed/acquired/cached/expires clocks; acquisition versus read/use/stage/flush remains distinct.
- Date-only, leap/nonexistent dates, unpadded China formats, ISO milliseconds/offset bounds, DST and local-to-UTC iteration, Friday carryover, calendar absence/expiry/holidays/early closes, gold overnight.
- Market/holding evidence slot isolation, foreign code, dual-model completion order, notes matched to exact evidence, disclosure/quarter/validUntil expiry and old-cache compatibility.
- Exact existing default graph/API surface, original five groups/compiler/dependencies/target/budget; no trusting internal objects to skip revalidation.
- New actual same-identity A reproduction and B bytes before later QA/performance qualification. Old §52 or historical 800 do not qualify a new candidate.

## Read snapshot hashes (raw source only; no gzip inference)

| File | Raw bytes | SHA256 |
| --- | ---: | --- |
| js/runtime/quote-contract.js | 13,872 | 3ad71a9914d1c198222cb395a7cf92392a2afb0ab0a918ad00ead040d7ffcc8f |
| js/runtime/quote-normalizer.js | 25,008 | 2268033d6f6852ac6b112b7f6ee6611f3788a4936ba88556df8ca0257cf1d07a |
| js/runtime/market-clock.js | 6,866 | 1589765feafd9e19d4fe2ce4ce33f9ccc34e5f0fca262552d11675badbd574c8 |
| js/runtime/market-session.js | 6,534 | d09955352829070f178501007db1a284f904c7e373b804004c1a3f89a7755bbd |
| js/freshness.js | 3,059 | 60dd9eab960587a717bcbdc87103a9f3531e6821164a2ac471cc4cc624dcb6be |
| js/calculator.js | 2,898 | 38c755b7c2415fa5d53de47a252a6f42b44773a3737d7bd200d6f6370b8334c8 |

The snapshot and marker inventory were produced by a read-only Node script using fs/crypto only; it did not import/execute application modules. Source import evidence uses rg over js. Existing test sources were read for obligations; no tests were run. Two incidental read/command errors are not product failures: initial performance-evidence path was missing (correct path is docs/v16.0.0/performance-evidence), and one PowerShell quoting expression failed before executing. A guessed quote-normalizer test filename was also absent; no result was fabricated for it.
