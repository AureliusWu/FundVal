# One original-recipe module attribution capture

2026-10-23. This is a diagnostic capture of the current unchanged §52/55 product, not a new candidate or minifier trial. Use the existing immutable exact A249 source in FundVal-private-vertical-20261023-a1/A and its same-dependency junction. Extract the original Vite config and its original named grouping/isolation helpers from the trusted local build script AST. Do not add plugins, mutate options or execute app modules. One original write:false build returns module metadata and complete actual app chunks.

Require every emitted app path/byte/SHA/gzip and cold set to match A's existing original full-build app manifest before interpreting any metadata. Protect root273/site127/explicit installed68/Git and A source before/after. Preserve native output, source and tool hashes. No source edit, install, live provider, browser, performance sampling, build recipe change or new optimization is authorized by this diagnostic.

Module renderedLength/originalLength/export metadata are bundler diagnostics, not per-module compressed contributions. Do not sum them as actual gzip or estimate a saving from raw lengths. If metadata are unavailable, report unavailable. Candidate selection still needs an actual whole-artifact screen and independent correctness evidence.
