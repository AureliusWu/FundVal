import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve, relative } from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { gzipSync } from 'node:zlib';
import { sha, inv, json, save, state, expected as currentExpected } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';

const here = import.meta.dirname, reference = 'C:/Users/84046/AppData/Local/Temp/FundVal-private-vertical-20261023-a1';
const root = resolve(reference, 'A');
const freeze = json(resolve(reference, 'FINAL_FREEZE.json'));
assert.deepEqual(inv(root, new Set(['node_modules', 'site'])), freeze.A.rows);
assert.deepEqual(inv(resolve(root, 'site')), currentExpected.site);
const before = state(here, 'before');
const require = createRequire(resolve(root, 'package.json'));
const {build: viteBuild} = await import(pathToFileURL(require.resolve('vite')));
const {parseSync} = await import(pathToFileURL(require.resolve('rolldown/utils')));
const source = readFileSync(resolve(root, 'scripts/build-site.mjs'), 'utf8');
const parsed = parseSync('build-site.mjs', source); assert.equal(parsed.errors.length, 0);
const names = ['APP_SHELL_FILENAME', 'APP_CHUNK_FILENAME', 'STARTUP_MODULES', 'POST_INTEGRITY_MODULES', 'BUSINESS_MODULES', 'APP_CHUNK_GROUPS', 'COLD_LAZY_MODULE'];
const functions = ['modulePath', 'collectStaticChunkGraph', 'assertStartupPhaseIsolation'];
const declarations = [];
for (const name of names) {
  const matches = parsed.program.body.filter(node => node.type === 'VariableDeclaration' && node.declarations.some(item => item.id.name === name));
  assert.equal(matches.length, 1, name); declarations.push(source.slice(matches[0].start, matches[0].end));
}
for (const name of functions) {
  const matches = parsed.program.body.filter(node => node.type === 'FunctionDeclaration' && node.id.name === name);
  assert.equal(matches.length, 1, name); declarations.push(source.slice(matches[0].start, matches[0].end));
}
const calls = [];
function walk(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'CallExpression' && node.callee.type === 'Identifier' && node.callee.name === 'viteBuild') calls.push(node);
  for (const [key, value] of Object.entries(node)) {
    if (['parent', 'loc', 'range', 'comments'].includes(key)) continue;
    if (Array.isArray(value)) value.forEach(walk); else if (value && typeof value === 'object') walk(value);
  }
}
walk(parsed.program); assert.equal(calls.length, 1); assert.equal(calls[0].arguments[0].type, 'ObjectExpression');
const expression = source.slice(calls[0].arguments[0].start, calls[0].arguments[0].end);
// Tool-only evaluation of the trusted fixed local builder configuration, not
// product eval/code-as-data or a rebuilt approximation of its grouping rules.
const recipe = new Function('resolve', 'relative', 'root', declarations.join('\n') + '\nreturn {config:(' + expression + '), modulePath, collectStaticChunkGraph, assertStartupPhaseIsolation};')(resolve, relative, root);
assert.equal(recipe.config.build.minify, 'oxc'); assert.equal(recipe.config.build.target, 'es2022'); assert.equal(recipe.config.build.write, false);
assert.equal(recipe.config.plugins, undefined); assert.equal(recipe.config.configFile, false);
let outcome = null, failure = null;
try {
  const result = await viteBuild(recipe.config);
  const outputs = Array.isArray(result) ? result.flatMap(item => item.output || []) : result.output || [];
  const chunks = outputs.filter(item => item.type === 'chunk'), byFile = new Map(chunks.map(chunk => [chunk.fileName, chunk]));
  const entries = chunks.filter(chunk => chunk.isEntry); assert.equal(entries.length, 1);
  const cold = recipe.collectStaticChunkGraph(byFile, [entries[0].fileName, ...entries[0].dynamicImports]);
  recipe.assertStartupPhaseIsolation(byFile, entries[0], cold);
  const manifest = json(resolve(root, 'site/js/app-chunks.json'));
  assert.deepEqual(chunks.map(chunk => chunk.fileName).sort(), manifest.chunks.map(row => row.path).sort());
  const rows = [];
  for (const chunk of chunks) {
    const expected = manifest.chunks.find(row => row.path === chunk.fileName), bytes = Buffer.from(chunk.code);
    assert.equal(bytes.length, expected.bytes, chunk.fileName); assert.equal(sha(bytes), expected.sha256, chunk.fileName);
    assert.equal(gzipSync(bytes).length, expected.gzipBytes, chunk.fileName);
    assert.equal(cold.has(chunk.fileName), expected.role === 'cold');
    assert.deepEqual(bytes, readFileSync(resolve(root, 'site', chunk.fileName)));
    save(resolve(here, 'chunks', chunk.fileName), bytes);
    const modules = Object.entries(chunk.modules).map(([id, value]) => ({
      path: recipe.modulePath(id), keys: Object.keys(value).sort(),
      originalLength: Number.isFinite(value.originalLength) ? value.originalLength : null,
      renderedLength: Number.isFinite(value.renderedLength) ? value.renderedLength : null,
      renderedExports: Array.isArray(value.renderedExports) ? [...value.renderedExports] : null,
      removedExports: Array.isArray(value.removedExports) ? [...value.removedExports] : null,
    })).sort((a, b) => a.path.localeCompare(b.path));
    rows.push({path: chunk.fileName, name: chunk.name, role: expected.role, rawBytes: bytes.length, gzipBytes: expected.gzipBytes,
      sha256: sha(bytes), imports: chunk.imports, dynamicImports: chunk.dynamicImports, exports: chunk.exports, modules});
  }
  rows.sort((a, b) => a.path.localeCompare(b.path));
  const modules = rows.flatMap(chunk => chunk.modules.map(module => ({...module, chunk: chunk.name, role: chunk.role}))).sort((a, b) => (b.renderedLength ?? -1) - (a.renderedLength ?? -1) || a.path.localeCompare(b.path));
  outcome = {status: 'EXACT_CURRENT_CHUNKS_METADATA_CAPTURE_ONLY', sourceCount: freeze.A.rows.length,
    sourceRowsSha256: sha(JSON.stringify(freeze.A.rows)), builderSha256: sha(Buffer.from(source)), toolSha256: sha(readFileSync(import.meta.filename)),
    allGzip: rows.reduce((sum, row) => sum + row.gzipBytes, 0), coldGzip: rows.filter(row => row.role === 'cold').reduce((sum, row) => sum + row.gzipBytes, 0),
    chunks: rows, modules, gzipPerModule: null, isolatedSavings: null, candidate: false, appExecution: false, test: false, performance: false};
} catch (error) { failure = {message: error.message, stack: error.stack}; }
let after = null, postflightError = null;
try {
  assert.deepEqual(inv(root, new Set(['node_modules', 'site'])), freeze.A.rows);
  assert.deepEqual(inv(resolve(root, 'site')), currentExpected.site);
  after = state(here, 'after'); assert.deepEqual(after, before);
} catch (error) {postflightError = {message: error.message, stack: error.stack};}
save(resolve(here, 'RESULT.json'), JSON.stringify({before, after, outcome, failure, postflightError}, null, 2) + '\n');
process.stdout.write(JSON.stringify({status: failure || postflightError ? 'CAPTURE_FAILURE' : outcome.status, modules: outcome?.modules.length,
  top: outcome?.modules.slice(0, 12).map(({path, renderedLength, originalLength, chunk}) => ({path, renderedLength, originalLength, chunk})), failure, postflightError}) + '\n');
if (failure || postflightError) process.exitCode = 2;
