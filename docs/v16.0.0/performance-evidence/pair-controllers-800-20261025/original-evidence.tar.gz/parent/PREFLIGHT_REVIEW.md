# Final controller-candidate paired-performance preflight

2026-10-25T06:26:15.814Z. Verdict: **FROZEN_PREFLIGHT_PASS_NOT_RUN**. The parent may launch the single predeclared `node run.mjs run` experiment after its own launch-preflight succeeds. This reviewer has not started a benchmark, browser, test, build, provider request or Gist operation. This is admission to measure, not a latency PASS, M3 exit, CI or release claim.

Applied performance-regression-check to comparison identity, fixed method, raw-result preservation and scope. Read the complete current runner, independent-audit script, protocol, original recipe review and common helper; inspected the unchanged sampler's parser, order plan, strict lock comparison, statistics, browser lifecycle, source/artifact identity and managed reference build/cleanup. Repository AGENTS.md was read. No repository or runner input was edited.

## Actual frozen inputs

An independent read-only checker executed once in final mode, native exit 0, **14 checks / 0 failures**. It recomputed the entire object and found it deeply equal to actual FROZEN.json, not merely its named SHA fields. Preserved raw Git/process command stdout, stderr and native receipts plus CHECKS.json are in:

`C:/Users/84046/AppData/Local/Temp/FundVal-controller-preflight-final-20261025-a1/final/`

Checker source `check.mjs` SHA256: `a1156bb402183e35d82e4e8dc836ddd7ac26be4a2e8926b3c7347e3a17ecd630`.

| Bound item | Independently observed |
| --- | --- |
| FROZEN.json bytes SHA256 | `5b454cd7c45741487f52bcfb24379cc4256ef0c5d8974aa2334993849679d054` |
| Complete selected source | 281 rows; sorted-JSON row SHA `8b93b2e2476757a381e3788f3f82428b54cfa26fae7fe6f3339a0896f8a71653` |
| Actual complete site | 129 files / 92,564,199 B; sorted-JSON row SHA `94bd2839eb13c06ae0000c98264587936d494eea3e3562786864f812bf5bf5ce` |
| Sampler artifact fingerprint | `bc9173dc63b1b2f8f3f1ca0e810799b1483559b8a8796fd6367c4759929c74a7` (path-NUL-hash algorithm; not the row SHA) |
| HEAD / branch | `170fd3eadc6da02750882f8a542904ee2358d0d9` / `codex/v16.0.0-m3-continuation`; dirty working-tree candidate, not immutable business SHA |
| Staged diff SHA | empty / `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| Same-phase tracked diff SHA | `3c009a2b5b616589a88c99853cc50a1daf5f00c2e19e6bbfac070199d7e4ee33` |
| QA_SOURCE_V3.json bytes SHA | `e30ff4b47e44ee7808a11b0610cf0a035dfbe605e30de4eb2af5c80eee01c9be` |
| Entire qa-v3 evidence row SHA | `edaf84b04a350792c59cf27b6cda4968a7bb4751e6970f7c49eea7e73f1a49f5` |
| Protocol / runner SHA | `ec131ab0f098a3b6bae6fe746efe0efc4b92bea207a719b69bcaae38d66e5e77` / `386e787ad710707b228fd3af3fed88682e66068549c83221fc3f2b3121f3e69a` |
| Post-run audit / common helper SHA | `312820ab11d7ddb22ac62784e435f2b64a690b182020f49f4813f624cfc14f9d` / `b991fa3b0eaa89a6789b914596f24f90fc339cf759d534d69cd5aaa887cea81d` |

The checker read the physical non-doc source inventory, verified the fixed v15 feedback document, rebuilt exactly the full 281-row selection and verified every selected installed68 file's length/SHA. Installed68 is a selected installation identity inventory, not a claim to hash every transitive binary. It verified actual site contents equal both build-01 and build-02 inventories. No incidental E2E files were present in site.

All seven qa-v3 RESULT.json files are LOCAL_GATE_PASS with null failure/postflightError and the same source identity. Every underlying command's actual native exit is 0, signal/error null, timedOut false; the checker verified stored stdout/stderr bytes and SHA against the actual receipt. Artifact phase has five separate receipts (chunks/graph/ocr/fingerprint/budget), not a nonexistent artifact.receipt.json. Test output is 1412 total / 1409 PASS / 0 FAIL / 3 existing Windows skip; syntax223, Chrome35/35, npm audit found0. Browser stderr352B remains preserved. Bundle receipts are actual all86,850/92,160 and cold47,014/52,241, pass true; graph literal closure/static bindings pass but evaluated false; OCR23 assets /88,196,906 B. These are verified existing QA evidence, not checks rerun by this reviewer.

## Fixed comparison and one-run method

- Reference is exactly `057042963a33579c624a41404a6d533dfda29768`; parent `c2980265d3c89f960517ced1527ba9cb85bf7c2b`, tree `40098290fb64d31e0c8fcc12e552b3a913b5c715`, epoch1791676800. Git objects were reread. No ref was created or moved.
- Reference/current normalized locks are strictly identical SHA `db9079726ec21ffe25c4882b47c5c8d5b03a4b5ef3036a587cee9c2e2b6336dc`; normalization removes only root package engines. Declared dependency maps and all actual direct installed versions match. Node24.14.0/npm11.9.0 match.
- Unchanged sampler SHA `2ca754524871b72c3c41f17ec2b6052ac74e3334ad034bf522a933cd9df295d7`; collector SHA `8a98f57980cfcde94e4035987c974b149c80bc27b51a1ca2309d3aed9d85bdd0`.
- Exact args are frozen: **800 retained +4 warmup, AB400/BA400, bootstrap5000, seed160003, timeout30000ms**, actual current root site, new pair-workspace/PAIR.json. No pair/output/launch/stdout/PID/receipt/outcome existed during review. No shortened preview, retries, replacement, outlier deletion, seed/N scan or inherited old raw.
- Original ratios1.15/1.20, absolute current maximum<3000ms, p95 interval width<=0.20 and confidence fraction>=0.95 remain. The unchanged sampler additionally checks save p95; no gate was relaxed. Generic minimum60 does not replace full804 completeness.
- One managed installed headless Chrome390x844; same synthetic clock/fixture and isolation, no-store cold/warm, real synthetic100shares/cost1.2 save. Only isolated reference is rebuilt, using reference epoch; current site is not rebuilt. Runner applies declared current epoch1792046773, FORCE_COLOR0/NO_COLOR1 and removes NODE_OPTIONS/NODE_V8_COVERAGE.
- Runner exclusively preserves raw native logs/status and binds before/after full source/site/selected installed/Git/protocol/tool/recipe/audit/helper/QA-file/entire-QA-tree state. It records this review's hash in LAUNCH. During measurement do not edit source, tracked docs, runner, protocol, dependencies, QA evidence or site, and do not run competing tests/builds/browser experiments.
- Post-run audit requires all804 complete, original order, no failure/replacement, whole summarizePairs object equality, all renderer deltas, exact source/artifacts/lock, health/instrumentation/cleanup/SW/drains and retained console/request counts. It independently executes the unchanged production statistical/renderer helpers; it is **not a second independently implemented statistics algorithm**. Raw native status stays separate from audit status. A failed/incomplete experiment is terminal for this declared run, not permission to relaunch.

## Instant workload observation and limits

Native read-only process check ran 2026-10-25T06:26:15.214Z–06:26:15.813Z, exit0, stderr0, and returned `[]` for matching measurement/test/build/server Node processes and automated Chrome/Edge. It outputs only PID/name/class, not unrelated command lines. This is an instantaneous observation, not a promise that no later OS/user workload can occur. Unrelated processes were not stopped.

Draft diagnostic addendum is retained in the separate review workspace: an unnecessarily escaped process-name regex was replaced before final mode with explicit browser-name membership and `[.]` filenames. Final native receipt records the corrected query. Two early ad-hoc QA-listing query errors were diagnostic-only, not test failures or hidden QA reruns. Draft/final originals were not overwritten.

The sampler's internal reference-build logs are not persisted by the unchanged tool; do not claim otherwise. Full raw data, warmups, missing values, nonzero console counts and original failures must remain. Cold/warm renderer coverage is post-commit PARTIAL, save MEASURED, not full startup/OS CPU. This preflight gives no real provider, Gist write/read, OCR, physical-device, PWA migration, CI, production or release evidence. Only total90KiB policy was approved; cold/finance/compatibility/latency/M4–M6 remain unchanged.
