# Current-correctness M3 paired-performance recipe: read-only review

2026-10-23. Verdict: RECIPE_SUPPORTED_WITH_EXISTING_057_REFERENCE; NOT_EXECUTED. Reuse the existing immutable same-dependency reference057042963a33579c624a41404a6d533dfda29768. Do not create a new ref, use c298 directly, weaken the lock check, or inherit the historical800-pair PASS.

Read current scripts/measure-performance-pair.mjs, its collect-baseline helpers and main flow, serve-site.mjs, M3_STATUS sections48/52, the complete historical pair-vite824-diagnostics-800-20261022 README/PROTOCOL/reference.json and relevant RESULTS, and the current budget freeze metadata. Applied performance-regression-check to repeatability and evidence boundaries. No measurement, browser, application, service, build, test, install or dependency mutation was started. Only this worker-owned new Temp directory/REPORT.md is written. A small Node JSON/hash diagnostic read Git blobs/package files only; it did not import or execute application/sampler code.

## 1. Reference and tool identities, freshly read

| Item | Current read-only result |
| --- | --- |
| c2980265d3c89f960517ced1527ba9cb85bf7c2b | Local commit object exists/readable; Vite8.2.2; declared deps and normalized lock DO NOT match current |
| c298 normalized lock SHA256 | 0b9db07c13394523bbee5d7b21d51cadb00f39b160794ebbda53ea8766b4aebf |
| 057042963a33579c624a41404a6d533dfda29768 | Exists/readable; parentc298; epoch1791676800; Vite8.2.4; declared deps and normalized lock match current exactly |
| 057 tree | 40098290fb64d31e0c8fcc12e552b3a913b5c715 |
| 057/current normalized lock SHA256 | db9079726ec21ffe25c4882b47c5c8d5b03a4b5ef3036a587cee9c2e2b6336dc |
| sampler SHA256 | 2ca754524871b72c3c41f17ec2b6052ac74e3334ad034bf522a933cd9df295d7 |
| collect-baseline SHA256 | 8a98f57980cfcde94e4035987c974b149c80bc27b51a1ca2309d3aed9d85bdd0 |
| available Node/npm | v24.14.0 /11.9.0, matching package engines |

The tool hashes equal the historical section48 protocol. Git's changed-path list c298->057 contains package.json and package-lock.json only. Ignoring line-ending changes gives1/1 and4/4 lines respectively; reference.json records the exact five Vite scalar changes. All eight declared dependency versions match installed package.json versions. The sampler's normalizedLock removes only packages[''].engines and JSON-stringifies everything else; the diagnostic used exactly that algorithm, not a broad dependency-set or version-only comparison.

c298 is usable as provenance, not the next run's --reference. Direct c298 would fail dependencyIdentity before browser sampling. Its availability is not permission to bypass that failure. Existing local ref refs/fundval-performance/v15.0.2-source-map-js-1.2.2-vite-8.2.4-20261022 already identifies057; use the full SHA without constructing or force-updating refs. Its timestamp is explicit comparison metadata, not a product release date. Original v15 size baseline40e68edab9cb3fba0b17338dc3672a82d13ad17e /70,207 B remains a separate historical anchor.

## 2. Exact proposed managed-mode command, NOT RUN

After the parent completes and freezes the final current QA/build identity and a new predeclared one-run protocol, use this command from D:/AI项目/FundVal. At review time the proposed output path below does not exist. Recheck immediately before the single launch; do not precreate the JSON itself because the sampler reserves it exclusively.

```powershell
$pairArguments = @(
  'D:\AI项目\FundVal\scripts\measure-performance-pair.mjs',
  '--reference', '057042963a33579c624a41404a6d533dfda29768',
  '--pairs', '800',
  '--warmup-pairs', '4',
  '--bootstrap', '5000',
  '--seed', '160003',
  '--timeout-ms', '30000',
  '--current-site', 'D:\AI项目\FundVal\site',
  '--output', 'D:\AI项目\FundVal\docs\v16.0.0\performance-evidence\m3-pair-correctness-800-20261023.json'
)
& 'C:\Program Files\nodejs\node.exe' @pairArguments
```

This is a proposed command only, not authorization to launch before freezing. Use an owned wrapper that exclusively reserves its launch record, preserves outer stdout/stderr/native exit and the same live process handle, and records controlled environment variables. Avoid accidental NODE_OPTIONS/coverage/debug flags or concurrent workload; any launcher environment normalization must be declared before sampling and applied once, not changed after seeing outcomes. Do not add unrecognized flags such as --iterations, --allow-lock-mismatch or --keep-snapshot. Do not run a60/200 preview or a second800 to select a favorable result.

The parser in measure-performance-pair.mjs:106 supports exactly these value switches:

- --pairs: even60..1000, default60 (therefore explicitly800).
- --warmup-pairs: even0..20, default4.
- --bootstrap: integer1000..50000, default5000.
- --seed: nonzero uint32, default160003.
- --timeout-ms: integer1000..120000, default30000; this is operation/navigation timeout, not total experiment duration.
- --reference: immutable full lowercase40-hex SHA; default40e, so explicitly override with057.
- --current-site, --output.
- External-only --reference-site, --reference-origin, --current-origin; both origins required together, distinct explicit loopback HTTP ports1024..65535, never4173; reference-site requires both origins.
- --help. Duplicate/unknown/missing options are rejected.

Managed mode is recommended. It verifies the current-site realpath is the root repository site, archives only057 into an owned fundval-baseline-* Temp directory, LF-normalizes isolated text, junctions existing pinned node_modules after strict dependency equality, substitutes only transport port literals in the snapshot, rebuilds only the isolated reference with referenceepoch1791676800, then starts two owned free loopback servers and one installed headless Chrome for both sides. Current site is never rebuilt by the sampler. External mode could use frozen custom directories, but provenance, server lifecycle and cleanup would then be caller-managed; it is not needed here.

Do not invoke collect-baseline.mjs main as a lightweight preparation command. Its main runs tests/coverage/audit/two builds/E2E/network samples and can update an existing report in --network-only mode; those are not the next paired protocol. The sampler imports only createSourceSnapshot/configureSnapshotTransport/safeRemoveSnapshot. Their reference snapshot and validated cleanup behavior can be reused without running the collector's main program.

## 3. Sampling and unchanged gates

Prespecify one experiment:800 retained complete pairs plus4 warmups,804 raw pairs total; retained AB400/BA400, deterministic whole-pair stratified bootstrap5000/seed160003, no retries/replacements/outlier stripping/mixing old rows, fixed timeout30000. Four warmups are retained in raw but excluded from inference. Both sides of each pair use fresh empty browser contexts; each context measures cold navigation, same-context no-store reload, then actual synthetic UI save100shares/cost1.2. One browser process serves both sides. The fixed synthetic time remains2026-08-28T06:45:10Z. Original Worker estimate/empty holdings fixtures are intercepted; all other providers and all Gist requests are blocked.

The original upgrade-plan hard latency limits remain cold/warm median<=+15%, p95<=+20%, save median<=+15%. The unchanged sampler applies its conservative median1.15 and p951.20 check to all three metrics, including save p95; preserve and report that additional tool check, do not silently redefine the original plan's save gate or relax the sampler. summarizePairs:146 additionally requires:

- all current retained critical-path observations below3000ms;
- balanced order and no zero-denominator inference;
- both sides p95 bootstrap95% interval relative width<=0.20;
- upper95% median and p95 ratio bounds within1.15/1.20, current p95 upper95% bound<3000ms, bootstrap pass fraction>=0.95 for a statistical PASS;
- an absolute current maximum>=3000 or a lower95% bound exceeding a ratio limit gives FAIL; other insufficient precision/balance cases remain INCONCLUSIVE.

MinimumPairs remains60 in the function, but a new800 protocol must separately require all800 complete plus4 warmups; a partial report cannot satisfy it just because the statistical helper's generic minimum is60. Bootstrap pass fraction is not the population's probability of passing.

Keep all health/integrity qualifications: pageerrors0, instrumentation complete, service worker events/controller/registrations/script requests0, every drain SETTLED, same-document renderer epochs/finite metrics, and cleanup PASS. A statistical PASS with changed source/artifacts, pageerrors, incomplete request instrumentation or unconfirmed cleanup is downgraded to INCONCLUSIVE by main. Native0/1/2 mean PASS/FAIL/INCONCLUSIVE; preserve the actual native exit, not the wrapper's expected-outcome status.

## 4. Pre-freeze requirements and comparability risks

1. Finish all intended current correctness/policy edits and final deterministic builds before measurement. Freeze the actual274-source scope,127-site files, explicit68 installed identities, HEAD/branch/staged/tracked patch, relevant untracked files, policy/protocol/tool hashes and command. Parent-reported1320PASS+3skip/Chrome35PASS are current QA context, not checks rerun by this reviewer or inherited latency PASS. The existing site manifest currently declares16chunks/all85,969/cold46,149; reading that sum is not fresh gzip verification. Bind the newly completed physical artifact-verification receipts and full127 rows to the new run.

2. Freeze new protocol before launching and do not edit tracked docs during the run: sourceIdentity hashes git diff --binary HEAD as well as build-relevant untracked paths. Its untracked filter is narrower than a whole source inventory (e.g. not all untracked tests/docs), so supplement it with the parent full274 and explicit installed68 pre/post inventory. HEAD170fd alone is not an immutable identity for this dirty candidate. Do not compare two valid diff snapshots from different documentation phases as if they should match; section48's independent-v1 cross-phase mistake must not recur.

3. Keep site free of incidental E2E output and extra files before freezing; sampler artifactFingerprint enumerates the complete tree and rejects non-regular entries. It fingerprints full reference/current trees before and after, and no-store transport checks index, all shell/manifest/chunks and CSS against those fingerprints. It does not authenticate a custom external server just from its port. New raw JSON must be outside both site trees and at a previously absent path; its writer uses exclusive reservation and descriptor-only final write. A zero-byte reserved file during sampling is not a completed result. The source-tree sorted-JSON inventory SHA and sampler path-NUL-hash SHA use different algorithms; label both, never equate them.

4. Preserve original reference provenance057/parentc298/tree40098290/epoch1791676800 and strict lockdb907972. Do not use a new synthetic ref, change v15 business/static bytes, install reference-specific dependencies, waive locks or rebase the historical70,207B baseline. The managed reference rebuild deliberately differs from current's source-date metadata; each side uses its own declared original epoch, and that is not a timing variable to tune.

5. Run with no parallel build/test/E2E/minifier/dependency work or competing agent browser sampling. Record machine/CPU/memory/Node/npm and actual Chrome version. A Chrome patch since historical155.0.8059.86 does not defeat the new same-process pair, but it prevents causal attribution to only one code change and prohibits pooling old and new samples. Keep power/foreground/workload conditions stable. The historical run took roughly35minutes; that is not a new duration promise. Tool-observation timeout is not sampler termination: resume the same live handle instead of relaunching. A real setup/measurement failure remains terminal with its partial report; no automatic rerun/1000-pair fallback/new seed in this declared protocol.

6. Managed lifecycle safely cleans only the owned browser/two servers and a validated fundval-baseline-* snapshot, unlinking the dependency junction before recursive removal. Existing user4173 is forbidden and unrelated processes must not be stopped. The sampler does not preserve subprocess reference-build stderr/logs; run() deliberately drains/discards them. Therefore outer command logs alone do not constitute preserved internal reference-build logs. Retain complete before/after reference inventories and exact provenance; if separately preserved rebuild receipts are required, predeclare independent reconstruction outside sampling as section48 did, rather than retroactively claiming deleted snapshot bytes/logs were reread. Do not change sampler midrun to add logging.

7. After the unique run, independently recompute the entire summarizePairs object with the unchanged5000/160003 configuration, all retained/warmup/order counts, rendererDelta snapshots, source/site/installed identity and health/instrumentation/cleanup. Preserve raw failures, nonzero console counts and all original/independent-tool errors. Console-count equality with blocked-request count does not establish every error's root cause. Cold/warm renderer counters remain PARTIAL post-commit attribution, save MEASURED within its explicit window; not independent OS CPU/fullstartup. Warm is HTTP no-store reload, not warm HTTP cache.

## 5. Why historical PASS is not inherited

M3_STATUS:48's800 run belongs to earlier diagnostics code/currentall84,187/cold44,699 and its exact source/site/Chrome identities. Section52 changed the real accuracy-enriched publication/settlement chain after the financial provenance fixes. The current artifact isall85,969/cold46,149 with different source/site bytes. Same sampler/lock/reference availability makes a new comparison possible; it does not make old timings apply to the fixed source. Similarly old200INCONCLUSIVE, old800PASS and current35E2E readiness observations cannot be pooled or transformed into a new paired PASS.

The approved90KiB total policy only changes the independent bundle ceiling to92,160; cold52,241 and latency/financial/compatibility rules remain intact. This sampler does not assert that bundle ceiling; keep real new-policy/old-policy budget reports separate as provenance. A new latency PASS would be local desktop hermetic evidence only, not actual financial sources, Gist writes, OCR engine/PWA/physicalAndroid/iOS/production, exact CI, M3 exit or release. Do not claim fewer requests/faster time are caused only by the last correctness fix; the v15 comparison includes accumulated changes.

## Review diagnostics and stop

Only read-only inspection/static JSON/hash/Git commands were used. One initial rg used an unsupported Windows wildcard path and was replaced with concrete paths; one broad Git diff displayed line-ending noise, then JSON/ignore-EOL checks established the exact dependency facts. No measurement/setup probe was launched as a result. No project file/ref/index or dependency was edited. Review complete; stop.
