import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { readFileSync, existsSync, openSync, writeSync, closeSync } from 'node:fs';
import { resolve } from 'node:path';
import { sha, inv, json, save, native } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';
import { normalizedLock, artifactFingerprint, parseOptions } from 'file:///D:/AI项目/FundVal/scripts/measure-performance-pair.mjs';
const here=import.meta.dirname,root='D:/AI项目/FundVal',phase=process.argv[2];
const policy='C:/Users/84046/AppData/Local/Temp/FundVal-budget-policy-20261023-parent';
const budgetBefore=json(resolve(policy,'BEFORE.json'));
const qa='C:/Users/84046/AppData/Local/Temp/FundVal-m3-responsibility-extraction-20261023-parent';
const source=json(resolve(qa,'QA_SOURCE_V3.json')),siteRows=json(resolve(qa,'qa-v3/build-02/site.inventory.json'));
for(const gate of ['test','check','build-01','e2e','build-02','artifact','audit']) assert.equal(json(resolve(qa,'qa-v3',gate,'RESULT.json')).status,'LOCAL_GATE_PASS');
const protocol='docs/v16.0.0/performance-evidence/pair-controllers-800-20261025/PROTOCOL.md';
const output=resolve(here,'PAIR.json');
const reference='057042963a33579c624a41404a6d533dfda29768';
const args=[resolve(root,'scripts/measure-performance-pair.mjs'),'--reference',reference,'--pairs','800','--warmup-pairs','4','--bootstrap','5000','--seed','160003','--timeout-ms','30000','--current-site',resolve(root,'site'),'--output',output];
const expectedTools={'scripts/measure-performance-pair.mjs':'2ca754524871b72c3c41f17ec2b6052ac74e3334ad034bf522a933cd9df295d7','scripts/collect-baseline.mjs':'8a98f57980cfcde94e4035987c974b149c80bc27b51a1ca2309d3aed9d85bdd0'};
const review='C:/Users/84046/AppData/Local/Temp/FundVal-performance-recipe-review-20261023-worker/REPORT.md';
function git(out,label,args){const r=native(out,label,'git',['-C',root,...args]);assert.equal(r.receipt.nativeExit,0);assert.equal(r.receipt.signal,null);assert.equal(r.receipt.error,null);return r.stdout;}
async function state(out){
  assert.deepEqual(inv(root,new Set(['.git','node_modules','site','Temp','.claude','docs'])),source.noDocs);
  assert.equal(sha(JSON.stringify(source.full)),source.sourceRowsSha256);
  const selected=[...source.noDocs,...source.full.filter(r=>r.path==='docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md')].sort((a,b)=>a.path.localeCompare(b.path));
  assert.deepEqual(source.full,selected);
  assert.deepEqual(inv(resolve(root,'site')),siteRows);
  for(const r of budgetBefore.expected.installed){const b=readFileSync(resolve(root,'node_modules',r.path));assert.equal(b.length,r.bytes);assert.equal(sha(b),r.sha256);}
  const fixed=source.full.find(r=>r.path==='docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');assert.equal(sha(readFileSync(resolve(root,fixed.path))),fixed.sha256);
  for(const[path,digest]of Object.entries(expectedTools))assert.equal(sha(readFileSync(resolve(root,path))),digest);
  const head=git(out,'head',['rev-parse','HEAD']).toString().trim(),branch=git(out,'branch',['branch','--show-current']).toString().trim(),index=sha(git(out,'index',['diff','--cached','--binary']));
  assert.equal(head,budgetBefore.expected.head);assert.equal(branch,budgetBefore.expected.branch);assert.equal(index,budgetBefore.expected.indexSha256);
  const diff=git(out,'tracked-diff',['diff','--binary','HEAD','--']);
  const refLock=git(out,'reference-lock',['show',reference+':package-lock.json']),curLock=readFileSync(resolve(root,'package-lock.json'));
  assert.equal(normalizedLock(refLock),normalizedLock(curLock));assert.equal(sha(normalizedLock(curLock)),'db9079726ec21ffe25c4882b47c5c8d5b03a4b5ef3036a587cee9c2e2b6336dc');
  const rp=JSON.parse(git(out,'reference-package',['show',reference+':package.json'])),cp=json(resolve(root,'package.json'));
  const declared=p=>({...p.dependencies,...p.devDependencies});assert.deepEqual(declared(rp),declared(cp));
  for(const[name,v]of Object.entries(declared(cp)))assert.equal(json(resolve(root,'node_modules',name,'package.json')).version,v);
  const provenance=git(out,'reference-provenance',['show','-s','--format=%H%n%P%n%T%n%ct',reference]).toString().trim();
  assert.equal(provenance,reference+'\nc2980265d3c89f960517ced1527ba9cb85bf7c2b\n40098290fb64d31e0c8fcc12e552b3a913b5c715\n1791676800');
  return{sourceCount:source.full.length,sourceRowsSha256:source.sourceRowsSha256,siteCount:siteRows.length,siteRowsSha256:sha(JSON.stringify(siteRows)),installed:budgetBefore.expected.installed,head,branch,index,trackedDiffSha256:sha(diff),artifact:await artifactFingerprint(resolve(root,'site')),protocolSha256:sha(readFileSync(resolve(root,protocol))),runnerSha256:sha(readFileSync(import.meta.filename)),recipeReviewSha256:sha(readFileSync(review)),toolHashes:expectedTools,reference,referenceProvenance:provenance,normalizedLockSha256:sha(normalizedLock(curLock)),args,
    independentAuditSha256:sha(readFileSync(resolve(here,'independent-audit.mjs'))),
    commonHelperSha256:sha(readFileSync('C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs')),
    qaSourceSha256:sha(readFileSync(resolve(qa,'QA_SOURCE_V3.json'))),
    qaEvidenceRowsSha256:sha(JSON.stringify(inv(resolve(qa,'qa-v3'))))};
}
assert.equal(process.version,'v24.14.0');assert.equal(json('C:/Program Files/nodejs/node_modules/npm/package.json').version,'11.9.0');
assert.deepEqual(parseOptions(args.slice(1)).pairs,800);
if(phase==='freeze'){
  assert.equal(existsSync(output),false);assert.equal(existsSync(resolve(here,'FROZEN.json')),false);
  const frozen=await state(resolve(here,'preflight'));save(resolve(here,'FROZEN.json'),JSON.stringify(frozen,null,2)+'\n');
  save(resolve(here,'RECIPE_REVIEW.md'),readFileSync(review));
  process.stdout.write(JSON.stringify({status:'FROZEN_NOT_RUN',source:frozen.sourceRowsSha256,artifact:frozen.artifact.sha256,reference})+'\n');
}else if(phase==='run'){
  const frozen=json(resolve(here,'FROZEN.json'));assert.deepEqual(await state(resolve(here,'launch-preflight')),frozen);
  const preflightReview=resolve(here,'PREFLIGHT_REVIEW.md');assert.equal(existsSync(preflightReview),true);
  assert.equal(existsSync(output),false);
  const env={...process.env,SOURCE_DATE_EPOCH:'1792046773',FORCE_COLOR:'0',NO_COLOR:'1'};delete env.NODE_OPTIONS;delete env.NODE_V8_COVERAGE;
  const startedAt=new Date().toISOString(),stdoutPath=resolve(here,'sampler.stdout'),stderrPath=resolve(here,'sampler.stderr');
  const stdout=openSync(stdoutPath,'wx'),stderr=openSync(stderrPath,'wx');
  save(resolve(here,'LAUNCH.json'),JSON.stringify({startedAt,command:process.execPath,args,cwd:root,envPolicy:{SOURCE_DATE_EPOCH:env.SOURCE_DATE_EPOCH,FORCE_COLOR:'0',NO_COLOR:'1',removed:['NODE_OPTIONS','NODE_V8_COVERAGE']},frozenSha256:sha(readFileSync(resolve(here,'FROZEN.json'))),reviewSha256:sha(readFileSync(preflightReview))},null,2)+'\n');
  const child=spawn(process.execPath,args,{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});let error=null;
  save(resolve(here,'PID.json'),JSON.stringify({pid:child.pid,parentPid:process.pid,startedAt,command:process.execPath,args},null,2)+'\n');
  child.stdout.on('data',b=>{writeSync(stdout,b);process.stdout.write(b);});child.stderr.on('data',b=>{writeSync(stderr,b);process.stderr.write(b);});child.on('error',e=>{error=e.message;});
  const end=await new Promise(done=>child.once('close',(nativeExit,signal)=>done({nativeExit,signal})));closeSync(stdout);closeSync(stderr);
  const receipt={startedAt,finishedAt:new Date().toISOString(),...end,error,stdout:{bytes:readFileSync(stdoutPath).length,sha256:sha(readFileSync(stdoutPath))},stderr:{bytes:readFileSync(stderrPath).length,sha256:sha(readFileSync(stderrPath))}};
  save(resolve(here,'RECEIPT.json'),JSON.stringify(receipt,null,2)+'\n');
  let postflightError=null;try{assert.deepEqual(await state(resolve(here,'postflight')),frozen);}catch(e){postflightError={message:e.message,stack:e.stack};}
  const report=existsSync(output)&&readFileSync(output).length?json(output):null;
  save(resolve(here,'OUTCOME.json'),JSON.stringify({receipt,postflightError,reportExists:Boolean(report),rawReport:report?{bytes:readFileSync(output).length,sha256:sha(readFileSync(output)),status:report.status,observed:report.observed}:null,release:false,m3Exit:false},null,2)+'\n');
  process.stdout.write(JSON.stringify({receipt,postflightError,status:report?.status??'NO_COMPLETE_REPORT'})+'\n');
  process.exitCode=postflightError||error||end.signal?3:end.nativeExit;
}else throw new Error('Use freeze or run, exactly once each.');
