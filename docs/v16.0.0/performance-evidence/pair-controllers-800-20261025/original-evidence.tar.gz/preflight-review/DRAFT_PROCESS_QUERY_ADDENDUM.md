# Draft process-query qualification

The draft inventory/Git/QA checks are unchanged. Before final freeze review, inspection found that the JavaScript-embedded PowerShell process regex used unnecessary escaping which could miss browser names. The original draft/process-check.stdout and receipt remain unchanged. Do not use that draft process query alone as an admission claim.

A direct read-only PowerShell query using explicit `-in @('chrome.exe','msedge.exe')` and `[.]` filename matching returned an empty process list. The checker was adjusted only for this diagnostic expression before its final-mode execution; final-mode native receipts will preserve the exact corrected command. No sampler/test/build/browser was started and no frozen sampler/runner/protocol/production input was changed.

Two earlier ad-hoc QA listing queries had a PowerShell pipeline parse error and then assumed a nonexistent artifact/artifact.receipt.json. They performed no test or state mutation. The actual checker reads all five artifact native receipts (chunks/graph/OCR/fingerprint/budget), validates their exact stdout/stderr bytes and native statuses, and passed that inspection. Those listing errors are not business/test failures and not hidden reruns of QA.
