import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';

const here=import.meta.dirname;
const original='C:/Users/84046/AppData/Local/Temp/FundVal-pair-controllers-800-20261025-parent';
const sha=b=>createHash('sha256').update(b).digest('hex');
const read=name=>JSON.parse(readFileSync(resolve(original,name)));
const save=(name,value)=>writeFileSync(resolve(here,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const rawBytes=readFileSync(resolve(original,'PAIR.json')),rawHash=sha(rawBytes);
const report=JSON.parse(rawBytes),frozen=read('FROZEN.json'),receipt=read('RECEIPT.json'),outcome=read('OUTCOME.json');
const checks=[],check=(name,fn)=>{try{fn();checks.push({name,pass:true});}catch(error){checks.push({name,pass:false,reason:error.message});}};
check('raw SHA bound to completed outcome',()=>assert.deepEqual(outcome.rawReport,{bytes:rawBytes.length,sha256:rawHash,status:report.status,observed:report.observed}));
check('native final status',()=>{assert.equal(report.status,'PASS');assert.equal(receipt.nativeExit,0);assert.equal(receipt.signal,null);assert.equal(receipt.error,null);assert.equal(outcome.postflightError,null);});
check('full fixed request',()=>assert.deepEqual(report.requested,{retainedPairs:800,warmupPairs:4,bootstrap:5000,seed:160003}));
check('complete observed sample count',()=>{assert.equal(report.rawPairs.length,804);assert.deepEqual(report.observed,{retainedCompletePairs:800,warmupCompletePairs:4,failedPairs:0});});
check('immutable reference and source/artifact window',()=>{assert.equal(report.referenceSha,'057042963a33579c624a41404a6d533dfda29768');assert.deepEqual(report.currentSourceBefore,report.currentSourceAfter);assert.equal(report.currentSourceBefore.head,frozen.head);assert.equal(report.currentSourceBefore.trackedDiffSha256,frozen.trackedDiffSha256);assert.deepEqual(report.artifactsBefore,report.artifactsAfter);assert.deepEqual(report.artifactsBefore.current,frozen.artifact);});
check('reported integrity and health',()=>{assert.equal(report.integrity.status,'PASS');assert.deepEqual(report.health,{status:'PASS',pageErrors:0});assert.deepEqual(report.instrumentation,{status:'PASS'});assert.equal(report.dependencies.resolvedLockSha256,frozen.normalizedLockSha256);});
for(const[index,pair]of report.rawPairs.entries())check(`pair${index}/complete order and warmup flag`,()=>{assert.equal(pair.index,index);assert.equal(pair.retained,index>=4);assert.deepEqual(pair.order,index%2?['current','reference']:['reference','current']);assert.equal(pair.failure,undefined);assert.ok(pair.reference&&pair.current&&pair.finishedAt);});
const retained=report.rawPairs.slice(4),metrics={};
function directStats(values){assert.equal(values.length,800);assert.ok(values.every(value=>typeof value==='number'&&Number.isFinite(value)&&value>=0));const sorted=[...values].sort((a,b)=>a-b);return{samples:values.length,minimum:sorted[0],median:(sorted[399]+sorted[400])/2,p95:sorted[Math.ceil(.95*sorted.length)-1],maximum:sorted.at(-1)};}
for(const key of ['coldReadyMs','warmReadyMs','saveUiMs']){
  const reference=directStats(retained.map(pair=>pair.reference[key])),current=directStats(retained.map(pair=>pair.current[key]));
  const summary=report.summary.metrics[key];
  metrics[key]={reference,current,medianRatio:current.median/reference.median,p95Ratio:current.p95/reference.p95,medianDeltaPercent:(current.median/reference.median-1)*100,p95DeltaPercent:(current.p95/reference.p95-1)*100};
  check(key+'/independent complete-slice median p95 max ratios',()=>{for(const side of ['reference','current']){const{minimum,...compared}=metrics[key][side];assert.deepEqual(compared,summary[side]);}for(const field of ['medianRatio','p95Ratio','medianDeltaPercent','p95DeltaPercent'])assert.equal(metrics[key][field],summary[field]);assert.ok(current.maximum<3000);});
  check(key+'/reported bootstrap bound arithmetic only',()=>{assert.equal(summary.verdict,'PASS');assert.ok(summary.confidenceIntervals95.medianRatio[1]<=1.15);assert.ok(summary.confidenceIntervals95.p95Ratio[1]<=1.2);assert.ok(summary.passConfidence>=.95);for(const side of ['reference','current']){const ci=summary.confidenceIntervals95[side+'P95Ms'];assert.equal((ci[1]-ci[0])/summary[side].p95,summary.p95RelativeIntervalWidth[side]);assert.ok(summary.p95RelativeIntervalWidth[side]<=.2);} });
}
check('fixed reported method and balance',()=>{assert.deepEqual(report.summary.orderCounts,{AB:400,BA:400});assert.equal(report.summary.retainedPairs,800);assert.equal(report.summary.balanced,true);assert.equal(report.summary.method.bootstrap,5000);assert.equal(report.summary.method.seed,160003);assert.equal(report.summary.method.medianLimit,1.15);assert.equal(report.summary.method.p95Limit,1.2);assert.equal(report.summary.method.absoluteBudgetMs,3000);assert.equal(report.summary.method.stabilityLimit,.2);});
const aggregate={sides:0,drains:0,consoleErrors:0,pageErrors:0,serviceWorkerEvents:0,swScriptRequests:0,gistWriteRequests:0,requests:0,requestCategories:{},transports:{},rendererStatuses:{},rendererMissingReasons:{},rendererObjects:0,counterDeltas:0};
for(const pair of report.rawPairs)for(const side of ['reference','current']){
  const row=pair[side],id=`pair${pair.index}/${side}`;aggregate.sides++;
  aggregate.consoleErrors+=row.consoleErrors;aggregate.pageErrors+=row.pageErrors;aggregate.serviceWorkerEvents+=row.serviceWorkerEvents;
  check(id+'/zero page errors and all drains settled',()=>{assert.equal(row.pageErrors,0);assert.equal(row.networkInstrumentation.failures,0);assert.equal(row.serviceWorkerEvents,0);assert.deepEqual(row.drains.map(item=>item.reason),['beforeOwnedWarmReload','afterWarmReadiness','beforeOwnedContextClose']);for(const drain of row.drains){assert.equal(drain.status,'SETTLED');aggregate.drains++;}});
  for(const phase of ['cold','warm','save']){
    const b=row.breakdown[phase],r=b.renderer;aggregate.rendererObjects++;aggregate.rendererStatuses[phase+'/'+r.status]=(aggregate.rendererStatuses[phase+'/'+r.status]||0)+1;
    for(const reason of Object.values(r.invalidReasons))aggregate.rendererMissingReasons[reason]=(aggregate.rendererMissingReasons[reason]||0)+1;
    check(id+'/'+phase+'/SW and direct same-epoch counter subtraction',()=>{
      assert.equal(b.serviceWorkers.status,'REGISTRATION_BLOCKED');assert.equal(b.serviceWorkers.controlled,false);assert.equal(b.serviceWorkers.registrations,0);
      const a=r.snapshots.before,z=r.snapshots.after;assert.equal(a.invalidReason,null);assert.equal(z.invalidReason,null);assert.deepEqual(a.documentEpoch,z.documentEpoch);assert.ok(z.values.Timestamp>=a.values.Timestamp);assert.ok(z.documentTiming.observedAtDocumentMs>=a.documentTiming.observedAtDocumentMs);
      assert.equal(r.status,phase==='save'?'MEASURED':'PARTIAL');assert.deepEqual(r.invalidReasons,{});
      for(const[key,label]of [['TaskDuration','TaskMs'],['ScriptDuration','ScriptMs'],['LayoutDuration','LayoutMs'],['RecalcStyleDuration','RecalcStyleMs']]){assert.ok(Number.isFinite(a.values[key])&&Number.isFinite(z.values[key])&&z.values[key]>=a.values[key]);assert.equal((z.values[key]-a.values[key])*1000,r[label]);aggregate.counterDeltas++;}
    });
  }
  for(const request of row.requests){aggregate.requests++;aggregate.requestCategories[request.category]=(aggregate.requestCategories[request.category]||0)+1;aggregate.transports[request.transport]=(aggregate.transports[request.transport]||0)+1;if(request.role==='serviceWorkerScript')aggregate.swScriptRequests++;if(request.category==='gistWriteBlocked')aggregate.gistWriteRequests++;}
}
check('zero SW scripts and Gist writes',()=>{assert.equal(aggregate.swScriptRequests,0);assert.equal(aggregate.gistWriteRequests,0);});
check('four owned cleanup records',()=>{assert.equal(report.cleanup.length,4);for(const item of report.cleanup)assert.equal(item.status,'PASS');assert.equal(report.cleanup.filter(item=>item.resource==='ownedServer').length,2);assert.ok(report.cleanup.some(item=>item.resource==='ownedBrowser'));assert.ok(report.cleanup.some(item=>item.resource==='validatedTemporarySnapshot'));});
const owned=report.cleanup.filter(item=>item.resource==='ownedServer').map(item=>{const url=new URL(item.origin);assert.equal(url.protocol,'http:');assert.equal(url.hostname,'127.0.0.1');const port=Number(url.port);assert.ok(Number.isSafeInteger(port)&&port>=1024&&port<=65535&&port!==4173);return port;});
const pid=read('PID.json').pid;assert.ok(Number.isSafeInteger(pid)&&pid>0);
const ps=`$ErrorActionPreference='Stop'; $p = @(Get-Process -Id ${pid} -ErrorAction SilentlyContinue); $n = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in @(${owned.join(',')}) }); [pscustomobject]@{ observedAtUtc=[DateTime]::UtcNow.ToString('o'); samplerPid=${pid}; samplerPresent=($p.Count -gt 0); ownedPorts=@(${owned.join(',')}); listeners=@($n | Select-Object LocalAddress,LocalPort,OwningProcess) } | ConvertTo-Json -Depth 5 -Compress`;
const processStart=new Date().toISOString(),native=spawnSync('powershell.exe',['-NoProfile','-Command',ps],{windowsHide:true,encoding:null,timeout:30000});
const stdout=native.stdout??Buffer.alloc(0),stderr=native.stderr??Buffer.alloc(0);
writeFileSync(resolve(here,'owned-os.stdout'),stdout,{flag:'wx'});writeFileSync(resolve(here,'owned-os.stderr'),stderr,{flag:'wx'});
save('owned-os.receipt.json',{command:'powershell.exe',args:['-NoProfile','-Command',ps],startedAt:processStart,finishedAt:new Date().toISOString(),nativeExit:native.status,signal:native.signal,error:native.error?.message??null,stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}});
let os=null;check('actual owned OS point observation',()=>{assert.equal(native.status,0);assert.equal(native.signal,null);assert.equal(native.error,undefined);os=JSON.parse(stdout.toString());assert.equal(os.samplerPresent,false);assert.deepEqual(os.listeners,[]);});
check('original raw bytes unchanged after independent review',()=>assert.equal(sha(readFileSync(resolve(original,'PAIR.json'))),rawHash));
const result={schema:1,status:checks.every(item=>item.pass)?'READ_ONLY_TERMINAL_REVIEW_PASS':'READ_ONLY_TERMINAL_REVIEW_FAIL',raw:{bytes:rawBytes.length,sha256:rawHash},nativeSampler:receipt,scope:report.scope,environment:report.environment,metrics,aggregate,ownedOsObservation:os,checks,failures:checks.filter(item=>!item.pass),checkCount:checks.length,limitations:['Independent implementation of basic full-slice statistics and direct same-epoch counter subtraction; bootstrap was not independently reimplemented. Reported bootstrap bounds only checked arithmetically.','Current cold maximum exceeds reference; median/p95 PASS does not mean every observation is faster.','Navigation renderer PARTIAL, save MEASURED; not full startup or isolated OS CPU.','Equal console/block counts do not prove per-message root cause.','No new sampling/test/build/provider/Gist/physical-device/PWA/CI/production verification.','OS process/port check is an actual terminal point observation, not a universal no-background-work claim.'],release:false,m3Exit:false};
save('RESULT.json',result);
console.log(JSON.stringify({status:result.status,checkCount:result.checkCount,failures:result.failures,raw:result.raw,metrics,aggregate,ownedOsObservation:os},null,2));
if(result.failures.length)process.exitCode=1;
