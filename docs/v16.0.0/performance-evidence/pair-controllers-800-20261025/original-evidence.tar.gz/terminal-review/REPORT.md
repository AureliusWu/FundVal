# Final controller-candidate raw terminal review

2026-10-25. Verdict: `READ_ONLY_TERMINAL_REVIEW_PASS`, **7,253 checks / 0 failures**, actual Node native exit 0 / stderr 0. This independent review does not modify FundVal, the frozen candidate, original evidence, sampler or provider state. No new sampling, test, build, browser or network experiment was run.

## Actual evidence and scope

- Original: `C:/Users/84046/AppData/Local/Temp/FundVal-pair-controllers-800-20261025-parent/PAIR.json`.
- Raw: **88,027,817 B**, SHA256 `c0586a69852c8415090f46384ca1e1483ad41371adae4af3306bff85fdf1b4e7`; unchanged after review and exactly bound to the original OUTCOME record.
- Actual source: dirty candidate on HEAD `170fd3eadc6da02750882f8a542904ee2358d0d9`; current source/artifacts before/after agree with FROZEN, not a newly created immutable business commit.
- Reference is exact `057042963a33579c624a41404a6d533dfda29768`. Normalized lock SHA agrees with FROZEN. Physical source/install inventories are not rehashed by this child; that is the parent's separate frozen postflight/helper audit.
- Original native measurement is PASS / exit0, signal/error null, postflightError null. **804 complete pairs** = first4 prespecified warmups + the exact remaining800, AB400/BA400, original index/order/retained flag, no failed or replacement pairs.
- Windows x64 / Node24.14.0 / installed desktop Chrome155.0.8059.86 /390×844. Fixed synthetic clock and data, one browser, fresh context per side, no-store warm reload. No physical-device, actual financial-provider or Gist evidence.

## Independent basic statistics

`review.mjs` parses original raw bytes and uses `rawPairs.slice(4)` directly. It independently implements sorting, even-n median and nearest-rank p95; it does not import the sampler's statistics or renderer helpers. No filtering of finite values or successful rows is used to replace completeness; all800 values must be finite nonnegative numbers first. All reported medians, p95s, maxima and ratios match exactly.

| Metric | Reference median / p95 / max ms | Current median / p95 / max ms | Median / p95 delta | Original relative gate |
| --- | --- | --- | --- | --- |
| Cold readiness |128.2000 /161.6000 /237.7000|119.8000 /154.9000 /327.8000|−6.552% /−4.146%|PASS|
| Warm readiness |67.7500 /92.2000 /143.6000|60.2000 /80.2000 /129.5000|−11.144% /−13.015%|PASS|
| UI save |79.10315 /85.4128 /180.9507|66.06475 /72.4896 /96.6810|−16.483% /−15.130%|PASS|

All current maxima <3000ms. **Current cold max327.8 is worse than reference237.7** and remains included; median/p95 PASS does not mean every sample is faster. The reference is v15, not the immediately preceding controller-free candidate, so measured differences cannot be attributed causally to this extraction alone.

Bootstrap5000/seed160003 and the original 1.15 median/1.20 p95/0.20 interval-width metadata agree. This child checks the arithmetic of the **reported** p95 interval width, upper ratio bounds and >=0.95 fraction. **It does not independently reimplement or rerun bootstrap**. The parent's separate audit executes the unchanged original helper and compares its full summary object; these are distinct claims, not two independent statistical algorithms. The fraction1 is a resampling fraction, not a population pass probability.

## Full-row health, renderer and requests

-1608 sides, **4824 drains**, all `SETTLED` with original expected reasons; network instrumentation failures0; pageerror0; SW events/script requests/controller/registration0; Gist write requests0.
-4824 renderer objects: cold1608 PARTIAL, warm1608 PARTIAL, save1608 MEASURED; missing reasons empty. Independently compared same document epochs/clocks and **19,296** raw duration-counter subtractions. All agree exactly. This is direct arithmetic verification on the complete actual happy-path data, not independent implementation of every invalid-input branch in the renderer helper.
-80,400 requests:59,496 loopback static,3216 synthetic intercepts (1608 estimates+1608 holdings),17,688 blocked external/proxy. No real provider latency is measured.
-Console errors **17,688**, blocked requests **17,688**. Equal totals do **not** establish per-message causality, and this is not console-zero acceptance.
-Navigation renderer is post-commit PARTIAL and includes collection/harness overhead; these overlapping CDP counters are not additive isolated OS CPU or full startup attribution. Save is a real synthetic UI interaction including automation scheduling.
-Four original cleanup records PASS: owned browser, two owned servers and validated temporary reference snapshot. Internal reference-build native logs were not inspected or claimed to exist.

## Actual OS terminal point observation

Ports are taken directly from raw ownedServer cleanup origins, not guessed: **9232 and9235**. At `2026-10-25T07:06:25.4059025Z`, actual PowerShell query finds sampler PID30520 absent and no listeners on either owned port. Query native0 / stderr0. `owned-os.receipt.json` records its full exact command and stdout/stderr hashes. This is a point observation about owned resources only; it does not certify every background workload or OS scheduling condition.

## Follow-up

No contradiction was found that invalidates this local terminal report. The most important remaining boundaries are (1) immutable candidate/CI and artifact identity, (2) real financial/cloud/physical-device/PWA/production evidence, and (3) noncausal timing attribution and the retained cold maximum. Do not tune N/seed or remove the outlier to improve the story. Keep these results bound to the actual frozen source; continue the original M3 CI admission before M4 implementation.

This child applied the performance-regression-check workflow to comparison identity, complete statistics, measurement limits and regression reporting. It did not recommend a speculative runtime fix because this report establishes no new code defect. M3 EXIT and release remain unproven.

## Saved originals

This independent Temp folder contains exact `review.mjs`, `driver.mjs`, `RESULT.json`, `review.stdout`, `review.stderr`, `review.receipt.json`, `owned-os.stdout`, `owned-os.stderr`, `owned-os.receipt.json` and this report. Review script SHA256 `72ae085979028928da6b9b3e3d58fbd35f6c8b3169e09990017e2df4d05f0c65`. The driver exclusively created all native output files; no failed review was overwritten or silently retried. Initial exploratory reads existed only in thread tool output and are not represented as saved native evidence.
