# M3 storage / Schema 3 / Gist: bounded read-only review

Verdict: **BOUNDED_NO_MATERIAL_EQUIVALENT_DUPLICATION_CANDIDATE** in the specific cuts below. No new implementation, virtual variant, build, test, installation, minifier/property-mangling/string-pool probe or candidate gzip run was performed. This is not a claim that all storage refactoring or future optimization is impossible.

Read AGENTS.md, current M3_STATUS sections 28-45, and the linked historical startup-boundary report. Applied performance-regression-check only to evidence/measurement boundaries and data-reliability-audit to null/tombstone/compatibility boundaries; explicit read-only instructions preclude new performance or behavior runs. Current source/API behavior is not reported as buggy merely because a proposed simplification would change it.

## Current materiality anchor: actual existing chunks, not source-size promises

The audit read/parsed all existing sixteen app chunks and independently checked actual raw bytes/SHA against app-chunks.json. Gzip numbers below are the unchanged manifest's existing measurements, not marginal module costs or measured candidate savings.

| Existing artifact | Actual raw bytes | Existing gzip bytes | Scope |
| --- | ---: | ---: | --- |
| post-integrity | 101160 | 33921 | Mostly app/market/runtime; do not label it all storage |
| business-runtime | 82819 | 27848 | Not a second Schema 3 repository |
| startup-pure | 27349 | 8263 | Contains the actual shared schema, migration and repository implementations plus other startup-pure code |
| cloud | 18694 | 6381 | Shared cloud sync, Gist and archive UI code; not a marginal cost for any one module |
| all app | 245170 | 84187 | Existing threshold 77227.7 remains unmet; at least 6960 integer bytes needed |
| cold app | -- | 44699 | Existing threshold 52241, unchanged |

One copy each is present for the emitted normalize-record (1170 raw), normalize-document (850), migrate-legacy document (888), parse/migrate (1109), persist (1729), load (1793), legacy-edit reconcile (1997), recovery (830), cloud push (3932), cloud pull (1523), bridge-set (977), and Gist adapter factory (1724) bodies. These are AST/text-anchor ownership sizes in existing minified code, not additive gzip estimates or source maps. The cloud serializer itself is only 221 raw and canonical-cloud wrapper 248 raw. Repeated calls into these bodies are not copies of those bodies.

The initial text anchor for normalize-record also matched the substring inside the legacy-record error, and the readable-file anchor matched a generic cloud error. The final script narrows those two anchors to unique error strings before saving inventory.json. A subsequent tool-output capture was too short to parse and was rerun solely to preserve the complete read-only inventory. No business variant, test or compression sample was selected or rerun.

## Existing exclusions honored, not recycled as new experiments

- Section 28 already measured migration success factory (+13 gzip), schema scalar helper (-4), journal-membership reuse (-3), the storage combination (-14), and cloud parse factory (+17). Do not spend another series on those helper rearrangements.
- Sections 28/29/37 already examined cloud push/pull common prefixes or orchestration; their await/backup/pending/readback differences were retained. Section 32 already rejected cross-lock startup snapshot reuse and recorded the 10-to-20-share concurrency counterexample.
- Sections 36/39/40/41 cover minifiers/printers/scalars/string pools; none is proposed here. Section 44's fixed DTO/schema pooling was also only an optimistic small raw pool, not new gzip benefit.
- Sections 42-45 add observability/security behavior costs; none authorizes removing those contracts, changing ES2022/five groups/thresholds, or borrowing old-lock latency evidence.

## Cut 1: eliminate repeated normalization/canonical passes -- not a duplicated implementation

Locations: holdings-schema.js:67/102/139/143/188/201; cloud-sync.js:38/50/111/125/151; repository.js:248/264/294/311; app.js:245-246. Each underlying normalizer/serializer is already emitted once.

Example exact call order: makeCloudWritePayload(value, 3) first normalizes value; canonicalHoldingsDocument(document) normalizes the resulting frozen record/document again; JSON.parse then creates a distinct mutable projection. canonicalCloudPayload additionally parses/migrates and calls that writer. compareHoldingRecords normalizes both sides before priority comparisons, then full fingerprints independently normalize tied records.

Replacing the chain with direct JSON.stringify/returning the normalized frozen object changes validation calls, Date.parse/new Date/toISOString calls, allocation/freeze/mutability, and exception positions; canonical byte field order is part of the public API. A changing Date.parse or caller getter provides a source-level observable boundary. No such synthetic counterexample was executed here. Skipping calls saves call tokens while the full validator remains required by external schema, repository, OCR/import and cloud entry points; it does not remove the 9091-byte schema source from the product.

makeCloudWritePayload's Schema 2 branch is also live in pull-only legacy comparison through targetWriteSchema/ canonicalCloudPayload, even though new PATCH writes are V3-only. It must not be deleted or replaced by V3-only runtime assumptions. toLegacyHoldings includes note; cloud's legacyHolding intentionally omits that V3-only field, so they are not the same projection.

Existing coverage: holdings-canonical-v16.test.js:58-212 checks exact UTF8 bytes/key order, all canonical fields, null/0/negative-zero/exponential values, error priority, caller non-mutation, merge priority and tombstones. storage-holdings-schema.test.js:50-242 covers strict V3, deterministic legacy migration/future readonly and origin-aware merges. These are not complete call-trace tests for arbitrary getters, monkeypatched Date/JSON and every repeated normalization pass. No closed material deletion is justified by the current public contracts.

## Cut 2: share legacy migration and local old-tab edit parsing -- concrete non-equivalence

Locations: holdings-migration.js:21/34 and holdings-repository.js:436-507. Both mention shares/cost/name but have different algorithms and trust purposes.

- Migration obtains item.shares once as the legacyNumber argument; legacyNumber then validates that captured value. Local reconciliation first evaluates Number(item.shares), then separately reads item.shares for typeof and String checks. Factoring into a once-read scalar helper changes caller accessor counts and can change acceptance if successive reads differ. Throwing later reads would also stop at a different point.
- Migration's missing shares error has message 'shares is required' and details.field; local reconciliation has a different message/default details after its original Number/typeof/String sequence. The existing public APIs expose these error shapes.
- Local reconciliation treats an unchanged old zero cost as still-null when current cost is unknown and the projection is not newer; preserves absent notes but accepts an explicitly null note; retains records missing from the submitted array; honors explicit allowRestoreCodes and increments existing revisions. Legacy migration instead fixes deterministic stable IDs/revision 1 and has no current document against which to apply those edits.
- Both ultimately normalize strict V3; that common validation implementation is already shared. Merging the larger loops would need conditional policies and access/error schedules, not deletion of one complete equivalent duplicate.

Existing coverage: storage-reliability.test.js:101-127 checks missing-vs-null notes and malformed numbers in both entry paths; repository tests:224-294 cover re-add, absent rows and stale OCR snapshots; tests:347-363 cover old-tab edits/tombstones. They do not compare complete accessor/coercion/sentinel traces for the two entry paths. No candidate gzip/marginal body deletion was measured; source similarity is insufficient materiality evidence.

## Cut 3: duplicate identity-map loop and dead old APIs -- no material retained twin

holdings-schema.js:161 mergeHoldingsDocuments has a source-level identity-map loop resembling migration.js:65. Its only production occurrence is its declaration/export; actual production imports use explicit schema names, not that export or a schema namespace. The emitted product contains only one occurrence each of fund_code_identity_conflict and id_fund_code_conflict, attributable to the live migration path. Removing the public merge export would violate compatibility while not recover its 1287 source bytes from the bundle.

A narrower fresh observation: the migration candidate's stable ID is derived from its validated fundCode, so the two cross-ID assertions look redundant under native Map and unchanged built-ins. Removing the associated map/reads is nevertheless not full observable-operation equivalence (Map construction/get/set and potential throw schedule change), and all such bookkeeping is a subset of an existing 888-raw-byte emitted migration body, which cannot itself be removed. This is not a several-KB duplicated algorithm. It is a bounded low-materiality lead, not a qualified patch or gzip upper bound. Existing schema/canonical tests must keep their public identity-conflict/duplicate semantics; they do not authorize dropping another path's checks.

Likewise requiresSchema3CloudUpgrade, reconcileCloudBridgePayload's one-document wrapper, hasHoldingsGistFile and the older storage.js generic cloud/cache helpers remain public/test compatibility surfaces but are absent from the narrowed production consumers. Rewriting/deleting their source cannot be booked as production savings. This is consistent with, not a repetition of, the old retained-export screen.

## Cut 4: collapse Gist's shard scan and backup scan -- different access/throw times

Locations: gist-remote.js:45/54/63-126. GET performs: request -> response.ok/json/truncation -> files/version -> Object.entries(files) -> V3 filter -> lexicographic sort -> 64-file cap -> each readable-file check -> legacy check -> bridge all shards -> target canonical check -> merged canonical -> backupFiles(files) -> return. The second enumeration is deliberately after all reconciliation/canonical work in the current code; it is not two copies of a large reconciliation algorithm.

Building backup during the first scan would remove/reorder a second Object.entries read of enumerable file values and move file.content getter evaluation before readable/bridge/canonical failures. The public request adapter may return accessor-backed objects, so native JSON response assumptions cannot silently narrow that API. Moving serialization/backup failures across these guards changes observable throws/returns and backup content when supplied accessors change. The backup helper is only 329 source raw bytes; the complete emitted adapter, including GET and PATCH, is 1724 raw. No marginal gzip reward is established.

Reading just the current device shard, removing sorting, or treating malformed extra shards as optional is not equivalent: all device shards/canonical V3 file, retained legacy file, cap64, tombstone/origin-aware merge and exact current-device readback equality remain required. Discovery across up to five pages prefers any V3 archive before a saved legacy fallback; it is not interchangeable with fetching a single known Gist.

Existing gist-remote.test.js:70-160 checks stable filename hashing, all-shard plus newer-legacy reconciliation/backups, current-device-only PATCH retaining legacy, V2 zero-request rejection, truncation/cap and cross-page discovery. cloud-sync.test.js:383-400 checks aggregate readback cannot disguise an unsynchronized current device shard. These tests do not prove a reordered accessor/throw trace, so the single-pass idea is not closed.

## Cut 5: share backup/storage wrappers or delete repeated repository reads -- incompatible boundaries

Locations: storage.js:1-19; holdings-repository.js:55-76/126-170/214-311; cloud-archive-ui.js:189-231. Exact defaultStorage body duplication is 100 source bytes, not a material new engine. safeGetItem returns a raw getItem result, whereas repository get null-normalizes undefined; defaulted parameter placement can trigger another global localStorage getter when undefined is explicitly forwarded. set/remove wrappers also differ in storage truthiness/optional-call timing. A shared facade must preserve those semantics rather than assume native localStorage is the only public test input.

BackupRepositoryState returns Boolean and rotates/writes/verifies repository backup. backupCloudSyncSnapshot returns structured reasons, verifies rotation readback, serializes version/snapshot, and parses its readback. They are not duplicate backups. persist performs fresh future-schema/recovery -> previous snapshot/CAS -> backup -> journal prepare/readback -> V3 set/readback/strict parse -> V1 set/readback/JSON validation -> projection metadata set/readback -> journal removal -> optional cache removal -> published verified document. Failure rolls back only journal-owned values and may keep recoveryRequired; it must never return the uncommitted candidate.

Cloud adapters acquire a fresh origin WebLock for each short local load/backup/persist and reread current state when finalizing pending metadata. No lock spans network awaits. Push has initial GET, backup stability loop, pre-patch verified local persistence loop, PATCH, second GET, target/canonical verification, post-readback current-local merge, then pending metadata. Pull has one GET/backup/merge/conditional local commit/pending and never PATCHes. Their differences are not removable duplicate complete state machines; this is the already-excluded common-prefix engine, not a new proposal.

Existing repository tests:88-193 exercise backup failure/corrupt second V3 read/V1 write failure; tests:296-345 exercise journal-owned rollback versus foreign concurrent value; storage-reliability.test.js:65-219 covers future schema, every write stage quota, journal-clear failure, missing/rejected WebLocks, serialization between tabs and stale CAS. cloud-sync.test.js:178-199 and 340-425 cover edits at metadata finalization, backup/local-readback failure, required second GET and edits during PATCH. These are substantial current protections, not complete arbitrary Storage getter/throw/request microtask trace qualification for a new combined engine.

## Result, verification limits and next decision

No fresh closed, materials-worthy duplicate was found among these five cuts. Do not implement a callback-policy engine or a speculative helper series merely to get a new candidate. The three genuinely new close reads above (legacy numeric-access mismatch, Gist late backup enumeration, migration stable-ID bookkeeping) have concrete bounds/reasons; they do not establish impossibility for other storage representation or larger architecture designs.

If a later independent candidate identifies an actually retained duplicate body large enough to justify qualification, preserve its precise source/built reachability and require frozen old/new API byte/error/access traces, complete journal/lock/storage operation traces and same request/await order before any authorized actual original-recipe three-build measurement. Existing full test results alone do not certify a new deduplication. No moving data/templates off the app budget, weakening fields/compatibility, deleting all-shard work or changing the five groups/target/budget is proposed.

Trust verdict: **CONDITIONALLY TRUSTED for this read-only static assessment**, with no new current-data defect found. There is no new behavior PASS, gzip benefit, runtime latency, cloud-write, production or M3 admission claim. Current all-gzip remains the recorded 84187 against 77227.7; original M3 budget/remote-audit/open release status are not closed by this review.

Evidence: inventory.mjs and inventory.json contain original local command logic, exact source before/after hashes, all actual chunk byte/SHA records, emitted function-anchor sizes and explicit attribution limits. The final AST inventory command exited 0; it parses existing code only. No root, A/B qualification, site, package, lock or other repository file was edited.
