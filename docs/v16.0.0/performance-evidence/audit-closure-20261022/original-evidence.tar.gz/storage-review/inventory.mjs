import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const root = 'D:/AI项目/FundVal', require = createRequire(resolve(root, 'package.json'));
const { parseSync } = await import(pathToFileURL(require.resolve('rolldown/utils')));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const paths = ['js/storage.js', ...['holdings-schema', 'holdings-migration', 'holdings-repository', 'cloud-sync', 'gist-remote',
  'cloud-archive-ui', 'cloud-runtime', 'gist-runtime', 'startup-repository'].map(name => `js/storage/${name}.js`),
  'scripts/build-site.mjs', 'scripts/release-fingerprint.mjs'];
const sourceHashesBefore = {}, sourceFiles = [];
function visit(node, callback, parent = null) {
  if (!node || typeof node !== 'object') return;
  if (typeof node.type === 'string') callback(node, parent);
  for (const [key, child] of Object.entries(node)) {
    if (['loc', 'start', 'end'].includes(key)) continue;
    if (Array.isArray(child)) child.forEach(value => visit(value, callback, node));
    else if (child && typeof child === 'object') visit(child, callback, node);
  }
}
for (const path of paths) {
  const bytes = await readFile(resolve(root, path)), code = bytes.toString('utf8');
  sourceHashesBefore[path] = hash(bytes);
  const program = parseSync(path, code).program, functions = [];
  visit(program, node => {
    if (node.type === 'FunctionDeclaration') functions.push({ name: node.id?.name, line: code.slice(0, node.start).split('\n').length,
      rawBytes: Buffer.byteLength(code.slice(node.start, node.end)) });
  });
  sourceFiles.push({ path, bytes: bytes.length, functions });
}
const manifestBytes = await readFile(resolve(root, 'site/js/app-chunks.json')), manifest = JSON.parse(manifestBytes);
const chunks = [];
for (const row of manifest.chunks) {
  const bytes = await readFile(resolve(root, 'site', row.path)), code = bytes.toString('utf8');
  if (bytes.length !== row.bytes || hash(bytes) !== row.sha256) throw Error('Existing chunk differs from manifest: ' + row.path);
  const functions = [];
  visit(parseSync(row.path, code).program, (node, parent) => {
    if (['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.type)) functions.push({
      start: node.start, end: node.end, name: node.id?.name || parent?.key?.name || '<anonymous>' });
  });
  chunks.push({ ...row, code, functions });
}
const anchors = {
  normalizeHoldingRecordV3: 'invalid_record', normalizeHoldingsDocumentV3: 'expected holdings schema 3',
  migrateLegacyHoldingsToV3: 'expected a legacy array or schema 2 document', parseAndMigrateHoldings: 'holdings payload must be an object or array',
  persistHoldingsDocument: 'journal_write_failed', loadHoldingsRepository: 'compat_projection_corrupt',
  reconcileLegacyHoldings: 'legacy holdings must be an array', recoverPendingRepositoryTransaction: 'journal_finalize_failed',
  canonicalCloudPayload: 'cloud payload schema mismatch', makeCloudWritePayload: 'cloud writes support only schema 2 or schema 3',
  reconcileCloudBridgePayloadSet: 'bridge_v3_missing', synchronizeHoldingsCloud: 'local_snapshot_unstable',
  pullHoldingsCloud: 'pull-initial', createGistRemoteAdapter: 'Gist adapter requires a request function',
  readableFile: 'file_truncated', findExistingHoldingsGist: 'https://api.github.com/gists?per_page=100&page=',
};
const emittedAnchors = Object.entries(anchors).map(([name, anchor]) => ({ name, anchor,
  matches: chunks.flatMap(chunk => {
    const positions = []; let at = chunk.code.indexOf(anchor);
    while (at >= 0) { positions.push(at); at = chunk.code.indexOf(anchor, at + anchor.length); }
    return positions.map(position => {
      const fn = chunk.functions.filter(node => node.start <= position && node.end > position).sort((a, b) => (a.end - a.start) - (b.end - b.start))[0];
      return { chunk: chunk.path, compiledFunction: fn?.name || null,
        functionRawBytes: fn ? Buffer.byteLength(chunk.code.slice(fn.start, fn.end)) : null };
    });
  }) }));
const sourceHashesAfter = {};
for (const path of paths) sourceHashesAfter[path] = hash(await readFile(resolve(root, path)));
if (JSON.stringify(sourceHashesBefore) !== JSON.stringify(sourceHashesAfter)) throw Error('Inspected source changed during inventory');
console.log(JSON.stringify({ checkedAt: new Date().toISOString(), mode: 'Read-only existing-source and existing-artifact AST inventory. No build, test, variant, minifier or candidate gzip run.',
  sourceHashesBefore, sourceHashesAfter, sourceFiles, manifestSha256: hash(manifestBytes),
  existingChunks: chunks.map(({ code, functions, ...row }) => row),
  totals: { allManifestGzipBytes: chunks.reduce((sum, row) => sum + row.gzipBytes, 0),
    coldManifestGzipBytes: chunks.filter(row => row.role === 'cold').reduce((sum, row) => sum + row.gzipBytes, 0),
    allRawBytes: chunks.reduce((sum, row) => sum + row.bytes, 0) }, emittedAnchors,
  emittedIdentityConflictLiteralOccurrences: ['fund_code_identity_conflict', 'id_fund_code_conflict'].map(literal => ({ literal,
    occurrences: chunks.reduce((sum, chunk) => sum + chunk.code.split(literal).length - 1, 0) })),
  limitations: ['Gzip values are the unchanged manifest measurements, not marginal module gzip estimates.',
    'Anchor ownership is a bounded AST/text attribution, not source maps or a complete semantic/link proof.',
    'No synthetic API/getter/throw/storage/request behavior was executed in this read-only review.'] }, null, 2));
