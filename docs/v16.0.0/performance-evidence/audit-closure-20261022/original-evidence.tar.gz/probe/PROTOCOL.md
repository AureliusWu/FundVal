# Independent root audit recheck, 2026-10-22

Previous qualification turn made concrete progress: isolated Vite8.2.4 six-build/full-behavior screen passed, exactly five dependency scalars applied, root full QA/three builds passed, while root audit503 and one timeout remained UNKNOWN. Those records remain immutable.

This new independent probe has ONE npm audit attempt only (full JSON, includes dev), official registry, --fetch-timeout=20000 --fetch-retries=0, parent hard timeout45000ms. No retries after any result, no registry/package/source/budget/validator changes, no install/build/test/sampler. NonJSON/service error/timeout is UNKNOWN, not vulnerability0. PASS requires nativeexit0, metadata.vulnerabilities.total0 and vulnerabilities{} with all six original GHSA absent. A time-specific dependency audit is not universal security/production evidence.

Before/after require current root all270 frozen input rows equal prior B frozen and current all127-site inventory equal prior root round3; no source/output normalization or omitted differences. Capture full native command/stdout/stderr only in local Temp, do not print/commit response cookies. If archiving service-error headers, redact only cookie headers with original/sanitized hashes.

This does not rerun or change prior failed qualification. New evidence may close only its previously missing root audit after independent identity revalidation. Prior 1224/1221/3skip, syntax212, Chrome33 and nine artifact builds remain historical scoped evidence for these exact input/output identities, not newly executed tests, relative latency, exact-source CI, devices or release. M3 all84187>77227.7 and minimum6960 integer reduction remain hard failures.
