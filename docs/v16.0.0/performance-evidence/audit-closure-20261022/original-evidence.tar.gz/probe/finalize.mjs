import assert from 'node:assert/strict';
import { readFile,readdir,lstat,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const old='C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a',review='C:/Users/84046/AppData/Local/Temp/fundval-vite824-final-independent-review-20261022-4fc193e8/review-result.json';
const json=async p=>JSON.parse(await readFile(p,'utf8')),sha=b=>createHash('sha256').update(b).digest('hex');
const probe=await json(resolve(here,'result.json')),receipt=await json(resolve(here,'native-receipt-local.json'));
assert.equal(probe.verdict,'PASS_ROOT_AUDIT_ZERO');assert.equal(receipt.status,0);const audit=JSON.parse(receipt.stdout);
assert.equal(audit.metadata.vulnerabilities.total,0);assert.deepEqual(audit.vulnerabilities,{});assert.equal(receipt.stderr,'');
const prior=await json(review),priorQa=await json(resolve(old,'qa-summary.json'));
const rows=[];async function visit(path){const full=resolve(root,'node_modules',path),s=await lstat(full);assert.ok(!s.isSymbolicLink());if(s.isDirectory())for(const n of await readdir(full))await visit(path==='.'?n:path+'/'+n);
else if(path.endsWith('/package.json')||path==='package.json'||path==='.package-lock.json'||/\.(?:node|exe|dll|so|dylib)$/i.test(path)||path==='esbuild/bin/esbuild'){const b=await readFile(full);rows.push({path,bytes:b.length,sha256:sha(b)});}}
await visit('.');rows.sort((a,b)=>a.path.localeCompare(b.path));const installed={count:rows.length,bytes:rows.reduce((n,r)=>n+r.bytes,0),sha256:sha(JSON.stringify(rows))};
assert.deepEqual(installed,prior.installed.manifestsAndNativeInventory);
for(const [file,hash] of Object.entries(prior.evidenceHashes))assert.equal(sha(await readFile(resolve(old,file))),hash,'Historical evidence changed: '+file);
const args=['scripts/release-fingerprint.mjs','--assert-app-bundle-budget','site'],started=new Date().toISOString(),r=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',windowsHide:true});
const budgetReceipt={command:process.execPath,args,cwd:root,started,ended:new Date().toISOString(),status:r.status,stdout:r.stdout,stderr:r.stderr};
await writeFile(resolve(here,'budget-native.json'),JSON.stringify(budgetReceipt,null,2)+'\n',{flag:'wx'});
assert.equal(r.status,1);const budget=JSON.parse(r.stdout);assert.equal(budget.actualAllNonOcrGzipBytes,84187);assert.equal(budget.actualColdStartGzipBytes,44699);assert.equal(budget.allBudgetBytes,77227.7);assert.equal(budget.allPass,false);
const report={schema:1,status:'VITE824_LOCAL_QUALIFICATION_COMPLETE_M3_STILL_FAIL',rootQualificationComplete:true,appVersion:'15.0.2',
 sourceAndOutputIdentity:probe.after,installedIdentity:installed,installedRows:rows,audit:{nativeExit:0,total:0,devIncluded:71,started:receipt.started,ended:receipt.ended,attemptsInThisIndependentProbe:1,maxAttempts:1},
 priorQualification:{path:old,qaSummarySha256:sha(await readFile(resolve(old,'qa-summary.json'))),independentReviewSha256:sha(await readFile(review)),
 fullQaNotRerun:true,unit:priorQa.root.unit,syntax:priorQa.root.syntaxFiles,e2e:priorQa.root.e2eSummary,sourceExact:true,outputExact:true,preservedRoot503AndTimeout:true},
 budget:{nativeExit:1,...budget,minimumIntegerReductionBytes:6960},stage:'M3_IN_PROGRESS',relativeLatencyQualified:false,newCi:false,pushed:false,deployed:false,
 limitations:['Dependency audit0 is time-specific; it does not prove universal security or production non-exploitability.','No full tests/build/browser/performance were rerun in this audit-only probe.','The original all-budget remains FAIL; all original grouping/target/compatibility/source validation constraints remain.']};
await writeFile(resolve(here,'final-status.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...report,installedRows:undefined}));
