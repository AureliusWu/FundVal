import assert from 'node:assert/strict';
import { readFile,readdir,lstat,cp,mkdir,mkdtemp,writeFile,copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { dirname,resolve,join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
const here=dirname(fileURLToPath(import.meta.url)),out='D:/AI项目/FundVal/docs/v16.0.0/performance-evidence/audit-closure-20261022';
const sha=b=>createHash('sha256').update(b).digest('hex');
const staging=await mkdtemp(join(tmpdir(),'fundval-audit-closure-archive-'));
const cohorts=[['probe',here],['independent-audit-review','C:/Users/84046/AppData/Local/Temp/fundval-audit-recheck-independent-20261022-112647-825'],
 ['diagnostics-review','C:/Users/84046/AppData/Local/Temp/fundval-diagnostics-structure-review-20261022-112112-922'],
 ['cross-group-review','C:/Users/84046/AppData/Local/Temp/fundval-m3-cross-group-readonly-20261022-execution-contract.md'],
 ['storage-review','C:/Users/84046/AppData/Local/Temp/fundval-storage-boundary-review-20261022-39ad715e']];
for(const [name,from]of cohorts)await cp(from,resolve(staging,name),{recursive:true,errorOnExist:true,force:false});
async function inventory(base){const rows=[];async function visit(p){const f=resolve(base,p),s=await lstat(f);assert.ok(!s.isSymbolicLink());if(s.isDirectory())for(const n of await readdir(f))await visit(p==='.'?n:p+'/'+n);else{assert.ok(s.isFile());const b=await readFile(f);rows.push({path:p,bytes:b.length,sha256:sha(b)});}}await visit('.');rows.sort((a,b)=>a.path.localeCompare(b.path));return rows;}
const rows=await inventory(staging);await mkdir(out,{recursive:true});const archive=resolve(out,'original-evidence.tar.gz');
assert.equal(await lstat(archive).then(()=>true,()=>false),false);
for(const args of [['-czf',archive,'-C',staging,'.']]){const r=spawnSync('tar.exe',args,{encoding:'utf8',windowsHide:true});assert.equal(r.status,0,r.stderr);}
const extraction=await mkdtemp(join(tmpdir(),'fundval-audit-closure-extract-')),r=spawnSync('tar.exe',['-xzf',archive,'-C',extraction],{encoding:'utf8',windowsHide:true});assert.equal(r.status,0,r.stderr);
assert.deepEqual(await inventory(extraction),rows);const b=await readFile(archive);
const record={schema:1,archive:'original-evidence.tar.gz',files:rows.length,uncompressedBytes:rows.reduce((n,r)=>n+r.bytes,0),bytes:b.length,sha256:sha(b),inventorySha256:sha(JSON.stringify(rows)),extractionVerified:true,cohorts,rows};
await writeFile(resolve(out,'archive-audit.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
for(const [from,to]of [['final-status.json','final-status.json'],['result.json','audit-result.json']])await copyFile(resolve(here,from),resolve(out,to));
await copyFile(fileURLToPath(import.meta.url),resolve(out,'archive-tool.mjs.txt'));console.log(JSON.stringify({...record,rows:undefined}));
