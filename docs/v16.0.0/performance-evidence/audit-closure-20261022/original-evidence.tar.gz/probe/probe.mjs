import assert from 'node:assert/strict';
import { readFile,readdir,lstat,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const old='C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a';
const sha=b=>createHash('sha256').update(b).digest('hex'),read=async p=>JSON.parse(await readFile(p,'utf8'));
const frozen=await read(resolve(old,'B-source-frozen.json')),expectedSite=(await read(resolve(old,'ROOT-verification-3.json'))).whole;
async function identity(){const rows=[];for(const row of frozen.rows){const b=await readFile(resolve(root,row.path));rows.push({path:row.path,bytes:b.length,sha256:sha(b)});}assert.deepEqual(rows,frozen.rows);
 const site=[];async function visit(path){const full=resolve(root,'site',path),s=await lstat(full);assert.ok(!s.isSymbolicLink());if(s.isDirectory())for(const n of await readdir(full))await visit(path==='.'?n:path+'/'+n);else{assert.ok(s.isFile());const b=await readFile(full);site.push({path,bytes:b.length,sha256:sha(b)});}}
 await visit('.');site.sort((a,b)=>a.path.localeCompare(b.path));assert.deepEqual(site,expectedSite.rows);
 return {inputs:{files:rows.length,bytes:frozen.bytes,sha256:sha(JSON.stringify(rows))},site:{files:site.length,bytes:expectedSite.bytes,sha256:sha(JSON.stringify(site))}};}
const before=await identity(),args=['C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js','audit','--json','--registry=https://registry.npmjs.org','--fetch-timeout=20000','--fetch-retries=0'];
const started=new Date().toISOString(),r=spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',windowsHide:true,timeout:45000,maxBuffer:8*1024*1024});
const receipt={command:process.execPath,args,cwd:root,node:process.version,started,ended:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?.message||null,stdout:r.stdout||'',stderr:r.stderr||''};
await writeFile(resolve(here,'native-receipt-local.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
let body=null;try{body=JSON.parse(receipt.stdout);}catch{}
const ids=['GHSA-698v-4r3x-3vcv','GHSA-r825-w8mm-5pxw','GHSA-587h-7wmj-h5pm','GHSA-9jrq-w75r-8gcw','GHSA-rq7h-c2jc-7f22','GHSA-vfpm-58rq-9qcg'];
const zero=r.status===0&&body?.metadata?.vulnerabilities?.total===0&&JSON.stringify(body.vulnerabilities)==='{}'&&ids.every(id=>!receipt.stdout.includes(id));
const after=await identity();assert.deepEqual(before,after);
const report={schema:1,verdict:zero?'PASS_ROOT_AUDIT_ZERO':'UNKNOWN_REMOTE_SERVICE',nativeExit:r.status,signal:r.signal,error:receipt.error,started,ended:receipt.ended,before,after,
 metadata:zero?body.metadata:null,advisoryIdsAbsent:zero?ids:[],serviceMessage:typeof body?.message==='string'?body.message:null,attempts:1,maxAttempts:1,
 originalReceiptSha256:sha(await readFile(resolve(here,'native-receipt-local.json'))),previousQualification:'vite824-security-20261022',
 reranTests:false,relativeLatencyQualified:false,allBudgetPass:false,newCi:false,deployed:false};
await writeFile(resolve(here,'result.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));
process.exitCode=zero?0:2;
