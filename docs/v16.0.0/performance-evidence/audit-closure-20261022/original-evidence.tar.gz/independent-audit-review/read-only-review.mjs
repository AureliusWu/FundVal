import assert from 'node:assert/strict';
import { readFile, readdir, lstat } from 'node:fs/promises';
import { resolve, relative } from 'node:path';
import { createHash } from 'node:crypto';

const evidence = 'C:/Users/84046/AppData/Local/Temp/fundval-m3-audit-recheck-20261022-65c22cb471b2';
const qualification = 'C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a';
const priorReviewPath = 'C:/Users/84046/AppData/Local/Temp/fundval-vite824-final-independent-review-20261022-4fc193e8/review-result.json';
const root = 'D:/AI项目/FundVal';
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const hashFile = async path => sha(await readFile(path));
const protocol = await readFile(resolve(evidence, 'PROTOCOL.md'), 'utf8');
const probeCode = await readFile(resolve(evidence, 'probe.mjs'), 'utf8');
const receipt = await json(resolve(evidence, 'native-receipt-local.json'));
const result = await json(resolve(evidence, 'result.json'));
const final = await json(resolve(evidence, 'final-status.json'));
const budgetReceipt = await json(resolve(evidence, 'budget-native.json'));
const audit = JSON.parse(receipt.stdout);
const budget = JSON.parse(budgetReceipt.stdout);
const prior = await json(priorReviewPath);
const priorQa = await json(resolve(qualification, 'qa-summary.json'));
const frozen = await json(resolve(qualification, 'B-source-frozen.json'));
const expectedWhole = (await json(resolve(qualification, 'ROOT-verification-3.json'))).whole;
assert.match(protocol, /ONE npm audit attempt only/);
assert.equal((probeCode.match(/spawnSync\(/g) || []).length, 1);
assert.equal((await lstat(resolve(evidence, 'PROTOCOL.md'))).mtimeMs <= Date.parse(receipt.started), true);
assert.deepEqual(receipt.args, ['C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js', 'audit', '--json', '--registry=https://registry.npmjs.org', '--fetch-timeout=20000', '--fetch-retries=0']);
assert.equal(receipt.cwd, root); assert.equal(receipt.status, 0); assert.equal(receipt.signal, null); assert.equal(receipt.error, null); assert.equal(receipt.stderr, '');
assert.equal(audit.auditReportVersion, 2); assert.deepEqual(audit.vulnerabilities, {});
assert.deepEqual(audit.metadata.vulnerabilities, { info: 0, low: 0, moderate: 0, high: 0, critical: 0, total: 0 });
assert.equal(audit.metadata.dependencies.dev, 71);
assert.equal(result.attempts, 1); assert.equal(result.maxAttempts, 1);
assert.equal(result.originalReceiptSha256, await hashFile(resolve(evidence, 'native-receipt-local.json')));
const advisoryIds = ['GHSA-698v-4r3x-3vcv','GHSA-r825-w8mm-5pxw','GHSA-587h-7wmj-h5pm','GHSA-9jrq-w75r-8gcw','GHSA-rq7h-c2jc-7f22','GHSA-vfpm-58rq-9qcg'];
assert.deepEqual(result.advisoryIdsAbsent, advisoryIds);
advisoryIds.forEach(id => assert.equal(receipt.stdout.includes(id), false));
const inputRows = [];
for (const row of frozen.rows) {
  const path = resolve(root, row.path); assert.equal(relative(root, path).startsWith('..'), false);
  const bytes = await readFile(path); inputRows.push({ path: row.path, bytes: bytes.length, sha256: sha(bytes) });
}
assert.deepEqual(inputRows, frozen.rows);
const wholeRows = [];
async function walkSite(path) {
  const absolute = resolve(root, 'site', path), stat = await lstat(absolute); assert.equal(stat.isSymbolicLink(), false);
  if (stat.isDirectory()) for (const name of await readdir(absolute)) await walkSite(path === '.' ? name : `${path}/${name}`);
  else { assert.equal(stat.isFile(), true); const bytes = await readFile(absolute); wholeRows.push({ path, bytes: bytes.length, sha256: sha(bytes) }); }
}
await walkSite('.'); wholeRows.sort((a,b) => a.path.localeCompare(b.path)); assert.deepEqual(wholeRows, expectedWhole.rows);
assert.deepEqual(result.before, result.after);
assert.equal(inputRows.length, 270); assert.equal(wholeRows.length, 127);
assert.equal(sha(JSON.stringify(inputRows)), result.after.inputs.sha256);
assert.equal(sha(JSON.stringify(wholeRows)), result.after.site.sha256);
assert.deepEqual(final.sourceAndOutputIdentity, result.after);
const installedRows = [];
async function walkInstalled(path) {
  const absolute = resolve(root, 'node_modules', path), stat = await lstat(absolute); assert.equal(stat.isSymbolicLink(), false);
  if (stat.isDirectory()) for (const name of await readdir(absolute)) await walkInstalled(path === '.' ? name : `${path}/${name}`);
  else if (path.endsWith('/package.json') || path === 'package.json' || path === '.package-lock.json' || /\.(?:node|exe|dll|so|dylib)$/i.test(path) || path === 'esbuild/bin/esbuild') {
    const bytes = await readFile(absolute); installedRows.push({ path, bytes: bytes.length, sha256: sha(bytes) });
  }
}
await walkInstalled('.'); installedRows.sort((a,b) => a.path.localeCompare(b.path));
const installed = { count: installedRows.length, bytes: installedRows.reduce((sum,row) => sum + row.bytes, 0), sha256: sha(JSON.stringify(installedRows)) };
assert.equal(installed.count, 68); assert.deepEqual(installed, prior.installed.manifestsAndNativeInventory);
assert.deepEqual(installedRows, final.installedRows); assert.deepEqual(installed, final.installedIdentity);
const historicReceipts = [];
for (const [path, expected] of Object.entries(prior.evidenceHashes)) {
  const actual = await hashFile(resolve(qualification, path)); assert.equal(actual, expected); historicReceipts.push({ path, sha256: actual });
}
assert.equal(final.priorQualification.qaSummarySha256, await hashFile(resolve(qualification, 'qa-summary.json')));
assert.equal(final.priorQualification.independentReviewSha256, await hashFile(priorReviewPath));
assert.deepEqual(final.priorQualification.unit, priorQa.root.unit); assert.deepEqual(final.priorQualification.syntax, priorQa.root.syntaxFiles); assert.deepEqual(final.priorQualification.e2e, priorQa.root.e2eSummary);
assert.equal(final.priorQualification.fullQaNotRerun, true); assert.equal(final.priorQualification.preservedRoot503AndTimeout, true);
assert.equal(budgetReceipt.status, 1); assert.deepEqual(budgetReceipt.args, ['scripts/release-fingerprint.mjs', '--assert-app-bundle-budget', 'site']);
assert.equal(budget.actualAllNonOcrGzipBytes, 84187); assert.equal(budget.actualColdStartGzipBytes, 44699); assert.equal(budget.allBudgetBytes, 77227.7); assert.equal(budget.allPass, false);
assert.equal(final.rootQualificationComplete, true); assert.equal(final.status, 'VITE824_LOCAL_QUALIFICATION_COMPLETE_M3_STILL_FAIL'); assert.equal(final.stage, 'M3_IN_PROGRESS');
assert.equal(final.relativeLatencyQualified, false); assert.equal(final.newCi, false); assert.equal(final.pushed, false); assert.equal(final.deployed, false);
const sensitiveHits = [], bundleHashes = [];
function scanJson(value, path) {
  if (typeof value === 'string') {
    if (/(?:^|\r?\n)\s*(?:set-cookie|cookie|authorization|proxy-authorization)\s*:/im.test(value)) sensitiveHits.push({ path, kind: 'HTTP sensitive header' });
    if (/\b(?:gh[pousr]_[A-Za-z0-9]{12,}|github_pat_[A-Za-z0-9_]{12,}|Bearer\s+[A-Za-z0-9._~+/-]{8,}|Basic\s+[A-Za-z0-9+/=]{8,})/i.test(value)) sensitiveHits.push({ path, kind: 'credential pattern' });
  } else if (value && typeof value === 'object') for (const [key, child] of Object.entries(value)) {
    if (/^(?:set-cookie|cookie|authorization|proxy-authorization|x-api-key)$/i.test(key)) sensitiveHits.push({ path: `${path}.${key}`, kind: 'sensitive header property' });
    scanJson(child, `${path}.${key}`);
  }
}
for (const name of (await readdir(evidence)).sort()) {
  const path = resolve(evidence, name), stat = await lstat(path); assert.equal(stat.isFile(), true);
  const bytes = await readFile(path), text = bytes.toString('utf8'); bundleHashes.push({ path: name, bytes: bytes.length, sha256: sha(bytes) });
  if (name.endsWith('.json')) scanJson(JSON.parse(text), name);
  else if (/(?:^|\r?\n)\s*(?:set-cookie|cookie|authorization|proxy-authorization)\s*:/im.test(text)) sensitiveHits.push({ path: name, kind: 'HTTP sensitive header line' });
}
assert.deepEqual(sensitiveHits, []);
console.log(JSON.stringify({ schema: 1, verdict: 'PASS_READ_ONLY_ROOT_AUDIT_CLOSURE_REVIEW', capturedAt: new Date().toISOString(),
  noNetworkTestBuildInstallOrAuditExecutedByReviewer: true,
  audit: { commandVerified: true, recordedNativeExit: receipt.status, recordedStart: receipt.started, recordedEnd: receipt.ended, attempts: 1, completeJson: true, vulnerabilitiesTotal: 0, devDependenciesIncluded: 71, originalSixAdvisoriesAbsent: true },
  sourceAndOutputIdentity: result.after, installedIdentity: installed, historicalReceiptHashesVerified: historicReceipts,
  priorQaKeptHistorical: true, budget: { nativeExit: budgetReceipt.status, allGzipBytes: 84187, allBudget: 77227.7, minimumIntegerGap: 6960, verdict: 'FAIL', importClosureVerifiedByThisBudgetReceipt: budget.importClosureVerified },
  finalStatusSupported: final.status, sensitiveOutputScan: { sensitiveHeaderOrCredentialFindings: sensitiveHits, archivalScope: 'only these seven new-probe files; do not copy prior raw 503 cookie-bearing receipts without their existing redaction rules' },
  bundleHashes, boundary: 'Time-specific local Vite patch qualification may close; M3 budget/performance/exact CI/release remain open. Prior full QA and original root 503+timeout are not rerun or rewritten.' }, null, 2));
