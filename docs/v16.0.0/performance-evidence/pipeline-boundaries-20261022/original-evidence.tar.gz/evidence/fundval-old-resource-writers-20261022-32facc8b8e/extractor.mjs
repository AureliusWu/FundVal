import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {APP_FUNCTIONS,APP_CONSTANTS} from './plan.mjs';
const require=createRequire('D:/AI项目/FundVal/package.json');
const {parseSync}=require('rolldown/utils');
export const sha=value=>createHash('sha256').update(value).digest('hex');
export async function extractApp(root){
  const original=await readFile(root+'/js/app.js');
  const source=original.toString('utf8').replaceAll('\r\n','\n');
  const result=parseSync('app.js',source);
  assert.equal(result.errors.length,0);
  const slices=[];
  for(const name of APP_FUNCTIONS){
    const nodes=result.program.body.filter(n=>n.type==='FunctionDeclaration'&&n.id.name===name);
    assert.equal(nodes.length,1,name);
    const n=nodes[0],text=source.slice(n.start,n.end);
    slices.push({name,kind:'function',start:n.start,end:n.end,line:source.slice(0,n.start).split('\n').length,
      endLine:source.slice(0,n.end).split('\n').length,sha256:sha(text),text});
  }
  for(const name of APP_CONSTANTS){
    const nodes=result.program.body.flatMap(n=>n.type==='VariableDeclaration'?n.declarations:[]).filter(n=>n.id.name===name);
    assert.equal(nodes.length,1,name);
    const n=nodes[0],text='const '+source.slice(n.start,n.end)+';';
    slices.push({name,kind:'constant',start:n.start,end:n.end,line:source.slice(0,n.start).split('\n').length,
      endLine:source.slice(0,n.end).split('\n').length,sha256:sha(text),text});
  }
  return {rawSha256:sha(original),normalizedSha256:sha(source),slices};
}
