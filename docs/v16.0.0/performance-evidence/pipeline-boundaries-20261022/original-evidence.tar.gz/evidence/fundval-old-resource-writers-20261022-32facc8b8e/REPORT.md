# OLD resource / outer-writer baseline attempt — incomplete, retained

2026-10-22. This is an unsuccessful preparation/run attempt, not a baseline qualification. No candidate was implemented. No build/install/minifier/network/browser or root source/site/docs/persistent-Storage writes occurred.

Prepared 234 finite cases and copied 80 current files (complete js tree, package.json, four existing test anchors, and the two next-http-boundary spec files). Current/frozen byte identities and exact AST App slices were frozen before execution. Source inventory rows SHA256: cd1664ef974852734ee9e2e49d4ba47c6085e40228c054a02065c4f9c995a4aa.

One native runner execution: exit 1, stdout 0 bytes, stderr 1300 bytes. It failed while importing the frozen old module closure: js/runtime/market-clock.js imports data/market-calendars.json, which was not included by the full-js-only freezer. Completed cases: 0/234. No case output was fabricated. FAILURE.json retains actual error/stack; NATIVE_RECEIPT.json retains command/cwd/native exit/UTC timing and output SHA. Native stderr SHA256: fc8919978ccf5655b6caf390ce400760c39a9a95155c83546b6755da8f17d3ba.

POSTFLIGHT.json confirms every frozen/current selected file, parser tree and prepared script remains unchanged; denied fetch and persistent-Storage attempts were zero. It does not assert that the source closure was complete. There was no retry, no source/harness repair, and no additional variant in this workspace.

Coverage/gap: all R01/R03/S01/S03 planned observations remain NOT_RUN. The App harness is based on actual AST slices of saveCache/slimFundCache/holdingsHash/reconcileActiveFundState and real imported dependencies, but its runtime behavior is not qualified. The next safe step requires a separately declared new system-Temp attempt that recursively freezes actual static imports, including JSON, before executing the same bounded case plan. This failure is a harness acquisition gap, not evidence about application semantics, complete candidate behavior, or 6960B/gzip materiality.

PROTOCOL.md, plan.mjs, CASES.json, extractor.mjs, APP_SLICES.json and app-extracted/ preserve exactly what was attempted. No changes to this prepared runner are proposed in place.
