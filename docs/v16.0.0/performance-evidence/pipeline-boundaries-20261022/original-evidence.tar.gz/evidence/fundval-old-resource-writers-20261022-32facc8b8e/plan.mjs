export const ROW_FIELDS = ('code name type status source kind source_status last_nav est_nav est_change nav_date est_time '
  + 'source_time source_time_precision est_label est_kind est_realtime est_note is_fallback value_date base_nav_date '
  + 'base_nav value_nav value_change estimate_nav estimate_change coverage quote_count report_date model_version '
  + 'estimate_model_version target_nav_date est_model_version fallback_reason fetched_at').split(' ');
export const cases = [
  ...ROW_FIELDS.flatMap(field => ['absent','undefined','null','nan','minus-zero'].map(state => ({id:`R01:${field}:${state}`,kind:'presence',field,state}))),
  {id:'R01:official-null-aliases',kind:'official'},
  {id:'R01:metadata-not-inverse-of-quote',kind:'metadata'},
  ...['row','quote','payload'].flatMap(target => ['enumerable-string','enumerable-symbol','nonenumerable-string'].map(mode => ({id:`R03:${target}:${mode}`,kind:'strict',target,mode}))),
  {id:'R03:allowed-nonenumerable-name',kind:'strict',target:'row',mode:'allowed-nonenumerable'},
  ...['row.source_quote','row.name','quote.value','payload.rows'].flatMap(target => ['acquisition','strict'].map(mode => ({id:`R03:getter:${target}:${mode}`,kind:'getter',target,mode}))),
  ...['numeric-string','boolean','positive-infinity','negative-infinity','nan','zero','minus-zero','inside-tolerance','exact-tolerance','outside-tolerance'].map(mode => ({id:`R02:alias:${mode}`,kind:'alias',mode})),
  {id:'R02:wire-numeric-string',kind:'wire'},
  ...['common-order-unknown','new-fund-acquisition','market-only','no-own-time','inactive-pruning','empty-active'].map(mode=>({id:`S01:refresh:${mode}`,kind:'refresh',mode})),
  ...['common-order-unknown','reconcile-amounts-active','empty-active','persist-false','previous-no-data','previous-malformed','read-throw','set-throw','row-getter-throw','row-cycle','remove-throw'].map(mode=>({id:`S01-S03:edit:${mode}`,kind:'edit',mode})),
  ...['duplicate','invalid-clock','row-getter','row-cycle'].map(mode=>({id:`S03:direct-refresh:${mode}`,kind:'direct-error',mode})),
  ...['success','storage-throw','storage-false','duplicate','invalid-clock','row-getter','row-cycle'].map(mode=>({id:`S03:scope:${mode}`,kind:'scope',mode})),
];
export const APP_FUNCTIONS = ['saveCache','slimFundCache','holdingsHash','reconcileActiveFundState'];
export const APP_CONSTANTS = ['CACHE_KEY','SKIP_CACHE_KEYS'];
export const anchors = ['test/refresh-resource-cache-v16.test.js','test/generation-resource-scope-v16.test.js',
  'test/cache-fund-identity-v16.test.js','test/app-holdings-hash-closed-v16.test.js'];
