$ErrorActionPreference='Stop'
$taskDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$taskNode=(Get-Command node).Source
$stdoutPath=Join-Path $taskDir 'native.stdout.txt'
$stderrPath=Join-Path $taskDir 'native.stderr.txt'
if (Test-Path -LiteralPath $stdoutPath) { throw 'Native output already exists; no retry' }
$start=[DateTime]::UtcNow
$timer=[System.Diagnostics.Stopwatch]::StartNew()
& $taskNode (Join-Path $taskDir 'runner.mjs') 1> $stdoutPath 2> $stderrPath
$nativeExit=$LASTEXITCODE
$timer.Stop()
$receipt=[ordered]@{command=@($taskNode,(Join-Path $taskDir 'runner.mjs'));cwd=(Get-Location).Path;startedUtc=$start.ToString('o');endedUtc=[DateTime]::UtcNow.ToString('o');elapsedMs=$timer.ElapsedMilliseconds;nativeExit=$nativeExit;stdout=(Get-FileHash -LiteralPath $stdoutPath -Algorithm SHA256).Hash.ToLower();stderr=(Get-FileHash -LiteralPath $stderrPath -Algorithm SHA256).Hash.ToLower();stdoutBytes=(Get-Item -LiteralPath $stdoutPath).Length;stderrBytes=(Get-Item -LiteralPath $stderrPath).Length}
$receipt|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $taskDir 'NATIVE_RECEIPT.json') -Encoding UTF8
Write-Output ($receipt|ConvertTo-Json -Compress)
exit $nativeExit
