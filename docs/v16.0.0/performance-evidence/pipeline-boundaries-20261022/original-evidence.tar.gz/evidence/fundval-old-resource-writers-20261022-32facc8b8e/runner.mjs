import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname,join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {extractApp,sha} from './extractor.mjs';
import {inventory,named} from './inventory.mjs';
import {cases} from './plan.mjs';
const dir=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const prepared=JSON.parse(await readFile(join(dir,'PREPARED.json'),'utf8'));
assert.deepEqual(await named(dir,prepared.scripts.map(r=>r.path)),prepared.scripts);
for(const r of prepared.source)assert.equal(sha(await readFile(join(root,r.path))),r.sha256,'Current changed: '+r.path);
assert.deepEqual(await inventory(prepared.frozen),prepared.source);
for(const p of prepared.parser)assert.deepEqual(await inventory(p.root),p.rows);
const NOW=Date.parse('2026-09-30T06:00:00Z'),LATER=NOW+5000,CODE='005844',OTHER='000001',KEY='estimates:'+CODE;
const CACHE_KEY='fuyu_funds_cache_v1';
const actualDateNow=Date.now; Date.now=()=>NOW;
let deniedFetch=0,deniedStorage=0;
const previousFetch=globalThis.fetch,previousLocal=Object.getOwnPropertyDescriptor(globalThis,'localStorage'),previousSession=Object.getOwnPropertyDescriptor(globalThis,'sessionStorage');
globalThis.fetch=()=>{deniedFetch++;throw new Error('Network prohibited');};
for(const n of ['localStorage','sessionStorage'])Object.defineProperty(globalThis,n,{configurable:true,get(){deniedStorage++;throw new Error('Persistent Storage prohibited');}});
const modules=async base=>{
  const get=async p=>import(pathToFileURL(join(base,p)).href);
  return {resource:await get('js/runtime/refresh-resource-cache.js'),scope:await get('js/runtime/generation-resource-scope.js'),
    storage:await get('js/storage.js'),active:await get('js/runtime/active-holdings.js'),amounts:await get('js/runtime/holding-quote-amounts.js'),
    schema:await get('js/storage/holdings-schema.js'),quote:await get('js/runtime/quote-contract.js'),wire:await get('js/runtime/worker-contract.js'),
    ttl:(await get('js/config.js')).TTL,app:await extractApp(base)};
};
function representation(value,seen=new Map()){
  if(value===undefined)return {type:'undefined'};
  if(typeof value==='number')return Number.isNaN(value)?{type:'number',value:'NaN'}:Object.is(value,-0)?{type:'number',value:'-0'}:!Number.isFinite(value)?{type:'number',value:String(value)}:value;
  if(typeof value==='symbol')return {type:'symbol',description:value.description};
  if(typeof value==='function')return {type:'function',name:value.name};
  if(value===null||typeof value!=='object')return value;
  if(seen.has(value))return {ref:seen.get(value)};
  const id=seen.size;seen.set(value,id);
  return {id,type:Array.isArray(value)?'array':'object',frozen:Object.isFrozen(value),keys:Reflect.ownKeys(value).map(key=>{
    const d=Object.getOwnPropertyDescriptor(value,key);
    return {key:typeof key==='symbol'?{symbol:key.description}:key,enumerable:d.enumerable,configurable:d.configurable,
      ...('value'in d?{writable:d.writable,value:representation(d.value,seen)}:{get:d.get?.name||null,set:d.set?.name||null})};
  })};
}
const errorInfo=(e,sentinel)=>({name:e?.name,message:e?.message,sentinel:e===sentinel,constructor:e?.constructor?.name});
function outcome(fn,sentinel){try{const value=fn();return {ok:true,value};}catch(error){return {ok:false,error:errorInfo(error,sentinel)};}}
function serialResult(result){if(!result.ok)return result;const value=result.value;const json=outcome(()=>JSON.stringify(value));return {ok:true,shape:representation(value),json:json.ok?{value:json.value??null,sha256:json.value===undefined?null:sha(json.value)}:{error:json.error}};}
function observedJSON(trace,sentinel){const parse=JSON.parse,stringify=JSON.stringify;return {
  parse(...args){trace.push({op:'JSON.parse'});try{return parse(...args);}catch(error){trace.push({op:'JSON.parse.throw',error:errorInfo(error,sentinel)});throw error;}},
  stringify(...args){trace.push({op:'JSON.stringify'});try{return stringify(...args);}catch(error){trace.push({op:'JSON.stringify.throw',error:errorInfo(error,sentinel)});throw error;}}
};}
function traceSerialize(trace,sentinel,fn){const original=JSON.stringify,observed=observedJSON(trace,sentinel);JSON.stringify=observed.stringify;
  try{return fn();}catch(error){trace.push({op:'serializer.throw',error:errorInfo(error,sentinel)});throw error;}finally{JSON.stringify=original;}}
function observe(value,label,trace){return new Proxy(value,{get(o,k,r){trace.push(['get',label,typeof k==='symbol'?'symbol:'+k.description:k]);return Reflect.get(o,k,r);},
  ownKeys(o){trace.push(['ownKeys',label]);return Reflect.ownKeys(o);},getOwnPropertyDescriptor(o,k){trace.push(['descriptor',label,typeof k==='symbol'?'symbol:'+k.description:k]);return Reflect.getOwnPropertyDescriptor(o,k);},
  set(o,k,v,r){trace.push(['set',label,String(k)]);return Reflect.set(o,k,v,r);}});}
const q=(extra={})=>({fundCode:CODE,fundName:'Synthetic fund',market:'cn',assetKind:'fund',valueKind:'intraday_estimate',value:1.1,changePct:0,baseNav:1,
  baseNavDate:'2026-09-29',targetDate:'2026-09-30',sourceId:'sinan-estimate-proxy',sourceTier:'primary',status:'realtime',
  observedAt:'2026-09-30T05:59:00Z',fetchedAt:'2026-09-30T06:00:00Z',reasonCodes:[],...extra});
const basicRow=()=>({code:CODE,name:'Synthetic fund',status:'ok',est_change:0,source_quote:q()});
const options=()=>({now:NOW,fetchedAt:NOW,sourceDate:'2026-09-30'});
const nav=(code=CODE)=>({code,source:'eastmoney-official-nav',status:'current',nav:1.1,prevNav:1,date:'2026-09-29',prevDate:'2026-09-28',change:10,changeAmt:0.1,fundName:'Synthetic fund'});
const navEntry=(m,at=NOW,code=CODE)=>m.resource.makeRefreshResourceEntry('nav:'+code,nav(code),{now:at,fetchedAt:at,sourceDate:'2026-09-29'});
function resourceInput(c,trace,sentinel){
  let row=basicRow(),raw=row.source_quote,payload={codes:[CODE],rows:[row],source:'sinan-estimate-proxy'};
  if(c.kind==='presence'){
    delete row[c.field];if(c.state!=='absent')row[c.field]={undefined:undefined,null:null,nan:NaN,'minus-zero':-0}[c.state];
  }else if(c.kind==='official'){
    raw=q({valueKind:'official_nav',sourceId:'eastmoney-official-nav',sourceTier:'secondary',status:'official',observedAt:'2026-09-29',
      officialNavDate:'2026-09-29',targetDate:'2026-09-29',baseNavDate:'2026-09-28'});
    row={code:CODE,status:'ok',last_nav:null,base_nav:undefined,est_nav:1.1,value_nav:1.1,estimate_nav:null,value_change:0,estimate_change:null,est_change:-0,source_quote:raw};
  }else if(c.kind==='metadata'){
    row={...row,coverage:101,quote_count:3.5,report_date:'not-a-date',model_version:'row-v1',estimate_model_version:null,
      est_model_version:undefined,fetched_at:'safe-but-not-timestamp',type:-0};
  }else if(c.kind==='strict'){
    const target=c.target==='row'?row:c.target==='quote'?raw:payload;
    if(c.mode==='enumerable-string')target.extraUnknown='opaque';
    if(c.mode==='enumerable-symbol')target[Symbol('extra')]='opaque';
    if(c.mode==='nonenumerable-string')Object.defineProperty(target,'extraUnknown',{value:'opaque',enumerable:false});
    if(c.mode==='allowed-nonenumerable')Object.defineProperty(row,'name',{value:'hidden-own-name',enumerable:false,configurable:true});
  }else if(c.kind==='alias'){
    row.est_change={'numeric-string':'0',boolean:false,'positive-infinity':Infinity,'negative-infinity':-Infinity,nan:NaN,zero:0,'minus-zero':-0,
      'inside-tolerance':0.999999e-7,'exact-tolerance':1e-7,'outside-tolerance':1.000001e-7}[c.mode];
  }
  if(c.kind==='getter'){
    const [owner,key]=c.target.split('.');const target=owner==='row'?row:owner==='quote'?raw:payload;
    if(c.target!=='payload.rows')Object.defineProperty(target,key,{enumerable:true,configurable:true,get(){trace.push(['sentinel',c.target]);throw sentinel;}});
  }
  if(c.kind!=='getter'||c.target!=='row.source_quote')row.source_quote=observe(raw,'quote',trace);
  row=observe(row,'row',trace);payload.rows=[row];
  if(c.kind==='getter'&&c.target==='payload.rows')Object.defineProperty(payload,'rows',{enumerable:true,configurable:true,get(){trace.push(['sentinel',c.target]);throw sentinel;}});
  payload=observe(payload,'payload',trace);
  return {row,payload,sourceDate:c.kind==='official'?'2026-09-29':'2026-09-30'};
}
function resourceCase(m,c){
  const outputs={};
  for(const operation of c.kind==='getter'?[c.mode]:['acquisition','strict','json-restored']){
    const trace=[],sentinel=Object.assign(new Error('sentinel:'+c.id),{name:'SentinelError'});
    const input=resourceInput(c,trace,sentinel);
    const result=outcome(()=>{
      if(operation==='acquisition')return m.resource.makeRefreshResourceEntry(KEY,input.payload,{...options(),sourceDate:input.sourceDate});
      const base=m.resource.makeRefreshResourceEntry(KEY,{codes:[CODE],rows:[basicRow()],source:'sinan-estimate-proxy'},options());
      const rawEntry={...base,sourceDate:input.sourceDate,payload:input.payload};
      return m.resource.validateRefreshResourceEntry(KEY,operation==='json-restored'?JSON.parse(JSON.stringify(rawEntry)):rawEntry,{now:NOW});
    },sentinel);
    const actualTrace=trace.slice();outputs[operation]={...serialResult(result),trace:actualTrace,accepted:result.ok&&result.value!==null};
    if(c.kind==='strict'){
      const expected=operation!=='acquisition'&&c.mode==='enumerable-string'?false:true;
      assert.equal(outputs[operation].accepted,expected,c.id+':'+operation);
    }
    if(c.kind==='getter')assert.equal(outputs[operation].accepted,false,c.id+':'+operation);
    if(c.kind==='alias')assert.equal(outputs[operation].accepted,
      !['numeric-string','boolean','outside-tolerance',...(operation==='json-restored'?[]:['positive-infinity','negative-infinity'])].includes(c.mode),c.id+':'+operation);
    if(['official','metadata'].includes(c.kind))assert.equal(outputs[operation].accepted,true,c.id+':'+operation);
  }
  return outputs;
}
function writerRow(m,trace){
  const row={zUnknown:{nested:'keep'},primary_nav:999,code:CODE,shares:999,cost:888,today_profit:777,curr_value:666,
    undefinedField:undefined,nanField:NaN,minusZero:-0,functionField:function opaque(){},message:'drop',quoteCandidates:['drop'],_cached:true,
    quote:m.quote.createQuoteEnvelope(q(),{now:NOW}),tailUnknown:'tail'};
  row[Symbol('aggregateSymbol')]='drop';Object.defineProperty(row,'nonEnumerableUnknown',{value:'drop',enumerable:false});return observe(row,'aggregate-row',trace);
}
function previous(m,ownTime=true){const value={topZ:'retain-edit-only',holdingsHash:'old',data:[{code:CODE}],
  source:'old-source',refreshResources:{['nav:'+CODE]:navEntry(m),['nav:'+OTHER]:navEntry(m,NOW,OTHER)},
  expiresAt:NOW+m.ttl.INTRADAY,fetchedAt:NOW,topA:{unknown:true}};if(ownTime)value.time=NOW-1;return value;}
function storageAdapter(initial,mode,sentinel,trace){
  let bytes=initial;const counts={get:0,set:0,remove:0};
  const fail=()=>{trace.push({op:'Storage.throw',error:errorInfo(sentinel,sentinel)});throw sentinel;};
  return {counts,read:()=>bytes,storage:{getItem(key){counts.get++;trace.push({op:'get',key});if(mode==='read-throw')fail();return bytes;},
    setItem(key,value){counts.set++;trace.push({op:'set',key,value,sha256:sha(value)});if(mode==='set-throw'||mode==='storage-throw')fail();if(mode==='storage-false')return false;bytes=String(value);},
    removeItem(key){counts.remove++;trace.push({op:'remove',key});if(mode==='remove-throw')fail();bytes=null;}}};
}
function appHarness(m,rows,store,mode,trace,sentinel){
  const T0='2026-09-28T00:00:00.000Z',T1='2026-09-29T00:00:00.000Z';
  const holdingRecords=mode==='empty-active'||mode==='remove-throw'?[]:[{id:'fund:'+CODE,fundCode:CODE,fundName:'Current fund',shares:10,costNav:1.25,
    createdAt:T0,updatedAt:T1,deletedAt:null,revision:1,deviceId:'synthetic:device',note:null}];
  const document=m.schema.normalizeHoldingsDocumentV3({schema:3,updatedAt:T1,deviceId:'synthetic:device',holdings:holdingRecords});
  const bindings={...m.active,...m.amounts,canonicalHoldingsDocument:m.schema.canonicalHoldingsDocument,JSON:observedJSON(trace,sentinel),
    safeGetItem:key=>m.storage.safeGetItem(key,store.storage),safeSetItem:(key,value)=>m.storage.safeSetItem(key,value,store.storage),
    safeRemoveItem:key=>m.storage.safeRemoveItem(key,store.storage),
    initialHoldings:m.schema.toLegacyHoldings(document),initialDocument:document,initialRows:rows,
    renderFundList:()=>{trace.push({op:'renderFunds'});},renderHoldingsList:()=>{trace.push({op:'renderHoldings'});}};
  const body=[...m.app.slices.filter(r=>r.kind==='constant').map(r=>r.text),
    'let holdings=initialHoldings,holdingsDocument=initialDocument,fundsData=initialRows;',
    'let holdingsCache={},holdingsMetaCache={},fundTypeCache={},fundFeeCache={},fundHoldingsRequests=new Map(),expandedFund=null;',
    ...m.app.slices.filter(r=>r.kind==='function').map(r=>r.text),
    'return {save:saveCache,reconcile:reconcileActiveFundState,state:()=>fundsData,hash:()=>holdingsHash(holdings)};'].join('\n');
  return new Function(...Object.keys(bindings),body)(...Object.values(bindings));
}
function editCase(m,c){
  const trace=[],sentinel=Object.assign(new Error('sentinel:'+c.id),{name:'SentinelError'});
  const old=previous(m),row=writerRow(m,trace),rows=[row,{code:OTHER,unknown:'inactive'}];
  if(c.mode==='row-getter-throw')Object.defineProperty(row,'badGetter',{enumerable:true,get(){trace.push({op:'sentinel-getter'});throw sentinel;}});
  if(c.mode==='row-cycle')row.cycle=row;
  const initial=c.mode==='previous-malformed'?'{':JSON.stringify(c.mode==='previous-no-data'?{unknown:'no-data'}:old);
  const store=storageAdapter(initial,c.mode,sentinel,trace),app=appHarness(m,rows,store,c.mode,trace,sentinel);
  const result=outcome(()=>['reconcile-amounts-active','empty-active','remove-throw','persist-false'].includes(c.mode)?
    app.reconcile({render:false,...(c.mode==='persist-false'?{persistCache:false}:{})}):app.save(rows),sentinel);
  const actualTrace=trace.slice();
  const persisted=outcome(()=>store.read()===null?null:JSON.parse(store.read()),sentinel);
  assert.equal(result.ok,true,c.id+' edit swallows declared failures');
  const expectedSet=['common-order-unknown','reconcile-amounts-active','set-throw'].includes(c.mode)?1:0;
  assert.equal(store.counts.set,expectedSet,c.id+':set');
  assert.equal(store.counts.remove,['empty-active','remove-throw'].includes(c.mode)?1:0,c.id+':remove');
  if(c.mode==='common-order-unknown'){
    assert.deepEqual(Object.keys(persisted.value),Object.keys(old));assert.equal(persisted.value.topZ,old.topZ);assert.equal(persisted.value.fetchedAt,NOW);
    assert.equal(persisted.value.data.length,2);assert.equal(persisted.value.data[0].primary_nav,999);
  }
  if(c.mode==='reconcile-amounts-active'){
    assert.equal(persisted.value.data.length,1);assert.equal(persisted.value.data[0].shares,10);assert.equal(persisted.value.data[0].cost,1.25);
    assert.notEqual(persisted.value.data[0].curr_value,666);assert.equal(persisted.value.data[0].primary_nav,999);
  }
  return {result:serialResult(result),attempts:store.counts,trace:actualTrace,bytes:store.read(),persisted:serialResult(persisted),state:representation(app.state()),holdingHash:app.hash()};
}
function refreshArguments(m,mode,trace,sentinel){
  const old=previous(m,mode!=='no-own-time'),row=writerRow(m,trace),data=[row,{code:OTHER,unknown:'inactive'}];
  let now=LATER,activeCodes=[CODE],staged={};
  if(mode==='new-fund-acquisition')staged={['nav:'+CODE]:navEntry(m,LATER)};
  if(mode==='market-only')staged={['meta:'+CODE]:m.resource.makeRefreshResourceEntry('meta:'+CODE,{code:CODE,source:'eastmoney-official-nav',meta:{manager:'Synthetic'}},{now:LATER,fetchedAt:LATER,sourceDate:'2026-09-29'})};
  if(mode==='no-own-time')staged={['nav:'+CODE]:navEntry(m,LATER)};
  if(mode==='inactive-pruning')staged={['nav:'+OTHER]:navEntry(m,LATER,OTHER)};
  if(mode==='empty-active')activeCodes=[];
  if(mode==='duplicate')data.push({code:CODE,duplicate:true});
  if(mode==='invalid-clock')now=NaN;
  if(mode==='row-getter')Object.defineProperty(row,'badGetter',{enumerable:true,get(){trace.push({op:'sentinel-getter'});throw sentinel;}});
  if(mode==='row-cycle')row.cycle=row;
  return {previous:old,data,now,activeCodes,staged,holdingsHash:'current-hash'};
}
function refreshCase(m,c){
  const trace=[],sentinel=new Error('sentinel:'+c.id),args=refreshArguments(m,c.mode,trace,sentinel);
  const result=outcome(()=>traceSerialize(trace,sentinel,()=>m.resource.serializeRefreshAggregate(args)),sentinel),actualTrace=trace.slice();
  const parsed=result.ok?JSON.parse(result.value):null;
  if(c.kind==='refresh'){
    assert.equal(result.ok,true,c.id);assert.equal('topZ'in parsed,false);assert.equal('topA'in parsed,false);
    assert.deepEqual(Object.keys(parsed),['data','refreshResources','fetchedAt','expiresAt','source',...(c.mode==='no-own-time'?[]:['time']),'holdingsHash']);
    assert.equal(parsed.fetchedAt,['new-fund-acquisition','no-own-time'].includes(c.mode)?LATER:NOW);
    assert.equal(parsed.data.length,c.mode==='empty-active'?0:1);
    if(parsed.data.length)assert.equal(parsed.data[0].primary_nav,999);
  }else{
    assert.equal(result.ok,false,c.id);assert.equal(result.error.sentinel,c.mode==='row-getter',c.id);
    if(c.mode==='duplicate')assert.equal(result.error.message,'Duplicate fund data cannot be persisted.');
    if(c.mode==='invalid-clock')assert.equal(result.error.message,'Refresh aggregate requires a valid clock.');
  }
  return {result:serialResult(result),trace:actualTrace,parsed:representation(parsed),storageAttempts:0};
}
async function scopeCase(m,c){
  const trace=[],sentinel=new Error('sentinel:'+c.id),args=refreshArguments(m,c.mode,trace,sentinel);
  const controller=new AbortController(),context={generation:7,signal:controller.signal,isCurrent:()=>true,commit:op=>({committed:true,value:op()})};
  const scope=m.scope.createGenerationResourceScope({context,plan:{generation:7,resources:[{key:'nav:'+CODE,action:'fetch'}]},now:()=>LATER});
  const entry=navEntry(m,LATER);
  await scope.acquire('nav:'+CODE,()=>entry);
  const stage=scope.stageCache('nav:'+CODE,entry,value=>!!m.resource.validateRefreshResourceEntry('nav:'+CODE,value,{now:LATER}));assert.equal(stage,true,c.id);
  const store=storageAdapter(JSON.stringify(previous(m)),c.mode,sentinel,trace);
  const serialize=staged=>traceSerialize(trace,sentinel,()=>m.resource.serializeRefreshAggregate({...args,staged}));
  const first=scope.flushCache({storage:store.storage,serialize}),second=scope.flushCache({storage:store.storage,serialize});
  const expectedAttempt=['success','storage-throw','storage-false'].includes(c.mode)?1:0;
  assert.equal(store.counts.set,expectedAttempt,c.id);assert.equal(second,false,c.id+' no second write');
  assert.equal(first,c.mode==='success',c.id+' first');assert.equal(scope.snapshot().writeAttempts,expectedAttempt);
  return {stage,first,second,attempts:store.counts,snapshot:representation(scope.snapshot()),trace,bytes:store.read()};
}
function wireCase(m,c){
  const row={code:CODE,name:'Synthetic fund',status:'ok',source:'sinan-estimate-proxy',kind:'intraday_estimate',base_nav:'1',base_nav_date:'2026-09-29',
    value_nav:'1.1',estimate_nav:'1.1',estimate_change:'0%',est_change:'0%',source_time:'2026-09-30T05:59:00Z',value_date:'2026-09-30'};
  const result=outcome(()=>m.wire.normalizeWorkerEstimateRow(row,{now:NOW,wireVersion:1}));assert.equal(result.ok,true,c.id);
  assert.equal(result.value.est_change,0);assert.equal(result.value.est_nav,1.1);return serialResult(result);
}
const records=[];await mkdir(join(dir,'case-output'),{recursive:false});
try{
  const a=await modules(root),b=await modules(prepared.frozen);assert.deepEqual(a.app,b.app);
  for(const c of cases){
    const execute=async m=>['presence','official','metadata','strict','getter','alias'].includes(c.kind)?resourceCase(m,c):
      c.kind==='wire'?wireCase(m,c):c.kind==='edit'?editCase(m,c):c.kind==='scope'?scopeCase(m,c):refreshCase(m,c);
    const current=await execute(a),frozen=await execute(b);assert.deepEqual(current,frozen,c.id+' current/frozen full record');
    const record={id:c.id,kind:c.kind,equal:true,current,frozen};records.push(record);
    await writeFile(join(dir,'case-output',String(records.length).padStart(3,'0')+'.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
    console.log('PASS '+c.id);
  }
  assert.equal(deniedFetch,0);assert.equal(deniedStorage,0);
  const result={schema:1,kind:'frozen-old-control-not-candidate',caseCount:cases.length,complete:records.length===cases.length,
    comparisons:records.length,deniedFetch,deniedStorage,allEqual:true,records};
  await writeFile(join(dir,'BASELINE.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({complete:true,cases:records.length,comparisons:records.length,deniedFetch,deniedStorage}));
}catch(error){
  await writeFile(join(dir,'FAILURE.json'),JSON.stringify({completed:records.length,next:cases[records.length],error:errorInfo(error),stack:error.stack},null,2)+'\n',{flag:'wx'});
  throw error;
}finally{
  Date.now=actualDateNow;globalThis.fetch=previousFetch;
  for(const [n,d]of [['localStorage',previousLocal],['sessionStorage',previousSession]]){if(d)Object.defineProperty(globalThis,n,d);else delete globalThis[n];}
  const current=await named(root,prepared.source.map(r=>r.path));assert.deepEqual(current,prepared.source);
  assert.deepEqual(await inventory(prepared.frozen),prepared.source);for(const p of prepared.parser)assert.deepEqual(await inventory(p.root),p.rows);
  assert.deepEqual(await named(dir,prepared.scripts.map(r=>r.path)),prepared.scripts);
  await writeFile(join(dir,'POSTFLIGHT.json'),JSON.stringify({sourceUnchanged:true,frozenUnchanged:true,parserUnchanged:true,scriptsUnchanged:true,
    source:current,sourceRowsSha256:sha(JSON.stringify(current)),endedAt:new Date().toISOString(),deniedFetch,deniedStorage},null,2)+'\n',{flag:'wx'});
}
