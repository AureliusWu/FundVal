import assert from 'node:assert/strict';
import {mkdir,cp,readFile,writeFile,access,readdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
import {extractApp,sha} from './extractor.mjs';
import {inventory,named} from './inventory.mjs';
import {cases,anchors} from './plan.mjs';
const dir=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal',frozen=join(dir,'frozen-old');
try{await access(join(dir,'PREPARED.json'));throw new Error('PREPARED already exists');}catch(e){if(e.code!=='ENOENT')throw e;}
await mkdir(frozen,{recursive:false});
await cp(root+'/js',frozen+'/js',{recursive:true,errorOnExist:true,force:false});
await cp(root+'/package.json',frozen+'/package.json',{errorOnExist:true,force:false});
for(const p of anchors){await mkdir(dirname(join(frozen,p)),{recursive:true});await cp(join(root,p),join(frozen,p),{errorOnExist:true,force:false});}
const spec='docs/v16.0.0/performance-evidence/worker-seam-20261022/next-http-boundary/';
await mkdir(join(frozen,spec),{recursive:true});
for(const p of ['REPORT.md','FIELD_LEDGER.json'])await cp(join(root,spec,p),join(frozen,spec,p),{errorOnExist:true,force:false});
const frozenRows=await inventory(frozen);
for(const row of frozenRows){assert.equal(sha(await readFile(join(root,row.path))),row.sha256,row.path);}
const current=await extractApp(root),copy=await extractApp(frozen); assert.deepEqual(current,copy);
await mkdir(join(dir,'app-extracted'),{recursive:false});
for(const row of copy.slices)await writeFile(join(dir,'app-extracted',row.name+'.js.txt'),row.text,{flag:'wx'});
await writeFile(join(dir,'APP_SLICES.json'),JSON.stringify(copy,null,2)+'\n',{flag:'wx'});
await writeFile(join(dir,'CASES.json'),JSON.stringify(cases,null,2)+'\n',{flag:'wx'});
const req=createRequire(root+'/package.json');
const parserPath=req.resolve('rolldown/utils');
const parserRoots=['D:/AI项目/FundVal/node_modules/rolldown','D:/AI项目/FundVal/node_modules/@rolldown/binding-win32-x64-msvc'];
const parser=[];for(const root of parserRoots)parser.push({root,rows:await inventory(root)});
const scripts=['PROTOCOL.md','plan.mjs','extractor.mjs','inventory.mjs','prepare.mjs','runner.mjs','record.ps1'];
const prepared={schema:1,root,frozen,createdAt:new Date().toISOString(),caseCount:cases.length,
  node:{path:process.execPath,version:process.version,sha256:sha(await readFile(process.execPath))},
  source:frozenRows,sourceRowsSha256:sha(JSON.stringify(frozenRows)),scripts:await named(dir,scripts),
  parserPath,parser,app:copy.slices.map(({text,...x})=>x)};
await writeFile(join(dir,'PREPARED.json'),JSON.stringify(prepared,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({prepared:join(dir,'PREPARED.json'),caseCount:cases.length,files:frozenRows.length,sourceRowsSha256:prepared.sourceRowsSha256}));
