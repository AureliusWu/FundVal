import {readdir,readFile,stat} from 'node:fs/promises';
import {join,relative} from 'node:path';
import {sha} from './extractor.mjs';
export async function inventory(root){
  const rows=[];
  async function visit(path){for(const entry of (await readdir(path,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name,'en'))){
    const p=join(path,entry.name); if(entry.isDirectory())await visit(p); else if(entry.isFile()){
      const bytes=await readFile(p); rows.push({path:relative(root,p).replaceAll('\\','/'),bytes:bytes.length,sha256:sha(bytes)});
    } else throw new Error('Unexpected non-file in frozen identity: '+p);
  }}
  await visit(root); return rows;
}
export async function named(root,paths){const rows=[];for(const path of paths){const b=await readFile(join(root,path));rows.push({path,bytes:b.length,sha256:sha(b)});}return rows;}
