# One authorized freezer correction, not a case retry selection

Parent authorized this one independent correction after the first workspace failed before any case (completed 0/234): C:/Users/84046/AppData/Local/Temp/fundval-old-resource-writers-20261022-32facc8b8e. All original failure stdout/stderr/receipt/PREPARED/POSTFLIGHT/harness/cases are retained there and are not overwritten.

This new system-Temp workspace copies PROTOCOL.md, plan.mjs, extractor.mjs, inventory.mjs, runner.mjs and record.ps1 byte-for-byte from that failed preparation. The only tool correction is prepare.mjs: AST-enumerate all static relative import/export/dynamic-literal JS/JSON dependencies, check missing paths and workspace containment before cases, freeze every dependency plus package.json, verify the copied import closure, and retain its ledger. The plan and all 234 case intents and runner bytes are unchanged. No filtering, additional candidate/variant/build/budget probe, root source/site/docs changes, installation or network. No failed case was discarded: no case ran in attempt one.

One corrected preparation followed by one native runner invocation. If infrastructure fails again, retain it and report, without an automatic loop. Runtime failures are not relabelled as product failures or successes. Bounded baseline evidence only; no 7KB qualification.
