# 冻结 OLD：R01/R03/S01/S03 有限完整记录

2026-10-22。本目录是下一条完整 acquisition→cache→projection→compat-egress 候选的独立旧控制，不是候选实现、采用决定或 6960B/gzip 资格。没有改 root/candidate/source/site/docs、预算、Schema3、版本或依赖；没有 build/install/minifier/network/browser/真实 Storage。使用 data-reliability-audit 的来源、存在性、时钟与追溯规则；未做实时对账，不能升级为线上数据可信度验收。

## 结果与原件

- 唯一纠正后 runner：native exit **0**，stdout 6862B，stderr **0B**，UTC 2026-10-22T05:51:25.7268458Z → 05:51:27.1784820Z（1445ms）。stdout 为逐例 PASS 的普通记录，不是 Node test/TAP/fullQA。
- 234/234 预声明 cases 全部完成；每例 current OLD 与 frozen OLD 完整 recording 相等。资源子操作为每侧599个（acquisition/strict/JSON-restored，getter仅指定阶段）；不把内部附加 make/validate 调用估算为精确总调用数。
- `BASELINE.json` **37,057,036B**，SHA256 `54402bff2876697d005b301bc0fc16686c8f88f8a3fbdf2c7d98fb1ac263737c`。每例也独立保留在 `case-output/001.json`…`234.json`，未选择/过滤。
- 只读 artifact 核验：`verify-records.mjs` native0 / stderr0，2442 checks，其中1252项原 JSON/Storage 字节SHA复算；核对234个编号、计划顺序、逐例全文、原 native stdout/stderr、完整相等及 postflight。它不重新运行任何业务 case。
- 实际 denied fetch=0、denied persistent Storage=0；真实所有写操作仅落在新系统 Temp。程序对 localStorage/sessionStorage/fetch 设置拒绝保护，所有 Storage 尝试来自合成内存 adapter 并单独记数。

机器入口：`PREPARED.json`、`CASES.json`、`BASELINE.json`、`OBSERVED_LEDGER.json`、`NATIVE_RECEIPT.json`、`VERIFY_RECEIPT.json`、`POSTFLIGHT.json`。最终 `FINAL_INVENTORY.json` 列所有文件SHA（自身排除）。

## 首次工具失败保留，不是病例淘汰

旧目录 [旧失败报告](../fundval-old-resource-writers-20261022-32facc8b8e/REPORT.md) 全部保留。首个 runner native1/stdout0B/stderr1300B，completed **0/234**；冻结器仅复制完整 js 而遗漏 market-clock 的相对 JSON 依赖，frozen import 抛 ERR_MODULE_NOT_FOUND。旧 PREPARED/POSTFLIGHT/失败输出/runner/用例均未覆写。

父任务明确授权一次独立冻结器纠正。本目录的 `plan.mjs` / `runner.mjs` / `record.ps1` / `extractor.mjs` / `inventory.mjs` / 原 `PROTOCOL.md` 与首次目录逐字节相同。仅新 prepare.mjs 补齐 AST 静态依赖冻结，另加 CORRECTION_PROTOCOL.md；无新变体、用例过滤或采样选择。

## 冻结与真实执行边界

执行前已冻结当前73个 JS 文件、calendar JSON、package.json、四个真实既有测试锚、完整 REPORT/FIELD_LEDGER 规格，共81文件。源库存行 SHA256 `e932d5a40bd12c8f4de446e6d8099656fb89dd9cd02ef23fae60bdfc0228d2aa`。AST 静态闭包74文件、191条相对 import/export/dynamic-literal 边，missing0 / external0；当前与冻结闭包完全相等。全 js 库存另记两处 OCR 非字面量 import（local-ocr/paddle-local-ocr），本 harness 未导入/调用这些 OCR 模块；不把静态闭包认证说成所有动态运行路径证明。

`frozen-old/` 保留完整实际旧文件，不复制算法重写为 oracle。current 一侧直接 import D:/AI项目/FundVal 下真实公开 resource/scope/storage/active-holdings/holding-quote-amounts/schema/quote/wire 模块；frozen 一侧独立 import 字节一致副本。这里的两个 OLD 控制相等用于固化输入输出，不是用“两个新wrapper共用新core”给未来实现自证。

App 不启动全应用/DOM。沿既有 `test/app-holdings-hash-closed-v16.test.js` 与 `test/cache-fund-identity-v16.test.js` 的 rolldown AST 提取方式，分别从 current/frozen App 提取原函数和原常量；原文、范围、hash 在 APP_SLICES.json 与 app-extracted/。只注入当前 holding/document/fundsData 状态、真实模块依赖、固定 Date.now、内存 Storage、未运行的 render 回调。Schema3 canonical hash 使用真实 schema 函数，不造假 hash。

| 原 App 切片 | 源行 | SHA256 |
| --- | --- | --- |
| reconcileActiveFundState | 251–275 | 5559164975ebebf2a81ed4090ca22645c9d2f11c3883d9d60a77c4b858ffbf35 |
| holdingsHash | 335–337 | 97c953233c0be72a482f2a294aafe9e1e80ccb446915b9037253f28510818772 |
| slimFundCache | 592–594 | 5750df22e9c7b6328944aae85a45250d85e4744359dac70ee253fb8dac137907 |
| saveCache | 596–603 | 8d1d1258bcf0a163ddbe7b22e19bc296a035c83225dac3bffa6ebfde0291794f |

原 resource 的 estimateRow/payloadFor/make/validate/serialize 及原 scope 的 acquire/stage/flush 全部运行真实模块，不抽出重写；scope context 的 isCurrent/commit 是明确合成同步 adapter，不冒充完整真实 coordinator/代际取消证明。App 使用真实 safeGet/Set/Remove（js/storage.js:1–17）。JSON 观察器只委托原 JSON 方法，异常记录后原对象重抛；resource Proxy 记录 get/ownKeys/descriptor，aggregate Proxy 另记可信覆盖 set。记录 output own顺序、descriptor、undefined/NaN/-0/symbol/冻结与引用图，以及原 JSON bytes/SHA、Storage attempts、scope counters。

关键源SHA：App `9b5394ef5045458a93753b043a6a485272e29a8c477270a54e07f90dc6b6083e`；resource `7f0103a803f83b31df0631cb3a7c53949e7f80259c909becf4eccc6ce0fb6231`；scope `66bdb6c89399ded70f9566a0f797a842f74ee8095cbce2447db96b80f7f959ff`；calendar `1fe1f801dc368fc55908b797e8e18ab778b5ba492c1530b1840374d51ff1b45b`。全81行及 parser/node 执行身份在 PREPARED；原有 source/冻结副本/parser/准备脚本在 POSTFLIGHT 逐项未变。

## 有限 case 分配

| 组 | 数量 | 实际覆盖 |
| --- | ---: | --- |
| R01 presence | 175 | 全35 ROW_FIELDS × absent/own undefined/null/NaN/-0；分别 acquisition、strict原对象、JSON往返后 |
| R01 official / metadata | 2 | official显式null aliases、版本/raw fetched_at/非Quote可逆metadata |
| R03 strict | 10 | row/Quote/payload 各 enumerable extra string、enumerable symbol、nonenumerable extra string；allowed nonenumerable name |
| R03 getter | 8 | row.source_quote、row.name、quote.value、payload.rows，各 acquisition/strict阶段 |
| R02 aliases / wire | 11 | est_change number-string/boolean/±Infinity/NaN/0/-0/1e-7内外与精确边界；真实 wire numeric-string对照 |
| S01 refresh | 6 | top unknown/order、new fund/market-only/no-own-time/inactive/empty-active |
| S01/S03 edit | 11 | save/reconcile、active/current holding、empty/remove/persistfalse、bad previous/read/write/getter/cycle |
| S03 direct serializer | 4 | duplicate active row/invalid clock/getter sentinel/cycle，原 throw |
| S03 scope | 7 | success、Storage throw/false、duplicate/clock/getter/cycle；第二 flush、精确次数 |

## 观察到的兼容约束

1. **R01 不能丢 own-presence。** 以 name 为例：absent 输出无 key；own undefined 内存保留 enumerable own key，但 JSON 后缺席；null原样；NaN在resource clean阶段变null；-0内存仍-0而JSON后0。175项保留全部接受/拒绝结果，不宣称35字段在五状态下都有效。正常row按固定ROW_FIELDS选own字段、source_quote最后，不沿输入插入顺序任意排序。
2. **Quote 不可逆。** row.coverage=101、quote_count=3.5、report_date='not-a-date'、model_version='row-v1'、estimate_model_version=null、est_model_version=own undefined、fetched_at='safe-but-not-timestamp' 可保留；同一 source_quote.coverage/modelVersion 为null。official 的 null/undefined aliases 不回填成Quote值；具体内存/JSON在 OBSERVED_LEDGER。
3. **R03 不是 Reflect.ownKeys 白名单。** acquisition 剪去额外 enumerable string；strict原对象和JSON恢复对象拒这个string。额外symbol/nonenumerable string在strict不导致拒绝，且最终不保留；allowed nonenumerable name会被选择成enumerable own输出。不能借新codec强化成拒所有额外own key。
4. **数值域/JSON边界不同。** real wire 接受合法数字string，resource number-only拒。est_change 的±Infinity在原对象 acquisition/strict拒，而原JSON先把其转null后 strict可接受；NaN占位可接受。精确1e-7及其内侧接受，外侧拒绝。这个矩阵只对 changePct=0 的 est_change 精确量化边界，不冒充所有浮点基准的完整证明。
5. **两个outer writer不可合并policy。** refresh输出先data/refreshResources，再继承旧own五键，丢topZ/topA等unknown；edit spread previous保留全部top unknown与原key位置。两者行级保留未知enumerable string（除_cached/message/quoteCandidates），undefined/function/symbol与非枚举字段在Object.entries/JSON边界丢失，nonfinite→null、-0→0。相同最终语义值也必须保原JSON字段顺序。
6. **active/resources不同。** refresh裁inactive row与resource；edit.saveCache本身不做active裁剪，reconcile先裁data并用当前holding shares10/cost1.25重投影金额，但沿用旧refreshResources（包括inactive资源）。这里实际证明holding金额覆盖curr_value/today_profit等同名旧值；primary_nav=999在reconcile不被改，它属于buildFundData的另一真实投影边界，不能误记成本组已验证全部可信primary覆盖。
7. **时钟不同。** edit只改data/完整Schema3 holdingsHash，不动fetchedAt/expiresAt/source/time；refresh无新有效fund获取或market/meta-only时也不续基金时钟。新NAV acquisition推进top clocks，只有previous own time存在才补写time。行内原Quote/source evidence不因此换新获取时间。
8. **失败层级/次数。** direct serializer 的 duplicate/clock为原TypeError，getter为同一sentinel，cycle为原JSON TypeError；scope吞serializer异常后第一次flushfalse，第二次false，Storage set0。scope Storage throw/returnfalse均set1、cacheWrites0、第二次flushfalse；success set1/cacheWrites1/第二次false。App bad prior/read/getter/cycle均无set，set失败恰好get1/set1且外部返回undefined；empty active恰好remove1、get/set0，remove throw被真实safe wrapper吞。persistCachefalse三类Storage尝试均0。

原预期异常不是 native stderr 警告：它们在 case recording 中按旧层级观测/捕获。对外可见的异常记录name/message/constructor/sentinel身份；App内部吞掉的getter仅能观测getter命中与未写/返回undefined，不能谎称公开返回了该error身份。完整trace保留此可观察性限制。

## 覆盖缺口与交接

这是固定单钟、合成数据、离线Node环境下的旧控制。没有任意对象全集证明、getter自变值/所有toJSON/prototype组合、所有数值alias浮点基准、全provider/TTL/日期/并发失败组合；不替代R04/R05/H01/H02、完整HTTP/Abort、App DOM/UI、真实repository安装事件或完整coordinator。App这里提取真实reconcile/save而不启动全App，render=false；来源Quote/模型/primary投影的完整纵切面由另代理A08/M04负责，不重复并不等于覆盖自动闭合。

当前有限234记录可供之后**同一完整候选**逐例读取旧原件与期望记录作独立控制，但这次没有运行candidate、没有净gzip、没有改原预算或宣布M3退出。若后续需要扩展缺口，须先另行预声明，不能原地改这些冻结记录、过滤失败或把后来的新输出反填为旧期望。

到此停止业务执行。无后续build/test/变体/源修复。原失败目录与本目录全部可供父任务独立读取/归档。
