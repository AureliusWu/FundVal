import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const dir=dirname(fileURLToPath(import.meta.url)),sha=v=>createHash('sha256').update(v).digest('hex');
const read=async p=>JSON.parse(await readFile(join(dir,p),'utf8'));
const baseline=await read('BASELINE.json'),plan=await read('CASES.json'),receipt=await read('NATIVE_RECEIPT.json'),prepared=await read('PREPARED.json'),post=await read('POSTFLIGHT.json');
let checks=0;const check=(a,b)=>{assert.deepEqual(a,b);checks++;};
check(receipt.nativeExit,0);check(receipt.stderrBytes,0);check(baseline.complete,true);check(baseline.caseCount,234);check(baseline.comparisons,234);
check(baseline.records.length,plan.length);check(new Set(plan.map(c=>c.id)).size,234);check(baseline.deniedFetch,0);check(baseline.deniedStorage,0);
check(post.sourceUnchanged,true);check(post.frozenUnchanged,true);check(post.parserUnchanged,true);check(post.scriptsUnchanged,true);check(post.source,prepared.source);
check(prepared.importClosure.missing.length,0);check(prepared.importClosure.external.length,0);
const stdout=await readFile(join(dir,'native.stdout.txt')),stderr=await readFile(join(dir,'native.stderr.txt'));
check(sha(stdout),receipt.stdout);check(sha(stderr),receipt.stderr);
const lines=stdout.toString('utf8').trimEnd().split(/\r?\n/);check(lines.length,235);
const groups={};const observed=[];
const get=(shape,key)=>shape?.keys?.find(row=>row.key===key)?.value;
const rowFrom=result=>get(get(get(result?.shape,'payload'),'rows'),'0');
const ownKeys=shape=>shape?.keys?.map(row=>row.key);
let jsonHashChecks=0;
function hashes(value){if(!value||typeof value!=='object')return;
  if(value.json&&typeof value.json.value==='string'){check(sha(value.json.value),value.json.sha256);jsonHashChecks++;}
  if(value.op==='set'&&typeof value.value==='string'){check(sha(value.value),value.sha256);jsonHashChecks++;}
  for(const child of Object.values(value)){if(Array.isArray(child))for(const item of child)hashes(item);else hashes(child);}
}
for(let i=0;i<plan.length;i++){
  const p=plan[i],r=baseline.records[i];check(r.id,p.id);check(r.equal,true);check(r.current,r.frozen);check(lines[i],'PASS '+p.id);
  check(await read('case-output/'+String(i+1).padStart(3,'0')+'.json'),r);hashes(r);
  groups[r.kind]=(groups[r.kind]||0)+1;
  if(['presence','official','metadata','strict','getter','alias'].includes(p.kind)){
    const outputs={};for(const [name,output] of Object.entries(r.current)){
      const row=rowFrom(output);outputs[name]={accepted:output.accepted,outerError:output.ok?null:output.error,
        rowOwnKeys:ownKeys(row),...(p.field?{field:p.field,fieldDescriptor:row?.keys?.find(row=>row.key===p.field)||null}:{}),
        ...(p.kind==='official'||p.kind==='metadata'?{rowMemory:row,rowJSON:output.json?.value?JSON.parse(output.json.value)?.payload?.rows?.[0]??null:null}:{}),
        traceEvents:output.trace.length};
    }observed.push({id:p.id,outputs});
  }else if(p.kind==='edit'){
    const c=r.current,parsed=(()=>{try{return JSON.parse(c.bytes);}catch{return null;}})();
    observed.push({id:p.id,attempts:c.attempts,return:c.result,topKeys:parsed?Object.keys(parsed):null,
      dataCodes:parsed?.data?.map(row=>row.code),rowKeys:parsed?.data?.[0]?Object.keys(parsed.data[0]):null,
      resources:parsed?.refreshResources?Object.keys(parsed.refreshResources):null,
      clocks:parsed?Object.fromEntries(['fetchedAt','expiresAt','source','time','holdingsHash'].filter(k=>Object.hasOwn(parsed,k)).map(k=>[k,parsed[k]])):null,
      errors:c.trace.filter(v=>v.error),jsonBytes:c.bytes===null?null:Buffer.byteLength(c.bytes),jsonSha256:c.bytes===null?null:sha(c.bytes)});
  }else if(p.kind==='scope'){
    observed.push({id:p.id,stage:r.current.stage,first:r.current.first,second:r.current.second,attempts:r.current.attempts,
      snapshot:r.current.snapshot,errors:r.current.trace.filter(v=>v.error),jsonBytes:Buffer.byteLength(r.current.bytes),jsonSha256:sha(r.current.bytes)});
  }else if(p.kind==='refresh'){
    const parsed=JSON.parse(r.current.result.shape);
    observed.push({id:p.id,topKeys:Object.keys(parsed),rowKeys:parsed.data[0]?Object.keys(parsed.data[0]):[],dataCodes:parsed.data.map(row=>row.code),
      resources:Object.keys(parsed.refreshResources),clocks:Object.fromEntries(['fetchedAt','expiresAt','source','time','holdingsHash'].filter(k=>Object.hasOwn(parsed,k)).map(k=>[k,parsed[k]])),
      jsonBytes:Buffer.byteLength(r.current.result.shape),jsonSha256:sha(r.current.result.shape)});
  }else observed.push({id:p.id,result:r.current});
}
check((await readdir(join(dir,'case-output'))).length,234);
const result={schema:1,kind:'read-only-record-certification',nativeBaselineExit:receipt.nativeExit,recordChecks:checks,jsonHashChecks,groups,
  completeCases:plan.length,baselineSha256:sha(await readFile(join(dir,'BASELINE.json'))),sourceRowsSha256:prepared.sourceRowsSha256,
  casePlanSha256:sha(await readFile(join(dir,'plan.mjs'))),runnerSha256:sha(await readFile(join(dir,'runner.mjs'))),observed};
await writeFile(join(dir,'OBSERVED_LEDGER.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({checks,jsonHashChecks,cases:plan.length,groups,baselineSha256:result.baselineSha256,sourceRowsSha256:result.sourceRowsSha256}));
