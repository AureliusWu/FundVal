import assert from 'node:assert/strict';
import {mkdir,cp,readFile,writeFile,access,readdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {dirname,join,resolve,relative,extname} from 'node:path';
import {extractApp,sha} from './extractor.mjs';
import {inventory,named} from './inventory.mjs';
import {cases,anchors} from './plan.mjs';
const dir=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal',frozen=join(dir,'frozen-old');
const req=createRequire(root+'/package.json');
const {parseSync}=req('rolldown/utils');
async function staticClosure(base,seeds){
  const queue=[...seeds],visited=new Set(),edges=[],nonliteral=[],external=[],missing=[];
  while(queue.length){
    const path=queue.shift();if(visited.has(path))continue;visited.add(path);
    let bytes;try{bytes=await readFile(join(base,path));}catch(e){missing.push({path,code:e.code});continue;}
    if(!['.js','.mjs'].includes(extname(path)))continue;
    const parsed=parseSync(path,bytes.toString('utf8'));assert.equal(parsed.errors.length,0,path);
    const references=[];
    function visit(n){if(!n||typeof n!=='object')return;
      if(['ImportDeclaration','ExportNamedDeclaration','ExportAllDeclaration'].includes(n.type)&&n.source)references.push(n.source.value);
      if(n.type==='ImportExpression'){if(typeof n.source?.value==='string')references.push(n.source.value);else nonliteral.push({path,start:n.start,end:n.end});}
      for(const value of Object.values(n)){if(Array.isArray(value))for(const child of value)visit(child);else if(value&&typeof value==='object')visit(value);}
    }visit(parsed.program);
    for(const source of references){
      if(!source.startsWith('.')){external.push({path,source});continue;}
      const absolute=resolve(base,dirname(path),source),target=relative(base,absolute).replaceAll('\\','/');
      assert.ok(!target.startsWith('../')&&!target.includes(':')&&!target.startsWith('/'),'import escapes: '+path+' '+source);
      assert.ok(['.js','.mjs','.json'].includes(extname(target)),'unsupported static import: '+target);
      edges.push({from:path,source,to:target});queue.push(target);
    }
  }
  return {files:[...visited].sort(),edges:edges.sort((a,b)=>(a.from+' '+a.source).localeCompare(b.from+' '+b.source,'en')),external,nonliteral,missing};
}
try{await access(join(dir,'PREPARED.json'));throw new Error('PREPARED already exists');}catch(e){if(e.code!=='ENOENT')throw e;}
await mkdir(frozen,{recursive:false});
await cp(root+'/js',frozen+'/js',{recursive:true,errorOnExist:true,force:false});
await cp(root+'/package.json',frozen+'/package.json',{errorOnExist:true,force:false});
const jsRows=await inventory(root+'/js');
const closure=await staticClosure(root,jsRows.filter(r=>['.js','.mjs'].includes(extname(r.path))).map(r=>'js/'+r.path));
await writeFile(join(dir,'IMPORT_CLOSURE_PREFLIGHT.json'),JSON.stringify(closure,null,2)+'\n',{flag:'wx'});
assert.equal(closure.missing.length,0,'All static source imports must exist before execution');
for(const path of closure.files.filter(path=>!path.startsWith('js/'))){await mkdir(dirname(join(frozen,path)),{recursive:true});await cp(join(root,path),join(frozen,path),{errorOnExist:true,force:false});}
const frozenClosure=await staticClosure(frozen,jsRows.filter(r=>['.js','.mjs'].includes(extname(r.path))).map(r=>'js/'+r.path));
assert.deepEqual(frozenClosure,closure,'Frozen old static import closure must exactly match');
await writeFile(join(dir,'IMPORT_CLOSURE_FROZEN.json'),JSON.stringify(frozenClosure,null,2)+'\n',{flag:'wx'});
for(const p of anchors){await mkdir(dirname(join(frozen,p)),{recursive:true});await cp(join(root,p),join(frozen,p),{errorOnExist:true,force:false});}
const spec='docs/v16.0.0/performance-evidence/worker-seam-20261022/next-http-boundary/';
await mkdir(join(frozen,spec),{recursive:true});
for(const p of ['REPORT.md','FIELD_LEDGER.json'])await cp(join(root,spec,p),join(frozen,spec,p),{errorOnExist:true,force:false});
const frozenRows=await inventory(frozen);
for(const row of frozenRows){assert.equal(sha(await readFile(join(root,row.path))),row.sha256,row.path);}
const current=await extractApp(root),copy=await extractApp(frozen); assert.deepEqual(current,copy);
await mkdir(join(dir,'app-extracted'),{recursive:false});
for(const row of copy.slices)await writeFile(join(dir,'app-extracted',row.name+'.js.txt'),row.text,{flag:'wx'});
await writeFile(join(dir,'APP_SLICES.json'),JSON.stringify(copy,null,2)+'\n',{flag:'wx'});
await writeFile(join(dir,'CASES.json'),JSON.stringify(cases,null,2)+'\n',{flag:'wx'});
const parserPath=req.resolve('rolldown/utils');
const parserRoots=['D:/AI项目/FundVal/node_modules/rolldown','D:/AI项目/FundVal/node_modules/@rolldown/binding-win32-x64-msvc'];
const parser=[];for(const root of parserRoots)parser.push({root,rows:await inventory(root)});
const original='C:/Users/84046/AppData/Local/Temp/fundval-old-resource-writers-20261022-32facc8b8e';
const originalIdentity=[];
for(const path of ['PROTOCOL.md','plan.mjs','extractor.mjs','inventory.mjs','runner.mjs','record.ps1']){
  const before=await readFile(join(original,path)),after=await readFile(join(dir,path));assert.equal(sha(before),sha(after),path+' unchanged case/harness bytes');
  originalIdentity.push({path,originalSha256:sha(before),correctedSha256:sha(after)});
}
const scripts=['PROTOCOL.md','CORRECTION_PROTOCOL.md','plan.mjs','extractor.mjs','inventory.mjs','prepare.mjs','runner.mjs','record.ps1'];
const prepared={schema:1,root,frozen,createdAt:new Date().toISOString(),caseCount:cases.length,
  node:{path:process.execPath,version:process.version,sha256:sha(await readFile(process.execPath))},
  source:frozenRows,sourceRowsSha256:sha(JSON.stringify(frozenRows)),scripts:await named(dir,scripts),
  parserPath,parser,app:copy.slices.map(({text,...x})=>x),importClosure:closure,original,originalIdentity};
await writeFile(join(dir,'PREPARED.json'),JSON.stringify(prepared,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({prepared:join(dir,'PREPARED.json'),caseCount:cases.length,files:frozenRows.length,sourceRowsSha256:prepared.sourceRowsSha256}));
