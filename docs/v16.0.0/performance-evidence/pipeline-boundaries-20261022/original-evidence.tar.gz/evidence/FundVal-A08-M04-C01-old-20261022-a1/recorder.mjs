import {spawnSync} from 'node:child_process';
import {mkdirSync,readFileSync,writeFileSync,readdirSync,copyFileSync} from 'node:fs';
import {resolve,basename} from 'node:path';
import {createHash} from 'node:crypto';
const [label,command,...args]=process.argv.slice(2),root=import.meta.dirname,runs=resolve(root,'runs'),prefix=resolve(runs,label),inputsDir=prefix+'.inputs';
if(!/^[a-z0-9-]+$/.test(label||'')||!command)throw new Error('Invalid native receipt command');mkdirSync(runs,{recursive:true});mkdirSync(inputsDir);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),inputs=[];
for(const path of readdirSync(root).filter(name=>/\.(?:mjs|json|md)$/.test(name)).sort()){const bytes=readFileSync(resolve(root,path));copyFileSync(resolve(root,path),resolve(inputsDir,path));inputs.push({path,bytes:bytes.length,sha256:sha(bytes)});}
const startedAt=new Date().toISOString(),result=spawnSync(command,args,{cwd:root,encoding:null,timeout:45000,maxBuffer:30_000_000,windowsHide:true}),endedAt=new Date().toISOString(),stdout=result.stdout||Buffer.alloc(0),stderr=result.stderr||Buffer.alloc(0);
writeFileSync(prefix+'.stdout',stdout,{flag:'wx'});writeFileSync(prefix+'.stderr',stderr,{flag:'wx'});
const receipt={label,command,args,cwd:root,startedAt,endedAt,status:result.status,signal:result.signal,error:result.error?{name:result.error.name,message:result.error.message,code:result.error.code}:null,stdout:{path:basename(prefix+'.stdout'),bytes:stdout.length,sha256:sha(stdout)},stderr:{path:basename(prefix+'.stderr'),bytes:stderr.length,sha256:sha(stderr)},inputs};
writeFileSync(prefix+'.receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify(receipt)+'\n');process.exitCode=result.status??98;
