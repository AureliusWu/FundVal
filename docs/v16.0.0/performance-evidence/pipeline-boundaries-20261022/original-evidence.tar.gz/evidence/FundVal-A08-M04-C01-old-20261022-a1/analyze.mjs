// Post-outcome, read-only certification of the retained fixed OLD baseline.
// No SUT calls, case edits, or output rewriting occur here.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex');
const raw=await readFile(resolve(dir,'baseline-01.json')),data=JSON.parse(raw),result=JSON.parse(await readFile(resolve(dir,'RESULT.json'),'utf8'));
function field(value,key){return value?.properties?.find(item=>item.key.type==='string'&&item.key.value===key)?.value;}
function scalar(value){return value?.type==='null'?null:value?.type==='undefined'?undefined:value?.value;}
function decode(value,seen=new Map()){
 if(value?.type==='reference')return seen.get(value.id);
 if(!value||!value.properties)return scalar(value);
 const output=value.type==='array'||value.type==='Map'?[]:{};seen.set(value.id,output);
 if(value.type==='Map')for(const [key,item]of value.entries)output.push([decode(key,seen),decode(item,seen)]);
 else for(const item of value.properties){if(value.type==='array'&&item.key.value==='length')continue;output[item.key.value]=decode(item.value,seen);}
 return output;
}
const rows=data.rows.map(row=>({id:row.spec.id,expected:row.spec.expected,observed:row.root.summary.outcome,same:row.same,error:row.root.error,events:row.root.events,summary:row.root.summary,decoded:decode(row.root.result),json:row.root.json}));
const at=id=>rows.find(row=>row.id===id),checks=[];
const check=(name,condition)=>checks.push({name,pass:Boolean(condition)});
check('exact34 fixed cases',data.rows.length===34&&data.cases.length===34);
check('all34 complete root/frozen outputs same',data.rows.every(row=>isDeepStrictEqual(row.root,row.frozen)));
check('all68 forbidden counters zero',data.rows.every(row=>[row.root,row.frozen].every(side=>Object.values(side.events.forbidden).every(count=>count===0))));
check('exact sole retained expectation mismatch',result.status==='RETAINED_FAILURE'&&result.expectedPass===33&&isDeepStrictEqual(result.failures,[{id:'A08-market-hk',same:true,expected:false,forbiddenZero:true,actual:'rejected'}]));
check('baseline raw bytes/hash agrees recorded result',raw.length===result.bytes&&sha(raw)===result.sha256);
check('all206 pre/post inventories same',data.preflight.length+data.postflight.length===206&&[...data.preflight,...data.postflight].every(item=>item.same));
const control=at('A08-control'),hk=at('A08-market-hk'),foreign=at('A08-foreign-fundCode');
check('A08 control whole loader enters entry',control.observed==='entry'&&control.events.transport.http===1&&control.events.transport.httpJson===1&&control.events.resourceCallCount===1);
check('foreign identity survives HTTP and is rejected at resource',foreign.summary.httpRowsCaptured&&foreign.summary.quoteFundCode==='000999'&&foreign.events.resourceCallCount===1&&foreign.observed==='rejected');
check('market hk survives HTTP then resource rejects',hk.summary.quoteMarket==='hk'&&hk.summary.httpRowsCaptured&&hk.events.resourceCallCount===1&&hk.observed==='rejected');
check('cached provenance and model conflicts are not hidden by early row pruning',['A08-cache-tier','A08-model-flag','A08-holdings-flag','A08-row-fetch-before-observed','A08-original-source','A08-cachedAt'].every(id=>at(id).summary.httpRowsCaptured&&at(id).events.resourceCallCount===1&&at(id).observed==='rejected'));
check('stale conflicts are filtered before resource constructor',['A08-stale','A08-model-stale','A08-future-official-date'].every(id=>at(id).summary.httpRowsCaptured&&at(id).events.resourceCallCount===0&&at(id).observed==='filtered'));
check('actual WorkerContractError class/name/code for alias conflict',at('A08-alias-conflict').error?.name==='WorkerContractError'&&at('A08-alias-conflict').error.instanceof.WorkerContractError&&at('A08-alias-conflict').error.code.value==='WORKER_ALIAS_CONFLICT');
check('actual WorkerContractError for schema string',at('A08-schema-string').error?.instanceof.WorkerContractError&&at('A08-schema-string').error.code.value==='WORKER_SCHEMA_UNSUPPORTED');
check('input source_quote is overwritten before resource acceptance',at('A08-source-quote-overwritten').decoded.inputPayload.items[0].source_quote.fundCode==='000999'&&at('A08-source-quote-overwritten').summary.quoteFundCode==='000002'&&at('A08-source-quote-overwritten').observed==='entry');
check('opaque and meta survive HTTP but not resource row',at('A08-inert-opaque').summary.httpRowOwnKeys.includes('opaqueExtension')&&at('A08-inert-opaque').summary.httpRowOwnKeys.includes('meta')&&!at('A08-inert-opaque').summary.entryRowOwnKeys.includes('opaqueExtension')&&!at('A08-inert-opaque').summary.entryRowOwnKeys.includes('meta'));
const rescue=at('A08-second-clock-rescue');
check('second-clock safe rescue retained',rescue.error===null&&rescue.summary.getTimeCount===3&&rescue.summary.rowStatus==='error'&&rescue.summary.quoteStatus==='unavailable'&&rescue.observed==='filtered');
const dual=at('M04-dual-installed');
check('real holdings compose first installs 1.2 change',dual.decoded.holdingsEstimate.available&&Math.abs(dual.decoded.composed.est_change-1.2)<1e-9&&dual.decoded.composed.est_holdings_model===true&&!dual.decoded.composed.est_model);
check('real overseas build keeps both flags and overwrites shared estimate',dual.summary.builtFlags.model===true&&dual.summary.builtFlags.holdings===true&&dual.summary.sharedEst.nav===1.03&&dual.summary.sharedEst.change===3);
check('both effective model candidates read shared change3 but separate coverage',dual.summary.candidates.filter(q=>q.kind.includes('estimate')&&q.kind!=='intraday_estimate').length===2&&dual.summary.candidates.some(q=>q.kind==='holding_lookthrough_estimate'&&q.change===3&&q.coverage===60)&&dual.summary.candidates.some(q=>q.kind==='model_estimate'&&q.change===3&&q.coverage===100));
check('selected model and immutable source quote are distinct',dual.summary.selected.kind==='model_estimate'&&dual.summary.selected.value===1.03&&dual.summary.sourceQuote.kind==='official_nav'&&dual.summary.sourceQuote.value===1);
check('selected dual model prediction is3 and official note survives',isDeepStrictEqual(dual.summary.ledgerPredictions,[3])&&dual.decoded.notes.officialNote.includes('最近正式净值涨跌')&&dual.decoded.notes.estimateNote.includes('合成模型'));
check('holdings-only does not record overseas accuracy',at('M04-holdings-only').summary.selected.kind==='holding_lookthrough_estimate'&&at('M04-holdings-only').summary.ledgerPredictions.length===0);
check('official current date blocks model installation',at('M04-current-official-blocks').summary.builtFlags.model===null&&at('M04-current-official-blocks').summary.builtFlags.holdings===null&&at('M04-current-official-blocks').summary.selected.kind==='official_nav');
check('seeded stale model still appears in secondary note but not accuracy',at('M04-seeded-dual-stale').summary.selected.kind==='official_nav'&&at('M04-seeded-dual-stale').decoded.notes.modelNote.includes('+99.00%')&&at('M04-seeded-dual-stale').decoded.notes.modelNote.includes('9.9000')&&at('M04-seeded-dual-stale').summary.ledgerPredictions.length===0);
check('accuracy chooses selected quote1.5 not raw99',at('C01-selected-not-raw').decoded.fund.est_change===99&&isDeepStrictEqual(at('C01-selected-not-raw').summary.ledgerPredictions,[1.5]));
check('stale and before1430 no prediction but still save empty rows',['C01-stale','C01-before1430'].every(id=>at(id).observed===0&&at(id).events.memory.counts.setSuccess===1&&at(id).events.memory.finalEntries[0][1]==='[]'));
check('duplicate two actual updates one stored prediction',at('C01-duplicate').events.memory.counts.get===2&&at('C01-duplicate').events.memory.counts.setSuccess===2&&at('C01-duplicate').decoded.operations.length===2&&at('C01-duplicate').observed===1);
check('next settlement only matches previous base date',at('C01-next-settlement').decoded.ledger[0].actual_change===null&&at('C01-next-settlement').decoded.ledger[1].actual_change===-0.8&&at('C01-next-settlement').decoded.ledger[1].opaque==='matched');
check('confidence zero intentionally maps unknown',at('C01-confidence-zero').decoded.ledger[0].confidence==='unknown');
check('failed memory set is swallowed while raw malformed data remains',at('C01-malformed-failed-memory').error===null&&at('C01-malformed-failed-memory').events.memory.counts.setAttempt===1&&at('C01-malformed-failed-memory').events.memory.counts.setSuccess===0&&at('C01-malformed-failed-memory').events.memory.finalEntries[0][1]==='{"unexpected":true}');
check('unknown existing ledger properties survive update',at('C01-unknown-ledger').decoded.ledger.some(row=>row.opaque?.synthetic===true));
const certificate={scope:'Post-outcome analysis of retained OLD outputs only; no new SUT invocations',baseline:{bytes:raw.length,sha256:sha(raw)},checks,pass:checks.every(item=>item.pass),retainedExpectedMismatch:result.failures,rows};
await writeFile(resolve(dir,'ANALYSIS.json'),JSON.stringify(certificate,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({pass:certificate.pass,checks:checks.length,failures:checks.filter(item=>!item.pass),summaries:rows.map(({id,summary,error,events,decoded})=>({id,summary,error,clock:events.clock,storage:events.memory?.counts,notes:decoded?.notes}))},null,2)+'\n');
if(!certificate.pass)process.exitCode=1;
