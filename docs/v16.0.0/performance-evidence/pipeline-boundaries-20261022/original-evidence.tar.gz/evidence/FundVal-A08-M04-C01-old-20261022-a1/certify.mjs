// Read-only dataset/source certification, not a second OLD or candidate run.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
const dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex'),json=async path=>JSON.parse(await readFile(resolve(dir,path),'utf8'));
const prepared=await json('PREPARED.json'),baseline=await json('baseline-01.json'),result=await json('RESULT.json'),analysis=await json('ANALYSIS.json'),correction=await json('ACCEPTANCE_CORRECTION.json'),checks=[];
const check=(name,pass)=>checks.push({name,pass:Boolean(pass)});
for(const label of ['prepare-01','baseline-01','analysis-01']){
 const receipt=await json(`runs/${label}.receipt.json`);
 check(label+' native exit retained',receipt.status===(label==='prepare-01'?0:1));
 for(const kind of ['stdout','stderr']){const b=await readFile(resolve(dir,'runs',receipt[kind].path));check(label+' '+kind+' exact',b.length===receipt[kind].bytes&&sha(b)===receipt[kind].sha256);}
 for(const item of receipt.inputs){const b=await readFile(resolve(dir,`runs/${label}.inputs`,item.path));check(label+' input '+item.path+' archived exact',b.length===item.bytes&&sha(b)===item.sha256);}
}
for(const item of prepared.files)for(const [side,base]of [['root',prepared.root],['frozen',prepared.frozen]]){const b=await readFile(resolve(base,item.path));check(side+' '+item.path+' unchanged',b.length===item.bytes&&sha(b)===item.sha256);}
for(const item of prepared.references){for(const [side,path]of [['root',resolve(prepared.root,item.path)],['reference-copy',resolve(dir,'references',item.path)]]){const b=await readFile(path);check(side+' '+item.path+' reference unchanged',b.length===item.bytes&&sha(b)===item.sha256);}}
for(const item of [...prepared.toolInventory,...prepared.previous]){const b=await readFile(item.path);check('tool/prior '+item.path+' unchanged',b.length===item.bytes&&sha(b)===item.sha256);}
const executionReceipt=await json('runs/baseline-01.receipt.json');
for(const name of ['PROTOCOL.md','cases.mjs','cases.json','baseline.mjs','PREPARED.json','extracts-root.json','extracts-frozen.json']){const b=await readFile(resolve(dir,name)),expected=executionReceipt.inputs.find(item=>item.path===name);check(name+' same as executed immutable input',expected&&b.length===expected.bytes&&sha(b)===expected.sha256);}
check('exact 34/68 fixed OLD scope',baseline.cases.length===34&&baseline.rows.length===34&&result.invocations===68);
check('all34 complete comparisons independently recomputed',baseline.rows.every(row=>isDeepStrictEqual(row.root,row.frozen)));
check('all68 no forbidden operations',baseline.rows.every(row=>[row.root,row.frozen].every(side=>Object.values(side.events.forbidden).every(value=>value===0))));
check('single original forecast error retained not greenwashed',result.status==='RETAINED_FAILURE'&&result.expectedPass===33&&result.failures.length===1&&result.failures[0].id==='A08-market-hk'&&baseline.cases.find(row=>row.id==='A08-market-hk').expected==='entry');
check('derived analysis original mistaken-kind check also retained',!analysis.pass&&analysis.checks.filter(item=>!item.pass).length===1&&analysis.checks.find(item=>!item.pass).name==='both effective model candidates read shared change3 but separate coverage');
const at=id=>analysis.rows.find(row=>row.id===id),dual=at('M04-dual-installed'),hk=at('A08-market-hk');
check('actual dual quarterly candidate remains model_estimate, NOT forced holdings kind',dual.summary.candidates.some(q=>q.source==='quarterly-holdings-model'&&q.kind==='model_estimate'&&q.coverage===60&&q.change===3)&&dual.summary.candidates.some(q=>q.source==='market-model'&&q.kind==='model_estimate'&&q.coverage===100&&q.change===3));
check('corrected hk chain row realtime versus Quote delayed retained',hk.decoded.httpRows[0][1].est_realtime===true&&hk.decoded.httpRows[0][1].source_quote.status==='delayed'&&hk.decoded.httpRows[0][1].source_quote.reasonCodes.includes('MARKET_NOT_OPEN')&&hk.events.resourceCallCount===1&&hk.observed==='rejected');
const calendar=JSON.parse(await readFile(resolve(prepared.frozen,'data/market-calendars.json'),'utf8'));check('frozen calendar has no hk',!Object.hasOwn(calendar.calendars,'hk'));
check('candidate acceptance correction is narrow and candidate not yet run',correction.candidateStatus==='NOT_RUN'&&correction.caseId==='A08-market-hk'&&correction.originalCaseExpected==='entry'&&correction.frozenOldObserved==='rejected'&&correction.other33OriginalExpectations==='UNCHANGED'&&!correction.globalWaiver&&!correction.caseFiltering&&!correction.validationRelaxation);
const artifacts=[];
for(const path of ['PROTOCOL.md','cases.mjs','cases.json','prepare.mjs','baseline.mjs','recorder.mjs','PREPARED.json','extracts-root.json','extracts-frozen.json','baseline-01.json','RESULT.json','analyze.mjs','ANALYSIS.json','ACCEPTANCE_CORRECTION.json']){const b=await readFile(resolve(dir,path));artifacts.push({path,bytes:b.length,sha256:sha(b)});}
const output={schema:1,scope:'Read-only certification of original retained OLD baseline; no SUT rerun, no candidate or size qualification',pass:checks.every(item=>item.pass),checks,artifacts,oldRuns:{prepare:0,baseline:1,analysis:1},originalExpectedPass:'33/34',completeDifferential:'34/34',materiality:'NOT_RUN'};
await writeFile(resolve(dir,'CERTIFICATION.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({pass:output.pass,checks:checks.length,failures:checks.filter(item=>!item.pass),artifacts},null,2)+'\n');if(!output.pass)process.exitCode=1;
