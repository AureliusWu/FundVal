import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {specs,NOW,CODE,httpCase,modelCase,accuracyCase} from './cases.mjs';
const dir=import.meta.dirname,NativeDate=globalThis.Date,nativeFetch=globalThis.fetch;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const prepared=JSON.parse(await readFile(resolve(dir,'PREPARED.json'),'utf8'));
const oldStorageDescriptors=Object.fromEntries(['localStorage','sessionStorage'].map(key=>[key,Object.getOwnPropertyDescriptor(globalThis,key)]));
let currentForbidden=null;
for(const key of ['localStorage','sessionStorage'])Object.defineProperty(globalThis,key,{configurable:true,get(){if(currentForbidden)currentForbidden[key]++;throw new Error('Real '+key+' denied by fixed synthetic protocol');}});
async function verifySources(){
 const checks=[];
 for(const item of prepared.files)for(const [side,base]of [['root',prepared.root],['frozen',prepared.frozen]]){const bytes=await readFile(resolve(base,item.path));checks.push({side,path:item.path,bytes:bytes.length,sha256:sha(bytes),same:bytes.length===item.bytes&&sha(bytes)===item.sha256});}
 for(const item of prepared.references){const bytes=await readFile(resolve(prepared.root,item.path));checks.push({side:'reference-root',path:item.path,sha256:sha(bytes),same:sha(bytes)===item.sha256});const frozen=await readFile(resolve(dir,'references',item.path));checks.push({side:'reference-copy',path:item.path,sha256:sha(frozen),same:sha(frozen)===item.sha256});}
 for(const item of [...prepared.toolInventory,...prepared.previous]){const bytes=await readFile(item.path);checks.push({side:'tool-or-prior',path:item.path,sha256:sha(bytes),same:sha(bytes)===item.sha256});}
 if(checks.some(item=>!item.same))throw new Error('Source/evidence changed: '+JSON.stringify(checks.filter(item=>!item.same)));
 return checks;
}
const preflight=await verifySources();
async function apiAt(base,side){
 const get=path=>import(pathToFileURL(resolve(base,path)).href);
 const [http,wire,resource,holdings,model,overseas,accuracy,quote,normalizer,session,amounts,calculator,F]=await Promise.all([
  get('js/eastmoney-estimate.js'),get('js/runtime/worker-contract.js'),get('js/runtime/refresh-resource-cache.js'),get('js/holdings-estimate.js'),get('js/runtime/fund-model-enrichment.js'),get('js/overseas-model.js'),get('js/accuracy.js'),get('js/runtime/quote-contract.js'),get('js/runtime/quote-normalizer.js'),get('js/runtime/market-session.js'),get('js/runtime/holding-quote-amounts.js'),get('js/calculator.js'),get('test/fixtures/worker-contract-v16.js')]);
 const extracts=JSON.parse(await readFile(resolve(dir,`extracts-${side}.json`),'utf8'));
 return {http,wire,resource,holdings,model,overseas,accuracy,quote,normalizer,session,amounts,calculator,F,extracts};
}
const apis={root:await apiAt(prepared.root,'root'),frozen:await apiAt(prepared.frozen,'frozen')};
function ownSnapshot(value,seen=new Map()){
 if(value===null)return {type:'null'};
 const type=typeof value;
 if(type==='undefined')return {type};
 if(type==='number')return {type,value:Number.isNaN(value)?'NaN':value===Infinity?'Infinity':value===-Infinity?'-Infinity':Object.is(value,-0)?'-0':value};
 if(type==='string'||type==='boolean')return {type,value};
 if(type==='bigint')return {type,value:String(value)};
 if(type==='symbol')return {type,value:String(value),global:Symbol.keyFor(value)??null};
 if(type==='function')return {type,name:value.name,length:value.length};
 if(seen.has(value))return {type:'reference',id:seen.get(value)};
 const id=seen.size+1;seen.set(value,id);
 const keySnapshot=key=>typeof key==='symbol'?{type:'symbol',value:String(key),global:Symbol.keyFor(key)??null}:{type:'string',value:key};
 const properties=Reflect.ownKeys(value).map(key=>{const d=Object.getOwnPropertyDescriptor(value,key),out={key:keySnapshot(key),enumerable:d.enumerable,configurable:d.configurable};if(Object.hasOwn(d,'value')){out.writable=d.writable;out.value=ownSnapshot(d.value,seen);}else{out.get=d.get?{name:d.get.name,length:d.get.length}:null;out.set=d.set?{name:d.set.name,length:d.set.length}:null;}return out;});
 const result={type:Array.isArray(value)?'array':value instanceof Map?'Map':value instanceof Set?'Set':value instanceof NativeDate?'Date':'object',id,prototype:Object.getPrototypeOf(value)?.constructor?.name??null,extensible:Object.isExtensible(value),properties};
 if(value instanceof Map)result.entries=[...value].map(([key,item])=>[ownSnapshot(key,seen),ownSnapshot(item,seen)]);
 if(value instanceof Set)result.entries=[...value].map(item=>ownSnapshot(item,seen));
 if(value instanceof NativeDate)result.time=NativeDate.prototype.getTime.call(value);
 return result;
}
function jsonBytes(value){try{const text=JSON.stringify(value);return {ok:true,type:typeof text,text:text??null,bytes:text===undefined?0:Buffer.byteLength(text),sha256:text===undefined?null:sha(Buffer.from(text))};}catch(error){return {ok:false,name:error.name,message:error.message};}}
function errorView(error,api){return error?{name:error.name,code:ownSnapshot(error.code),message:error.message,instanceof:{Error:error instanceof Error,TypeError:error instanceof TypeError,RangeError:error instanceof RangeError,WorkerContractError:error instanceof api.wire.WorkerContractError},ownKeys:Reflect.ownKeys(error).map(String).filter(key=>key!=='stack'),ownProperties:Reflect.ownKeys(error).filter(key=>key!=='stack').map(key=>({key:String(key),descriptor:ownSnapshot(Object.getOwnPropertyDescriptor(error,key))}))}:null;}
function memory(initial=null,failWrite=false){
 const map=new Map(initial===null?[]:[['fuyu_overseas_accuracy_v1',initial]]),events=[],counts={get:0,setAttempt:0,setSuccess:0,remove:0};
 const storage={getItem(key){counts.get++;events.push({op:'getItem',key,value:map.get(key)??null});return map.get(key)??null;},setItem(key,value){counts.setAttempt++;events.push({op:'setItem',key,value:String(value),failure:failWrite});if(failWrite)throw new Error('Synthetic memory write denied');counts.setSuccess++;map.set(key,String(value));},removeItem(key){counts.remove++;events.push({op:'removeItem',key});map.delete(key);}};
 return {storage,map,events,counts};
}
function actualNotes(api,fund){return new Function('f',[api.extracts.esc,api.extracts.fmt,api.extracts.fmt4,api.extracts.latestNavMoveOf,api.extracts.secondaryNotes,'return {estimateNote,primaryNote,modelNote,officialMove,officialNote};'].join('\n'))(fund);}
function actualBuild(api,Clock){
 const dependencies={...api.quote,...api.normalizer,...api.session,...api.amounts,...api.calculator,applyOverseasModelEstimate:api.model.applyOverseasModelEstimate,Date:Clock};
 return new Function(...Object.keys(dependencies),[api.extracts.isRealFundName,api.extracts.isUsableNav,api.extracts.buildFundData,'return buildFundData;'].join('\n'))(...Object.values(dependencies));
}
async function runOne(spec,api){
 const clockEvents=[],flowEvents=[],forbidden={fetch:0,localStorage:0,sessionStorage:0},transport={http:0,httpJson:0,model:0,modelJson:0},resourceCalls=[];
 class Clock extends NativeDate{constructor(...args){if(!args.length)clockEvents.push({op:'new Date()',value:NOW});super(...(args.length?args:[NOW]));}static now(){clockEvents.push({op:'Date.now()',value:NOW});return NOW;}}
 let storageState=null,result=null,error=null,summary=null;
 currentForbidden=forbidden;globalThis.Date=Clock;globalThis.fetch=async()=>{forbidden.fetch++;throw new Error('Unplanned global fetch denied');};
 try{
  if(spec.group==='A08'){
   const input=httpCase(api.F,spec.id),payloadJson=JSON.stringify(input.payload);let getTimeCount=0;
   class ChangingDate extends Clock{getTime(){getTimeCount++;const value=getTimeCount===1?NOW:NOW-2*3600_000;clockEvents.push({op:'ChangingDate.getTime()',ordinal:getTimeCount,value});return value;}}
   const httpNow=input.now==='CHANGING_DATE'?new ChangingDate(NOW):input.now;
   globalThis.fetch=async(url,options)=>{transport.http++;flowEvents.push({op:'synthetic HTTP',url:String(url),cache:options?.cache,signalAborted:options?.signal?.aborted});if(String(url)!=='https://synthetic.invalid/estimates?codes='+CODE){forbidden.fetch++;throw new Error('Unplanned URL denied: '+url);}const response=new Response(payloadJson,{status:200,headers:{'Content-Type':'application/json'}});const original=response.json.bind(response);response.json=()=>{transport.httpJson++;flowEvents.push({op:'response.json()'});return original();};return response;};
   let httpRows=null;
   const dependencies={observing:false,estimateVisited:0,estimateObserved:0,estimateDenied:0,
    clients:{async estimates(snapshot,options,context,dispatch){flowEvents.push({op:'client.estimates',snapshotCodes:snapshot.map(item=>item.code),force:options.force});const rows=await dispatch(()=>api.http.fetchEstimateRows(snapshot.map(item=>item.code),{api:'https://synthetic.invalid/estimates',force:false,now:httpNow}));httpRows=rows;flowEvents.push({op:'HTTP rows captured',size:rows.size});return rows;}},
    snapshot:[{code:CODE,name:'合成当前持仓',shares:10,cost:0.9}],options:{force:false},context:{signal:new AbortController().signal},
    scope:{dispatch(source,operation){flowEvents.push({op:'dispatch',source});return operation();}},estimateResource:{key:'estimates:'+CODE,codes:[CODE]},now:()=>{clockEvents.push({op:'resource now()',value:NOW});return NOW;},
    makeRefreshResourceEntry(...args){resourceCalls.push(args);flowEvents.push({op:'makeRefreshResourceEntry'});return api.resource.makeRefreshResourceEntry(...args);}};
   const loader=new Function(...Object.keys(dependencies),'return ('+api.extracts.estimateLoader+');')(...Object.values(dependencies));
   let entry=null;try{entry=await loader();}catch(caught){error=caught;}
   const row=httpRows?.get(CODE),outcome=error?error.code||error.name:entry?'entry':resourceCalls.length?'rejected':'filtered';
   summary={outcome,httpRowsCaptured:Boolean(httpRows),resourceCalls:resourceCalls.length,rowStatus:row?.status??null,quoteKind:row?.source_quote?.valueKind??null,quoteStatus:row?.source_quote?.status??null,quoteFundCode:row?.source_quote?.fundCode??null,quoteFundName:row?.source_quote?.fundName??null,quoteMarket:row?.source_quote?.market??null,quoteConfidence:row?.source_quote?.confidence??null,getTimeCount,
    httpRowOwnKeys:row?Reflect.ownKeys(row).map(String):[],entryRowOwnKeys:entry?.payload?.rows?.[0]?Reflect.ownKeys(entry.payload.rows[0]).map(String):[]};
   result={inputPayload:input.payload,inputPayloadJson:payloadJson,httpRows,resourceCalls,entry};
  }else if(spec.group==='M04'){
   const input=modelCase(spec.id),syntheticConfig={schema:1,updated_at:'synthetic-fixed',models:{[CODE]:{version:'synthetic-v1',label:'合成模型',confidence:'high',quarter:'2026Q3',valid_until:'2026-10-31',min_weight:100,legs:[{code:'sh000001',weight:100}]}},rules:[]};
   const config=await api.overseas.loadOverseasModels(async(url,options)=>{transport.model++;flowEvents.push({op:'synthetic model fetch',url:String(url),cache:options.cache,signalAborted:options.signal.aborted});return {ok:true,async json(){transport.modelJson++;return structuredClone(syntheticConfig);}};});
   const sourceQuote=api.quote.createQuoteEnvelope({fundCode:CODE,fundName:'合成基金',market:'cn',assetKind:'fund',valueKind:'official_nav',value:1,changePct:(1/0.99-1)*100,baseNav:0.99,baseNavDate:'2026-09-28',targetDate:'2026-09-29',officialNavDate:'2026-09-29',sourceId:'eastmoney-official-nav',sourceTier:'secondary',status:input.staleSource?'stale':'official',observedAt:'2026-09-29',fetchedAt:new Clock(NOW).toISOString(),reasonCodes:[]},{now:NOW});
   const raw={code:CODE,name:'合成基金',status:'ok_official',last_nav:0.99,est_nav:1,est_change:(1/0.99-1)*100,nav_date:'2026-09-28',est_time:'2026-09-29',base_nav:0.99,base_nav_date:'2026-09-28',value_date:'2026-09-29',est_kind:'official_nav',est_realtime:false,source_quote:sourceQuote,...input.rawOverrides};
   const move={nav:1,prevNav:0.99,date:'2026-09-29',prevDate:'2026-09-28',change:(1/0.99-1)*100,changeAmt:0.01,fundName:'合成基金',meta:{synthetic:true},...input.moveOverrides};
   const holdingsInput=input.withHoldings?api.F.holdingRows().map(item=>({...item,change:2,quoteTime:'2026-09-30 14:43:00'})):null;
   const holdingsEstimate=holdingsInput?api.holdings.calculateHoldingsEstimate(holdingsInput,{now:NOW,reportDate:'2026-06-30',requireCurrentReport:true}):null;
   const composed=api.holdings.composeFundEnrichment(raw,{officialNavMove:move,holdingsEstimate});
   const built=actualBuild(api,Clock)(composed,{code:CODE,name:'合成当前持仓',shares:10,cost:0.9},input.quotes),notes=actualNotes(api,built.data);
   storageState=memory();api.accuracy.updateFundAccuracy(built.data,{now:NOW,storage:storageState.storage});
   const stored=storageState.map.get('fuyu_overseas_accuracy_v1')??null,ledger=stored===null?[]:JSON.parse(stored);
   summary={outcome:spec.id==='M04-stale-provenance'?built.data.quote.status:built.data.quote.valueKind,holdingsAvailable:holdingsEstimate?.available??null,composedFlags:{model:composed.est_model??null,holdings:composed.est_holdings_model??null},builtFlags:{model:built.data.est_model??null,holdings:built.data.est_holdings_model??null,modelStale:built.data.est_model_stale??null},sharedEst:{nav:built.data.est_nav,change:built.data.est_change,note:built.data.est_note??null},selected:{kind:built.data.quote.valueKind,status:built.data.quote.status,value:built.data.quote.value,change:built.data.quote.changePct},candidates:built.data.quoteCandidates.map(q=>({kind:q.valueKind,status:q.status,value:q.value,change:q.changePct,coverage:q.coverage,source:q.sourceId})),sourceQuote:{kind:built.data.source_quote?.valueKind,value:built.data.source_quote?.value},ledgerPredictions:Array.isArray(ledger)?ledger.map(row=>row.predicted_change):[]};
   result={input,syntheticConfig,config,raw,move,holdingsInput,holdingsEstimate,composed,built,notes,ledger};
  }else{
   const input=accuracyCase(spec.id),fund=input.fund;storageState=memory(input.initial,input.failWrite);const operations=[];
   for(let ordinal=1;ordinal<=input.repeats;ordinal++){const returned=api.accuracy.updateFundAccuracy(fund,{now:input.now,storage:storageState.storage});operations.push({ordinal,returned});}
   const stored=storageState.map.get('fuyu_overseas_accuracy_v1')??null,parsed=stored===null?null:JSON.parse(stored),ledger=api.accuracy.normalizeAccuracyRows(parsed);
   summary={outcome:ledger.length,ledgerPredictions:ledger.map(row=>row.predicted_change),actualChanges:ledger.map(row=>row.actual_change),confidence:ledger.map(row=>row.confidence??null),accuracy:fund.accuracy};
   result={input,operations,fund,parsed,ledger};
  }
 }catch(caught){error=caught;summary={outcome:'UNEXPECTED_THROW'};}
 finally{globalThis.Date=NativeDate;globalThis.fetch=nativeFetch;currentForbidden=null;}
 // Close and copy event/count arrays before the observational serializer can inspect values.
 const events={clock:structuredClone(clockEvents),flow:structuredClone(flowEvents),resourceCallCount:resourceCalls.length,transport:{...transport},forbidden:{...forbidden},memory:storageState?{counts:{...storageState.counts},events:structuredClone(storageState.events),finalEntries:[...storageState.map]}:null};
 return {id:spec.id,group:spec.group,expected:spec.expected,summary,error:errorView(error,api),events,result:ownSnapshot(result),json:jsonBytes(result)};
}
const rows=[],checks=[];
for(const spec of specs){
 const root=await runOne(spec,apis.root),frozen=await runOne(spec,apis.frozen),same=isDeepStrictEqual(root,frozen);
 const expected=Object.is(root.summary.outcome,spec.expected),forbiddenZero=Object.values(root.events.forbidden).every(count=>count===0)&&Object.values(frozen.events.forbidden).every(count=>count===0);
 checks.push({id:spec.id,same,expected,forbiddenZero,actual:root.summary.outcome});rows.push({spec,root,frozen,same,expected,forbiddenZero});
 process.stdout.write(JSON.stringify({id:spec.id,same,expected,actual:root.summary.outcome,forbiddenZero})+'\n');
}
const postflight=await verifySources();
const output={schema:1,scope:'Frozen OLD characterization only; no candidate qualification, full-domain or size claim',preflight,postflight,cases:specs,checks,rows};
const bytes=Buffer.from(JSON.stringify(output,null,2)+'\n');await writeFile(resolve(dir,'baseline-01.json'),bytes,{flag:'wx'});
const result={status:checks.every(row=>row.same&&row.expected&&row.forbiddenZero)?'PASS':'RETAINED_FAILURE',cases:specs.length,invocations:rows.length*2,differentialPass:checks.filter(row=>row.same).length,expectedPass:checks.filter(row=>row.expected).length,forbiddenZero:checks.every(row=>row.forbiddenZero),sourceChecks:preflight.length+postflight.length,bytes:bytes.length,sha256:sha(bytes),failures:checks.filter(row=>!row.same||!row.expected||!row.forbiddenZero)};
await writeFile(resolve(dir,'RESULT.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
for(const [key,descriptor]of Object.entries(oldStorageDescriptors)){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}
process.stdout.write(JSON.stringify(result)+'\n');if(result.status!=='PASS')process.exitCode=1;
