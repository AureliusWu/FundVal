export const NOW=Date.parse('2026-09-30T06:45:00Z');
export const CODE='000002';
export const specs=Object.freeze([
 ['A08-control','A08','entry'],['A08-foreign-fundCode','A08','rejected'],['A08-fundName','A08','entry'],['A08-market-hk','A08','entry'],
 ['A08-cache-tier','A08','rejected'],['A08-stale','A08','filtered'],['A08-model-flag','A08','rejected'],['A08-holdings-flag','A08','rejected'],
 ['A08-model-stale','A08','filtered'],['A08-confidence','A08','entry'],['A08-future-official-date','A08','filtered'],['A08-row-fetch-before-observed','A08','rejected'],
 ['A08-original-source','A08','rejected'],['A08-cachedAt','A08','rejected'],['A08-alias-conflict','A08','WORKER_ALIAS_CONFLICT'],['A08-schema-string','A08','WORKER_SCHEMA_UNSUPPORTED'],
 ['A08-source-quote-overwritten','A08','entry'],['A08-inert-opaque','A08','entry'],['A08-assetKind-ignored','A08','entry'],['A08-second-clock-rescue','A08','filtered'],
 ['M04-dual-installed','M04','model_estimate'],['M04-holdings-only','M04','holding_lookthrough_estimate'],['M04-overseas-only','M04','model_estimate'],
 ['M04-current-official-blocks','M04','official_nav'],['M04-stale-provenance','M04','stale'],['M04-seeded-dual-stale','M04','official_nav'],
 ['C01-selected-not-raw','C01',1],['C01-stale','C01',0],['C01-before1430','C01',0],['C01-duplicate','C01',1],
 ['C01-next-settlement','C01',2],['C01-confidence-zero','C01',1],['C01-malformed-failed-memory','C01',0],['C01-unknown-ledger','C01',2],
].map(([id,group,expected],index)=>Object.freeze({index:index+1,id,group,expected})));
export function httpCase(F,id){
 let now=NOW;
 const row=F.intradayRow({source:'sinan-estimate-proxy',name:'合成基金',source_time:'2026-09-30T14:44:00+08:00',estimate_time:'2026-09-30T14:44:00+08:00',est_time:'2026-09-30T14:44:00+08:00'});
 const payload=F.estimatesV2([row],{fetched_at:'2026-09-30T06:44:30Z',generated_at:'2026-09-30T06:44:30Z'});
 switch(id){
  case 'A08-control':break;
  case 'A08-foreign-fundCode':row.fundCode='000999';break;
  case 'A08-fundName':row.fundName='合成独立来源名称';break;
  case 'A08-market-hk':row.market='hk';break;
  case 'A08-cache-tier':Object.assign(row,{sourceTier:'cache',originalSource:'sinan-estimate-proxy',originalSourceTier:'primary',cacheState:'fresh',cachedAt:NOW-30000,expiresAt:NOW+60000});break;
  case 'A08-stale':row.stale=true;break;
  case 'A08-model-flag':row.est_model=true;break;
  case 'A08-holdings-flag':row.est_holdings_model=true;break;
  case 'A08-model-stale':row.est_model_stale=true;break;
  case 'A08-confidence':row.confidence='low';break;
  case 'A08-future-official-date':row.officialNavDate='2026-10-01';break;
  case 'A08-row-fetch-before-observed':row.fetched_at='2026-09-30T06:43:00Z';break;
  case 'A08-original-source':row.originalSource='sinan-estimate-proxy';break;
  case 'A08-cachedAt':row.cachedAt=NOW-30000;break;
  case 'A08-alias-conflict':row.est_nav=9;break;
  case 'A08-schema-string':payload.schema_version='2';break;
  case 'A08-source-quote-overwritten':row.source_quote={fundCode:'000999',value:99,status:'realtime'};break;
  case 'A08-inert-opaque':row.meta={synthetic:true,optional:null};row.opaqueExtension={tag:'synthetic-only',zero:0};break;
  case 'A08-assetKind-ignored':row.assetKind='invented';break;
  case 'A08-second-clock-rescue':now='CHANGING_DATE';break;
  default:throw new Error('Undeclared HTTP case '+id);
 }
 return {payload,now};
}
export function modelCase(id){
 const data={now:NOW,withHoldings:true,quotes:{sh000001:{changePct:3,sourceTime:'2026-09-30 14:44:00'}},rawOverrides:{},moveOverrides:{}};
 if(id==='M04-holdings-only')data.quotes={};
 if(id==='M04-overseas-only')data.withHoldings=false;
 if(id==='M04-current-official-blocks')data.moveOverrides={date:'2026-09-30',prevDate:'2026-09-29',nav:1.1,prevNav:1,change:10,changeAmt:0.1};
 if(id==='M04-stale-provenance'){data.staleSource=true;data.moveOverrides={status:'stale',stale:true,cacheState:'stale'};}
 if(id==='M04-seeded-dual-stale'){
  data.withHoldings=false;data.quotes={};data.rawOverrides={est_model:true,est_model_stale:true,est_holdings_model:true,est_nav:9.9,est_change:99,est_time:'2026-09-30 14:43:00',est_note:'合成旧双模型说明',
   est_model_base_nav:1,est_model_base_date:'2026-09-29',est_model_target_date:'2026-09-30',est_model_version:'synthetic-old',est_model_weight:100,
   est_holdings_base_nav:1,est_holdings_base_date:'2026-09-29',est_holdings_target_date:'2026-09-30',est_holdings_coverage:60};
 }
 return data;
}
export function accuracyCase(id){
 const fund={code:CODE,est_model:true,est_model_stale:false,est_change:99,est_model_version:'synthetic-v1',est_model_label:'合成模型',est_confidence:'high',
  quote:{fundCode:CODE,valueKind:'model_estimate',status:'model',changePct:1.5,baseNavDate:'2026-09-29',targetDate:'2026-09-30'}};
 const data={fund,now:NOW,repeats:1,initial:null,failWrite:false};
 if(id==='C01-stale')fund.quote.status='stale';
 if(id==='C01-before1430')data.now=Date.parse('2026-09-30T06:29:00Z');
 if(id==='C01-duplicate')data.repeats=2;
 if(id==='C01-confidence-zero')fund.est_confidence=0;
 if(id==='C01-malformed-failed-memory'){data.initial=JSON.stringify({unexpected:true});data.failWrite=true;}
 if(id==='C01-next-settlement'){
  fund.quote.valueKind='official_nav';fund.latest_nav_move={date:'2026-09-30',prevDate:'2026-09-29',change:-0.8};
  data.initial=JSON.stringify([
   {code:CODE,prediction_date:'2026-09-28',target_nav_date:'next',base_nav_date:'2026-09-28',predicted_change:1,actual_change:null,opaque:'unmatched'},
   {code:CODE,prediction_date:'2026-09-29',target_nav_date:'next',base_nav_date:'2026-09-29',predicted_change:-1,actual_change:null,opaque:'matched'}]);
 }
 if(id==='C01-unknown-ledger')data.initial=JSON.stringify([{code:CODE,prediction_date:'2026-09-28',target_nav_date:'2026-09-28',base_nav_date:'2026-09-25',model_version:'old',predicted_change:2,actual_change:null,opaque:{synthetic:true}}]);
 return data;
}
