# A08 / M04 / C01：冻结 OLD 实际行为基线与可达性审计

2026-10-22。只读、合成、有限范围；不修改 root、候选或既有证据。没有 build/install/network/browser、真实 Storage、云数据或用户持仓。本报告不是完整候选验收、6960B 材料性证明或 M3 出口。

## 结论与必须保留的失败

固定 34 案例（A08 20、M04 6、C01 8），root OLD 与独立冻结 OLD 各执行一次，共 68 次顶层场景调用。完整结果快照、own keys/顺序/描述符、JSON 字节、时钟、错误类型与内存存储事件：**34/34 完全一致**；68 次 forbidden fetch/localStorage/sessionStorage 计数全为 0。每个 HTTP 案例只调用一次 synthetic HTTP；没有连网。

但不是“原预期全绿”：预声明预期 **33/34** 正确，`A08-market-hk` 原预计 entry，真实两侧都是 rejected。`baseline-01` 原生命令 exit=1、原 cases.expected="entry"、RESULT=RETAINED_FAILURE 和全部 raw 均保留，未修改案例或为变绿重跑。这是初始 forecast 错误，不是产品回归、可忽略输入或全局 waiver。

后续只读分析另有一个断言也错了，已保留 `analysis-01` exit=1：双 flag 下季度来源候选实际也变成 `model_estimate`，并非预想的 `holding_lookthrough_estimate`。这个新事实促成下方 P1 来源归属审计；不把兼容记录当作必须永久保留缺陷的授权。

`certify-01` exit=0，153 项只读复核通过；`reachability-01` exit=0，19 项源码可达性检查通过。它们不重新运行 OLD、不替换上述 exit=1，也不授予新候选资格。

## 证据入口与冻结身份

- `PROTOCOL.md`：结果前的范围、固定批次及失败政策。
- `cases.mjs` / `cases.json`：完整固定 34 案例。SHA256 `752d1587dec8ee74dbd0adf4812052be98a0032fb0b6c42d354482054e6603a5` / `35e99313ce619fac33b9c6fc3d09fefbc0dc3908073a528666b34fdce4e52491`。
- `PREPARED.json`：41 个源码/数据/package/fixture 闭包文件，共 404301B；逐项 hash、相对依赖、7 个参考文件副本、3 个已安装解析工具身份、18 个真实语法节点切片与4份旧证据 hash。清单 SHA256 `add459ea16e2078d65a5a22d433003e4a35dff68819decc9f9bbba733f4592ca`。
- `frozen/`：独立 byte-identical OLD。没有修改冻结原件。
- `extracts-root.json` / `extracts-frozen.json`：真实 App build/helpers/secondary declarations 和刷新器 loader 的实际语法节点源文本，二者 SHA256 均为 `6e9c183855e946f994a0ff38ef97c7e35e5775c96c860031c0eea3b247355da8`。片段先 CRLF→LF 再按 AST start/end 截取，元数据保留转换说明。
- `baseline.mjs`：已执行 harness，17308B/SHA256 `852562026df3a209d36d828dea47890d38e3170913a3b5979d3e7330183b0e30`。
- `baseline-01.json`：完整机器原件，6704652B/SHA256 `56dfd31b9116842bb21ee59eae31e4631b2e817d2d1947e886bface0869b83d2`。`rows[].root` / `.frozen` 是完整各侧结果；`result` 是描述符/特殊值/共享引用快照，`json` 保存原 JSON 字节与 hash，`events` 是输出观察前复制的事件。
- `ANALYSIS.json`：后验可读解码与31个断言，30通过、1个旧假设失败，原件保留。
- `ACCEPTANCE_CORRECTION.json`：候选尚未执行时，单独声明 hk 固定案例的未来对照须采用实际冻结 OLD rejected；不改原 expected。
- `CERTIFICATION.json`、`REACHABILITY.json` 与 `reachability-sources/`：153项原件复核、19项只读可达性检查及18份完整源副本。源码每项与原冻结身份比对（适用者），不冒充 App 浏览器运行。
- `runs/<label>.stdout/.stderr/.receipt.json/.inputs/`：全部五个原生探针命令的原 stdout、stderr、exit、时间、命令与脚本输入副本。五次 stderr 均 0B。另有工具读取期间的不存在路径定位错误，保留于会话；未当作 probe PASS 或产品失败。

## 实际执行的独立边界

真实源码入口：`D:/AI项目/FundVal/js/eastmoney-estimate.js:13`、`:83`，`js/runtime/refresh-execution.js:142`，`js/runtime/refresh-resource-cache.js:39`/`:179`；M04：`js/holdings-estimate.js:76`/`:192`，`js/runtime/fund-model-enrichment.js:12`，`js/app.js:656`，`:1431`；C01：`js/accuracy.js:57`。

采用仓库 `test/cache-fund-identity-v16.test.js` 的 rolldown parseSync/声明切片方法，提取真实函数/语句；不是重写算法。调用真实模块实现，冻结 root 与 frozen 分别加载其自己的 WorkerContractError 类。没有让两个新 wrapper 共用新 core 来相互证明。

A08：真实 fetchEstimateRows → parseWorkerEnvelope → normalizeEstimateRow（含第二次 wire normalize）→ normalizeEstimateQuote → 生产 loader 原箭头 → 真实 makeRefreshResourceEntry。用 local Response(JSON) 替换 transport，记录 resource 前 HTTP Map/row/source Quote 和传入 resource 的实际 args，以及最终 entry/null/throw。此组不包含 acquireEntry 外层、缓存命中、完整 coordinator/source health/flush。

M04：真实 calculateHoldingsEstimate → composeFundEnrichment → 真模型 config loader（显式 fakeFetcher）→ AST 原 App buildFundData → AST 原 secondary-note 语句 → 显式调用真实 updateFundAccuracy（仅 memoryStorage）。后两者证明旧数据在这些入口下的有效值，**不证明真实 App 同代 enriched callback 已自动触发 accuracy hook**，见下方影响审计。

C01：真实 accuracy load/save/normalize/record/settle/stats。内存 get/set 原始字符串、尝试与成功次数、最终 bytes 都保留。失败 set 的 synthetic Error 在真实 safeSetItem 中被吞，观察到的是无外抛、setAttempt1/setSuccess0、原 bytes 保留；不声称捕获 safeSetItem 内部每个局部变量。

## A08 固定结果 ledger

entry=实际返回资源；rejected=已调用真实资源构造但返回 null；filtered=生产 loader 无 usable row、没有调用资源构造。WORKER_* 是实际抛出的 genuine WorkerContractError（name/code/message/instanceof 全保存）。

| 固定案例 | OLD 实际结果 | 必须区分的阶段 |
|---|---|---|
| control | entry | 完整链有效 |
| foreign-fundCode | rejected | HTTP Quote 身份为000999，不能剪掉后救活000002 |
| fundName | entry | 独立 fundName 进入 Quote 后才被 row 白名单剪除 |
| market-hk | rejected，原 forecast entry 错误 | HTTP Quote delayed、row.est_realtime=true，资源冲突拒绝 |
| cache-tier | rejected | cache provenance 在剪裁前影响 Quote |
| stale | filtered | source Quote stale |
| model-flag | rejected | source Quote kind 变 model_estimate |
| holdings-flag | rejected | source Quote kind 变 holding_lookthrough_estimate |
| model-stale | filtered | source Quote stale |
| confidence | entry | 'low'进入 Quote 归一化，原字段随后剪裁 |
| future-official-date | filtered | 日期导致 source Quote stale |
| row-fetch-before-observed | rejected | row fetched_at 覆盖传入 fetchedAt，时间逆序 |
| original-source | rejected | 非缓存 quote 的 provenance 字段不被静默忽略 |
| cachedAt | rejected | 非缓存 quote 的 cachedAt 不能提前删去救活 |
| alias-conflict | WORKER_ALIAS_CONFLICT | envelope阶段，未取得HTTP行 |
| schema-string | WORKER_SCHEMA_UNSUPPORTED | envelope阶段，未取得HTTP行 |
| source-quote-overwritten | entry | 输入 foreign source_quote 被公共 normalizeEstimateRow 重新生成替换 |
| inert-opaque | entry | meta/opaqueExtension保留在HTTP行、资源行才剪掉 |
| assetKind-ignored | entry | 原 row.assetKind 不决定该 Quote identity 的 assetKind |
| second-clock-rescue | filtered | 第二次 normalize genuinely ROW_INVALID，安全救援后 row.status=error/Quote unavailable |

### hk 的真实拒绝链及候选前 correction

冻结 `data/market-calendars.json` 没有 hk。`js/runtime/market-clock.js:72` 对 hk 给 unknown，而不是按看似正常的14:45交易时段擅自确认 open。`quote-normalizer.js:123` 只在已验证 open 时给 realtime；本行 Quote=delayed，含 MARKET_NOT_OPEN。公共 HTTP row 仍按上游 fresh 保留 `est_realtime=true`（eastmoney-estimate.js:42）。生产资源 `refresh-resource-cache.js:81` 明确拒绝 `row.est_realtime===true` 配非 realtime Quote。因此不是“hk 字符串非法”，而是实际 freshness 与 row flag 的冲突。

未来候选必须对该固定案完整匹配冻结实际 OLD rejected，包括已捕获HTTP行/Quote、一次make调用返回null；不能变成entry、filtered或被剔除。只对此一个错误 forecast 建单独 acceptance correction；其他33个原预期不变，无全局 waiver，不削弱任何验证。候选本轮 NOT_RUN。

### 第二 clock 的真实安全救援

同 realm ChangingDate 依次 getTime：1790750700000、1790743500000、1790743500000，共3次。第一次 envelope 校验通过；第二次 row normalize 发现 source future 抛 ROW_INVALID，真实 normalizeEstimateRow 仅救援 genuine class+该code；第三次 Quote normalization 用同一对象。最终 status=error，message=估值契约不完整，Quote unavailable；loader filtered、make调用0。该案例既不是单独属性 toy，也不是用新core互比。

## M04 固定结果 ledger

| 固定案例 | compose/build/selection 的实际结果 |
|---|---|
| dual-installed | 重仓计算 available、change1.2/coverage60；compose先设holdings flag、est_nav1.012；build的市场模型后写est_nav1.03/change3，两个flag同时true。source_quote仍official_nav/value1。最终market-model胜出。显式accuracy记录3。 |
| holdings-only | 没有可用市场腿，保持holding_lookthrough_estimate/change1.2；显式accuracy无预测但保存[]。 |
| overseas-only | 没有holdings安装，model_estimate/change3，显式accuracy记录3。 |
| current-official-blocks | 当日正式净值阻断重复叠加；两个新flag都不安装，选official_nav/value1.1。 |
| stale-provenance | stale source_quote与latest move不提供可信baseline；不安装两个新模型，选stale。 |
| seeded-dual-stale | 原双flag、共享9.9/99保留；两个模型候选stale，选official_nav/value1；原render modelNote仍含+99.00%/9.9000/旧说明，显式accuracy不记录。 |

关键纠正：dual-installed 季度候选 sourceId=quarterly-holdings-model/coverage60，但实际 valueKind=**model_estimate**、value1.03/change3；market-model候选也是model_estimate/value1.03/change3、coverage100。kindFromRow 对继承的 est_model 优先于显式 holding_lookthrough kind（quote-normalizer.js:74）；这不是单纯“两个独立候选同值”的自然业务结果。

## C01 固定结果 ledger

| 固定案例 | 最终logical ledger / 真实存储事件 |
|---|---|
| selected-not-raw | 1条，predicted_change1.5；raw est_change99不被拿来记预测。get1/set1成功。 |
| stale | 0条，仍get1/set1保存[]。 |
| before1430 | 14:29不记预测，仍get1/set1保存[]。 |
| duplicate | 实际两次update，get2/set2；同日同model只1条。 |
| next-settlement | 两条原记录；base日期不匹配那条保持actual=null，匹配prevDate那条actual=-0.8，opaque保留；误差-0.19999999999999996、方向100。 |
| confidence-zero | 1条；旧 `|| 'unknown'` 使0写为unknown，完整原件保留该语义。 |
| malformed-failed-memory | 非数组初始JSON被logical normalize为[]；setAttempt1/setSuccess0、无外抛、原{"unexpected":true} bytes原样保留；不能把logical空数组说成成功清空真实存储。 |
| unknown-ledger | 新记录前置，旧opaque对象和未知字段保留，总2条。 |

## P1-M04-PROVENANCE：真实规则可达的模型来源归属缺陷（只读判定）

不是仅靠任意合成 direct model 才可达。当前真实配置 `data/overseas-models.json:58` 的“沪深300”规则请求sh000300；合法非QDII“沪深300指数”名称分类cn-index（freshness.js:24；market-session.js:24）。刷新计划允许cn/cn-index重仓（refresh-plan.js:8/:104），App启用mainland holding代码（app.js:903），同时 clients.models 对全部active做select、没有海外市场门槛（:906-909）。overseasComponents明确允许sh/sz六位代码（remote-schema.js:108）。security任务把holdings与selected models同代合并，enriched把双方传给App（refresh-execution.js:241/:313）。因此仅需合法当日报告/行情、上一日正式baseline、无实时主估值，真实配置下也允许这一条路径；此结论是源码可达性证明，不是线上发生率证明。

沿真实 App：composeFundEnrichment先applyHoldingsEstimate，设est_realtime=false并保留完整holdings副字段；buildFundData后applyOverseasModelEstimate正接受false状态且不检查基金market，再覆盖共享est_nav/est_change/est_time/est_note、只增加est_model，未解除holdings flag。随后normalizeHoldingLookthroughQuote复制整个fund、继承est_model，再从共享est_*读出市场模型数值，并混合季度来源/coverage/基期。source registry声称quarterly只具holding_lookthrough能力（source-registry.js:29），这个候选却成model_estimate。这是可达来源归属缺陷，建议P1单列处理；它不应被“兼容重构必须等于OLD”自动变成永久要求。

影响必须限定：本批新鲜同代安装的两个模型基期相同（同一个latestOfficialNavBase），市场模型同时覆盖est_time及est_model_time，最终候选值/变化/时间相同。compareQuotesByQuality按sourceId最终排序，market-model在quarterly之前；因此实际selectedQuote来自market-model，与当前1.03/3及primary金额一致。该批**没有证明用户主金额错误、基期错配或线上资金损失**。P1依据是可达候选provenance不真实，而不是夸大出已证实主金额损坏。

持久化/恢复：App slimFundCache(:44/:592) 与serializeRefreshAggregate(:20/:232)只排除_cached/message/quoteCandidates；两个flag、共享est值、基期副字段、已selected的quote都会保留。正常tryShowCache(:1009)优先d.quote，不重新生成candidate，因此正常缓存恢复并不会立即把非selected季度伪候选升为主值，也不会修复残留来源状态。只有缺失selected quote的legacy恢复才buildFundQuoteCandidates；本轮未执行那个扩大域，不能把此静态分支说成已证明缓存主金额错误。

最小修复方向（不实施、不自动选政策）：

1. 在私有管线重构前单独定义模型覆盖政策与回归锚。若业务只需一个模型，成功安装market模型时必须明确作废已被取代的holdings解释与副状态，而不是遗留“两个模型都有效”的表象；若两个来源都要保留，就保存两份独立不可变候选（值、change、base/target、time、coverage、confidence/version/note），避免共享est_*被后写覆盖。
2. 仅强制季度candidate的kind不能修复其数值已来自市场模型；仅把flags互斥也属于业务政策改变，须由parent决定，不能以减包为理由暗改。
3. 独立回归锚：真实“沪深300”rule（非任意direct配置）、国内合法6只披露贡献1.2、指数变化3、相同官方baseline，验证季度来源不得宣称3；验证selected主Quote及金额、两个来源说明/coverage/版本、当前正式阻断、stale、raw aggregate保存及legacy缺quote恢复。原34案例和失败仍保持不可变，未来有意修复用独立新fixture/差异说明，不覆写OLD历史。

另一个覆盖边界：真实App仅commitRefreshedFund(:814-819)的primary publish有accuracy hook；ui.enriched(:935-938)直接upsert，未走该hook。M04在build后显式真实accuracy调用证明“若调用时怎样记录”，不证明该生产callback已经调用。本轮未重跑完整App生命周期来证明丢记发生率；应单独回归该编排与generation guard，不把内存入口PASS当成生产预测采样已闭合。

## 精确限制与停止点

未执行完整App DOM/浏览器、完整refresh coordinator、失败重试/abort/source health/cache-hit/flush、真实模型网络数据或真实Storage。A08经HTTP JSON，故symbol/getter/Proxy输入域与全own-property可观察输入不由这20案覆盖；前轮64案也不能自动替代本链缺失域。M04没有运行真实配置全App路线，只做19项源码可达性审计并保留真实算法合成安装结果。C01只有8个固定ledger情况，不是所有Storage错误、模型分布/统计质量或准确率可信证明。R01/R03/S01/S03由兄弟任务单独覆盖，不重复冒领。

未实施新pipeline，未运行候选、build或压缩，无7KB资格。尊重本子任务只读范围不等于声称用户禁止后续所有Temp结构原型；是否先修P1、再继续兼容原型由parent据本证据处理。旧公开API与source/site边界未更动。

有限任务到此停止；后续采用 `baseline-01.json` 的实际OLD输出与单独的hk acceptance correction，以及parent对已识别P1的独立修复决定。不得把RETained_FAILURE改述为全绿。
