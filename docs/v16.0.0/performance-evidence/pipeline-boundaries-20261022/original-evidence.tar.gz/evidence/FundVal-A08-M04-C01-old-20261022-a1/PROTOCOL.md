# Fixed OLD A08/M04/C01 chain characterization

Declared 2026-10-22 before freezing/extracting or observing any case outcomes. New system Temp only. Root/candidate/previous evidence remain immutable. No build/install/browser/network/real Storage/cloud. All cases contain synthetic fixed-date data. AGENTS.md and data-reliability-audit were read; no live-data qualification is attempted.

## Fixed batch

Exactly34 cases, fixed in cases.mjs before preparation: A08 twenty HTTP-estimate cases; M04 six real composition/build/secondary/accuracy cases; C01 eight real accuracy/memoryStorage cases. Run each once against current root OLD source and once against byte-identical independently copied frozen OLD source. Retain expected rejects/throws and mismatches; no filtering or candidate implementation.

A08 must execute real fetchEstimateRows with a local synthetic Response(JSON) fetch replacement, real parser/second normalize/source Quote, and the exact production estimate acquisition loader extracted from refresh-execution.js. That loader, not a handwritten copy, decides usable rows and calls real makeRefreshResourceEntry. Record HTTP row/source Quote before resource pruning and final entry/null/error. There is no coordinator/cache-hit/flush or real network in this group. Other R01/R03/S01/S03 property/serializer matrices belong to the sibling task.

M04 must execute real calculateHoldingsEstimate, real composeFundEnrichment, real overseas config loader/apply function and exact AST-extracted buildFundData from App, then exact secondary-note statements extracted from renderFundList and real updateFundAccuracy with synthetic memoryStorage. A fixed one-leg synthetic direct model uses sh000001, weight100, change3, current source time. This is a legal model fixture for the overseas-model algorithm, not real model/provider data. Preserve the genuine dual-flag/shared-est overwrite behavior; never assume exclusivity or fix it.

C01 executes actual updateFundAccuracy/load/save/record/settle/statistics with explicit memoryStorage. Cases cover selected-model versus raw est_change, stale, pre14:30, duplicate, next/base-date settlement, confidence0 fallback, malformed/failed memory storage, and unknown ledger row preservation. Do not replace the algorithm with expected-output code.

## Independent real-source extraction

Use the existing test/cache-fund-identity-v16.test.js parseSync/declaration slicing approach: parse current App with installed rolldown/utils, extract actual function node text (buildFundData plus pure helper dependencies), not copied application algorithms. Locate the exact executor estimate loader arrow by AST under estimateBatches. Extract exact secondary-note declaration statements (estimateNote through officialNote) from real renderFundList. Save span/source/hash metadata and verbatim extracts before outcomes. The harness supplies only data/dependencies/clock/transport/storage, as existing tests do; full App DOM startup is NOT_RUN.

Freeze required source roots and their complete literal static relative dependency closure, fixture, package.json and reference test sources byte-for-byte. Record parser tool entry/native identity without installing. Record root/frozen selected sources and old evidence inventories before/after. Freeze harness/protocol/cases before execution. Actual source hashes may not change between preparation and characterization.

## Clock, outputs and failure handling

Each root/frozen call uses a fresh case factory, model config and memoryStorage. A same-realm Date subclass fixes global Date defaults during only that call; record Date.now/no-arg constructor and explicit ChangingDate getTime events. The same clock is supplied to the extracted App function and real imported modules. Restore native Date/fetch in finally. These events include active harness scaffolding and are not performance measurements or exclusive CPU attribution.

Freeze/copy event arrays before output inspection. Record full own-key/order/descriptor snapshots, special number/null/undefined states, JSON bytes, error name/code/message/instanceof, mock fetch/model-load counts, memory get/set attempts/successes and final memory bytes. Exclude stack path text from differential equality. A08 expected throw cases remain in the baseline; expected resource null/filtered cases are not called harness failures.

Synthetic fetch accepts only the one fixed .invalid estimates URL. Model loading receives an explicit local fakeFetcher. Any unplanned global fetch increments a forbidden counter and throws; global localStorage/sessionStorage getters also throw/count. No real storage is used.

All probe native stdout/stderr/exit/time/command and script inputs are captured. If a harness/source-extraction error occurs, preserve its run and exact scripts, correct only the harness in a new recorded run, never change the34 scenarios or root/frozen sources. A correction is not disguised as an original first-run PASS. Stop after bounded baseline and report.

No complete candidate, new parser, full API equivalence, provider/data reliability acceptance, net gzip saving,6960B promise, M3 exit or release follows.
