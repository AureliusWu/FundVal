// Final archival inventory/postflight only. No SUT/candidate execution.
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {resolve,relative} from 'node:path';
import {createHash} from 'node:crypto';
const dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex'),readJson=async path=>JSON.parse(await readFile(resolve(dir,path),'utf8'));
const prepared=await readJson('PREPARED.json'),reachability=await readJson('REACHABILITY.json'),certification=await readJson('CERTIFICATION.json'),checks=[];
async function exact(name,path,expected){const b=await readFile(path);checks.push({name,path,bytes:b.length,sha256:sha(b),same:b.length===expected.bytes&&sha(b)===expected.sha256});}
for(const item of prepared.files)for(const [side,base]of [['root',prepared.root],['frozen',prepared.frozen]])await exact(side+' source',resolve(base,item.path),item);
for(const item of prepared.references){await exact('root reference',resolve(prepared.root,item.path),item);await exact('frozen reference',resolve(dir,'references',item.path),item);}
for(const item of [...prepared.previous,...prepared.toolInventory])await exact('prior evidence/tool',item.path,item);
for(const item of reachability.inventory){await exact('reachability root',resolve(prepared.root,item.path),item);await exact('reachability frozen',resolve(dir,'reachability-sources',item.path),item);}
for(const item of certification.artifacts)await exact('original fixed artifact',resolve(dir,item.path),item);
for(const label of ['prepare-01','baseline-01','analysis-01','certify-01','reachability-01']){const receipt=await readJson(`runs/${label}.receipt.json`);for(const kind of ['stdout','stderr'])await exact(label+' '+kind,resolve(dir,'runs',receipt[kind].path),receipt[kind]);for(const item of receipt.inputs)await exact(label+' archived input',resolve(dir,`runs/${label}.inputs`,item.path),item);}
const postflight={schema:1,scope:'Final old-evidence/source freeze; no SUT rerun',pass:checks.every(item=>item.same),checks};
await writeFile(resolve(dir,'FINAL_POSTFLIGHT.json'),JSON.stringify(postflight,null,2)+'\n',{flag:'wx'});
const excluded=['FINAL_INVENTORY.json','runs/freeze-01.stdout','runs/freeze-01.stderr','runs/freeze-01.receipt.json'];
const files=[];
async function visit(path){for(const entry of await readdir(path,{withFileTypes:true})){const absolute=resolve(path,entry.name),name=relative(dir,absolute).replaceAll('\\','/');if(entry.isDirectory())await visit(absolute);else if(entry.isFile()&&!excluded.includes(name)){const b=await readFile(absolute);files.push({path:name,bytes:b.length,sha256:sha(b)});}else if(!entry.isFile())throw new Error('Unexpected nonfile archive member '+name);}}
await visit(dir);files.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
const inventoryBytes=Buffer.from(JSON.stringify(files)),inventory={schema:1,algorithm:'sha256(UTF8(JSON.stringify(files sorted ascending path code units))); each item path/bytes/sha256 in that property order',excludedSelfProof:excluded,files:files.length,bytes:files.reduce((sum,item)=>sum+item.bytes,0),inventorySha256:sha(inventoryBytes),entries:files};
await writeFile(resolve(dir,'FINAL_INVENTORY.json'),JSON.stringify(inventory,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({pass:postflight.pass,postflightChecks:checks.length,inventoryFiles:inventory.files,inventoryBytes:inventory.bytes,inventorySha256:inventory.inventorySha256,excludedSelfProof:excluded})+'\n');if(!postflight.pass)process.exitCode=1;
