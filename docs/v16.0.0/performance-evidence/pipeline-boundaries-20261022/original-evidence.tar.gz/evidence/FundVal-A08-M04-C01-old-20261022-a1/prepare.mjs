import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {resolve,relative,dirname,extname} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {specs} from './cases.mjs';
const dir=import.meta.dirname,root='D:/AI项目/FundVal',frozen=resolve(dir,'frozen'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
await mkdir(frozen);
const roots=['js/app.js','js/eastmoney-estimate.js','js/runtime/refresh-resource-cache.js','js/runtime/refresh-execution.js','js/holdings-estimate.js','js/runtime/fund-model-enrichment.js','js/accuracy.js','js/overseas-model.js','test/fixtures/worker-contract-v16.js'];
const files=new Map();
async function visit(path){
 path=path.replaceAll('\\','/');if(files.has(path))return;const absolute=resolve(root,path);if(relative(root,absolute).replaceAll('\\','/')!==path||path.startsWith('../'))throw new Error('Bad source path '+path);
 const bytes=await readFile(absolute),imports=[];
 if(extname(path)==='.js')for(const pattern of [/\bimport\s+(?:[^;'"]*?\s+from\s+)?['"](\.{1,2}\/[^'"]+)['"]/g,/\bexport\s+[^;'"]*?\s+from\s+['"](\.{1,2}\/[^'"]+)['"]/g])for(const match of bytes.toString('utf8').matchAll(pattern)){const dep=relative(root,resolve(dirname(absolute),match[1])).replaceAll('\\','/');if(!imports.includes(dep))imports.push(dep);}
 files.set(path,{path,bytes:bytes.length,sha256:sha(bytes),imports});const target=resolve(frozen,path);await mkdir(dirname(target),{recursive:true});await copyFile(absolute,target);for(const next of imports)await visit(next);
}
for(const path of roots)await visit(path);
await visit('package.json');
const references=['AGENTS.md','test/cache-fund-identity-v16.test.js','test/quote-period.test.js','test/holdings-estimate.test.js','test/accuracy.test.js','test/estimate-http-characterization-v16.test.js','test/refresh-execution-v16.test.js'];
const refs=[];for(const path of references){const bytes=await readFile(resolve(root,path)),target=resolve(dir,'references',path);await mkdir(dirname(target),{recursive:true});await copyFile(resolve(root,path),target);refs.push({path,bytes:bytes.length,sha256:sha(bytes)});}
const req=createRequire(resolve(root,'package.json')),parserPath=req.resolve('rolldown/utils'),tools=[parserPath,resolve(dirname(parserPath),'../package.json')];
try{tools.push(req.resolve('@rolldown/binding-win32-x64-msvc'));}catch{}
const toolInventory=[];for(const path of tools){const bytes=await readFile(path);toolInventory.push({path,bytes:bytes.length,sha256:sha(bytes)});}
const {parseSync}=await import(pathToFileURL(parserPath).href);
function walk(node,callback){if(!node||typeof node!=='object')return;callback(node);for(const value of Object.values(node)){if(Array.isArray(value))value.forEach(child=>walk(child,callback));else if(value&&typeof value==='object')walk(value,callback);}}
const extracted=[];
for(const [side,base]of [['root',root],['frozen',frozen]]){
 const app=(await readFile(resolve(base,'js/app.js'),'utf8')).replaceAll('\r\n','\n'),program=parseSync('app.js',app).program;
 const output={};
 const save=(name,text,start,end,source)=>{output[name]=text;extracted.push({side,name,source,start,end,normalization:'CRLF to LF before AST offsets',bytes:Buffer.byteLength(text),sha256:sha(Buffer.from(text))});};
 for(const name of ['buildFundData','isRealFundName','isUsableNav','esc','fmt','fmt4','latestNavMoveOf']){const matches=program.body.filter(node=>node.type==='FunctionDeclaration'&&node.id.name===name);if(matches.length!==1)throw new Error('Ambiguous real App function '+name);const node=matches[0];save(name,app.slice(node.start,node.end),node.start,node.end,'js/app.js');}
 const render=program.body.find(node=>node.type==='FunctionDeclaration'&&node.id.name==='renderFundList'),notes=[];
 walk(render,node=>{if(node.type==='VariableDeclaration'&&node.declarations.some(value=>['estimateNote','primaryNote','modelNote','officialMove','officialNote'].includes(value.id?.name)))notes.push(node);});
 if(notes.length!==5)throw new Error('Expected five actual secondary note statements, got '+notes.length);notes.sort((a,b)=>a.start-b.start);save('secondaryNotes',app.slice(notes[0].start,notes.at(-1).end),notes[0].start,notes.at(-1).end,'js/app.js');
 const execution=(await readFile(resolve(base,'js/runtime/refresh-execution.js'),'utf8')).replaceAll('\r\n','\n'),executionProgram=parseSync('refresh-execution.js',execution).program;let batches;
 walk(executionProgram,node=>{if(node.type==='VariableDeclarator'&&node.id?.name==='estimateBatches'){if(batches)throw new Error('Duplicate estimateBatches');batches=node;}});
 const calls=[];walk(batches,node=>{if(node.type==='CallExpression'&&node.callee?.type==='Identifier'&&node.callee.name==='acquireEntry')calls.push(node);});
 if(calls.length!==1||calls[0].arguments[1]?.type!=='ArrowFunctionExpression')throw new Error('Ambiguous real production acquisition loader');const loader=calls[0].arguments[1];save('estimateLoader',execution.slice(loader.start,loader.end),loader.start,loader.end,'js/runtime/refresh-execution.js');
 await writeFile(resolve(dir,`extracts-${side}.json`),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
}
for(const name of new Set(extracted.map(item=>item.name))){const pair=extracted.filter(item=>item.name===name);if(pair.length!==2||pair[0].sha256!==pair[1].sha256)throw new Error('Root/frozen extract differs '+name);}
const previousPaths=['C:/Users/84046/AppData/Local/Temp/FundVal-http-vertical-ledger-20261022-a1/REPORT.md','C:/Users/84046/AppData/Local/Temp/FundVal-http-vertical-ledger-20261022-a1/FIELD_LEDGER.json','C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1/cases.mjs','C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1/baseline-01.json'];
const previous=[];for(const path of previousPaths){const bytes=await readFile(path);previous.push({path,bytes:bytes.length,sha256:sha(bytes)});}
const inventory=[...files.values()].sort((a,b)=>a.path.localeCompare(b.path));
const prepared={schema:1,root,frozen,roots,files:inventory,sourceInventorySha256:sha(Buffer.from(JSON.stringify(inventory))),references:refs,toolInventory,extracted,previous,cases:specs};
await writeFile(resolve(dir,'PREPARED.json'),JSON.stringify(prepared,null,2)+'\n',{flag:'wx'});await writeFile(resolve(dir,'cases.json'),JSON.stringify(specs,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({status:'PREPARED',files:inventory.length,bytes:inventory.reduce((sum,item)=>sum+item.bytes,0),sourceInventorySha256:prepared.sourceInventorySha256,extracts:extracted.length,cases:specs.length,toolInventory})+'\n');
