import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, existsSync, lstatSync, realpathSync, renameSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createServer } from 'node:net';
import { sha, inv, json, save } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';

const here=import.meta.dirname,root='D:/AI项目/FundVal',before=json(resolve(here,'BEFORE.json')),expected=before.expected;
const npm='C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js',phase=process.argv[2];
const freezePath=resolve(here,'FINAL_SOURCE.json');
const exclusions=new Set(['.git','node_modules','site','Temp','.claude','docs']);
const modified=['scripts/release-fingerprint.mjs','test/app-bundle-budget-v16.test.js'];
const added=['test/app-bundle-budget-policy-v16.test.js'];
assert.equal(process.version,'v24.14.0');
assert.equal(json('C:/Program Files/nodejs/node_modules/npm/package.json').version,'11.9.0');

async function native(out,label,command,args,extra={},timeoutMs=240000) {
  const env={...process.env,SOURCE_DATE_EPOCH:'1792046773',...extra};delete env.NODE_OPTIONS;
  mkdirSync(out,{recursive:true});const startedAt=new Date().toISOString();
  const child=spawn(command,args,{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
  const stdout=[],stderr=[];let error=null,timedOut=false,exitObserved=false,termination=null;
  child.stdout.on('data',b=>stdout.push(b));child.stderr.on('data',b=>stderr.push(b));
  child.on('error',e=>{error=e.message;});child.once('exit',()=>{exitObserved=true;});
  const timer=setTimeout(()=>{
    timedOut=true;
    if(child.pid&&!exitObserved&&child.exitCode===null&&child.signalCode===null){
      const stopped=spawnSync('taskkill.exe',['/PID',String(child.pid),'/T','/F'],{windowsHide:true,encoding:null,timeout:15000});
      termination={nativeExit:stopped.status,signal:stopped.signal,error:stopped.error?.message??null,stdout:(stopped.stdout??Buffer.alloc(0)).toString('base64'),stderr:(stopped.stderr??Buffer.alloc(0)).toString('base64')};
    }else{termination={status:'TREE_TERMINATION_UNCONFIRMED',exitObserved};child.stdout.destroy();child.stderr.destroy();}
  },timeoutMs);
  const end=await new Promise(done=>child.once('close',(nativeExit,signal)=>done({nativeExit,signal})));clearTimeout(timer);
  const outBytes=Buffer.concat(stdout),errBytes=Buffer.concat(stderr);
  save(resolve(out,label+'.stdout'),outBytes);save(resolve(out,label+'.stderr'),errBytes);
  const receipt={label,command,args,cwd:root,envExtra:{SOURCE_DATE_EPOCH:'1792046773',...extra},startedAt,finishedAt:new Date().toISOString(),...end,error,timedOut,termination,
    stdout:{bytes:outBytes.length,sha256:sha(outBytes)},stderr:{bytes:errBytes.length,sha256:sha(errBytes)}};
  save(resolve(out,label+'.receipt.json'),JSON.stringify(receipt,null,2)+'\n');
  process.stdout.write(JSON.stringify(receipt)+'\n');
  return{receipt,stdout:outBytes,stderr:errBytes};
}
function completed(receipt,code=0){assert.equal(receipt.error,null);assert.equal(receipt.signal,null);assert.equal(receipt.timedOut,false);assert.equal(receipt.nativeExit,code);}
async function sourceState(out,label,freeze) {
  const rows=inv(root,exclusions);
  if(freeze)assert.deepEqual(rows,freeze.noDocs,'frozen source unchanged');
  else{
    const old=new Map(expected.noDocs.map(r=>[r.path,r])),current=new Map(rows.map(r=>[r.path,r]));
    assert.deepEqual(rows.filter(r=>!old.has(r.path)).map(r=>r.path),added);
    assert.deepEqual(expected.noDocs.filter(r=>!current.has(r.path)),[]);
    assert.deepEqual(rows.filter(r=>old.has(r.path)&&r.sha256!==old.get(r.path).sha256).map(r=>r.path),modified);
  }
  const fixed=expected.rows.find(r=>r.path==='docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');
  assert.equal(sha(readFileSync(resolve(root,fixed.path))),fixed.sha256);
  const full=[...rows,fixed].sort((a,b)=>a.path.localeCompare(b.path));assert.equal(full.length,274);
  for(const r of expected.installed){const b=readFileSync(resolve(root,'node_modules',r.path));assert.equal(b.length,r.bytes);assert.equal(sha(b),r.sha256);}
  assert.deepEqual(inv(resolve(root,'site'),new Set(['.playwright-results'])),expected.site,'actual product artifact unchanged');
  for(const[tag,args,value]of[['head',['rev-parse','HEAD'],expected.head],['branch',['branch','--show-current'],expected.branch],['index',['diff','--cached','--binary'],expected.indexSha256]]){
    const r=await native(out,label+'-'+tag,'git',args);completed(r.receipt);assert.equal(tag==='index'?sha(r.stdout):r.stdout.toString().trim(),value);
  }
  return{noDocs:rows,full,sourceRowsSha256:sha(JSON.stringify(full)),siteRowsSha256:sha(JSON.stringify(expected.site)),installed:expected.installed.length,head:expected.head,branch:expected.branch,indexSha256:expected.indexSha256};
}
async function unusedPort(port){await new Promise((ok,fail)=>{const server=createServer();server.once('error',fail);server.listen(port,'127.0.0.1',()=>server.close(error=>error?fail(error):ok()));});}
async function preserveE2E(){
  const from=resolve(root,'site/.playwright-results');
  if(!existsSync(from))return null;
  assert.equal(dirname(from),resolve(root,'site'));assert.equal(lstatSync(from).isSymbolicLink(),false);
  assert.equal(realpathSync(from).toLowerCase(),from.toLowerCase());
  const target=resolve(root,'Temp/budget-policy-e2e-20261023-01');assert.equal(existsSync(target),false);
  assert.equal(dirname(target),resolve(root,'Temp'));assert.equal(lstatSync(dirname(target)).isSymbolicLink(),false);
  const rows=inv(from);renameSync(from,target);assert.deepEqual(inv(target),rows);
  save(resolve(here,'E2E_ARTIFACTS.json'),JSON.stringify({from,target,rows,rowsSha256:sha(JSON.stringify(rows))},null,2)+'\n');
  return{from,target,count:rows.length};
}

async function main(){
  assert.ok(['freeze','test','check','build-01','e2e','preserve-e2e','build-02','build-03','build-04','artifact','audit'].includes(phase));
  const out=resolve(here,'gates',phase);assert.equal(existsSync(out),false);mkdirSync(out,{recursive:true});
  if(phase==='freeze'){
    const state=await sourceState(out,'freeze',null);
    save(freezePath,JSON.stringify({...state,protocolSha256:sha(readFileSync(resolve(here,'PROTOCOL.md'))),gatesToolSha256:sha(readFileSync(import.meta.filename))},null,2)+'\n');
    process.stdout.write(JSON.stringify({phase,status:'POLICY_SOURCE_FROZEN',source:state.full.length,sourceRowsSha256:state.sourceRowsSha256})+'\n');return;
  }
  const frozen=json(freezePath);assert.equal(sha(readFileSync(import.meta.filename)),frozen.gatesToolSha256);assert.equal(sha(readFileSync(resolve(here,'PROTOCOL.md'))),frozen.protocolSha256);
  let start=null,end=null,result=null,failure=null,postflightError=null;
  try{
    start=await sourceState(out,'before',frozen);
    if(phase==='preserve-e2e')result=await preserveE2E();
    else if(phase==='artifact'){
      result=[];
      for(const[label,args]of[['chunks',['--verify-app-chunks-directory','site']],['graph',['--verify-app-module-graph','site']],['ocr',['--verify-ocr-directory','site/assets/ocr']],['fingerprint',['--directory','site']],['budget',['--assert-app-bundle-budget','site']]]){
        const r=await native(out,label,process.execPath,['scripts/release-fingerprint.mjs',...args]);completed(r.receipt);result.push(r.receipt);
        if(label==='budget'){const report=JSON.parse(r.stdout.toString());assert.equal(report.allBudgetBytes,92160);assert.equal(report.previousAllBudgetBytes,77227.7);assert.equal(report.actualAllNonOcrGzipBytes,85969);assert.equal(report.actualColdStartGzipBytes,46149);assert.equal(report.pass,true);}
      }
    }else{
      const extra=phase==='e2e'?{FUNDVAL_E2E_PORT:'12437',PLAYWRIGHT_JSON_OUTPUT_FILE:resolve(out,'report.json')}:{};
      if(phase==='e2e')await unusedPort(12437);
      if(phase.startsWith('build')){assert.equal(existsSync(resolve(root,'site/.playwright-results')),false,'preserve E2E before build');assert.equal(lstatSync(resolve(root,'site')).isSymbolicLink(),false);}
      const args=phase==='test'?['test']:phase==='check'?['run','check']:phase==='e2e'?['run','test:e2e','--','--reporter=list,json']:phase==='audit'?['audit','--audit-level=high','--registry=https://registry.npmjs.org']:['run','build'];
      const r=await native(out,phase,process.execPath,[npm,...args],extra,phase==='e2e'?240000:180000);completed(r.receipt);result=r.receipt;
      if(phase.startsWith('build'))save(resolve(out,'site.inventory.json'),JSON.stringify(inv(resolve(root,'site')),null,2)+'\n');
      if(phase==='e2e'){assert.equal(existsSync(resolve(out,'report.json')),true);await unusedPort(12437);}
    }
  }catch(error){failure={message:error.message,stack:error.stack};}
  try{end=await sourceState(out,'after',frozen);assert.deepEqual(end,start);}catch(error){postflightError={message:error.message,stack:error.stack};}
  const status=failure||postflightError?'GATE_FAILURE':'GATE_PASS_ONLY';
  save(resolve(out,'RESULT.json'),JSON.stringify({phase,status,before:start,after:end,result,failure,postflightError,release:false,m3Exit:false},null,2)+'\n');
  process.stdout.write(JSON.stringify({phase,status,failure,postflightError})+'\n');
  if(failure||postflightError)process.exitCode=2;
}
await main();
