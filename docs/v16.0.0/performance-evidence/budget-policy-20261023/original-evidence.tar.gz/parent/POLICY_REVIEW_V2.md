# Independent policy fixture review V2, 2026-10-23

Verdict: PASS_FOR_SCOPED_THIRD_TEST_DIFF. The negative fixture correction is appropriate for the explicitly approved 92,160 B total ceiling; no admission or safety weakening was found. This does not grant V2 test/build/application success, M3 exit or release authority. The original POLICY_REVIEW.md is not modified.

## Retained V1 failure, not relabeled

Read gates/test/test.receipt.json, test.stdout, test.stderr and RESULT.json. The actual parent run is npm test, 2026-10-23 06:18:56.084 -> 06:19:04.102 UTC, nativeExit1, no signal/error/timeout, stdout130205B, stderr0B. Both stdout/stderr SHA256 match their receipt. Raw output reports 1323 total / 1319 PASS / 1 FAIL / 3 Windows skips. The only failing test is standalone candidate admission's over-budget negative, with Missing expected rejection at the original test line129. RESULT correctly remains GATE_FAILURE, postflightError:null. This is not converted into a full-suite PASS.

The saved original test contains 90,000 raw deterministic high-entropy bytes in its oversized lazy chunk and only asserts archive/site raw total >90,000 before expecting budget rejection. The newly authorized gate is 92,160 actual gzip bytes, not 90,000 raw bytes. The old fixture no longer established its own over-budget precondition; successful candidate verification and the missing rejection are causally consistent with the intentional new policy. The raw retained log does not print that fixture's exact gzip count, so this review does not invent one or claim a fresh recompression measurement.

## Exact third-file diff

git --no-index compared original/test/release-candidate.test.js with the current file. Its native1 is the expected diff result, not a test run. Only these test changes occur:

1. Import the existing verifyAppChunkReleaseDirectory API.
2. Increase oversized deterministic fixture bytes from90,000 to100,000; the ordinary16-byte fixture and deterministic generation loop are unchanged.
3. Before candidate creation, call the existing physical verifier and assert actual.actualAllNonOcrGzipBytes >92,160, with an explicit negative-fixture precondition message.
4. Update the separate raw inventory-retention assertion from >90,000 to >100,000.

The existing final assert.rejects on verifyAndExtractCandidate and its budget-error matcher remain unchanged. No test is deleted/skipped, no admission error is caught/suppressed, and no expected rejection is turned into success. The new precondition directly prevents a future policy/fixture mismatch from silently masquerading as an admission-code regression. It uses actual recomputed compressed byte accounting, not manifest gzip metadata or the raw total assertion.

scripts/release-candidate.mjs remains byte-identical in V1, V2 and the current file, SHA256 af9928d6692b128765cf2b8c7d8c09fcd847feb13497b6ae4f7b8db5d3fba266. Its standalone admission still performs fingerprint verification and assertAppBundleBudget(await verifyAppChunkReleaseDirectory(destination)). The policy ceiling, physical validation, archive/provenance rules and normal positive candidate tests are not changed by this third-file correction.

## Frozen identity and V2 separation

- Saved original test SHA256 26a24b53831da894805be6c39b8a4b2c6b49f4646226a6af815c917c8fc52432 matches FINAL_SOURCE.json's V1 row.
- Current test SHA256 c3eea272f581512a62f46113ee1b7c49d72572feec6d6b9fd049e47655eb8abb,11428B matches FINAL_SOURCE_V2.json's V2 row.
- V1 and V2 both contain274 full rows. Comparing those frozen arrays finds only test/release-candidate.test.js changed; no additions/deletions or other row changes.
- V2 source rows SHA is89bdfff42618da6b1743a61e96bf4177ba34329ea716acb73c49e3ee920cc80f. Its site rows SHA remains0641039bb788b27c58c0ec0dc3d93b40cbc95bc2c51c935c105c9354c9b29d31.
- Original PROTOCOL.md still matches V2's recorded protocolSha256. New PROTOCOL_V2_ADDENDUM.md matches its independently recorded cb43c9988e127bfc29ca126ef54812877e00189be880aacc321875c07654fc37.
- gates-v2.mjs matches its frozen hash087d0660d310bde0b53077e45d5a7d3f9e1132018ddc845eab7823a770b3c3cc. Static inspection shows separate FINAL_SOURCE_V2.json/gates-v2 paths, declaration of the third modified test, prior source/site/install checks and native failure handling. It does not overwrite the old gates/test result. This is a source review, not execution of that controller.
- Original POLICY_REVIEW.md was only read/hash-checked, SHA2561a5405fc2c5b9ef94642398a1e24b7f4d5594c2c48e36d276d0381b5d25da52f. This new addendum does not rewrite its scoped13/13 targeted result into full-suite success.

## Scope and stop

Applied performance-regression-check to evidence boundaries: actual gzip differs from raw fixture size, a changed policy requires a correctly bounded negative fixture, and failed old evidence must remain visible. The task's no-run instruction takes precedence over new measurements. This reviewer ran no test/app/build/CLI verifier/compression probe and edited no root file. The only write is this requested POLICY_REVIEW_V2.md.

An initial read used the wrong flat gates/test.stdout location; the directory inventory then identified the retained nested gates/test/test.stdout path. This was a read-path diagnostic, not a missing/failing test artifact. The subsequent exact raw files and receipt hashes are the basis above. V2 runtime results are intentionally not inferred or inherited from V1. Review complete; stop.
