# Independent policy review, 2026-10-23

Verdict: PASS_FOR_SCOPED_POLICY_DIFF, with one documentation integration follow-up below. No actionable code defect, undeclared budget gate, policy-metadata override, or weakening of the existing physical artifact verification was found in this bounded read-only review. This is not a build/test/application execution, final admission, M3 exit or publication approval.

The direct human authorization relayed by the parent is narrowly scoped: total non-OCR app-chunk gzip ceiling becomes 90 KiB / 92,160 B; cold 52,241 B, financial checks, compatibility and latency remain unchanged; no direct release. Read the complete AGENTS.md and performance-regression-check skill. The skill was applied to measurement/provenance boundaries; the task explicitly forbids new tests/builds/runtime execution. No such command was run by this reviewer. The only reviewer write is this requested Temp file.

## Exact policy diff versus the frozen pre-policy files

Reviewed git --no-index output against original/scripts/release-fingerprint.mjs and original/test/app-bundle-budget-v16.test.js, not just the repository's already-dirty HEAD diff. The diff command's native 1 denotes expected differences, not a failed test.

The production-tool delta consists solely of the policy constants/comments and two additive report fields:

| Contract | Reviewed result |
| --- | --- |
| v15 baseline commit | 40e68edab9cb3fba0b17338dc3672a82d13ad17e, unchanged |
| v15 baseline all gzip | 70,207 B, unchanged |
| former ceiling provenance | previousAllBudgetBytes = 70,207 * 11 / 10 = 77,227.7 B |
| active policy id | v16-total-90kib-approved-20261023 |
| active all numerator / denominator | 921,600 / 10 = 92,160 B |
| cold ceiling | 52,241 B, unchanged |
| all comparison | all * 10 <= 921,600, inclusive integer boundary |
| overflow guard | Number.isSafeInteger(all * 10), unchanged |
| input validity | positive safe integer cold; safe integer all >= cold, unchanged |
| result | frozen report, coldPass && allPass, unchanged decision form |
| import proof flag | importClosureVerified:false, unchanged |

No argument, environment variable, manifest field or result metadata selects the policy. analyzeAppChunkBudgets reads only the two measurement properties and constructs its report from literals/constants; it does not spread result. Therefore forged allBudgetBytes/numerator/denominator/coldBudgetBytes/budgetPolicy/previousAllBudgetBytes cannot change the ceiling or report provenance. Direct analyzer tests remain arithmetic/API tests, not proof that caller-supplied numbers represent files; the authoritative CLI still obtains numbers from verified real bytes first.

## Existing safety/accounting remains byte-for-byte in the frozen-tool diff

All of the following tool bodies are outside the policy diff:

- normalized relative paths, root containment, traversal/control-character rejection;
- regular-file/directory and symlink rejection, realpath containment, no-follow file opening and inode/device/size/time checks;
- manifest schema/path/role/positive safe-integer bytes/gzip/hash/duplicate validation;
- complete cold/lazy partition, cold entry, disjointness and complete membership;
- recursive actual chunk inventory including non-JS files and rejection of unlisted/missing files;
- per-file physical bytes and SHA256 verification;
- actual gzipSync(content).length recomputation and equality with manifest gzip declarations;
- summation of all chunks and cold-role chunks from those verified buffers;
- CLI verifyAppChunkReleaseDirectory -> emit measured analysis -> assertAppBundleBudget ordering;
- independent OCR manifest/resource verification and graph/static-binding commands.

The arithmetic approval does not turn a malformed manifest, forged compressed size, omitted lazy file, hash/path/symlink problem or graph failure into a PASS. Artifact top-level metadata may be retained inside the validated manifest for other callers, but it is not spread into the returned measurements or policy report.

## No missed active hard-coded old total gate found

Read/search covered scripts, tests, package.json, .github workflows, AGENTS, README, the upgrade plan and policy document. The only active total-budget implementation found is scripts/release-fingerprint.mjs. CI and deploy still invoke --assert-app-bundle-budget against actual site. scripts/build-site.mjs retains APP_SHELL_GZIP_BUDGET = 52_241, as does its source-contract test; this is the unchanged cold gate, not a missed total ceiling.

Remaining 77,227.7 references in executable tests are intentional previous-policy provenance or explicit between-old-and-new boundary assertions, not admission gates. Historical reports and old saved measurements correctly retain the old limit and FAIL. Existing v15 baseline/README figures remain historical comparison facts. No change to compiler/target/five groups, build script, dependencies, runtime JS, financial validation, version or release authority was found relative to the pre-policy source inventory.

## Test review and preserved execution evidence

Read all seven new policy tests and all six existing budget tests. New coverage pins provenance/baseline, unchanged existing 85,969/46,149 synthetic measurements, inclusive 92,160 and rejecting 92,161, unchanged cold boundary, simultaneous failures, forged policy metadata and the former 77,228-byte boundary now fitting the intentional new policy. Existing tests keep malformed measurement, forged gzip, partition, complete inventory and symlink coverage. The CLI fixture now first proves a real approximately 80K file lies above the old threshold but within the new one and is admitted, then creates approximately 100K and verifies native CLI failure. This is an intentional ceiling update, not deleted rejection coverage.

Read the parent's native receipts/stdout/stderr, without re-executing them:

| Preserved run | Native exit | Recorded result | Raw receipt integrity |
| --- | ---: | --- | --- |
| old-budget-before | 1 | actual all85,969/cold46,149; old total77,227.7 FAIL | stdout358B/stderr67B and both SHA match receipt |
| policy-red-01 | 1 | seven new tests: 1 PASS / 6 FAIL | stdout6067B/stderr0B and both SHA match receipt |
| policy-green-01 | 0 | thirteen targeted tests: 13 PASS / 0 FAIL / 0 skip | stdout1315B/stderr0B and both SHA match receipt |

The RED is an expected implementation-policy mismatch, not evidence that old financial behavior was defective. The GREEN is parent-executed targeted evidence, not a reviewer-run full gate or physical-device/production claim. Future final real CLI, full QA, deterministic builds and fresh paired performance remain separate required work as declared in the protocol.

## Fresh read-only identity checks

PROTOCOL.md SHA256 e8797b2b3ac015743d166ec643a684435d64bd1e3d36e5688ef4e1a49310d3ec matches BEFORE.json's frozen protocolSha256.

Rehashed all 273 existing pre-policy rows in BEFORE.expected.rows: exactly two differ, as declared:

- scripts/release-fingerprint.mjs: old 4d99eda7af1da3c999090364926c78ea27597c4107892ae82b9894bb43a704c3 -> reviewed e5dd8e5a8131114773f1b615845a0208e1c103fe72f9d6934733c85215ac7fe6.
- test/app-bundle-budget-v16.test.js: old d132121e356d738e7ab7d47089d849db7c2060c6807fbd54026a8d9c2df50b77 -> reviewed d84a418809eaf90d9ff645d5556f04e8e2aafbf56cfac6cad30fac0a9b16bfcb.

Rehashed the 127 pre-policy site rows: zero differences. Rehashed the explicit 68 installed file rows: zero differences. This is an identity read, not a rebuild, fresh compression measurement or complete inventory of newly created paths. New additive policy test is reviewed separately, SHA256 045bc3310a38397acf3e6705bdf3a12aea7a044948b3ffb2afa276bd0f5dd3be.

UPGRADE_PLAN's Git diff changes the active total gate and adds an explicit policy record, leaving cold/latency rows unchanged. The new BUNDLE_BUDGET_POLICY_20261023.md preserves old/new limits, old FAIL and non-release boundaries; its linked module-attribution evidence exists. Reviewed plan SHA256 efd2d979c6588b8d528764ea2d0820db719a59e5d3b48c411e23df3c7617f030; policy document SHA256 add461097eefcd47abe55a7301d781a63759761b0691b2a0cdc5a56826fe7c02.

The 273-row pre-policy inventory includes only one docs file, not all historical docs, so this report does not claim a fresh byte-for-byte pre/post freeze of every historical report. The reviewed existing old native FAIL/RED files are intact by receipt hashes; M3_STATUS sections53-55 still state the old-policy failures and do not retcon rejected prototypes/compiler prerequisites into successes.

## Documentation integration follow-up, non-blocking to the code diff

At review time M3_STATUS's top current summary still says root all85,969 / budget FAIL for section55, before the new policy section has been recorded. When the parent appends the new policy and new real-gate results, update only the current summary to distinguish old-policy FAIL from new-policy budget result. Keep sections53-55 and their original failures unchanged. Do not simply replace their old thresholds or claim M3 EXIT/publication from a ceiling change. This was sent to the parent before report completion.

## Limits and stop

No further action is taken. No tests/build/app/CLI verifier/audit/network checks were run by this reviewer; no root file was edited. One read-only PowerShell receipt-summary command had a parser error before execution, then the syntax-only corrected summary produced the receipt/hash comparisons above. No test result or business conclusion was inferred from that tool error. This review supports only the precise reviewed policy delta and static accounting integrity, not all later parent edits or future generated artifacts.
