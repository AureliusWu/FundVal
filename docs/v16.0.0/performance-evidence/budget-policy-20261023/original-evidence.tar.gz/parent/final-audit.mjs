import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { sha, inv, json, save, native } from 'file:///C:/Users/84046/AppData/Local/Temp/FundVal-closure-overlay-20261023-parent/common.mjs';
const here=import.meta.dirname,root='D:/AI项目/FundVal',before=json(resolve(here,'BEFORE.json')),frozen=json(resolve(here,'FINAL_SOURCE_V2.json'));
const out=resolve(here,'final-audit');assert.equal(existsSync(out),false);
function verifyState(){
  assert.deepEqual(inv(root,new Set(['.git','node_modules','site','Temp','.claude','docs'])),frozen.noDocs);
  assert.deepEqual(inv(resolve(root,'site')),before.expected.site);
  for(const r of before.expected.installed){const b=readFileSync(resolve(root,'node_modules',r.path));assert.equal(b.length,r.bytes);assert.equal(sha(b),r.sha256);}
  for(const [tag,args,value]of[['head',['rev-parse','HEAD'],before.expected.head],['branch',['branch','--show-current'],before.expected.branch],['index',['diff','--cached','--binary'],before.expected.indexSha256]]){
    const r=native(out,'pre-'+tag,'git',['-C',root,...args]);assert.equal(r.receipt.nativeExit,0);assert.equal(tag==='index'?sha(r.stdout):r.stdout.toString().trim(),value);
  }
}
verifyState();
for(const path of ['package.json','js/ocr/asset-manifest.js']){
  const expected=before.expected.rows.find(r=>r.path===path),b=readFileSync(resolve(root,path));
  assert.equal(b.length,expected.bytes);assert.equal(sha(b),expected.sha256);save(resolve(here,'original',path),b);
}
const original=readFileSync(resolve(here,'original/scripts/release-fingerprint.mjs'));
assert.equal(sha(original),before.expected.rows.find(r=>r.path==='scripts/release-fingerprint.mjs').sha256);
const old=native(out,'old-budget-after',process.execPath,[resolve(here,'original/scripts/release-fingerprint.mjs'),'--assert-app-bundle-budget',resolve(root,'site')]);
assert.equal(old.receipt.nativeExit,1);assert.equal(old.receipt.signal,null);assert.equal(old.receipt.error,null);
const oldReport=JSON.parse(old.stdout);assert.equal(oldReport.allBudgetBytes,77227.7);assert.equal(oldReport.pass,false);assert.equal(oldReport.actualAllNonOcrGzipBytes,85969);assert.equal(oldReport.actualColdStartGzipBytes,46149);
const phases=['test','check','build-01','e2e','preserve-e2e','build-02','build-03','build-04','artifact','audit'];
const gates=phases.map(phase=>{
  const r=json(resolve(here,'gates-v2',phase,'RESULT.json'));assert.equal(r.status,'GATE_PASS_ONLY');assert.equal(r.failure,null);assert.equal(r.postflightError,null);
  assert.equal(r.before.sourceRowsSha256,frozen.sourceRowsSha256);assert.equal(r.after.sourceRowsSha256,frozen.sourceRowsSha256);
  return{phase,status:r.status,result:r.result};
});
const first=json(resolve(here,'gates/test/RESULT.json'));assert.equal(first.status,'GATE_FAILURE');
const failedReceipt=json(resolve(here,'gates/test/test.receipt.json'));assert.equal(failedReceipt.nativeExit,1);
const report=json(resolve(here,'gates-v2/e2e/report.json'));assert.equal(report.stats.expected,35);assert.equal(report.stats.unexpected,0);assert.equal(report.stats.skipped,0);assert.equal(report.stats.flaky,0);
const e2e=json(resolve(here,'E2E_ARTIFACTS.json'));assert.deepEqual(inv(e2e.target),e2e.rows);
assert.ok(e2e.rows.some(r=>r.path.endsWith('actual-accuracy-lifecycle.json')));
const newReport=JSON.parse(readFileSync(resolve(here,'gates-v2/artifact/budget.stdout'),'utf8'));
assert.equal(newReport.allBudgetBytes,92160);assert.equal(newReport.previousAllBudgetBytes,77227.7);assert.equal(newReport.coldBudgetBytes,52241);assert.equal(newReport.pass,true);
for(const phase of ['build-01','build-02','build-03','build-04'])assert.deepEqual(json(resolve(here,'gates-v2',phase,'site.inventory.json')),before.expected.site);
const stdout=readFileSync(resolve(here,'gates-v2/test/test.stdout'),'utf8');
assert.match(stdout,/tests 1323/);assert.match(stdout,/pass 1320/);assert.match(stdout,/fail 0/);assert.match(stdout,/skipped 3/);
assert.equal(readFileSync(resolve(here,'gates-v2/audit/audit.stdout'),'utf8').trim(),'found 0 vulnerabilities');
assert.equal(json(resolve(here,'gates-v2/audit/audit.receipt.json')).nativeExit,0);
assert.equal(json(resolve(here,'gates-v2/e2e/e2e.receipt.json')).stderr.bytes,352);
for(const r of inv(root,new Set(['.git','node_modules','site','Temp','.claude','docs'])))assert.equal(r.sha256,frozen.noDocs.find(x=>x.path===r.path).sha256);
const result={schema:1,status:'POLICY_AND_LOCAL_QA_PASS_ONLY',approval:'2026-10-23 human total-only 90KiB approval; not release',
  policyDelta:{previousAllBudgetBytes:77227.7,allBudgetBytes:92160,coldBudgetBytes:52241},
  source:{count:frozen.full.length,rowsSha256:frozen.sourceRowsSha256,modified:['scripts/release-fingerprint.mjs','test/app-bundle-budget-v16.test.js','test/release-candidate.test.js'],added:['test/app-bundle-budget-policy-v16.test.js']},
  site:{count:before.expected.site.length,rowsSha256:sha(JSON.stringify(before.expected.site)),actualAllGzipBytes:85969,actualColdGzipBytes:46149,changed:false,deterministicBuilds:4},
  oldCli:old.receipt,oldReport,newReport,gates,
  fullTest:{total:1323,pass:1320,fail:0,skip:3,note:'existing Windows-only skips, not PASS'},syntaxFiles:216,
  browser:{expected:35,unexpected:0,skip:0,flaky:0,stderrBytes:352,warning:'two NO_COLOR/FORCE_COLOR warnings, not console-zero assertion',actualArtifacts:e2e.rows.length,actualArtifactsRowsSha256:e2e.rowsSha256},
  audit:{nativeExit:0,result:'found 0 vulnerabilities',scope:'actual current npm audit --audit-level=high --registry=https://registry.npmjs.org'},
  retainedFailure:{v1NativeExit:1,reason:'90K raw negative fixture legitimately fit new gzip budget; corrected to100K plus actual gzip assertion',redPolicyTests:'6 RED/1 PASS before policy implementation'},
  graphScope:{literalBindingsAndClosure:true,evaluated:false,startupOrderVerified:false,dynamicNamespaceMembersVerified:false},
  installedCount:68,head:before.expected.head,branch:before.expected.branch,indexSha256:before.expected.indexSha256,
  release:false,m3Exit:false,remaining:['new current-source paired performance','exact immutable candidate CI/review','later M4-M6/physical devices/production']};
save(resolve(here,'RESULTS.json'),JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify({status:result.status,source:result.source,site:result.site,browser:result.browser,oldNativeExit:old.receipt.nativeExit,newBudgetPass:newReport.pass})+'\n');
