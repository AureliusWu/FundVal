import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { readFile,readdir,lstat,writeFile,mkdir,copyFile } from 'node:fs/promises';
import { dirname,resolve } from 'node:path';
import { fileURLToPath,pathToFileURL } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url));
const [mode,side,round]=process.argv.slice(2),sha=b=>createHash('sha256').update(b).digest('hex');
const json=async p=>JSON.parse(await readFile(resolve(here,p),'utf8'));
const save=async(p,v)=>writeFile(resolve(here,p),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const snap=await json('snapshot.json');
const root=side==='ROOT'?'D:/AI项目/FundVal':resolve(here,side||'.');
async function source(base){const rows=[];for(const row of snap.rows){const b=await readFile(resolve(base,row.path));rows.push({path:row.path,bytes:b.length,sha256:sha(b)});}return {count:rows.length,bytes:rows.reduce((s,r)=>s+r.bytes,0),sha256:sha(JSON.stringify(rows)),rows};}
async function site(base){const rows=[];async function visit(path){const full=resolve(base,path),s=await lstat(full);assert.ok(!s.isSymbolicLink());if(s.isDirectory())for(const name of await readdir(full))await visit(path==='.'?name:path+'/'+name);else{assert.ok(s.isFile());const b=await readFile(full);rows.push({path,bytes:b.length,sha256:sha(b)});}}await visit('.');rows.sort((a,b)=>a.path.localeCompare(b.path));return {count:rows.length,bytes:rows.reduce((s,r)=>s+r.bytes,0),sha256:sha(JSON.stringify(rows)),rows};}
if(mode==='freeze'){
  for(const s of ['A','B'])await save(s+'-source-frozen.json',await source(resolve(here,s)));
  console.log('Frozen full270 inputs for A/B; this scope includes non-build historical dot-directory artifacts.');
}else if(mode==='build'||mode==='certify'){
  assert.ok(['A','B','ROOT'].includes(side));assert.ok(/^[123]$/.test(round));
  const frozen=await json((side==='ROOT'?'B':side)+'-source-frozen.json');
  assert.deepEqual(await source(root),frozen,'Source differs before build');
  if(mode==='build'){
    const p=spawnSync(process.execPath,[resolve(here,'run.mjs'),side,'build-'+round,'0','NODE','C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js','run','build'],{cwd:root,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});
    assert.equal(p.status,0,p.stdout+'\n'+p.stderr);
  }
  const api=await import(pathToFileURL(resolve(root,'scripts/release-fingerprint.mjs')));
  const output=resolve(root,'site'),whole=await site(output),critical=await api.fingerprintReleaseDirectory(output),chunks=await api.verifyAppChunkReleaseDirectory(output),budget=api.analyzeAppChunkBudgets(chunks),graph=await api.verifyAppModuleGraphReleaseDirectory(output),ocr=await api.verifyOcrReleaseDirectory(resolve(output,'assets/ocr'));
  const report={side,round:Number(round),whole,critical,chunks,budget,graph,ocr,sourceAfter:await source(root)};
  if(mode==='build')await save(side+'-verification-'+round+'.json',report);
  else assert.deepEqual(report,await json(side+'-verification-'+round+'.json'),'Saved original build no longer matches disk');
  assert.deepEqual(report.sourceAfter,frozen,'Source differs after build');
  assert.equal(whole.count,127);assert.equal(whole.bytes,92537133);assert.equal(whole.sha256,'5b946d23a08cd42743e5151b3ba5bb62ec52b7b6016dcd83eafaac42817124a9');
  assert.equal(critical,'3103251a7107ebb76d61c0a7131430ccf221e204e6aac931a319649c7608bf55');
  if(side!=='A'||round!=='1')assert.deepEqual(whole,(await json('A-verification-1.json')).whole,'Whole artifact differs from A1 anchor');
  for(const row of whole.rows.filter(r=>r.path==='js/app-chunks.json'||r.path==='js/app-shell.js'||r.path.startsWith('js/chunks/'))){const to=resolve(here,side+'-app-'+round,row.path);await mkdir(dirname(to),{recursive:true});await copyFile(resolve(output,row.path),to);}
  console.log(JSON.stringify({side,round,whole:{count:whole.count,bytes:whole.bytes,sha256:whole.sha256},critical,budget,graph,ocr}));
}else throw Error('Usage: verify.mjs freeze | build A|B|ROOT 1|2|3');
