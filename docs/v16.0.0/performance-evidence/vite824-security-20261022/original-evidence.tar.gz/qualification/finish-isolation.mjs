import assert from 'node:assert/strict';
import { readFile,writeFile,cp } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url));
const json=async n=>JSON.parse(await readFile(resolve(here,n),'utf8'));
for(const side of ['A','B']){
  for(const name of ['unit-full','syntax-full','e2e-full'])assert.equal((await json(side+'-'+name+'.json')).status,0);
  await cp(resolve(here,side,'site/.playwright-results'),resolve(here,side+'-e2e-results'),{recursive:true,errorOnExist:true});
}
const networkFailure=await json('B-audit-full.json');assert.equal(networkFailure.status,1);assert.ok(networkFailure.stdout.includes('network timeout'));
const receipt=await json('B-audit-bounded-repeat.json');assert.equal(receipt.status,0);
const audit=JSON.parse(receipt.stdout);assert.deepEqual(audit.vulnerabilities,{});assert.equal(audit.metadata.vulnerabilities.total,0);
for(const id of ['GHSA-698v-4r3x-3vcv','GHSA-r825-w8mm-5pxw','GHSA-587h-7wmj-h5pm','GHSA-9jrq-w75r-8gcw','GHSA-rq7h-c2jc-7f22','GHSA-vfpm-58rq-9qcg'])assert.ok(!receipt.stdout.includes(id));
for(const [side,round] of [['B',2],['A',2],['A',3],['B',3]]){
  const r=spawnSync(process.execPath,[resolve(here,'verify.mjs'),'build',side,String(round)],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});
  process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');assert.equal(r.status,0);
}
const runs=[];
for(const [side,round] of [['A',1],['B',1],['B',2],['A',2],['A',3],['B',3]])runs.push(await json(side+'-verification-'+round+'.json'));
for(const r of runs){assert.deepEqual(r.whole,runs[0].whole);assert.deepEqual(r.chunks,runs[0].chunks);assert.deepEqual(r.budget,runs[0].budget);assert.deepEqual(r.graph,runs[0].graph);assert.deepEqual(r.ocr,runs[0].ocr);}
await writeFile(resolve(here,'isolation-screen.json'),JSON.stringify({schema:1,screen:'PASS_ISOLATED_BYTE_IDENTITY_AND_BEHAVIOR_ONLY',buildOrder:runs.map(r=>r.side+r.round),whole:runs[0].whole,critical:runs[0].critical,budget:runs[0].budget,graph:runs[0].graph,ocr:runs[0].ocr,auditTotal:0,testsPerSide:{total:1224,pass:1221,skip:3,fail:0,syntax:212,e2e:33},runtimeLatency:'NOT_MEASURED',m3:'IN_PROGRESS',rootAdopted:false,newCi:false,deployed:false},null,2)+'\n',{flag:'wx'});
console.log('Isolation screen PASS; root not yet adopted; all-budget remains FAIL.');
