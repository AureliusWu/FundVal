import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const [side,label,expected,program,...args]=process.argv.slice(2),here=dirname(fileURLToPath(import.meta.url));
if(!['A','B','ROOT'].includes(side)||!/^[a-z0-9-]+$/.test(label||''))throw Error('Invalid arguments');
const cwd=side==='ROOT'?'D:/AI项目/FundVal':resolve(here,side),command=program==='NODE'?process.execPath:program;
const env={...process.env,SOURCE_DATE_EPOCH:'1792046773',FUNDVAL_E2E_PORT:side==='B'?'12455':'12453'};
const selected={SOURCE_DATE_EPOCH:env.SOURCE_DATE_EPOCH,FUNDVAL_E2E_PORT:env.FUNDVAL_E2E_PORT,
 NODE_OPTIONS:env.NODE_OPTIONS||null,NODE_ENV:env.NODE_ENV||null,CI:env.CI||null,TZ:Intl.DateTimeFormat().resolvedOptions().timeZone,
 proxyConfigured:Boolean(env.HTTPS_PROXY||env.HTTP_PROXY||env.https_proxy||env.http_proxy)};
const started=new Date().toISOString(),r=spawnSync(command,args,{cwd,env,encoding:'utf8',windowsHide:true,maxBuffer:64*1024*1024});
const record={side,label,cwd,command,args,env:selected,node:process.version,started,ended:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?.message||null,stdout:r.stdout||'',stderr:r.stderr||''};
writeFileSync(resolve(here,side+'-'+label+'.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
process.stdout.write(record.stdout);process.stderr.write(record.stderr);console.log(JSON.stringify({side,label,nativeExit:r.status,expected:Number(expected)}));
process.exitCode=r.status===Number(expected)?0:1;
