import assert from 'node:assert/strict';
import { readFile,readdir,lstat,mkdir,copyFile,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal',rows=[];
const sha=b=>createHash('sha256').update(b).digest('hex');
const excluded=new Set(['.git','node_modules','site','Temp','.claude','docs']);
async function visit(path){const full=resolve(root,path),s=await lstat(full);assert.equal(s.isSymbolicLink(),false);
 if(s.isDirectory()){for(const name of await readdir(full))if(path!=='.'||!excluded.has(name))await visit(path==='.'?name:path+'/'+name);}
 else {assert.ok(s.isFile());assert.ok(!/(^|\/)\.env(?:\.|$)/.test(path),'Unexpected secret file in source snapshot');
 const b=await readFile(full);rows.push({path,bytes:b.length,sha256:sha(b)});
 for(const side of ['A','B']){const to=resolve(here,side,path);await mkdir(dirname(to),{recursive:true});await copyFile(full,to);}}}
await visit('.');await visit('docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');
rows.sort((a,b)=>a.path.localeCompare(b.path));
for(const row of rows){assert.equal(sha(await readFile(resolve(root,row.path))),row.sha256);for(const side of ['A','B'])assert.equal(sha(await readFile(resolve(here,side,row.path))),row.sha256);}
await writeFile(resolve(here,'snapshot.json'),JSON.stringify({schema:1,root,files:rows.length,bytes:rows.reduce((s,r)=>s+r.bytes,0),sha256:sha(JSON.stringify(rows)),rows},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({files:rows.length,bytes:rows.reduce((s,r)=>s+r.bytes,0),inventory:sha(JSON.stringify(rows))}));
