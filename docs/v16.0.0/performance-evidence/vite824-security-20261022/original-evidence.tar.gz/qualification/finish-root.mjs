import assert from 'node:assert/strict';
import { readFile,writeFile,cp } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal',json=async n=>JSON.parse(await readFile(resolve(here,n),'utf8'));
for(const name of ['unit-full','syntax-full','e2e-full','install-clean','policy-before','policy-after','esbuild-approved'])assert.equal((await json('ROOT-'+name+'.json')).status,0);
await cp(resolve(root,'site/.playwright-results'),resolve(here,'ROOT-e2e-results'),{recursive:true,errorOnExist:true});
for(const round of [2,3]){const r=spawnSync(process.execPath,[resolve(here,'verify.mjs'),'build','ROOT',String(round)],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');assert.equal(r.status,0);}
for(const [label,args,exit] of [
 ['budget-native',['--assert-app-bundle-budget','site'],1],
 ['graph-native',['--verify-app-module-graph','site'],0],
 ['bindings-native',['--verify-app-static-bindings','site'],0],
 ['ocr-assets',['--verify-ocr-directory','site/assets/ocr'],0]
]){const r=spawnSync(process.execPath,[resolve(here,'run.mjs'),'ROOT',label,String(exit),'NODE','scripts/release-fingerprint.mjs',...args],{encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024});process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');assert.equal(r.status,0);}
const isolation=await json('isolation-screen.json'),builds=await Promise.all([1,2,3].map(n=>json('ROOT-verification-'+n+'.json')));
for(const r of builds){assert.deepEqual(r.whole,isolation.whole);assert.deepEqual(r.graph,isolation.graph);}
const unit=await json('ROOT-unit-full.json'),syntax=await json('ROOT-syntax-full.json'),e2e=await json('ROOT-e2e-full.json');
assert.match(unit.stdout,/tests 1224/);assert.match(unit.stdout,/pass 1221/);assert.match(unit.stdout,/fail 0/);assert.match(unit.stdout,/skipped 3/);assert.match(syntax.stdout,/Syntax checked 212/);assert.match(e2e.stdout,/33 passed/);
const audits=await Promise.all(['ROOT-audit-full.json','ROOT-audit-bounded-repeat.json'].map(json));
const audit0=audits.some(r=>{try{return r.status===0&&JSON.parse(r.stdout).metadata.vulnerabilities.total===0;}catch{return false;}});
for(const name of ['package.json','package-lock.json'])assert.deepEqual(await readFile(resolve(root,name)),await readFile(resolve(here,'B',name)));
const protectedPaths=['scripts/build-site.mjs','js/version.js','js/runtime/refresh-coordinator.js','js/runtime/refresh-runtime.js','js/runtime/source-registry.js','js/runtime/generation-resource-scope.js','js/runtime/refresh-resource-cache.js','scripts/measure-performance-pair.mjs','scripts/collect-baseline.mjs'];
const git=args=>{const r=spawnSync('git',args,{cwd:root,encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});assert.equal(r.status,0,r.stderr);return r.stdout;};
assert.equal(git(['diff','--name-only','HEAD','--',...protectedPaths]),'');
await writeFile(resolve(here,'tracked-diff-after-security.patch'),git(['diff','--binary','HEAD']),{flag:'wx'});
const report={schema:1,version:'15.0.2',stage:'M3_IN_PROGRESS',head:git(['rev-parse','HEAD']).trim(),branch:git(['branch','--show-current']).trim(),
 patch:{rootApplied:true,files:['package.json','package-lock.json'],allowedScalarChanges:5,otherLockedPackageMetadataChanged:0,
   viteBefore:'8.2.2',viteAfter:'8.2.4',rolledBack:false,rootQualificationComplete:audit0},
 isolated:{...isolation,whole:undefined},root:{
   unit:{total:1224,pass:1221,fail:0,skipped:3,durationMs:Number(unit.stdout.match(/duration_ms ([0-9.]+)/)[1])},syntaxFiles:212,e2eSummary:e2e.stdout.match(/33 passed \([^\n]+/)[0],
   builds:builds.map(({side,round,whole,critical,chunks,budget,graph,ocr,sourceAfter})=>({side,round,whole,critical,chunks,budget,graph,ocr,sourceAfter})),
   audit:{status:audit0?'PASS_ZERO':'UNKNOWN_REMOTE_SERVICE',attempts:audits.map(r=>({nativeExit:r.status,message:(()=>{try{return JSON.parse(r.stdout).message||null;}catch{return 'Non-JSON response';}})()})),attemptLimitReached:!audit0}},
 protectedPaths,relativeLatencyQualified:false,newCi:false,pushed:false,deployed:false,ocrEngine:'NOT_RUN',physicalDevices:'NOT_RUN',liveFinance:'NOT_RUN',gistWrites:'NOT_RUN',
 limitations:['Byte identity is not latency evidence.','Original all-budget remains FAIL; minimum6960 integer bytes reduction.','No old-lock pair can be inherited.','A1 verifier assertion stack was not separately captured; original successful build and saved report retained.']};
await writeFile(resolve(here,'qa-summary.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({rootQualificationComplete:audit0,rootAudit:report.root.audit,unit:report.root.unit,e2e:report.root.e2eSummary,budget:builds[0].budget,wholeHash:builds[0].whole.sha256}));
