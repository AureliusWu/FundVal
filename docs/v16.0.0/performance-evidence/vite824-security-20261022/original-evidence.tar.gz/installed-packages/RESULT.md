# Read-only installed dependency comparison

Captured UTC: 2026-10-22T03:03:00.811Z
Runtime: C:\Program Files\nodejs\node.exe, v24.14.0, win32/x64.

## Targets and outcome

Qualification base: C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a

Actual install directories are A and B. A-app-1 and B-app-1 are not compared as installed trees.

- A and B each contain 57 installed package roots with actual name/version read from package.json.
- Recursive scan covered 63 package.json files per side: 57 installed manifests and 6 module-format subdirectory metadata files without name/version. No deeper nested installed package roots were present.
- Only installed name/version difference: vite 8.2.2 -> 8.2.4. The other 56 package manifests have identical name/version and file SHA256.
- All 6 extra module-format manifests also have identical file SHA256.
- No separately installed launch-editor package manifest exists; this comparison does not repeat the parent inline-code review.
- rolldown and @rolldown/binding-win32-x64-msvc: 1.2.5 on both sides.
- esbuild and @esbuild/win32-x64: 0.28.2 on both sides.
- lightningcss-win32-x64-msvc: 1.33.0 on both sides.

## Lockfile cross-check

Root lockfileVersion A=3, B=3. Each root lock has 109 package entries: root plus 108 dependency entries.

- Root package-lock.json differs at exactly 4 JSON scalars: root devDependencies.vite; node_modules/vite version/resolved/integrity.
- Root package.json differs at exactly 1 JSON scalar: devDependencies.vite. Combined difference count: exactly the predeclared 5 scalars.
- Of the 108 dependency lock entries, all 107 non-Vite entries are structurally identical.
- Each node_modules/.package-lock.json has 57 entries; only the 3 Vite version/resolved/integrity scalars differ.
- All 57 actual installed manifests match each respective root and hidden lock version. Missing installed lock entries, version mismatches, and explicit-name mismatches: all 0.
- The 51 root-lock entries absent on disk are identical across A/B, all optional and all excluded by observed win32/x64 platform or CPU. These include the absent nested playwright/node_modules/fsevents Darwin entry. Hidden locks have 0 entries absent on disk.

A root lock SHA256: 4a9441b3e294166d25ea1c304574afe2afa169b75087a6d31ae15a52dcbd7b85
B root lock SHA256: afe6a0d4aefe8668fc6c0d761bdfa8c59823225faa9923d60307a14a2cb7ee78

## Native file byte identity

All discovered .exe and .node files were read and SHA256-hashed, never executed. Exactly 3 files per side; corresponding A/B files have the same size and hash.

| Relative path within A or B | Bytes | A = B SHA256 |
| --- | ---: | --- |
| node_modules/@esbuild/win32-x64/esbuild.exe | 11694592 | c7bee37877d0aa6a046e52783fa0a2cf1a9ce5579d68bb3083bda99d4bff18ef |
| node_modules/@rolldown/binding-win32-x64-msvc/rolldown-binding.win32-x64-msvc.node | 21401600 | 7d51fbe850cc06771ad2e85615d5e1a86b5e323b6f34d7a5aa2728e1a9f364b9 |
| node_modules/lightningcss-win32-x64-msvc/lightningcss.win32-x64-msvc.node | 9484800 | d043df0f0675e7fffed4cf8b8c33e28639ec9f21d445c21e7fe4985e4a9b5a91 |

## Directory isolation

- PowerShell Get-Item for each node_modules: Attributes=16 (Directory only), LinkType=null, Target=null.
- Node lstat: isSymbolicLink=false for both top-level node_modules.
- fs.realpathSync resolves to each original A/node_modules or B/node_modules path; those paths are distinct.
- Recursive scan found 0 symbolic links/reparse links within each installed tree. No symlink targets were followed or needed.

## Coverage and limits

The walker visits every ordinary directory recursively beneath node_modules. It parses every package.json and classifies installed roots by the final node_modules segment, including scoped and arbitrarily nested packages. It separately retains other module-format manifests and hashes every .exe and .node file. Parse errors: A=0, B=0.

This verifies installed manifest identity, complete lock JSON differences, native byte equality, and absence of node_modules junction/symlink sharing. It does not claim equality of every non-manifest JavaScript file or independently verify package tarball integrity. Inline Vite launch-editor implementation review remains the parent task.

No installation, build, test, package script, or native binary was run. No A/B or D:/AI项目/FundVal file was changed. The comparison script and captured evidence were written only to this independent evidence directory.

## Reproducible commands and captured results

Comparison command (exit code 0; complete stdout in installed-comparison.json):

```powershell
& 'C:\Program Files\nodejs\node.exe' 'C:\Users\84046\AppData\Local\Temp\fundval-installed-version-review-20261022-56c0cbac\compare-installed.mjs'
```

Directory attributes command (exit code 0):

```powershell
Get-Item -LiteralPath 'C:\Users\84046\AppData\Local\Temp\fundval-vite824-qualification-20261022-0d5350fa5e31a\A\node_modules','C:\Users\84046\AppData\Local\Temp\fundval-vite824-qualification-20261022-0d5350fa5e31a\B\node_modules' -Force | Select-Object FullName,Attributes,LinkType,Target | ConvertTo-Json -Depth 4
```

Captured attributes:

```json
[
  {
    "FullName": "C:\\Users\\84046\\AppData\\Local\\Temp\\fundval-vite824-qualification-20261022-0d5350fa5e31a\\A\\node_modules",
    "Attributes": 16,
    "LinkType": null,
    "Target": null
  },
  {
    "FullName": "C:\\Users\\84046\\AppData\\Local\\Temp\\fundval-vite824-qualification-20261022-0d5350fa5e31a\\B\\node_modules",
    "Attributes": 16,
    "LinkType": null,
    "Target": null
  }
]
```

