import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const base = 'C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a';
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const normalized = (p) => p.split(path.sep).join('/');
const order = (xs) => xs.sort((a, b) => a.path.localeCompare(b.path, 'en'));
const readJSON = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
function isPackageRootManifest(relativePath) {
  const parts = relativePath.split('/');
  if (parts.at(-1) !== 'package.json') return false;
  const lastNM = parts.lastIndexOf('node_modules');
  const suffix = parts.slice(lastNM + 1, -1);
  return suffix.length === (suffix[0]?.startsWith('@') ? 2 : 1);
}
function scan(label) {
  const root = path.join(base, label);
  const manifests = [];
  const nativeFiles = [];
  const symlinks = [];
  const errors = [];
  function walk(directory) {
    for (const item of fs.readdirSync(directory, { withFileTypes: true })) {
      const full = path.join(directory, item.name);
      const relative = normalized(path.relative(root, full));
      if (item.isSymbolicLink()) {
        symlinks.push({ path: relative, target: fs.readlinkSync(full) });
        continue;
      }
      if (item.isDirectory()) walk(full);
      else if (item.isFile() && /\.(?:node|exe)$/i.test(item.name)) {
        const bytes = fs.readFileSync(full);
        nativeFiles.push({ path: relative, bytes: bytes.length, sha256: sha(bytes) });
      }
      else if (item.isFile() && item.name === 'package.json') {
        try {
          const bytes = fs.readFileSync(full);
          const manifest = JSON.parse(bytes.toString('utf8'));
          manifests.push({ path: relative.replace(/\/package\.json$/, ''), name: manifest.name ?? null, version: manifest.version ?? null, sha256: sha(bytes), installedRoot: isPackageRootManifest(relative) });
        } catch (error) {
          errors.push({ path: relative, error: String(error) });
        }
      }
    }
  }
  walk(path.join(root, 'node_modules'));
  const lockBytes = fs.readFileSync(path.join(root, 'package-lock.json'));
  const lock = JSON.parse(lockBytes.toString('utf8'));
  const hiddenLockPath = path.join(root, 'node_modules', '.package-lock.json');
  const hiddenLock = fs.existsSync(hiddenLockPath) ? readJSON(hiddenLockPath) : null;
  const installed = order(manifests.filter((m) => m.installedRoot));
  const embedded = order(manifests.filter((m) => !m.installedRoot));
  const installedMap = new Map(installed.map((m) => [m.path, m]));
  function lockComparison(packages) {
    const versionMismatch = [];
    const explicitNameMismatch = [];
    const missingFromLock = [];
    for (const item of installed) {
      const entry = packages[item.path];
      if (!entry) missingFromLock.push(item);
      else if (entry.version !== item.version) versionMismatch.push({ path: item.path, actual: item.version, lock: entry.version });
      if (entry?.name && entry.name !== item.name) explicitNameMismatch.push({ path: item.path, actual: item.name, lock: entry.name });
    }
    const absentOnDisk = [];
    for (const [packagePath, entry] of Object.entries(packages)) {
      if (packagePath && !installedMap.has(packagePath)) absentOnDisk.push({ path: packagePath, version: entry.version, optional: entry.optional ?? false, os: entry.os ?? null, cpu: entry.cpu ?? null });
    }
    return { installedChecked: installed.length, missingFromLock, versionMismatch, explicitNameMismatch, absentOnDisk: order(absentOnDisk) };
  }
  const nameVersionSet = [...new Set(installed.map((m) => `${m.name}@${m.version}`))].sort();
  return {
    label,
    root,
    rootRealPath: fs.realpathSync(root),
    nodeModules: { path: path.join(root, 'node_modules'), realPath: fs.realpathSync(path.join(root, 'node_modules')), isSymbolicLink: fs.lstatSync(path.join(root, 'node_modules')).isSymbolicLink() },
    lockfileVersion: lock.lockfileVersion,
    lockSHA256: sha(lockBytes),
    installedRootCount: installed.length,
    uniqueNameVersionCount: nameVersionSet.length,
    allPackageManifestCount: manifests.length,
    embeddedManifestCount: embedded.length,
    symlinks,
    nativeFiles: order(nativeFiles),
    errors,
    installed,
    embedded,
    nameVersionSet,
    projectLockEntryCount: Object.keys(lock.packages ?? {}).length,
    projectLockComparison: lockComparison(lock.packages ?? {}),
    hiddenLockEntryCount: hiddenLock ? Object.keys(hiddenLock.packages ?? {}).length : null,
    hiddenLockComparison: hiddenLock ? lockComparison(hiddenLock.packages ?? {}) : null,
    rawLock: lock,
    rawHiddenLock: hiddenLock,
  };
}
function deepDiff(a, b, at = '') {
  if (Object.is(a, b)) return [];
  if (typeof a !== 'object' || a === null || typeof b !== 'object' || b === null || Array.isArray(a) !== Array.isArray(b)) return [{ path: at, A: a, B: b }];
  const result = [];
  for (const key of [...new Set([...Object.keys(a), ...Object.keys(b)])].sort()) {
    const next = at + '/' + key.replace(/~/g, '~0').replace(/\//g, '~1');
    if (!Object.hasOwn(a, key)) result.push({ path: next, B: b[key], only: 'B' });
    else if (!Object.hasOwn(b, key)) result.push({ path: next, A: a[key], only: 'A' });
    else result.push(...deepDiff(a[key], b[key], next));
  }
  return result;
}
function installedDiff(a, b) {
  const aa = new Map(a.map((m) => [m.path, m]));
  const bb = new Map(b.map((m) => [m.path, m]));
  const result = [];
  for (const packagePath of [...new Set([...aa.keys(), ...bb.keys()])].sort()) {
    const A = aa.get(packagePath);
    const B = bb.get(packagePath);
    if (!A || !B || A.name !== B.name || A.version !== B.version) result.push({ path: packagePath, A: A ? {name: A.name, version: A.version} : null, B: B ? {name: B.name, version: B.version} : null });
  }
  return result;
}
const A = scan('A');
const B = scan('B');
const lockDifferences = deepDiff(A.rawLock, B.rawLock);
const hiddenLockDifferences = deepDiff(A.rawHiddenLock, B.rawHiddenLock);
const packageDifferences = deepDiff(readJSON(path.join(base, 'A', 'package.json')), readJSON(path.join(base, 'B', 'package.json')));
const packageRootDifferences = installedDiff(A.installed, B.installed);
const embeddedManifestDifferences = installedDiff(A.embedded, B.embedded);
const manifestByteDifferences = A.installed.filter((item) => {
  const other = B.installed.find((candidate) => candidate.path === item.path);
  return other && item.sha256 !== other.sha256;
}).map((item) => ({ path: item.path, A: item.sha256, B: B.installed.find((candidate) => candidate.path === item.path).sha256 }));
const keyPackages = Object.fromEntries([A, B].map((side) => [side.label, side.installed.filter((m) => /(?:^|\/)(?:vite|rolldown|esbuild|launch-editor)(?:$|\/)|@(?:rolldown|esbuild)\//.test(m.path))]));
const result = {
  generatedUTC: new Date().toISOString(),
  runtime: { executable: process.execPath, version: process.version, platform: process.platform, arch: process.arch },
  scope: { base, labels: ['A', 'B'], readOnly: true, includes: 'Every installed package root manifest recursively, plus all other package.json files, root lock and hidden installed lock' },
  summary: {
    installed: { A: A.installedRootCount, B: B.installedRootCount },
    uniqueNameVersion: { A: A.uniqueNameVersionCount, B: B.uniqueNameVersionCount },
    allManifests: { A: A.allPackageManifestCount, B: B.allPackageManifestCount },
    embeddedManifests: { A: A.embeddedManifestCount, B: B.embeddedManifestCount },
    projectLockEntries: { A: A.projectLockEntryCount, B: B.projectLockEntryCount },
    hiddenLockEntries: { A: A.hiddenLockEntryCount, B: B.hiddenLockEntryCount },
    packageRootDifferenceCount: packageRootDifferences.length,
    embeddedManifestDifferenceCount: embeddedManifestDifferences.length,
    manifestByteDifferenceCount: manifestByteDifferences.length,
    packageJSONDifferenceCount: packageDifferences.length,
    lockDifferenceCount: lockDifferences.length,
    hiddenLockDifferenceCount: hiddenLockDifferences.length,
  },
  packageRootDifferences,
  embeddedManifestDifferences,
  manifestByteDifferences,
  packageDifferences,
  lockDifferences,
  hiddenLockDifferences,
  keyPackages,
  nativeFileDifferences: deepDiff(A.nativeFiles, B.nativeFiles),
  sides: [A, B].map(({ rawLock, rawHiddenLock, ...side }) => side),
};
console.log(JSON.stringify(result, null, 2));
