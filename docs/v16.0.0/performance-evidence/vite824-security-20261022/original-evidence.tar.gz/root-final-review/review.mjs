import assert from 'node:assert/strict';
import { readFile, readdir, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';

const root = 'D:/AI项目/FundVal';
const qualification = 'C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a';
const readJson = async path => JSON.parse(await readFile(path, 'utf8'));
const json = name => readJson(resolve(qualification, name));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const qa = await json('qa-summary.json');
const frozenA = await json('A-source-frozen.json'), frozenB = await json('B-source-frozen.json');
const snapshot = await json('snapshot.json');
assert.equal(qa.patch.rootApplied, true);
assert.equal(qa.patch.rootQualificationComplete, false);
assert.equal(qa.root.audit.status, 'UNKNOWN_REMOTE_SERVICE');
assert.equal(qa.root.audit.attemptLimitReached, true);
assert.equal(qa.stage, 'M3_IN_PROGRESS');
assert.equal(qa.relativeLatencyQualified, false);
for (const field of ['newCi', 'pushed', 'deployed']) assert.equal(qa[field], false);

function diff(a, b, path = []) {
  if (Object.is(a, b)) return [];
  if (a && b && typeof a === 'object' && typeof b === 'object' && Array.isArray(a) === Array.isArray(b)) {
    return [...new Set([...Object.keys(a), ...Object.keys(b)])].sort().flatMap(key =>
      !Object.hasOwn(a, key) || !Object.hasOwn(b, key)
        ? [{ path: [...path, key], a: a[key], b: b[key], missing: !Object.hasOwn(a, key) ? 'A' : 'B' }]
        : diff(a[key], b[key], [...path, key]));
  }
  return [{ path, a, b }];
}
const rootPackage = await readJson(resolve(root, 'package.json'));
const rootLock = await readJson(resolve(root, 'package-lock.json'));
const aPackage = await readJson(resolve(qualification, 'A/package.json'));
const aLock = await readJson(resolve(qualification, 'A/package-lock.json'));
const changes = [...diff(aPackage, rootPackage).map(row => ({ file: 'package.json', ...row })),
  ...diff(aLock, rootLock).map(row => ({ file: 'package-lock.json', ...row }))];
const allowed = [['package.json', ['devDependencies', 'vite']],
  ['package-lock.json', ['packages', '', 'devDependencies', 'vite']],
  ...['version', 'resolved', 'integrity'].map(key => ['package-lock.json', ['packages', 'node_modules/vite', key]])];
assert.equal(changes.length, 5);
assert.deepEqual(changes.map(row => JSON.stringify([row.file, row.path])).sort(), allowed.map(row => JSON.stringify(row)).sort());
for (const file of ['package.json', 'package-lock.json']) assert.deepEqual(await readFile(resolve(root, file)), await readFile(resolve(qualification, 'B', file)));
assert.equal(rootPackage.devDependencies.vite, '8.2.4');
assert.equal(rootPackage.version, '15.0.2');
const metadataPath = resolve(root, 'docs/v16.0.0/performance-evidence/execution-skips-20261022/security-triage/registry-metadata.json');
const metadataBytes = await readFile(metadataPath), metadata = JSON.parse(metadataBytes);
const official = metadata.versions.find(row => row.version === '8.2.4');
assert.equal(rootLock.packages['node_modules/vite'].integrity, official.dist.integrity);
assert.equal(rootLock.packages['node_modules/vite'].resolved, official.dist.tarball);
const otherLockChanges = Object.keys(aLock.packages).filter(key => !['', 'node_modules/vite'].includes(key))
  .filter(key => diff(aLock.packages[key], rootLock.packages[key]).length);
assert.deepEqual(otherLockChanges, []);

async function source(base, model) {
  const rows = [];
  for (const row of model.rows) {
    const path = resolve(base, row.path), status = await lstat(path);
    assert.equal(status.isSymbolicLink(), false); assert.equal(status.isFile(), true);
    const bytes = await readFile(path); rows.push({ path: row.path, bytes: bytes.length, sha256: sha(bytes) });
  }
  return { count: rows.length, bytes: rows.reduce((sum, row) => sum + row.bytes, 0), sha256: sha(JSON.stringify(rows)), rows };
}
for (const frozen of [frozenA, frozenB]) {
  assert.equal(frozen.count, 270); assert.equal(frozen.sha256, sha(JSON.stringify(frozen.rows)));
}
assert.deepEqual(await source(root, frozenB), frozenB);
assert.deepEqual(await source(resolve(qualification, 'B'), frozenB), frozenB);
assert.deepEqual(await source(resolve(qualification, 'A'), frozenA), frozenA);
assert.deepEqual(frozenA.rows, snapshot.rows);
const git = args => execFileSync('git', args, { cwd: root, encoding: 'utf8', windowsHide: true });
const protectedPaths = ['scripts/build-site.mjs', 'js/version.js', 'js/runtime/refresh-coordinator.js',
  'js/runtime/refresh-runtime.js', 'js/runtime/source-registry.js', 'js/runtime/generation-resource-scope.js',
  'js/runtime/refresh-resource-cache.js', 'scripts/measure-performance-pair.mjs', 'scripts/collect-baseline.mjs'];
assert.deepEqual(qa.protectedPaths, protectedPaths);
assert.equal(git(['diff', '--name-only', 'HEAD', '--', ...protectedPaths]), '');
assert.equal(git(['rev-parse', 'HEAD']).trim(), qa.head);
assert.equal(git(['branch', '--show-current']).trim(), qa.branch);

async function inventory(base, select = () => true) {
  const rows = [];
  async function visit(prefix = '') {
    for (const item of await readdir(resolve(base, prefix), { withFileTypes: true })) {
      const path = prefix ? prefix + '/' + item.name : item.name;
      assert.equal(item.isSymbolicLink(), false);
      if (item.isDirectory()) await visit(path);
      else if (select(path)) { assert.equal(item.isFile(), true); const bytes = await readFile(resolve(base, path)); rows.push({ path, bytes: bytes.length, sha256: sha(bytes) }); }
    }
  }
  await visit(); rows.sort((a, b) => a.path.localeCompare(b.path));
  return { count: rows.length, bytes: rows.reduce((sum, row) => sum + row.bytes, 0), sha256: sha(JSON.stringify(rows)), rows };
}
const anchor = await json('A-verification-1.json');
assert.equal(anchor.whole.count, 127); assert.equal(anchor.whole.bytes, 92537133);
assert.equal(anchor.whole.sha256, '5b946d23a08cd42743e5151b3ba5bb62ec52b7b6016dcd83eafaac42817124a9');
const verificationFiles = [], rootReports = [];
for (const side of ['A', 'B', 'ROOT']) {
  for (const round of [1, 2, 3]) {
    const name = `${side}-verification-${round}.json`, report = await json(name);
    assert.equal(report.side, side); assert.equal(report.round, round);
    assert.deepEqual(report.whole, anchor.whole);
    assert.equal(report.whole.sha256, sha(JSON.stringify(report.whole.rows)));
    assert.deepEqual(report.sourceAfter, side === 'A' ? frozenA : frozenB);
    for (const key of ['critical', 'chunks', 'budget', 'graph', 'ocr']) assert.deepEqual(report[key], anchor[key]);
    const selected = report.whole.rows.filter(row => row.path === 'js/app-chunks.json' || row.path === 'js/app-shell.js' || row.path.startsWith('js/chunks/'));
    assert.equal(selected.length, 17);
    const retained = await inventory(resolve(qualification, `${side}-app-${round}`));
    assert.deepEqual(retained.rows, selected);
    verificationFiles.push(name); if (side === 'ROOT') rootReports.push(report);
  }
  assert.deepEqual(await inventory(resolve(side === 'ROOT' ? root : resolve(qualification, side), 'site')), anchor.whole);
}
assert.deepEqual(qa.root.builds, rootReports);
assert.equal(anchor.graph.literalImportClosureVerified, true); assert.equal(anchor.graph.staticBindingsVerified, true);
assert.equal(anchor.graph.chunkCount, 16); assert.equal(anchor.graph.staticEdgeCount, 18);
assert.equal(anchor.graph.dynamicEdgeCount, 10); assert.equal(anchor.graph.actualColdChunkCount, 6);
assert.deepEqual(anchor.ocr, { assetCount: 23, totalBytes: 88196906 });

const commands = {};
for (const label of ['install-clean', 'policy-before', 'policy-after', 'esbuild-approved', 'unit-full', 'syntax-full',
  'e2e-full', 'build-1', 'build-2', 'build-3', 'graph-native', 'bindings-native', 'ocr-assets']) {
  const record = await json(`ROOT-${label}.json`);
  assert.equal(record.side, 'ROOT'); assert.equal(record.cwd, root); assert.equal(record.status, 0);
  assert.equal(record.error, null); assert.equal(record.signal, null); assert.equal(record.node, 'v24.14.0');
  commands[label] = record;
}
assert.ok(commands['install-clean'].args.includes('ci') && commands['install-clean'].args.includes('--ignore-scripts'));
for (const label of ['policy-before', 'policy-after']) assert.match(commands[label].stdout, /Reviewed 5 locked install scripts/);
const unit = commands['unit-full'], syntax = commands['syntax-full'], e2e = commands['e2e-full'];
for (const pattern of [/tests 1224/, /pass 1221/, /fail 0/, /skipped 3/]) assert.match(unit.stdout, pattern);
assert.match(syntax.stdout, /Syntax checked 212/); assert.match(e2e.stdout, /33 passed/);
assert.deepEqual(qa.root.unit, { total: 1224, pass: 1221, fail: 0, skipped: 3, durationMs: Number(unit.stdout.match(/duration_ms ([0-9.]+)/)[1]) });
assert.equal(qa.root.syntaxFiles, 212); assert.match(qa.root.e2eSummary, /33 passed/);
assert.deepEqual(JSON.parse(commands['graph-native'].stdout), anchor.graph);
assert.equal(JSON.parse(commands['bindings-native'].stdout).staticBindingsVerified, true);
assert.match(commands['ocr-assets'].stdout, /Verified 23 OCR assets \(88196906 bytes\)/);
const budget = await json('ROOT-budget-native.json');
assert.equal(budget.status, 1); assert.deepEqual(JSON.parse(budget.stdout), anchor.budget);
assert.equal(anchor.budget.verdict, 'FAIL'); assert.equal(anchor.budget.coldPass, true); assert.equal(anchor.budget.allPass, false);
assert.equal(anchor.budget.actualColdStartGzipBytes, 44699); assert.equal(anchor.budget.actualAllNonOcrGzipBytes, 84187);
assert.equal(anchor.budget.coldBudgetBytes, 52241); assert.equal(anchor.budget.allBudgetBytes, 77227.7);

const auditFiles = (await readdir(qualification)).filter(name => /^ROOT-audit.*\.json$/.test(name)).sort();
assert.deepEqual(auditFiles, ['ROOT-audit-bounded-repeat.json', 'ROOT-audit-full.json']);
const auditFirst = await json('ROOT-audit-full.json'), auditRepeat = await json('ROOT-audit-bounded-repeat.json');
for (const record of [auditFirst, auditRepeat]) {
  assert.equal(record.status, 1); assert.equal(record.side, 'ROOT'); assert.equal(record.cwd, root);
  assert.ok(record.args.includes('--json')); assert.ok(!record.args.some(arg => arg.startsWith('--omit')));
}
assert.equal(JSON.parse(auditFirst.stdout).statusCode, 503);
assert.match(JSON.parse(auditRepeat.stdout).message, /network timeout/);
assert.deepEqual(qa.root.audit.attempts.map(row => row.nativeExit), [1, 1]);
const isolatedAudit = await json('B-audit-bounded-repeat.json');
assert.equal(isolatedAudit.status, 0); assert.equal(JSON.parse(isolatedAudit.stdout).metadata.vulnerabilities.total, 0);

assert.notEqual(await realpath(resolve(root, 'node_modules')), await realpath(resolve(qualification, 'B/node_modules')));
const manifestNative = path => path.endsWith('/package.json') || path === 'package.json' || path === '.package-lock.json'
  || /\.(?:node|exe|dll|so|dylib)$/i.test(path) || path === 'esbuild/bin/esbuild';
const rootInstalled = await inventory(resolve(root, 'node_modules'), manifestNative);
const bInstalled = await inventory(resolve(qualification, 'B/node_modules'), manifestNative);
assert.deepEqual(rootInstalled, bInstalled);
const installed = {};
for (const [name, version] of Object.entries({ ...rootPackage.dependencies, ...rootPackage.devDependencies })) {
  const manifest = await readJson(resolve(root, 'node_modules', name, 'package.json'));
  assert.equal(manifest.version, version); installed[name] = manifest.version;
}
for (const name of ['rolldown', '@rolldown/binding-win32-x64-msvc', 'lightningcss-win32-x64-msvc', '@esbuild/win32-x64']) {
  const manifest = await readJson(resolve(root, 'node_modules', name, 'package.json'));
  assert.equal(manifest.version, rootLock.packages['node_modules/' + name].version); installed[name] = manifest.version;
}
const bundled = await readFile(resolve(root, 'node_modules/vite/dist/node/chunks/node.js'), 'utf8');
assert.match(bundled, /launch-editor@2\.14\.2/); assert.doesNotMatch(bundled, /launch-editor@2\.14\.1/);
const nativeRows = rootInstalled.rows.filter(row => /\.(?:node|exe|dll|so|dylib)$/i.test(row.path) || row.path === 'esbuild/bin/esbuild');
const evidenceHashes = {};
for (const name of ['PROTOCOL.md', 'snapshot.json', 'B-source-frozen.json', 'qa-summary.json', ...verificationFiles,
  ...auditFiles, 'B-audit-bounded-repeat.json', 'ROOT-budget-native.json', 'ROOT-unit-full.json', 'ROOT-syntax-full.json', 'ROOT-e2e-full.json']) {
  evidenceHashes[name] = sha(await readFile(resolve(qualification, name)));
}
console.log(JSON.stringify({ verdict: 'ROOT_APPLIED_BEHAVIOR_AND_BYTE_IDENTITY_PASS_AUDIT_INCOMPLETE_M3_FAIL',
  checkedAt: new Date().toISOString(), root, qualification, rootQualificationComplete: false,
  rootAudit: { status: 'UNKNOWN_REMOTE_SERVICE', attempts: [{ file: 'ROOT-audit-full.json', nativeExit: 1, reason: 'HTTP_503' },
    { file: 'ROOT-audit-bounded-repeat.json', nativeExit: 1, reason: 'NETWORK_TIMEOUT' }], attemptLimitReached: true, noReviewerRetry: true,
    isolatedBAuditTotal: 0, isolatedResultTransferredToRoot: false },
  exactJsonChanges: changes, otherLockedPackageEntries: Object.keys(rootLock.packages).length - 2, otherLockChanges,
  root270InputsEqualBFrozen: true, sourceInventorySha256: frozenB.sha256, sourceBytes: frozenB.bytes,
  protectedPathsUnchangedFromHEADAndFrozenInput: protectedPaths,
  whole: { count: anchor.whole.count, bytes: anchor.whole.bytes, sha256: anchor.whole.sha256,
    rootRoundsEqual: 3, allIsolatedRoundsEqual: 6, actualRootABInventoriesEqual: true, retainedAppFilesPerRound: 17 },
  qa: { unit: qa.root.unit, syntaxFiles: 212, e2e: qa.root.e2eSummary,
    skipLines: unit.stdout.split('\n').filter(line => /# SKIP/.test(line)), logNativeExits: Object.fromEntries(Object.entries(commands).map(([key, value]) => [key, value.status])) },
  installed: { declaredAndRelevantNativePackageVersions: installed, manifestsAndNativeInventory: { count: rootInstalled.count,
    bytes: rootInstalled.bytes, sha256: rootInstalled.sha256 }, nativeRows, separateNodeModulesDirectories: true,
    bundledEditor: '2.14.2', officialViteIntegrity: official.dist.integrity, metadataSha256: sha(metadataBytes) },
  graph: anchor.graph, ocr: anchor.ocr, budget: { nativeExit: 1, ...anchor.budget, minimumIntegerReductionBytes: 6960 },
  stage: 'M3_IN_PROGRESS', relativeLatencyQualified: false, newCi: false, pushed: false, deployed: false,
  limitations: ['No install/test/build/audit executed by reviewer.', 'Root audit remains incomplete after HTTP 503 and sole bounded timeout repeat.',
    'Input freeze covers 270 copied files including historical dot-directory artifacts; not the separate 230-selected-input scope.',
    'Byte identity is not measured runtime latency; old-lock M3 paired evidence is not inherited.'], evidenceHashes }, null, 2));
