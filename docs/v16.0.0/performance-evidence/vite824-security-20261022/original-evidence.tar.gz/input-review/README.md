# Independent read-only input-boundary review

Command: `node C:\Users\84046\AppData\Local\Temp\fundval-vite824-independent-review-20261022-0842e02c\review.mjs`

Native exit: 0. Result: PASS_INPUT_BOUNDARY_ONLY, checked at 2026-10-22T02:58:58.344Z.

Read PROTOCOL.md and snapshot.json/snapshot.mjs in the qualification directory; did not execute snapshot.mjs because it writes A/B. Independently recomputed snapshot inventory metadata/hash, recursively compared A/B JSON with key-presence checks, verified all 270 copied input file hashes against the snapshot and current root, and checked for extra A/B input files while excluding changing node_modules/site/.git.

Only the five declared JSON leaf paths differ. All 107 other lock package entries are identical; A remains Vite 8.2.2, B is exact 8.2.4. Candidate version, resolved URL, integrity, engines, dependencies, optional dependencies and peer dependencies match the saved official npm metadata. Root remains byte-identical to the input snapshot. Detailed paths, hashes and expected B differences are in review-result.json.

Scope caveat: the full 270-file, 214,510,943-byte copy contains 24 historical .codex-tmp files totaling 202,403,286 bytes. The snapshot implementation excludes root-level site/Temp but not nested historical .codex-tmp/.../site outputs. These historical artifacts are present identically on both sides, not extra unlisted changes. Keep full-copy scope distinct from the separately selected 230-input scope; A anchor/output verification remains necessary. This is a reporting/scope caveat, not a five-path difference violation.

Adoption boundary: after the entire predeclared independent installation/audit/behavior/build-byte-identity qualification passes, only package.json and package-lock.json with these five scalar changes may be considered for root adoption. Do not copy node_modules, generated site, snapshots, or historical artifacts into root. This input review does not grant adoption, security-audit PASS, M3 performance PASS or release authority. Node/npm, other locked packages, lifecycle policy, five build groups, es2022, OXC and budgets remain unchanged.

No A/B or root files were edited. No install, test or build was executed by this reviewer. Only this separate review evidence directory was created.
