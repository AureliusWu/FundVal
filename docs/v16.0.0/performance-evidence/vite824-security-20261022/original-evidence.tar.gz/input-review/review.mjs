import assert from 'node:assert/strict';
import { readFile, readdir, lstat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, isAbsolute } from 'node:path';

const qualification = 'C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a';
const root = 'D:/AI项目/FundVal';
const metadataPath = resolve(root, 'docs/v16.0.0/performance-evidence/execution-skips-20261022/security-triage/registry-metadata.json');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const parse = async path => JSON.parse(await readFile(path, 'utf8'));
const snapshot = await parse(resolve(qualification, 'snapshot.json'));
const protocol = await readFile(resolve(qualification, 'PROTOCOL.md'));
const metadataBytes = await readFile(metadataPath);
const metadata = JSON.parse(metadataBytes);
const official = metadata.versions.find(row => row.version === '8.2.4');
assert.ok(official);
assert.equal(snapshot.schema, 1);
assert.equal(snapshot.root, root);
assert.equal(snapshot.files, snapshot.rows.length);
assert.equal(snapshot.bytes, snapshot.rows.reduce((sum, row) => sum + row.bytes, 0));
assert.equal(snapshot.sha256, hash(JSON.stringify(snapshot.rows)));
assert.equal(new Set(snapshot.rows.map(row => row.path)).size, snapshot.rows.length);

function diff(a, b, path = []) {
  if (Object.is(a, b)) return [];
  if (a && b && typeof a === 'object' && typeof b === 'object' && Array.isArray(a) === Array.isArray(b)) {
    const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])].sort();
    return keys.flatMap(key => !Object.hasOwn(a, key) || !Object.hasOwn(b, key)
      ? [{ path: [...path, key], a: a[key], b: b[key], missing: !Object.hasOwn(a, key) ? 'A' : 'B' }]
      : diff(a[key], b[key], [...path, key]));
  }
  return [{ path, a, b }];
}

const aPackage = await parse(resolve(qualification, 'A/package.json'));
const bPackage = await parse(resolve(qualification, 'B/package.json'));
const aLock = await parse(resolve(qualification, 'A/package-lock.json'));
const bLock = await parse(resolve(qualification, 'B/package-lock.json'));
const changes = [...diff(aPackage, bPackage).map(row => ({ file: 'package.json', ...row })),
  ...diff(aLock, bLock).map(row => ({ file: 'package-lock.json', ...row }))];
const allowed = [
  ['package.json', ['devDependencies', 'vite']],
  ['package-lock.json', ['packages', '', 'devDependencies', 'vite']],
  ['package-lock.json', ['packages', 'node_modules/vite', 'version']],
  ['package-lock.json', ['packages', 'node_modules/vite', 'resolved']],
  ['package-lock.json', ['packages', 'node_modules/vite', 'integrity']],
];
assert.equal(changes.length, 5);
assert.deepEqual(changes.map(row => JSON.stringify([row.file, row.path])).sort(), allowed.map(row => JSON.stringify(row)).sort());
assert.equal(aPackage.devDependencies.vite, '8.2.2');
assert.equal(aLock.packages[''].devDependencies.vite, '8.2.2');
assert.equal(aLock.packages['node_modules/vite'].version, '8.2.2');
assert.equal(bPackage.devDependencies.vite, official.version);
assert.equal(bLock.packages[''].devDependencies.vite, official.version);
assert.equal(bLock.packages['node_modules/vite'].version, official.version);
assert.equal(bLock.packages['node_modules/vite'].resolved, official.dist.tarball);
assert.equal(bLock.packages['node_modules/vite'].integrity, official.dist.integrity);
for (const field of ['engines', 'dependencies', 'optionalDependencies', 'peerDependencies']) {
  assert.deepEqual(bLock.packages['node_modules/vite'][field], official[field]);
}
const otherLockChanges = Object.keys(aLock.packages).filter(key => !['', 'node_modules/vite'].includes(key))
  .filter(key => diff(aLock.packages[key], bLock.packages[key]).length);
assert.deepEqual(otherLockChanges, []);

const mismatches = { A: [], B: [], root: [] }, hashes = { A: {}, B: {}, root: {} };
for (const row of snapshot.rows) {
  assert.ok(!isAbsolute(row.path) && !row.path.split('/').includes('..'));
  for (const side of ['A', 'B', 'root']) {
    const path = resolve(side === 'root' ? root : resolve(qualification, side), row.path);
    const status = await lstat(path);
    assert.equal(status.isSymbolicLink(), false);
    assert.equal(status.isFile(), true);
    const bytes = await readFile(path), digest = hash(bytes);
    if (['package.json', 'package-lock.json'].includes(row.path)) hashes[side][row.path] = digest;
    if (bytes.length !== row.bytes || digest !== row.sha256) mismatches[side].push({ path: row.path, bytes: bytes.length, sha256: digest });
  }
}
assert.deepEqual(mismatches.A, []);
assert.deepEqual(mismatches.root, []);
assert.deepEqual(mismatches.B.map(row => row.path).sort(), ['package-lock.json', 'package.json']);
const expectedPaths = snapshot.rows.map(row => row.path).sort();
const extraPaths = {};
for (const side of ['A', 'B']) {
  const paths = [];
  async function visit(prefix = '') {
    for (const item of await readdir(resolve(qualification, side, prefix), { withFileTypes: true })) {
      if (!prefix && ['node_modules', 'site', '.git'].includes(item.name)) continue;
      const path = prefix ? prefix + '/' + item.name : item.name;
      assert.equal(item.isSymbolicLink(), false);
      if (item.isDirectory()) await visit(path);
      else { assert.equal(item.isFile(), true); paths.push(path); }
    }
  }
  await visit();
  extraPaths[side] = paths.filter(path => !expectedPaths.includes(path));
  assert.deepEqual(paths.sort(), expectedPaths);
}
const historicalArtifacts = snapshot.rows.filter(row => row.path.startsWith('.codex-tmp/'));
console.log(JSON.stringify({ verdict: 'PASS_INPUT_BOUNDARY_ONLY', checkedAt: new Date().toISOString(), qualification,
  protocolSha256: hash(protocol), snapshotInventorySha256: snapshot.sha256, snapshotFiles: snapshot.files,
  snapshotBytes: snapshot.bytes, exactJsonChanges: changes, otherLockedPackageEntries: Object.keys(aLock.packages).length - 2,
  otherLockChanges, metadataCheckedAt: metadata.checked_at, metadataSha256: hash(metadataBytes), officialIntegrity: official.dist.integrity,
  snapshotMismatches: mismatches, extraPaths, hashes,
  scopeCaveat: { historicalDotCodexTmpFiles: historicalArtifacts.length, historicalDotCodexTmpBytes: historicalArtifacts.reduce((sum, row) => sum + row.bytes, 0) },
  limits: 'No install/build/test executed; node_modules/site ignored while installation proceeds. Input boundary alone does not authorize root adoption.' }, null, 2));
