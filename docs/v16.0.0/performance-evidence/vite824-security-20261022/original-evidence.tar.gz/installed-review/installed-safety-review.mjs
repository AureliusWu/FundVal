import { readFile, lstat } from 'node:fs/promises';
import { resolve, relative } from 'node:path';
import { createHash } from 'node:crypto';

const qualification = 'C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a';
const root = 'D:/AI项目/FundVal';
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const snapshot = await json(resolve(qualification, 'snapshot.json'));
const rootFiles = [], differences = [];
for (const row of snapshot.rows) {
  const path = resolve(root, row.path);
  if (relative(root, path).startsWith('..')) throw new Error('Out-of-root snapshot entry');
  try {
    const bytes = await readFile(path);
    const actual = { path: row.path, bytes: bytes.length, sha256: sha(bytes) };
    rootFiles.push(actual);
    if (actual.bytes !== row.bytes || actual.sha256 !== row.sha256) differences.push({ expected: row, actual });
  } catch (error) { differences.push({ path: row.path, error: error.code }); }
}
const versions = {}, directories = [];
for (const side of ['A', 'B']) {
  const vite = await json(resolve(qualification, side, 'node_modules/vite/package.json'));
  const rolldown = await json(resolve(qualification, side, 'node_modules/rolldown/package.json'));
  const esbuild = await json(resolve(qualification, side, 'node_modules/esbuild/package.json'));
  const chunkPath = resolve(qualification, side, 'node_modules/vite/dist/node/chunks/node.js');
  const chunk = await readFile(chunkPath, 'utf8');
  const lines = chunk.split(/\r?\n/);
  const matchingLines = lines.flatMap((line, index) => /launch-editor(?:-middleware)?@2\.14\.[12]|Cannot launch an editor with an argument|UNC paths are not supported|launchCommand = constructWindowsLaunchCommand|function constructWindowsLaunchCommand/.test(line)
    ? [{ line: index + 1, source: line }] : []);
  versions[side] = { vite: vite.version, rolldown: rolldown.version, esbuild: esbuild.version,
    middlewareDeclaredInVite: vite.devDependencies['launch-editor-middleware'],
    chunkSha256: sha(Buffer.from(chunk)), matchingLines };
  for (const name of ['node_modules', 'site']) {
    const path = resolve(qualification, side, name), stat = await lstat(path);
    directories.push({ side, name, path, directory: stat.isDirectory(), symbolicLink: stat.isSymbolicLink() });
  }
}
const firstAudit = await json(resolve(qualification, 'B-audit-full.json'));
const repeatedAudit = await json(resolve(qualification, 'B-audit-bounded-repeat.json'));
const firstBody = JSON.parse(firstAudit.stdout), repeatedBody = JSON.parse(repeatedAudit.stdout);
const policies = [];
for (const side of ['A', 'B']) for (const label of ['policy-before', 'install-clean', 'esbuild-approved', 'policy-after']) {
  const record = await json(resolve(qualification, `${side}-${label}.json`));
  policies.push({ side, label, status: record.status, args: record.args, stdout: record.stdout, stderr: record.stderr });
}
console.log(JSON.stringify({ schema: 1, capturedAt: new Date().toISOString(), scope: 'read-only installed-package and bundled-code evidence; no package execution, tests, builds, installs or writes to A/B/root',
  versions, directories, policies,
  audit: { first: { status: firstAudit.status, classification: 'UNKNOWN_NETWORK_TIMEOUT', args: firstAudit.args, body: firstBody },
    boundedRepeat: { status: repeatedAudit.status, args: repeatedAudit.args, body: repeatedBody,
      includesDev: !repeatedAudit.args.some(arg => arg === '--omit=dev' || arg === '--production'),
      noAdvisories: Object.keys(repeatedBody.vulnerabilities).length === 0 && repeatedBody.metadata.vulnerabilities.total === 0 } },
  rootSource: { expectedFiles: snapshot.files, matchedFiles: rootFiles.length - differences.length, frozenInventorySha256: snapshot.sha256,
    actualInventorySha256: sha(JSON.stringify(rootFiles)), differences,
    packageSha256: sha(await readFile(resolve(root, 'package.json'))), lockSha256: sha(await readFile(resolve(root, 'package-lock.json'))) },
  boundaries: ['Installed versions and bundled guards are source evidence, not an exploit test or universal security proof.',
    'Vite editor launch remains a development-server capability using configured local editor commands; do not treat patched guards or audit zero as permission to expose a dev server publicly.',
    'npm audit zero covers the registry advisory response for this installed dependency graph at the recorded time; first timeout stays UNKNOWN.',
    'Adoption still requires the predeclared independent source/lock, complete behavior and three-per-side all-file artifact identity gates.',
    'No browser latency, M3 all-budget pass, release, push or deployment is established by this review.'] }, null, 2));
