# Installed toolchain and local security-boundary review

Verdict: PASS for the installed-toolchain, isolation, bundled-fix-code and captured-audit evidence layer. This is not standalone approval to adopt the candidate: the complete predeclared behavior and three-per-side all-file artifact identity gates remain required.

## Scope and method

Read only the existing qualification at `C:\Users\84046\AppData\Local\Temp\fundval-vite824-qualification-20261022-0d5350fa5e31a`. No tests, builds, installs, application/package execution, network requests or writes to A/B/root were performed. The only executed JavaScript was the independent `installed-safety-review.mjs` evidence reader, which imports Node built-ins and performs file reads/hashing only. It prints `installed-safety-review.json`; stderr is separately retained.

## Confirmed facts

- Actual installed A Vite 8.2.2; B Vite 8.2.4. Both actual rolldown 1.2.5 and esbuild 0.28.2.
- B's installed Vite chunk contains explicit `launch-editor@2.14.2` and `launch-editor-middleware@2.14.2` region provenance. A's corresponding bundled versions are 2.14.1. These are bundled components, not standalone installed package roots or separate lock entries.
- B's actual `dist/node/chunks/node.js:11454` rejects arguments containing line breaks, line 11455 rejects `%`, and line 11525 rejects Windows UNC paths. The validated constructor is called before Windows `child_process.exec` at lines 11535-11545. A's old branch directly constructs its shell command without these two new argument checks (A lines 11365-11379).
- B Vite package metadata declares launch-editor-middleware `^2.14.2`; A declares `^2.14.1`. This metadata and executable-source provenance agree, but are not an exploit test.
- A/B node_modules and site are independent plain directories with no top-level symbolic-link target. Package/native binary comparison was delegated to a read-only scanner; its result is summarized below and retained in its separate evidence directory.
- Both npm clean-install records use `--ignore-scripts` and exit 0; pre/post policy records both retain the five locked lifecycle-script allowlist; explicit approved esbuild installer records exit 0. These records were inspected, not rerun.
- B audit-full's original status 1 and endpoint network-timeout JSON remain UNKNOWN, not a zero-advisory result. The one captured bounded repeat exits 0, has a complete auditReportVersion 2 JSON body, vulnerabilities `{}`, all severity counts and total 0, dev dependencies 71, no omit-dev flag, and empty stderr. Both records remain intact.
- Root's 270 frozen copy-inventory files currently match every expected byte length and SHA256. Frozen and current inventory SHA256 both `82606e6a07d805379f68889304d04cb228b883599b68ad2b33f1539beaf1349a`; no differences. This full-copy scope includes historical `.codex-tmp` assets and is not the separately selected 230-input scope.
- Root package.json SHA256 remains `bec262a94cc4f0366b5ca1160090f0ea5156570e963761bca5ce5b326ae4ff8d`; package-lock.json remains `4a9441b3e294166d25ea1c304574afe2afa169b75087a6d31ae15a52dcbd7b85`. The root is still the pre-existing dirty working tree; no cleanup or reset was done.

## Independent installed-package comparison

The recursive scanner reports 57 installed package roots per side, plus six package.json files that only mark CJS/ESM subdirectories and have no package name/version. The sole actual installed name/version difference is Vite 8.2.2 versus 8.2.4. All other 56 installed package versions and package.json hashes match; installed versions have zero mismatches against their own locks. Both locks have 109 entries and only four scalar differences, plus the single package.json Vite scalar, exactly the five-field allowed patch. Native package versions and three binary/binding file hashes match between A/B. No extra installed nested package roots or recursive symlinks were found. Platform-specific optional packages not physically installed are represented by lock entries, not counted as installed packages.

Detailed delegated evidence: `C:\Users\84046\AppData\Local\Temp\fundval-installed-version-review-20261022-56c0cbac\RESULT.md` and sibling `installed-comparison.json`. It verifies zero actual-version mismatches against both main and hidden installed locks; the 51 absent lock dependencies are all platform-inapplicable optional packages on win32/x64, equal on A/B. Exact matching native hashes:

- `@esbuild/win32-x64/esbuild.exe`: `c7bee37877d0aa6a046e52783fa0a2cf1a9ce5579d68bb3083bda99d4bff18ef`.
- `@rolldown/binding-win32-x64-msvc/rolldown-binding.win32-x64-msvc.node`: `7d51fbe850cc06771ad2e85615d5e1a86b5e323b6f34d7a5aa2728e1a9f364b9`.
- `lightningcss-win32-x64-msvc/lightningcss.win32-x64-msvc.node`: `d043df0f0675e7fffed4cf8b8c33e28639ec9f21d445c21e7fe4985e4a9b5a91`.

## Adoption and safety boundaries

This layer supports continuing the candidate qualification. Final adoption still requires the protocol's A anchor reproduction, complete behavior gates, all three A/B whole-site identity checks, fixed source/lock/policy inventories and independent final review; root install/audit/test/check/build/E2E/artifact verification is separate after adoption. Do not inherit an old-lock performance pair or loosen its lock comparison.

The patched editor endpoint is still a Node development-server capability that launches a configured local editor and retains a Windows shell execution path; these guards and registry audit zero are not permission to expose a development server publicly, nor a universal security proof. The audit is time-specific registry advisory evidence, not proof of the absence of undisclosed issues.

No browser latency measurement, M3 all-budget PASS, app version bump, push, deployment or release is established by this review. Existing performance budgets and unresolved acceptance gates remain unchanged.
