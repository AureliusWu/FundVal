import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('OCR import runs in an isolated local-only document and remains confirmation-gated', async () => {
  const [app, page, localOcr, paddleOcr, paddleEntry, layout, plan, catalog, ledger, index, importPage, build, workflow, sw, transaction] = await Promise.all([
    readFile(new URL('../js/app.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/ocr-import-page.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/local-ocr.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/paddle-local-ocr.js', import.meta.url), 'utf8'),
    readFile(new URL('../scripts/paddle-ocr-entry.mjs', import.meta.url), 'utf8'),
    readFile(new URL('../js/ocr-table-layout.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/holding-import-plan.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/fund-catalog.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/ocr/performance-ledger.js', import.meta.url), 'utf8'),
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
    readFile(new URL('../ocr-import.html', import.meta.url), 'utf8'),
    readFile(new URL('../scripts/build-site.mjs', import.meta.url), 'utf8'),
    Promise.all(['ci.yml', 'deploy.yml'].map(name => readFile(new URL(`../.github/workflows/${name}`, import.meta.url), 'utf8'))).then(parts => parts.join('\n')),
    readFile(new URL('../sw.js', import.meta.url), 'utf8'),
    readFile(new URL('../js/ocr/import-transaction.js', import.meta.url), 'utf8'),
  ]);

  assert.match(app, /window\.location\.assign\('ocr-import\.html'\)/);
  assert.doesNotMatch(app, /^import .*local-ocr/m);
  assert.doesNotMatch(app, /ocr-import-page\.js/);
  assert.doesNotMatch(index, /ocr-image-input|ocr-import-modal|image\/png,image\/jpeg,image\/webp/);
  assert.doesNotMatch(index, /assets\/ocr|tesseract/i);
  assert.match(importPage, /src="js\/ocr-import-page\.js"/);
  assert.match(importPage, /href="css\/ocr\.css"/);
  assert.match(importPage, /accept="image\/png,image\/jpeg,image\/webp"/);
  assert.match(importPage, /Content-Security-Policy/);
  assert.match(importPage, /default-src 'none'; script-src 'self' 'wasm-unsafe-eval'/);
  assert.match(importPage, /worker-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'/);
  assert.doesNotMatch(importPage, /unsafe-inline/);
  assert.doesNotMatch(importPage, /bootstrap\.js|app\.js|https?:\/\/|preconnect/i);
  assert.match(page, /import\('\.\/paddle-local-ocr\.js'\)/);
  assert.match(page, /reconstructOcrTableLayout/);
  assert.match(page, /let activeRecognitionTask = null/);
  assert.match(page, /if \(!file \|\| activeRecognitionTask\) return/);
  assert.match(page, /setRecognitionControlsDisabled\(true\)/);
  assert.match(page, /finally \{\s*finishRecognitionTask\(task\)/);
  assert.match(page, /recordOcrPerformance\(performanceRun\)/);
  assert.ok(
    page.indexOf("recordPerformanceOnce('none')") < page.indexOf('const holdingsSnapshot = await currentHoldings()'),
    'successful OCR performance must be recorded before holdings integrity can fail'
  );
  assert.match(page, /recognition\.text = ''[\s\S]*recognition\.tokens = \[\]/);
  assert.match(page, /\['ocr-image-input', 'ocr-import-pick', 'ocr-import-retry', 'ocr-import-confirm'\]/);
  assert.match(paddleOcr, /assertPaddleOcrBrowserCapabilities\(runtime\)/);
  assert.match(paddleOcr, /Worker[\s\S]*createImageBitmap[\s\S]*OffscreenCanvas[\s\S]*WebAssembly[\s\S]*structuredClone/);
  assert.match(paddleOcr, /Android 请升级到最新版 Chrome/);
  assert.doesNotMatch(paddleOcr, /selectOcrBackend|OCR_BACKEND\.WEBGPU|OCR_BACKEND\.WASM/);
  assert.match(paddleEntry, /\[OCR_BACKEND\.WEBGPU\][\s\S]*backend:\s*OCR_BACKEND\.WEBGPU/);
  assert.match(paddleEntry, /\[OCR_BACKEND\.WASM\][\s\S]*backend:\s*OCR_BACKEND\.WASM/);
  assert.doesNotMatch(paddleEntry, /backend:\s*['"]auto['"]/);
  assert.match(paddleEntry, /webgpuAttempted:\s*diagnostics\.webgpuAttempted === true/);
  assert.match(paddleEntry, /PERFORMANCE_FALLBACK_REASONS\.has\(submittedReason\)/);
  assert.match(paddleEntry, /createEngine = options => new LocalOcrEngine\(options\)/);
  assert.equal((paddleEntry.match(/new LocalOcrEngine\(/g) || []).length, 1);
  assert.doesNotMatch(page, /sourceHint\s*:/);
  assert.doesNotMatch(page, /document\.createElement\(['"]script|https?:\/\/qt\.gtimg|https?:\/\/fund\.eastmoney/i);
  assert.match(page, /await commitConfirmedImport\(globalThis\.localStorage, rows, state\.baselineDocument/);
  assert.match(transaction, /saveLegacyHoldingsTransaction\(storage, result\.holdings/);
  assert.match(page, /loadHoldingsRepository\(globalThis\.localStorage, \{ cacheKey: CACHE_KEY \}\)/);
  assert.match(page, /baselineDocument:\s*holdingsSnapshot\.document/);
  assert.match(transaction, /expectedDocument:\s*loaded\.document/);
  assert.match(page, /holding_changed_elsewhere/);
  assert.match(page, /runStartupIntegrityChecks\(globalThis\.localStorage\)/);
  assert.match(page, /safeSetItem\(OCR_IMPORT_PENDING_KEY, '1'\)/);
  assert.ok(
    transaction.indexOf('beforeSave()') < transaction.indexOf('saveLegacyHoldingsTransaction(storage, result.holdings'),
    'the recoverable sync flag must be persisted before canonical holdings are changed'
  );
  assert.match(page, /if \(!transactionResult \|\| !\(transactionResult\.recoveryRequired \|\| transactionResult\.recovery_required\)\) \{\s*safeRemoveItem\(OCR_IMPORT_PENDING_KEY\)/);
  assert.match(page, /window\.location\.replace\('\.\/\?ocr_import=1'\)/);
  assert.match(app, /consumeOcrImportReturn/);
  assert.match(app, /safeGetItem\(OCR_IMPORT_PENDING_KEY\) === '1'/);
  assert.match(localOcr, /new URL\('\.\.\/assets\/ocr\/tesseract\/worker\.min\.js', import\.meta\.url\)/);
  assert.match(localOcr, /workerBlobURL:\s*false/);
  assert.match(localOcr, /cacheMethod:\s*'none'/);
  assert.doesNotMatch(localOcr, /https?:\/\/|data:image|fetch\(/i);
  assert.match(paddleOcr, /paddle-ocr-engine\.mjs/);
  assert.match(paddleOcr, /PP-OCRv6_tiny_det_onnx_infer\.tar/);
  assert.match(paddleOcr, /numThreads:\s*1/);
  assert.match(paddleOcr, /normalizeOcrBackend\(input\.backend, 'none'\)/);
  assert.match(paddleOcr, /performance:\s*failurePerformance/);
  assert.match(paddleOcr, /webgpuAttempted:\s*input\.webgpuAttempted === true/);
  assert.match(page, /target\.capabilityClass = source\.capabilityClass/);
  assert.match(page, /target\.webgpuAttempted = source\.webgpuAttempted/);
  assert.match(page, /if \(typeof source\.fallback === 'boolean'\)[\s\S]*target\.fallback = source\.fallback/);
  assert.match(page, /target\.fallbackReason = source\.fallback/);
  assert.doesNotMatch(page, /target\.fallback = source\.fallback === true/);
  assert.doesNotMatch(paddleOcr, /https?:\/\/|data:image|fetch\(|localStorage|indexedDB/i);
  assert.doesNotMatch(layout, /fetch\(|localStorage|indexedDB|document\./i);
  assert.match(ledger, /PERFORMANCE_NUMERIC_FIELDS|INTEGER_FIELDS/);
  assert.match(ledger, /consistency:\s*'consistent'/);
  assert.match(ledger, /inconsistentRuns/);
  assert.doesNotMatch(ledger, /ocrText|imageBase64|localPath|fileName|fundName|holdingAmount/);
  assert.match(catalog, /FUND_CATALOG_PATH/);
  assert.match(catalog, /credentials:\s*'same-origin'/);
  assert.doesNotMatch(catalog, /https?:\/\/|document\.createElement\(['"]script|base64|localStorage|indexedDB/i);
  assert.doesNotMatch(catalog, /\b(?:File|Blob)\b/);
  assert.match(plan, /number != null && number > 0/);
  assert.match(plan, /row\.action === 'skip'/);
  assert.match(importPage, /确认并同步/);
  assert.match(importPage, /GitHub Gist/);
  assert.match(build, /tesseract\.esm\.min\.js/);
  assert.match(build, /chi_sim\.traineddata\.gz/);
  assert.match(build, /onnxruntime-web-MIT\.txt/);
  assert.match(build, /clipper-lib-BSL-1\.0\.txt/);
  assert.match(build, /chi_sim-MIT\.txt/);
  assert.match(build, /ocr-import\.html/);
  assert.match(build, /buildPaddleOcrAssets/);
  assert.match(workflow, /npm run build/);
  assert.match(workflow, /site\/assets\/ocr\/tessdata\/chi_sim\.traineddata\.gz/);
  assert.match(workflow, /site\/assets\/ocr\/paddle\/engine\/paddle-ocr-engine\.mjs/);
  assert.match(workflow, /PP-OCRv6_tiny_det_onnx_infer\.tar/);
  assert.match(workflow, /Verify Pages publishing mode/);
  assert.match(workflow, /\.build_type['"]?\)" = workflow/);
  assert.match(workflow, /Smoke-test deployed OCR assets/);
  assert.match(workflow, /engine\/assets\/fundval-paddle-worker\.js/);
  assert.match(workflow, /ort-wasm-simd-threaded\.jsep\.wasm/);
  assert.match(workflow, /--retry 12 --retry-all-errors --retry-delay 5/);
  const core = sw.slice(sw.indexOf('const CORE'), sw.indexOf('self.addEventListener'));
  assert.doesNotMatch(core, /assets\/ocr/);
  assert.match(sw, /url\.pathname\.includes\('\/assets\/ocr\/'\)[\s\S]*networkOnly\(event\.request\)/);
});

test('layout-only performance cannot erase an already observed OCR backend fallback', async () => {
  const page = await readFile(new URL('../js/ocr-import-page.js', import.meta.url), 'utf8');
  const start = page.indexOf('function mergeRecognitionPerformance(target, source)');
  const end = page.indexOf('\n}\n\nfunction element', start);
  assert.ok(start >= 0 && end > start, 'performance merge helper must remain extractable');
  const merge = new Function(
    'PERFORMANCE_NUMERIC_FIELDS',
    `${page.slice(start, end + 2)}; return mergeRecognitionPerformance;`
  )(['layoutMs', 'parseMs']);
  const target = {
    capabilityClass: 'unknown', backend: 'none', webgpuAttempted: false,
    fallback: false, fallbackReason: 'none', layoutMs: 0, parseMs: 0,
  };
  merge(target, {
    capabilityClass: 'webgpu', backend: 'wasm', webgpuAttempted: true,
    fallback: true, fallbackReason: 'initialization_failed',
  });
  merge(target, { layoutMs: 123, parseMs: 4 });
  assert.deepEqual(target, {
    capabilityClass: 'webgpu', backend: 'wasm', webgpuAttempted: true,
    fallback: true, fallbackReason: 'initialization_failed', layoutMs: 123, parseMs: 4,
  });
});
