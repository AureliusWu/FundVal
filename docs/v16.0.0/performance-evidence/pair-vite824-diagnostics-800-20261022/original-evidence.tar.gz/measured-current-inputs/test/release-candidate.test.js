import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, readFile, writeFile, rm, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { gzipSync } from 'node:zlib';
import { createCandidate, inventorySite, validateCandidateManifest, verifyAndExtractCandidate } from '../scripts/release-candidate.mjs';
import { fingerprintReleaseDirectory, RELEASE_CRITICAL_PATHS } from '../scripts/release-fingerprint.mjs';
import { validateCandidateRun } from '../scripts/resolve-release-candidate.mjs';
import { validateInstallPolicy } from '../scripts/dependency-install-policy.mjs';

const origin = { repository: 'AureliusWu/FundVal', sha: 'a'.repeat(40), runId: '123', attempt: '1' };
const verifiedRun = {
  id: 123, workflow_id: 88, path: '.github/workflows/ci.yml',
  repository: { full_name: origin.repository }, head_repository: { full_name: origin.repository },
  event: 'push', head_branch: 'main', head_sha: origin.sha, status: 'completed', conclusion: 'success', run_attempt: 1,
};

async function writeReleaseFixture(site, { oversized = false } = {}) {
  for (const path of RELEASE_CRITICAL_PATHS) {
    await mkdir(dirname(join(site, path)), { recursive: true });
    await writeFile(join(site, path), `synthetic:${path}\n`);
  }
  const lazy = Buffer.alloc(oversized ? 90_000 : 16);
  for (let offset = 0; offset < lazy.length; offset += 32) {
    createHash('sha256').update(`synthetic-fixture-${offset}`).digest().copy(lazy, offset);
  }
  const definitions = [
    ['js/app-shell.js', 'cold', Buffer.from('export const synthetic = true;\n')],
    ['js/chunks/feature-fixture.js', 'lazy', lazy],
  ];
  for (const [path, , bytes] of definitions) {
    await mkdir(dirname(join(site, path)), { recursive: true });
    await writeFile(join(site, path), bytes);
  }
  await writeFile(join(site, 'js/app-chunks.json'), JSON.stringify({
    schema: 1, entry: 'js/app-shell.js', coldStart: ['js/app-shell.js'], lazy: ['js/chunks/feature-fixture.js'],
    chunks: definitions.map(([path, role, bytes]) => ({ path, role, bytes: bytes.length,
      gzipBytes: gzipSync(bytes).length, sha256: createHash('sha256').update(bytes).digest('hex') })),
  }));
  return fingerprintReleaseDirectory(site);
}

test('candidate provenance rejects failed, fork, PR, branch, mismatched SHA and unrelated workflow runs', () => {
  const expected = { ...origin, workflowId: 88 };
  assert.equal(validateCandidateRun(verifiedRun, expected).artifactName, `fundval-candidate-${origin.sha}-1`);
  assert.equal(validateCandidateRun({ ...verifiedRun, run_attempt: 2 }, expected).artifactName, `fundval-candidate-${origin.sha}-2`);
  for (const mutation of [
    { status: 'in_progress' }, { conclusion: 'failure' }, { event: 'pull_request' },
    { head_branch: 'feature/v16' }, { head_sha: 'b'.repeat(40) }, { id: 456 }, { workflow_id: 89 },
    { path: '.github/workflows/untrusted.yml' }, { run_attempt: 0 },
    { run_attempt: '1' }, { run_attempt: '1\nsha=injected' }, { run_attempt: Number.MAX_SAFE_INTEGER },
    { run_attempt: NaN }, { run_attempt: Infinity }, { run_attempt: 1.5 },
    { repository: { full_name: 'Other/FundVal' } }, { head_repository: { full_name: 'Fork/FundVal' } },
  ]) assert.throws(() => validateCandidateRun({ ...verifiedRun, ...mutation }, expected));
  assert.throws(() => validateCandidateRun(verifiedRun, { ...expected, sha: '$(echo invalid)' }));
});

test('candidate verifier consumes one archive snapshot through stdin for all tar operations', async () => {
  const source = await readFile(new URL('../scripts/release-candidate.mjs', import.meta.url), 'utf8');
  const verifier = source.slice(source.indexOf('export async function verifyAndExtractCandidate'), source.indexOf('\nasync function main'));
  assert.equal((verifier.match(/readBoundedRegularFile\(archive,/g) || []).length, 1);
  assert.match(verifier, /createHash\('sha256'\)\.update\(archiveBytes\)/);
  for (const mode of ['-tf', '-tvf', '-xf']) {
    assert.ok(verifier.includes(`['${mode}', '-']`) || verifier.includes(`['${mode}', '-', '-C', destination]`));
  }
  assert.equal((verifier.match(/input: archiveBytes/g) || []).length, 3);
  assert.doesNotMatch(verifier, /\['-\w+f', archive/);
});

test('candidate verifier rejects symlinked bundle files before parsing them', async t => {
  const directory = await mkdtemp(join(tmpdir(), 'fundval-symlink-'));
  try {
    await mkdir(join(directory, 'bundle'));
    await writeFile(join(directory, 'metadata.json'), '{}');
    try { await symlink(join(directory, 'metadata.json'), join(directory, 'bundle', 'candidate.json'), 'file'); }
    catch (error) {
      if (['EPERM', 'EACCES'].includes(error.code)) { t.skip('Windows account cannot create a test symlink.'); return; }
      throw error;
    }
    await assert.rejects(() => verifyAndExtractCandidate({ ...origin, bundle: join(directory, 'bundle'), output: join(directory, 'bad') }));
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('candidate packing and extraction preserve every byte and reject modified archive or provenance', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'fundval-candidate-'));
  try {
    const site = join(directory, 'site');
    await mkdir(join(site, 'js'), { recursive: true });
    await mkdir(join(site, '.playwright-results'), { recursive: true });
    await writeReleaseFixture(site);
    await writeFile(join(site, 'index.html'), '<html>synthetic</html>\r\n');
    await writeFile(join(site, 'js', 'app.js'), 'export const value = 0;\n');
    await writeFile(join(site, '.playwright-results', 'ignored.txt'), 'test output');
    const releaseFingerprint = await fingerprintReleaseDirectory(site);
    const output = join(directory, 'bundle');
    const manifest = await createCandidate({ ...origin, site, output, event: 'push', branch: 'main', releaseFingerprint });
    assert.ok(manifest.site.files.some(file => file.path === 'js/chunks/feature-fixture.js'));
    assert.equal(manifest.site.files.some(file => file.path.includes('playwright')), false);
    const extracted = join(directory, 'extracted');
    await verifyAndExtractCandidate({ ...origin, bundle: output, output: extracted });
    assert.deepEqual(await inventorySite(extracted), manifest.site);
    assert.deepEqual(await readFile(join(extracted, 'index.html')), await readFile(join(site, 'index.html')));
    assert.throws(() => validateCandidateManifest(manifest, { ...origin, sha: 'b'.repeat(40) }));
    assert.throws(() => validateCandidateManifest({ ...manifest, event: 'pull_request' }, origin));
    assert.throws(() => validateCandidateManifest({ ...manifest, branch: 'feature/v16' }, origin));
    assert.throws(() => validateCandidateManifest({ ...manifest, site: { ...manifest.site, fingerprint: 'd'.repeat(64) } }, origin));
    const traversal = structuredClone(manifest);
    traversal.site.files[0].path = '../escape.js';
    assert.throws(() => validateCandidateManifest(traversal, origin));
    const duplicate = structuredClone(manifest);
    duplicate.site.files.push(duplicate.site.files[0]);
    assert.throws(() => validateCandidateManifest(duplicate, origin));
    await assert.rejects(() => verifyAndExtractCandidate({ ...origin, bundle: output, output: extracted }), /empty directory/);
    await writeFile(join(output, 'site.tar'), 'tampered archive');
    await assert.rejects(() => verifyAndExtractCandidate({ ...origin, bundle: output, output: join(directory, 'bad') }), /checksum/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('standalone candidate admission rejects a real over-budget artifact even if archive and inventory match', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'fundval-budget-admission-'));
  try {
    const site = join(directory, 'site');
    const releaseFingerprint = await writeReleaseFixture(site, { oversized: true });
    const output = join(directory, 'bundle');
    const manifest = await createCandidate({ ...origin, site, output, event: 'push', branch: 'main', releaseFingerprint });
    assert.ok(manifest.site.totalBytes > 90_000, 'WIP packaging is allowed and retains all bytes.');
    await assert.rejects(() => verifyAndExtractCandidate({ ...origin, bundle: output, output: join(directory, 'extracted') }),
      /bundle.*budget|budget.*exceed/i);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('standalone candidate admission recomputes release-critical fingerprint rather than trusting its declaration', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'fundval-fingerprint-admission-'));
  try {
    const site = join(directory, 'site');
    await writeReleaseFixture(site);
    const output = join(directory, 'bundle');
    await createCandidate({ ...origin, site, output, event: 'push', branch: 'main', releaseFingerprint: 'c'.repeat(64) });
    await assert.rejects(() => verifyAndExtractCandidate({ ...origin, bundle: output, output: join(directory, 'extracted') }),
      /release fingerprint mismatch/i);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('review branch candidates keep their origin and cannot enter production verification', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'fundval-review-'));
  try {
    const site = join(directory, 'site');
    await mkdir(site);
    await writeFile(join(site, 'index.html'), 'synthetic');
    const manifest = await createCandidate({ ...origin, site, output: join(directory, 'bundle'), event: 'pull_request', branch: 'feature/v16', releaseFingerprint: 'c'.repeat(64) });
    assert.equal(manifest.event, 'pull_request');
    assert.equal(manifest.branch, 'feature/v16');
    assert.throws(() => validateCandidateManifest(manifest, origin), /provenance/);
    await assert.rejects(() => createCandidate({ ...origin, site, output: join(site, 'bad'), event: 'push', branch: 'main', releaseFingerprint: 'c'.repeat(64) }), /outside/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('install policy requires an exact reviewed set of lifecycle scripts with unchanged integrity', async () => {
  const lock = JSON.parse(await readFile(new URL('../package-lock.json', import.meta.url), 'utf8'));
  const policy = JSON.parse(await readFile(new URL('../.github/dependency-install-policy.json', import.meta.url), 'utf8'));
  assert.equal(validateInstallPolicy(lock, policy).length, 5);
  for (const key of ['version', 'integrity']) {
    const changed = structuredClone(lock);
    changed.packages['node_modules/esbuild'][key] = 'unreviewed';
    assert.throws(() => validateInstallPolicy(changed, policy), /Unreviewed/);
  }
  const injected = structuredClone(lock);
  injected.packages['node_modules/unknown'] = { hasInstallScript: true, version: '1.0.0' };
  assert.throws(() => validateInstallPolicy(injected, policy), /set changed/);
});
