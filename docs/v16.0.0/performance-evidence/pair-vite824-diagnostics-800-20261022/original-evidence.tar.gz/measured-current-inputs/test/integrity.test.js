import test from 'node:test';
import assert from 'node:assert/strict';
import {
  appendDiagnostic,
  collectOrphanNavCacheKeys,
  mergeHoldingsByTimestamp,
  normalizeOcrDiagnosticForDisplay,
  normalizeHoldings,
  reconcileFundCache,
  selectSafeDiagnosticEvents,
  repairHoldingsState
} from '../js/integrity.js';

const NOW = '2026-07-15T04:00:00.000Z';

test('normalizes holdings and keeps the newest duplicate', () => {
  const result = normalizeHoldings([
    { code: '000001', name: '旧', shares: -1, updated_at: '2026-01-01T00:00:00Z' },
    { code: '000001', name: '新', shares: 2, updated_at: '2026-07-01T00:00:00Z' },
    { code: 'bad' }
  ], NOW);
  assert.deepEqual(result, [{
    code: '000001', name: '新', shares: 2, cost: 0,
    updated_at: '2026-07-01T00:00:00.000Z', deleted: false
  }]);
});

test('prefers tombstone when duplicate timestamps are equal', () => {
  const result = normalizeHoldings([
    { code: '000001', updated_at: NOW, deleted: false },
    { code: '000001', updated_at: NOW, deleted: true }
  ], NOW);
  assert.equal(result[0].deleted, true);
});

test('merges cloud holdings without resurrecting an equal-time tombstone', () => {
  const result = mergeHoldingsByTimestamp([
    { code: '000001', name: '本地', shares: 2, updated_at: NOW, deleted: false },
    { code: '000002', name: '保留顺序', shares: 1, updated_at: NOW },
  ], [
    { code: '000001', name: '云端删除', shares: 2, updated_at: NOW, deleted: true },
    { code: '000003', name: '仅云端', shares: 3, updated_at: NOW },
  ], NOW);
  assert.deepEqual(result.map(item => item.code), ['000001', '000002', '000003']);
  assert.equal(result[0].deleted, true);
});

test('keeps semantically invalid primary holdings intact when no backup is available', () => {
  const primaryRaw = JSON.stringify([{ code: '000001', name: '不能归零', shares: 'bad', cost: 1 }]);
  const result = repairHoldingsState({ primaryRaw, latestBackupRaw: null, previousBackupRaw: null, nowISO: NOW });
  assert.equal(result.preservePrimary, true);
  assert.equal(result.changed, false);
  assert.equal(result.source, 'semantic_invalid');
  assert.equal(result.corruptRaw, primaryRaw);
});

test('recovers corrupt primary holdings from latest backup', () => {
  const result = repairHoldingsState({
    primaryRaw: '{broken',
    latestBackupRaw: JSON.stringify({ holdings: [{ code: '000001', name: '恢复' }] }),
    previousBackupRaw: null,
    nowISO: NOW
  });
  assert.equal(result.recovered, true);
  assert.equal(result.source, 'latest_backup');
  assert.equal(result.holdings[0].name, '恢复');
});

test('removes deleted or unrelated funds from the persisted cache', () => {
  const result = reconcileFundCache(JSON.stringify({
    data: [{ code: '000001' }, { code: '000002' }],
    fetchedAt: 1000,
    expiresAt: 2000
  }), new Set(['000002']), 1500);
  assert.equal(result.remove, false);
  assert.deepEqual(result.cache.data, [{ code: '000002' }]);
});

test('rejects cache timestamps implausibly far in the future', () => {
  const result = reconcileFundCache({ data: [{ code: '000001' }], fetchedAt: 9999999 }, ['000001'], 1000, 100);
  assert.equal(result.remove, true);
});

test('v16 duplicate cached funds fail closed rather than retaining an arbitrary first quote', () => {
  const result = reconcileFundCache({ data: [{ code: '000001', quote: { value: 1 } }, { code: '000001', quote: { value: 2 } }], fetchedAt: 1000 }, ['000001'], 1500);
  assert.equal(result.remove, true);
  assert.equal(result.cache, null);
});

test('finds only orphan per-fund cache keys', () => {
  assert.deepEqual(
    collectOrphanNavCacheKeys(['fuyu_nav_move_000001', 'fuyu_nav_move_000002', 'other'], ['000002']),
    ['fuyu_nav_move_000001']
  );
});

test('diagnostics redact tokens and local image data while retaining a bounded history', () => {
  const raw = JSON.stringify([{ time: NOW, type: 'old', message: 'old', stack: '' }]);
  const result = appendDiagnostic(raw, {
    type: 'error',
    message: 'ghp_abcdefghijklmnopqrstuvwxyz1234 data:image/png;base64,QUJDREVGR0g='
  }, 1);
  assert.equal(result.length, 1);
  assert.match(result[0].message, /REDACTED_GITHUB_TOKEN/);
  assert.match(result[0].message, /REDACTED_IMAGE_DATA/);
  assert.doesNotMatch(result[0].message, /QUJDREVGR0g/);
});

test('diagnostic summary treats persisted entries as untrusted and emits fixed safe enums only', () => {
  const token = 'ghp_abcdefghijklmnopqrstuvwxyz123456';
  const path = 'C:\\Users\\person\\secret.png';
  const events = selectSafeDiagnosticEvents([
    { time: NOW, type: 'window_error', message: token },
    { time: NOW, type: token },
  ]);
  assert.deepEqual(events.map(entry => entry.type), ['window_error', 'unknown']);
  assert.doesNotMatch(JSON.stringify(events), /ghp_|secret\.png/i);

  const ocr = normalizeOcrDiagnosticForDisplay({
    backend: token,
    errorCategory: path,
    fallback: true,
  });
  assert.deepEqual(ocr, {
    backend: 'unknown', errorCategory: 'unknown',
    fallback: true, fallbackReason: 'unknown', consistency: 'inconsistent',
  });
  assert.doesNotMatch(JSON.stringify(ocr), /ghp_|Users|secret\.png/i);
});

test('OCR diagnostic display exposes contradictory backend telemetry instead of presenting it as a clean run', () => {
  const ocr = normalizeOcrDiagnosticForDisplay({
    capabilityClass: 'webgpu', backend: 'wasm', webgpuAttempted: false,
    fallback: false, fallbackReason: 'none', consistency: 'inconsistent', errorCategory: 'none',
  });
  assert.deepEqual(ocr, {
    backend: 'wasm', errorCategory: 'none',
    fallback: false, fallbackReason: 'none', consistency: 'inconsistent',
  });
});

test('OCR diagnostic display accepts an exhausted WebGPU to WASM initialization failure', () => {
  const ocr = normalizeOcrDiagnosticForDisplay({
    capabilityClass: 'webgpu', backend: 'none', webgpuAttempted: true,
    fallback: true, fallbackReason: 'initialization_failed',
    consistency: 'consistent', errorCategory: 'wasm_init_failed',
  });
  assert.equal(ocr.consistency, 'consistent');
});
