# New reference-only reproducibility check

Predeclared 2026-10-22 before creating a new reference snapshot or rebuilding.

Controller/evidence directory:
`C:/Users/84046/AppData/Local/Temp/fundval-reference-rebuild-20261022-0570429`.
The original helper has no output-directory parameter. Use its unchanged native
mkdtemp interface and record the separately returned `fundval-baseline-*` path
before building; retain that new snapshot. Do not move it or change TEMP/TMP.

Read original sampler settings at measure-performance-pair.mjs:678-686 and the
complete createSourceSnapshot/configureSnapshotTransport implementations.
Call original createSourceSnapshot with full reference SHA
057042963a33579c624a41404a6d533dfda29768, then original
configureSnapshotTransport(snapshot) exactly once. Its ordinary free-loopback
port replacement applies only to snapshot serve-site/playwright/v15 test text.
Do not substitute the old sampled port, add a different port recipe, start
servers/browsers or collect new timings. The original sampled snapshot was
already cleaned; this is a new reconstruction, never a re-read of that tree.

Use root's current strictly matching pinned node_modules junction, as the
original helper does. Do not install, run lifecycle scripts or modify dependency
bytes. Verify normalized locks and declared installed versions before building.

Run exactly three predetermined sequential actual reference builds, using the
same command as the sampler (not npm): process.execPath scripts/build-site.mjs,
cwd=new snapshot; inherited host env plus SOURCE_DATE_EPOCH=1791676800,
FORCE_COLOR=0 and NO_COLOR=1; original600000ms timeout and20MB stdout bound.
Capture every stdout/stderr/native exit separately and each complete output
inventory. Do not retry a failed build or change any option to obtain matching
bytes. A native/setup failure stops remaining builds and retains all receipts;
a byte mismatch remains a failure, never normalized away or replaced.

Compare every row against BOTH original raw artifactsBefore.reference and
artifactsAfter.reference in
`D:/AI项目/FundVal/docs/v16.0.0/performance-evidence/m3-pair-vite824-diagnostics-800-20261022.json`.
The real original reference has110 files/92344588B, artifact SHA
a18ee3fc44654061712e4714f257efbb8767571d07b868d579a56b5d5660f812.
Current has127 files/92537133B; do not require/reference invent127 files.
Use the original artifactFingerprint algorithm and also compare complete sorted
path/bytes/SHA arrays, without normalization or omitted differences. Record
three-run equality and original sampled reference equality separately.

The original reference build may recursively replace only its new snapshot/site.
Validate snapshot is a direct Temp fundval-baseline-* directory, root is not the
snapshot, and snapshot/site resolves inside it before each original build.
Never delete the snapshot or unlink its dependency junction in this task.

Freeze/check root270 inputs, root127 current site, installed68 rows, original
sampler/collector bytes, raw measurement file SHA and HEAD/branch/staged content
before/after. Keep report/scripts only here; do not edit root docs/site/source,
budgets, recipe, reference Git objects, original raw report or frozen evidence.
This check establishes reconstructed reference build determinism only, not new
latency evidence, production acceptance, budget PASS or M3 release admission.
