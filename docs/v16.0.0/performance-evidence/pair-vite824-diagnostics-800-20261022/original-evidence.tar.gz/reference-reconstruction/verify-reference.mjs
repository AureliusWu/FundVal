import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { readFile, writeFile, realpath, lstat } from 'node:fs/promises';
import { dirname, resolve, relative, isAbsolute, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url)), root = 'D:/AI项目/FundVal';
const reference = '057042963a33579c624a41404a6d533dfda29768';
const rawPath = resolve(root, 'docs/v16.0.0/performance-evidence/m3-pair-vite824-diagnostics-800-20261022.json');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const save = async (name, value) => writeFile(resolve(here, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const text = async (name, value) => writeFile(resolve(here, name), value, { flag: 'wx' });
const api = await import(pathToFileURL(resolve(root, 'scripts/measure-performance-pair.mjs')));
const collector = await import(pathToFileURL(resolve(root, 'scripts/collect-baseline.mjs')));
const sourceFrozen = await json('C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a/B-source-frozen.json');
const closure = await json(resolve(root, 'docs/v16.0.0/performance-evidence/audit-closure-20261022/final-status.json'));
function git(args) {
  const result = spawnSync('git', ['--no-optional-locks', ...args], { cwd: root, encoding: 'utf8', windowsHide: true, maxBuffer: 32 * 1024 * 1024 });
  assert.equal(result.status, 0, result.stderr); return result.stdout;
}
async function rootIdentity() {
  const source = [];
  for (const row of sourceFrozen.rows) {
    const bytes = await readFile(resolve(root, row.path)); source.push({ path: row.path, bytes: bytes.length, sha256: sha(bytes) });
  }
  assert.deepEqual(source, sourceFrozen.rows);
  const installed = [];
  for (const row of closure.installedRows) {
    const bytes = await readFile(resolve(root, 'node_modules', row.path));
    assert.equal(sha(bytes), row.sha256); installed.push({ ...row });
  }
  return { source, installed, currentArtifact: await api.artifactFingerprint(resolve(root, 'site')),
    samplerSha256: sha(await readFile(resolve(root, 'scripts/measure-performance-pair.mjs'))),
    collectorSha256: sha(await readFile(resolve(root, 'scripts/collect-baseline.mjs'))),
    rawSha256: sha(await readFile(rawPath)), head: git(['rev-parse', 'HEAD']).trim(),
    branch: git(['branch', '--show-current']).trim(), stagedDiffSha256: sha(git(['diff', '--cached', '--binary', 'HEAD'])) };
}
async function validateSnapshot(snapshot) {
  const actual = await realpath(snapshot), temp = await realpath(tmpdir());
  const child = relative(temp, actual);
  assert.ok(!isAbsolute(child) && !child.includes(sep) && /^fundval-baseline-[^/\\]+$/.test(child));
  assert.notEqual(actual.toLowerCase(), (await realpath(root)).toLowerCase());
  assert.ok((await lstat(actual)).isDirectory());
  const site = resolve(actual, 'site'), inside = relative(actual, site);
  assert.equal(inside, 'site'); assert.ok(!inside.startsWith('..'));
  const deps = resolve(actual, 'node_modules'); assert.ok((await lstat(deps)).isSymbolicLink());
  assert.equal(await realpath(deps), await realpath(resolve(root, 'node_modules')));
}
async function build(snapshot, round) {
  const command = process.execPath, args = ['scripts/build-site.mjs'];
  const overrides = { SOURCE_DATE_EPOCH: '1791676800', FORCE_COLOR: '0', NO_COLOR: '1' };
  const receipt = { round, command, args, cwd: snapshot, node: process.version, environmentOverrides: overrides,
    timeoutMs: 600_000, started: new Date().toISOString(), status: null, signal: null, error: null, stdoutOverflow: false };
  const stdout = [], stderr = []; let stdoutBytes = 0;
  const result = await new Promise(done => {
    const child = spawn(command, args, { cwd: snapshot, env: { ...process.env, ...overrides }, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    receipt.pid = child.pid;
    const timer = setTimeout(() => { receipt.timedOut = true; child.kill(); }, 600_000);
    child.stdout.on('data', bytes => {
      stdoutBytes += bytes.length; stdout.push(bytes);
      if (stdoutBytes > 20_000_000) { receipt.stdoutOverflow = true; child.kill(); }
    });
    child.stderr.on('data', bytes => stderr.push(bytes));
    child.once('error', error => { receipt.error = error.message; });
    child.once('close', (status, signal) => { clearTimeout(timer); done({ status, signal }); });
  });
  Object.assign(receipt, result, { ended: new Date().toISOString(), stdoutBytes,
    stdout: Buffer.concat(stdout).toString('utf8'), stderr: Buffer.concat(stderr).toString('utf8') });
  await text(`build-${round}.stdout.log`, receipt.stdout); await text(`build-${round}.stderr.log`, receipt.stderr);
  await save(`build-${round}.receipt.json`, receipt);
  return receipt;
}

const result = { schema: 1, purpose: 'Newly reconstructed reference-only reproducibility, not new timings', reference,
  started: new Date().toISOString(), validationDirectory: here, snapshot: null, rounds: [], status: 'INCOMPLETE',
  oldSampledSnapshotWasAlreadyRemoved: true, rebuiltSnapshotRetained: true, browserStarted: false, samplerRun: false, dependencyInstallRun: false };
try {
  const raw = await json(rawPath); assert.equal(raw.referenceSha, reference);
  assert.deepEqual(raw.artifactsBefore.reference, raw.artifactsAfter.reference);
  assert.equal(raw.artifactsBefore.reference.fileCount, 110);
  result.expectedReference = raw.artifactsBefore.reference;
  result.rootBefore = await rootIdentity(); assert.equal(result.rootBefore.currentArtifact.fileCount, 127);
  await save('root-before.json', result.rootBefore);
  const epoch = git(['show', '-s', '--format=%ct', reference]).trim(); assert.equal(epoch, '1791676800');
  assert.equal(api.normalizedLock(git(['show', reference + ':package-lock.json'])), api.normalizedLock(await readFile(resolve(root, 'package-lock.json'))));
  const expected = JSON.parse(git(['show', reference + ':package.json']));
  for (const [name, version] of Object.entries({ ...expected.dependencies, ...expected.devDependencies })) {
    assert.equal((await json(resolve(root, 'node_modules', name, 'package.json'))).version, version);
  }
  const snapshot = await collector.createSourceSnapshot(reference); result.snapshot = snapshot;
  await validateSnapshot(snapshot);
  const transport = await collector.configureSnapshotTransport(snapshot); result.transport = transport;
  await save('snapshot-identity.json', { reference, snapshot, transport, epoch, sharedDependencies: await realpath(resolve(snapshot, 'node_modules')),
    newSnapshot: true, originalSampledSnapshotReread: false, retained: true });
  for (let round = 1; round <= 3; round++) {
    await validateSnapshot(snapshot);
    const receipt = await build(snapshot, round); result.rounds.push({ round, nativeExit: receipt.status, signal: receipt.signal });
    assert.equal(receipt.status, 0, `Build ${round} failed; no retry`); assert.equal(receipt.error, null); assert.equal(receipt.stdoutOverflow, false);
    const artifact = await api.artifactFingerprint(resolve(snapshot, 'site'));
    const comparison = { round, artifact, matchesRawBefore: JSON.stringify(artifact) === JSON.stringify(raw.artifactsBefore.reference),
      matchesRawAfter: JSON.stringify(artifact) === JSON.stringify(raw.artifactsAfter.reference) };
    await save(`build-${round}.inventory.json`, comparison);
    Object.assign(result.rounds.at(-1), { fileCount: artifact.fileCount, totalBytes: artifact.totalBytes, sha256: artifact.sha256,
      matchesRawBefore: comparison.matchesRawBefore, matchesRawAfter: comparison.matchesRawAfter });
    assert.deepEqual(artifact, raw.artifactsBefore.reference, `Build ${round} differs from original sampled reference`);
    assert.deepEqual(artifact, raw.artifactsAfter.reference);
  }
  result.rootAfter = await rootIdentity(); await save('root-after.json', result.rootAfter);
  assert.deepEqual(result.rootAfter, result.rootBefore, 'Root/current output/dependencies/raw changed during reference-only work');
  result.status = 'PASS_REFERENCE_RECONSTRUCTION_THREE_BUILDS';
} catch (error) {
  result.status = 'FAIL_OR_INCOMPLETE'; result.failure = { name: error.name, message: error.message, stack: error.stack };
  process.exitCode = 1;
} finally {
  result.finished = new Date().toISOString();
  await save('result.json', result);
  console.log(JSON.stringify({ status: result.status, snapshot: result.snapshot, rounds: result.rounds, failure: result.failure }, null, 2));
}
