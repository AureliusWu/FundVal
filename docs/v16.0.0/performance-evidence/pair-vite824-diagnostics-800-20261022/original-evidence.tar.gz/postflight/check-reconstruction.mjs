import assert from 'node:assert/strict';
import { readFile, writeFile, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, dirname, relative, isAbsolute, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const dir='C:/Users/84046/AppData/Local/Temp/fundval-reference-rebuild-20261022-0570429';
const sha=b=>createHash('sha256').update(b).digest('hex'),json=async p=>JSON.parse(await readFile(p,'utf8'));
const result=await json(resolve(dir,'result.json'));
assert.equal(result.status,'PASS_REFERENCE_RECONSTRUCTION_THREE_BUILDS');
assert.equal(result.reference,'057042963a33579c624a41404a6d533dfda29768');
assert.deepEqual(result.rootBefore,result.rootAfter);
const snapshot=await realpath(result.snapshot),child=relative(await realpath(tmpdir()),snapshot);
assert.ok(!isAbsolute(child)&&!child.includes(sep)&&/^fundval-baseline-[^/\\]+$/.test(child));
assert.ok((await lstat(snapshot)).isDirectory());
const rawPath=resolve(root,'docs/v16.0.0/performance-evidence/m3-pair-vite824-diagnostics-800-20261022.json');
const rawBytes=await readFile(rawPath),raw=JSON.parse(rawBytes);
assert.equal(sha(rawBytes),'46aeb7a3ad8908bf256ffe4b17e706e59fddd282e5bdcbed994780222a9bf49f');
assert.equal(result.rootBefore.rawSha256,sha(rawBytes));
const api=await import(pathToFileURL(resolve(root,'scripts/measure-performance-pair.mjs')));
for(const i of [1,2,3]){
  const receipt=await json(resolve(dir,`build-${i}.receipt.json`));
  assert.equal(receipt.status,0);assert.equal(receipt.signal,null);assert.equal(receipt.error,null);assert.equal(receipt.stdoutOverflow,false);
  assert.equal(receipt.environmentOverrides.SOURCE_DATE_EPOCH,'1791676800');
  assert.deepEqual(receipt.args,['scripts/build-site.mjs']);assert.equal(receipt.cwd,result.snapshot);
  assert.equal(await readFile(resolve(dir,`build-${i}.stdout.log`),'utf8'),receipt.stdout);
  assert.equal(await readFile(resolve(dir,`build-${i}.stderr.log`),'utf8'),receipt.stderr);
  const inventory=await json(resolve(dir,`build-${i}.inventory.json`));
  assert.deepEqual(inventory.artifact,raw.artifactsBefore.reference);assert.deepEqual(inventory.artifact,raw.artifactsAfter.reference);
  assert.equal(inventory.matchesRawBefore,true);assert.equal(inventory.matchesRawAfter,true);
}
assert.deepEqual(await api.artifactFingerprint(resolve(snapshot,'site')),raw.artifactsAfter.reference);
assert.deepEqual(await api.artifactFingerprint(resolve(root,'site')),raw.artifactsAfter.current);
const report={schema:1,checkedAt:new Date().toISOString(),verdict:'REFERENCE_RECONSTRUCTION_INDEPENDENTLY_VERIFIED',threeNativeBuildExits:[0,0,0],
  referenceFiles:110,referenceBytes:92344588,referenceArtifactSha256:raw.artifactsAfter.reference.sha256,
  sourceDir:dir,snapshot,currentFiles:127,rawSha256:sha(rawBytes),originalRemovedSnapshotReread:false,newMeasurement:false,
  sourceBeforeAfterIdentical:true,stdoutStderrReceiptsVerified:true};
await writeFile(resolve(here,'reconstruction-check.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));
