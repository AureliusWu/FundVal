import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, readdir, lstat, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = 'D:/AI项目/FundVal';
const runDir = 'C:/Users/84046/AppData/Local/Temp/fundval-m3-pair824-20261022-84c9ce529d91';
const independentDir = 'C:/Users/84046/AppData/Local/Temp/fundval-pair824-prepared-verifier-20261022-114642-337';
const rawPath = resolve(root, 'docs/v16.0.0/performance-evidence/m3-pair-vite824-diagnostics-800-20261022.json');
const sha = b => createHash('sha256').update(b).digest('hex');
const json = async p => JSON.parse(await readFile(p, 'utf8'));
const result = { schema: 1, startedAt: new Date().toISOString(), checks: [], receipts: [] };
const eq = (a,b) => assert.deepStrictEqual(a,b);
async function check(name, fn) {
  try { await fn(); result.checks.push({ name, status: 'PASS' }); }
  catch (error) { result.checks.push({ name, status: 'FAIL', errorName: error.name, error: error.message }); }
}
function command(file, args) {
  const start = new Date().toISOString();
  const r = spawnSync(file, args, { cwd: root, encoding: null, windowsHide: true, timeout: 60_000, maxBuffer: 20_000_000 });
  result.receipts.push({ file, args, cwd: root, startedAt: start, endedAt: new Date().toISOString(),
    status: r.status, signal: r.signal, errorCode: r.error?.code || null, stdout: r.stdout?.toString('utf8') || '', stderr: r.stderr?.toString('utf8') || '' });
  return r;
}
function git(args) { const r=command('git',args); assert.equal(r.status,0); return r.stdout; }

const completion=await json(resolve(runDir,'native-completion.json'));
assert.equal(completion.status,0); assert.equal(completion.signal,null); assert.equal(completion.error,null);
const rawBytes=await readFile(rawPath), raw=JSON.parse(rawBytes), rawSha=sha(rawBytes);
result.raw={ path:rawPath,bytes:rawBytes.length,sha256:rawSha,collectedAt:raw.collectedAt,finishedAt:raw.finishedAt,status:raw.status };
await check('freeze exact measurement-window tracked diff before post-run documentation',async()=>{
  const b=git(['diff','--binary','HEAD','--']);
  assert.equal(sha(b),raw.currentSourceAfter.trackedDiffSha256);
  await writeFile(resolve(here,'measurement-window-tracked.patch'),b,{flag:'wx'});
  result.trackedPatch={bytes:b.length,sha256:sha(b)};
  const head=git(['rev-parse','HEAD']).toString('utf8').trim();
  const branch=git(['branch','--show-current']).toString('utf8').trim();
  const staged=git(['diff','--cached','--binary']);
  const reference=await json(resolve(runDir,'reference.json'));
  assert.equal(head,reference.after.head); assert.equal(branch,reference.after.branch); assert.equal(sha(staged),reference.after.index);
  const untracked=git(['ls-files','--others','--exclude-standard','-z']).toString('utf8').split('\0')
    .filter(p=>/^(?:js\/|css\/|data\/|scripts\/|assets\/|[^/]+\.(?:html|json))/.test(p)).sort();
  const hashes=[];for(const p of untracked)hashes.push(`${p}\0${sha(await readFile(resolve(root,p)))}`);
  assert.equal(sha(hashes.join('\n')),raw.currentSourceAfter.buildRelevantUntrackedSha256);
  eq(raw.currentSourceBefore,raw.currentSourceAfter);
  result.sourceIdentity={...raw.currentSourceAfter,branch,stagedDiffSha256:sha(staged),buildRelevantUntracked:untracked};
});

await check('complete source walk detects no extra missing or changed members in frozen scope',async()=>{
  const frozen=await json('C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a/B-source-frozen.json');
  const exclude=new Set(['.git','node_modules','site','Temp','.claude','docs']),rows=[];
  async function visit(path){const full=resolve(root,path),s=await lstat(full);assert.equal(s.isSymbolicLink(),false);
    if(s.isDirectory()){for(const name of await readdir(full))if(path!=='.'||!exclude.has(name))await visit(path==='.'?name:path+'/'+name);}
    else{assert.ok(s.isFile());assert.ok(!/(^|\/)\.env(?:\.|$)/.test(path));const b=await readFile(full);rows.push({path,bytes:b.length,sha256:sha(b)});}}
  await visit('.');await visit('docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md');rows.sort((a,b)=>a.path.localeCompare(b.path));
  eq(rows,frozen.rows);assert.equal(rows.length,270);assert.equal(sha(JSON.stringify(rows)),frozen.sha256);
  result.source={count:rows.length,bytes:rows.reduce((s,r)=>s+r.bytes,0),sha256:sha(JSON.stringify(rows)),rows};
});
await check('installed full declared inventory remains unchanged',async()=>{
  const closure=await json(resolve(root,'docs/v16.0.0/performance-evidence/audit-closure-20261022/final-status.json'));
  const rows=[];
  for(const row of closure.installedRows){const b=await readFile(resolve(root,'node_modules',row.path));rows.push({path:row.path,bytes:b.length,sha256:sha(b)});assert.equal(sha(b),row.sha256);}
  assert.equal(rows.length,68);result.installed={count:rows.length,bytes:rows.reduce((s,r)=>s+r.bytes,0),sha256:sha(JSON.stringify(rows)),rows};
});
await check('actual full current site equals raw before after and preflight',async()=>{
  const api=await import(pathToFileURL(resolve(root,'scripts/measure-performance-pair.mjs')));
  const actual=await api.artifactFingerprint(resolve(root,'site'));
  const preflight=await json(resolve(runDir,'preflight.json'));
  eq(actual,raw.artifactsBefore.current);eq(actual,raw.artifactsAfter.current);eq(actual,preflight.artifact);
  assert.equal(actual.fileCount,127);result.currentArtifact=actual;
  eq(raw.artifactsBefore.reference,raw.artifactsAfter.reference);
  result.referenceArtifact={...raw.artifactsAfter.reference,readCurrentPayload:false};
});
await check('full pair observations and independent bootstrap verification',async()=>{
  const v2=await json(resolve(independentDir,'finished-verification.v2.json'));
  assert.equal(v2.verificationVerdict,'EXACT_COMPLETE_RAW_VERIFIED');eq(v2.failures,[]);assert.equal(v2.checks.length,9663);
  assert.ok(v2.checks.every(r=>r.status==='PASS'));assert.equal(v2.rawSha256,rawSha);eq(v2.recomputedSummary,raw.summary);
  assert.equal(raw.rawPairs.length,804);let retained=0,warmups=0;
  const order={retainedAB:0,retainedBA:0,warmupAB:0,warmupBA:0},counts={reference:{consoleErrors:0,pageErrors:0,requests:0,blockedFailures:0,drains:0},current:{consoleErrors:0,pageErrors:0,requests:0,blockedFailures:0,drains:0}};
  raw.rawPairs.forEach((p,i)=>{assert.equal(p.index,i);assert.equal(p.retained,i>=4);assert.ok(!p.failure&&p.reference&&p.current);
    const bucket=i>=4?'retained':'warmup';if(i>=4)retained++;else warmups++;
    eq(p.order,i%2?['current','reference']:['reference','current']);order[bucket+(i%2?'BA':'AB')]++;
    for(const side of ['reference','current']){const s=p[side];counts[side].consoleErrors+=s.consoleErrors;counts[side].pageErrors+=s.pageErrors;
      counts[side].requests+=s.requests.length;counts[side].blockedFailures+=s.requests.filter(r=>r.failure&&r.transport==='blocked').length;
      assert.equal(s.networkInstrumentation.failures,0);assert.equal(s.serviceWorkerEvents,0);
      for(const d of s.drains){assert.equal(d.status,'SETTLED');counts[side].drains++;}
    }});
  eq(order,{retainedAB:400,retainedBA:400,warmupAB:2,warmupBA:2});assert.equal(retained,800);assert.equal(warmups,4);
  result.observations={counts,order,retained,warmups,independentChecks:v2.checks.length,independentFailureCount:v2.failures.length,independentObservational:v2.observational};
  result.summary=raw.summary;result.health=raw.health;result.instrumentation=raw.instrumentation;result.cleanup=raw.cleanup;
});
await check('original independent all-budget CLI still exits native1',async()=>{
  const r=command(process.execPath,['scripts/release-fingerprint.mjs','--assert-app-bundle-budget','site']);
  await writeFile(resolve(here,'budget-native.json'),JSON.stringify(result.receipts.at(-1),null,2)+'\n',{flag:'wx'});
  assert.equal(r.status,1);assert.equal(r.signal,null);assert.equal(r.error,undefined);
  result.budget={nativeExit:r.status,verdict:'FAIL',allGzipBytes:84187,limit:77227.7,minimumIntegerReduction:6960,coldGzipBytes:44699,coldLimit:52241};
});
await check('raw bytes unchanged through independent postflight',async()=>assert.equal(sha(await readFile(rawPath)),rawSha));
result.finishedAt=new Date().toISOString();result.failed=result.checks.filter(r=>r.status!=='PASS');result.verdict=result.failed.length?'POSTFLIGHT_FAILURE':'SOURCE_WINDOW_AND_FULL_INVENTORIES_VERIFIED';
await writeFile(resolve(here,'postflight.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({verdict:result.verdict,checks:result.checks.length,failures:result.failed,raw:result.raw,trackedPatch:result.trackedPatch,source:result.source&&{count:result.source.count,bytes:result.source.bytes,sha256:result.source.sha256},budget:result.budget}));
process.exitCode=result.failed.length?3:0;
