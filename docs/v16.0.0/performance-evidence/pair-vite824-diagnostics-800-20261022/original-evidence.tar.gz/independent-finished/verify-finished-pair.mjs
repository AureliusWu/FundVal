// PREPARED DURING SAMPLING. Do not execute until the parent explicitly confirms completion.
// This program never measures, rebuilds, installs, audits, retries or edits the raw report.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, lstat, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { dirname, resolve, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = 'D:/AI项目/FundVal';
const runDir = 'C:/Users/84046/AppData/Local/Temp/fundval-m3-pair824-20261022-84c9ce529d91';
const rawPath = resolve(root, 'docs/v16.0.0/performance-evidence/m3-pair-vite824-diagnostics-800-20261022.json');
const outputPath = resolve(here, 'finished-verification.json');
const expectedSampler = '2ca754524871b72c3c41f17ec2b6052ac74e3334ad034bf522a933cd9df295d7';
const expectedCollector = '8a98f57980cfcde94e4035987c974b149c80bc27b51a1ca2309d3aed9d85bdd0';
const expectedProtocol = '7f1da9c2d44319d23cddc8f958506a68940cb81a048b924b4bec00181d065ec9';
const sha = value => createHash('sha256').update(value).digest('hex');
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const hashFile = async path => sha(await readFile(path));
const finite = value => Number.isFinite(value) && value >= 0;
const count = value => Number.isSafeInteger(value) && value >= 0;
const failures = [], checks = [];
function check(name, fn) {
  try { fn(); checks.push({ name, status: 'PASS' }); return true; }
  catch (error) { checks.push({ name, status: 'FAIL', errorName: error.name }); failures.push(name); return false; }
}
async function asyncCheck(name, fn) {
  try { await fn(); checks.push({ name, status: 'PASS' }); return true; }
  catch (error) { checks.push({ name, status: 'FAIL', errorName: error.name }); failures.push(name); return false; }
}
const eq = (a, b) => assert.deepStrictEqual(a, b);
const aggregate = (target, key, amount = 1) => { target[key] = (target[key] || 0) + amount; };
function readOnlyGit(args) {
  const receipt = spawnSync('git', args, { cwd: root, encoding: null, windowsHide: true });
  assert.equal(receipt.status, 0); return receipt.stdout;
}
async function currentSourceIdentity() {
  const head = readOnlyGit(['rev-parse', 'HEAD']).toString('utf8').trim();
  const diff = readOnlyGit(['diff', '--binary', 'HEAD', '--']);
  const paths = readOnlyGit(['ls-files', '--others', '--exclude-standard', '-z']).toString('utf8').split('\0')
    .filter(path => /^(?:js\/|css\/|data\/|scripts\/|assets\/|[^/]+\.(?:html|json))/.test(path)).sort();
  const hashes = [];
  for (const path of paths) hashes.push(`${path}\0${await hashFile(resolve(root, path))}`);
  return { head, trackedDiffSha256: sha(diff), buildRelevantUntrackedSha256: sha(hashes.join('\n')),
    dirty: diff.length > 0 || paths.length > 0, label: 'Current working-tree candidate; HEAD is not an immutable identity for uncommitted changes.' };
}
function verifyArtifactInventory(inventory) {
  assert.ok(inventory && Array.isArray(inventory.files));
  eq([...inventory.files].sort((a,b) => a.path.localeCompare(b.path, 'en')), inventory.files);
  assert.equal(new Set(inventory.files.map(row => row.path)).size, inventory.files.length);
  for (const row of inventory.files) {
    assert.equal(typeof row.path, 'string'); assert.ok(!row.path.startsWith('/') && !row.path.split('/').includes('..'));
    assert.ok(count(row.bytes)); assert.match(row.sha256, /^[a-f\d]{64}$/);
  }
  assert.equal(inventory.fileCount, inventory.files.length);
  assert.equal(inventory.totalBytes, inventory.files.reduce((sum,row) => sum + row.bytes, 0));
  assert.equal(inventory.sha256, sha(inventory.files.map(row => `${row.path}\0${row.sha256}\n`).join('')));
  assert.ok(inventory.files.some(row => row.path === 'index.html'));
  assert.ok(inventory.files.some(row => row.path === 'js/app-shell.js'));
}

async function main() {
  // Both guards precede ANY read of the raw report. An empty reserved live file is not completion.
  assert.deepStrictEqual(process.argv.slice(2), ['--after-explicit-finish-notice'], 'Wait for explicit parent completion notice; this flag is not permission to inspect live raw.');
  const completion = await json(resolve(runDir, 'native-completion.json'));
  assert.ok(completion.ended && Number.isFinite(Date.parse(completion.ended)));
  assert.ok([0, 1, 2].includes(completion.status)); assert.equal(completion.signal, null); assert.equal(completion.error, null);
  assert.equal((await lstat(outputPath).then(() => true, error => error.code === 'ENOENT' ? false : Promise.reject(error))), false, 'Never overwrite a prior verification.');
  const rawBytes = await readFile(rawPath), rawSha256 = sha(rawBytes), raw = JSON.parse(rawBytes.toString('utf8'));
  const preflight = await json(resolve(runDir, 'preflight.json'));
  const reservation = await json(resolve(runDir, 'launch-reservation.json'));
  const reference = await json(resolve(runDir, 'reference.json'));
  let api = null, recomputedSummary = null;
  check('terminal raw has finishedAt and agrees with native completion', () => {
    assert.ok(Number.isFinite(Date.parse(raw.finishedAt))); assert.ok(Date.parse(raw.finishedAt) <= Date.parse(completion.ended));
    assert.ok(['PASS', 'FAIL', 'INCONCLUSIVE'].includes(raw.status)); assert.equal(completion.status, { PASS: 0, FAIL: 1, INCONCLUSIVE: 2 }[raw.status]);
    assert.ok(completion.stdout.includes(`PAIR ${raw.status}:`));
  });
  await asyncCheck('sampler collector and predeclared protocol hashes unchanged', async () => {
    assert.equal(await hashFile(resolve(root, 'scripts/measure-performance-pair.mjs')), expectedSampler);
    assert.equal(await hashFile(resolve(root, 'scripts/collect-baseline.mjs')), expectedCollector);
    assert.equal(await hashFile(resolve(runDir, 'PROTOCOL.md')), expectedProtocol);
    eq(preflight.scriptHashes, { sampler: expectedSampler, collector: expectedCollector });
    assert.equal(completion.samplerSha256, expectedSampler); assert.equal(completion.collectorSha256, expectedCollector);
  });
  check('exact original one-run arguments and metadata', () => {
    eq(completion.args, reservation.args); eq(completion.args, ['scripts/measure-performance-pair.mjs', '--pairs', '800', '--warmup-pairs', '4', '--bootstrap', '5000', '--seed', '160003', '--timeout-ms', '30000', '--reference', reference.commit, '--output', preflight.output]);
    eq(raw.requested, { retainedPairs: 800, warmupPairs: 4, bootstrap: 5000, seed: 160003 });
    assert.equal(resolve(preflight.output), rawPath); assert.equal(raw.schema, 1); assert.equal(raw.referenceSha, reference.commit);
    assert.equal(raw.measurement.protocol, 'paired-readiness-v2-same-document-counters');
    assert.equal(raw.measurement.fixedFixtureTime, '2026-08-28T06:45:10.000Z');
    eq(raw.environment.viewport, { width: 390, height: 844 }); assert.equal(raw.environment.node, 'v24.14.0'); assert.equal(raw.environment.chromeVersion, '155.0.8059.86');
    assert.equal(raw.lifecycle.mode, 'owned isolated snapshot and servers');
    eq(raw.lifecycle.referenceTransportEdits, ['scripts/serve-site.mjs', 'playwright.config.mjs', 'e2e/v15.spec.js']);
  });
  check('reference provenance and strict same-dependency identities', () => {
    assert.equal(reference.commit, '057042963a33579c624a41404a6d533dfda29768');
    assert.equal(reference.parent, 'c2980265d3c89f960517ced1527ba9cb85bf7c2b'); assert.equal(reference.changes.length, 5);
    eq(reference.before, reference.after); assert.equal(reference.pushed, false);
    assert.equal(raw.dependencies.referenceRawLockSha256, reference.referenceLockRawSha256);
    assert.equal(raw.dependencies.currentRawLockSha256, reference.currentLockRawSha256);
    assert.equal(raw.dependencies.resolvedLockSha256, reference.normalizedLockSha256);
    assert.equal(raw.dependencies.installed.vite, '8.2.4'); assert.equal(raw.dependencies.node, 'v24.14.0');
  });
  const pairs = Array.isArray(raw.rawPairs) ? raw.rawPairs : [];
  const rawCounts = { totalPairs: pairs.length, complete: 0, failed: 0, incompleteWithoutPairFailure: 0,
    retainedComplete: 0, warmupComplete: 0, retainedOrder: { AB: 0, BA: 0 }, warmupOrder: { AB: 0, BA: 0 } };
  const completeDesign = pairs.length === 804 && pairs.every(pair => pair.reference && pair.current && !pair.failure);
  let timingValuesValid = true;
  const observational = { sides: {}, requestCategories: {}, requestInstrumentation: {}, requestFailures: {},
    pageErrors: 0, pageErrorCategories: {}, consoleErrors: 0, serviceWorkerEvents: 0, serviceWorkerScriptRequests: 0,
    registrationAttempts: 0, controllers: 0, registrations: 0, rendererStatus: {}, rendererInvalidReasons: {}, drains: {},
    gistWriteAttempts: 0, networkInstrumentationFailures: 0 };
  check('raw contains all 800 retained plus four prespecified warmups', () => assert.equal(pairs.length, 804));
  check('raw pair prefix/order/retention/failure integrity; no replacements or dropped failures', () => {
    assert.ok(Array.isArray(raw.rawPairs));
    let sawFailure = false;
    pairs.forEach((pair, index) => {
      assert.equal(pair.index, index); assert.equal(pair.retained, index >= 4);
      eq(pair.order, index % 2 ? ['current', 'reference'] : ['reference', 'current']);
      assert.ok(!sawFailure, 'No later pair may replace or follow a failed pair');
      if (pair.failure) {
        sawFailure = true; assert.equal(index, pairs.length - 1); assert.ok(pair.order.includes(pair.failure.side));
        assert.ok(['MEASUREMENT_FAILED', 'INTERRUPTED'].includes(pair.failure.category));
        assert.equal(pair[pair.failure.side], null); assert.ok(raw.failure); assert.equal(raw.status, 'INCONCLUSIVE');
        if (pair.failure.side === pair.order[0]) assert.equal(pair[pair.order[1]], null);
      }
      if (pair.reference && pair.current && !pair.failure) assert.ok(Number.isFinite(Date.parse(pair.finishedAt)));
      else assert.ok(pair.failure || raw.failure, 'Incomplete samples require explicit terminal failure metadata');
    });
  });
  for (const [index, pair] of pairs.entries()) {
    const complete = Boolean(pair.reference && pair.current && !pair.failure), bucket = index >= 4 ? 'retainedOrder' : 'warmupOrder';
    if (complete) { rawCounts.complete++; rawCounts[index >= 4 ? 'retainedComplete' : 'warmupComplete']++; }
    if (pair.failure) rawCounts.failed++; else if (!complete) rawCounts.incompleteWithoutPairFailure++;
    if (pair.order?.join(',') === 'reference,current') rawCounts[bucket].AB++;
    else if (pair.order?.join(',') === 'current,reference') rawCounts[bucket].BA++;
    for (const side of ['reference', 'current']) {
      const sample = pair[side]; if (!sample) continue; // Counts only: inference NEVER filters missing/failed samples.
      aggregate(observational.sides, side);
      const tag = `${index}:${side}`;
      check(`sample timing and safe counter completeness ${tag}`, () => {
        for (const metric of ['coldReadyMs', 'warmReadyMs', 'saveUiMs']) if (!finite(sample[metric])) { timingValuesValid = false; assert.fail('Missing/invalid timing is not removable'); }
        for (const key of ['pageErrors', 'consoleErrors', 'serviceWorkerEvents']) assert.ok(count(sample[key]));
        assert.ok(sample.pageErrorCategories && typeof sample.pageErrorCategories === 'object');
        assert.equal(Object.values(sample.pageErrorCategories).reduce((sum,value) => { assert.ok(count(value)); return sum + value; }, 0), sample.pageErrors);
        assert.ok(count(sample.networkInstrumentation?.failures)); assert.ok(Array.isArray(sample.requests)); assert.ok(Array.isArray(sample.drains));
        assert.equal(sample.breakdown.cold.readyMs, sample.coldReadyMs); assert.equal(sample.breakdown.warm.readyMs, sample.warmReadyMs);
      });
      observational.pageErrors += sample.pageErrors || 0; observational.consoleErrors += sample.consoleErrors || 0;
      observational.serviceWorkerEvents += sample.serviceWorkerEvents || 0;
      observational.networkInstrumentationFailures += sample.networkInstrumentation?.failures || 0;
      for (const [category, value] of Object.entries(sample.pageErrorCategories || {})) aggregate(observational.pageErrorCategories, category, value);
      let requestCollectionFailures = 0, drainFailures = 0;
      check(`request and drain raw completeness ${tag}`, () => {
        sample.requests.forEach((request, requestIndex) => {
          assert.equal(request.index, requestIndex); aggregate(observational.requestCategories, `${side}:${request.phase}:${request.category}`);
          aggregate(observational.requestInstrumentation, `${side}:${request.instrumentation}`);
          assert.ok(['MEASURED', 'BLOCKED_NO_RESPONSE_BYTES', 'HERMETIC_POLICY_BLOCK', 'OWNED_OPTIONAL_CANCELLATION', 'UNEXPECTED_REQUEST_FAILURE', 'INCOMPLETE', 'INCOMPLETE_OWNED_CLOSE'].includes(request.instrumentation));
          if (request.failure) aggregate(observational.requestFailures, `${side}:${request.failure}:${request.instrumentation}`);
          if (request.role === 'serviceWorkerScript') observational.serviceWorkerScriptRequests++;
          if (request.category === 'gistWriteBlocked') observational.gistWriteAttempts++;
          if (request.instrumentation === 'HERMETIC_POLICY_BLOCK') assert.equal(request.transport, 'blocked');
          if (request.instrumentation === 'OWNED_OPTIONAL_CANCELLATION') { assert.equal(request.role, 'optionalQuoteBridge'); assert.ok(['ownedWarmReload','ownedContextClose'].includes(request.lifecycleCause)); assert.ok(request.failure); }
          if (['UNEXPECTED_REQUEST_FAILURE', 'INCOMPLETE', 'INCOMPLETE_OWNED_CLOSE'].includes(request.instrumentation)) requestCollectionFailures++;
          if (request.instrumentation === 'MEASURED') { assert.ok(request.timing && request.sizes); assert.ok(Number.isInteger(request.status)); }
          if (request.transport === 'blocked') assert.equal(request.sizes, null);
        });
        eq(sample.drains.map(row => row.reason), ['beforeOwnedWarmReload', 'afterWarmReadiness', 'beforeOwnedContextClose']);
        for (const drain of sample.drains) { assert.ok(['SETTLED','DEADLINE_INCOMPLETE'].includes(drain.status)); aggregate(observational.drains, `${side}:${drain.status}`); if (drain.status !== 'SETTLED') drainFailures++; }
        assert.equal(sample.networkInstrumentation.failures, requestCollectionFailures + drainFailures + (sample.serviceWorkerEvents ? 1 : 0));
      });
      check(`SW controlled worker and registration assertions ${tag}`, () => {
        assert.equal(sample.serviceWorkerEvents, 0);
        for (const phase of ['cold','warm','save']) {
          const policy = sample.breakdown[phase].serviceWorkers;
          assert.equal(policy.status, 'REGISTRATION_BLOCKED'); assert.equal(policy.controlled, false); assert.equal(policy.registrations, 0); assert.ok(count(policy.registrationAttempts));
          observational.registrationAttempts += policy.registrationAttempts; observational.controllers += Number(policy.controlled); observational.registrations += policy.registrations;
        }
      });
    }
  }
  check('observed metadata is a full recount, including all failures and warmups', () => eq(raw.observed, {
    retainedCompletePairs: rawCounts.retainedComplete, warmupCompletePairs: rawCounts.warmupComplete, failedPairs: rawCounts.failed }));
  check('retained AB BA are exactly 400 each and warmups exactly two each', () => {
    eq(rawCounts.retainedOrder, { AB: 400, BA: 400 }); eq(rawCounts.warmupOrder, { AB: 2, BA: 2 });
    assert.equal(rawCounts.retainedComplete, 800); assert.equal(rawCounts.warmupComplete, 4); assert.equal(rawCounts.failed, 0); assert.equal(rawCounts.incompleteWithoutPairFailure, 0);
  });
  // Importing the unchanged module is safe only now: its CLI main guard does not match this verifier.
  if (checks.find(row => row.name === 'sampler collector and predeclared protocol hashes unchanged')?.status === 'PASS') {
    api = await import(pathToFileURL(resolve(root, 'scripts/measure-performance-pair.mjs')));
  }
  if (api && completeDesign && timingValuesValid) {
    check('exact original summarizePairs recomputation using all retained samples', () => {
      recomputedSummary = api.summarizePairs(pairs.slice(4), { bootstrap: 5000, seed: 160003 });
      eq(recomputedSummary, raw.summary); assert.equal(raw.summary.method.minimumPairs, 60);
    });
    for (const [index,pair] of pairs.entries()) for (const side of ['reference','current']) for (const phase of ['cold','warm','save']) {
      const renderer = pair[side].breakdown[phase].renderer;
      check(`same-document renderer raw attribution recomputation ${index}:${side}:${phase}`, () => {
        eq(api.rendererDelta(renderer.snapshots.before, renderer.snapshots.after, { phase: phase === 'save' ? 'interaction' : 'navigation' }), renderer);
        if (phase !== 'save') assert.ok(['PARTIAL','UNAVAILABLE'].includes(renderer.status));
        aggregate(observational.rendererStatus, `${side}:${phase}:${renderer.status}`);
        for (const reason of Object.values(renderer.invalidReasons)) aggregate(observational.rendererInvalidReasons, `${side}:${phase}:${reason}`);
      });
    }
  } else failures.push('Exact inference not run: the requested 804 raw pairs are incomplete or invalid; no filtered replacement set was made.');
  check('internal full artifact inventories and source before/after equality', () => {
    for (const side of ['reference','current']) {
      verifyArtifactInventory(raw.artifactsBefore[side]); verifyArtifactInventory(raw.artifactsAfter[side]); eq(raw.artifactsBefore[side], raw.artifactsAfter[side]);
    }
    eq(raw.currentSourceBefore, raw.currentSourceAfter); eq(raw.artifactsBefore.current, preflight.artifact); assert.equal(raw.integrity.status, 'PASS');
  });
  if (api) await asyncCheck('current actual site remains equal to raw and preflight; no reference reread after cleanup', async () => {
    eq(await api.artifactFingerprint(resolve(root, 'site')), raw.artifactsAfter.current);
  });
  await asyncCheck('actual current source identity root branch and index remain exactly recorded', async () => {
    eq(await currentSourceIdentity(), raw.currentSourceAfter);
    assert.equal(raw.currentSourceAfter.head, reference.after.head);
    assert.equal(raw.currentSourceAfter.trackedDiffSha256, reference.after.diff);
    assert.equal(readOnlyGit(['branch','--show-current']).toString('utf8').trim(), reference.after.branch);
    assert.equal(sha(readOnlyGit(['diff','--cached','--binary'])), reference.after.index);
  });
  await asyncCheck('explicit 270 source files and installed 68 remain frozen', async () => {
    const frozen = await json('C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a/B-source-frozen.json');
    const rows = [];
    for (const row of frozen.rows) { const path = resolve(root,row.path); assert.ok(!relative(root,path).startsWith('..')); const bytes = await readFile(path); rows.push({path:row.path,bytes:bytes.length,sha256:sha(bytes)}); }
    eq(rows, frozen.rows); eq({count:rows.length,bytes:frozen.bytes,sha256:sha(JSON.stringify(rows))}, preflight.sourceInput); assert.equal(rows.length,270);
    const closure = await json(resolve(root,'docs/v16.0.0/performance-evidence/audit-closure-20261022/final-status.json'));
    assert.equal(closure.installedRows.length,68); for (const row of closure.installedRows) assert.equal(await hashFile(resolve(root,'node_modules',row.path)),row.sha256);
  });
  check('recorded health instrumentation cleanup and final native status preserve every outcome', () => {
    assert.equal(raw.health.status, observational.pageErrors ? 'FAIL' : 'PASS');
    assert.equal(raw.instrumentation.status, observational.networkInstrumentationFailures ? 'INCOMPLETE' : 'PASS');
    assert.equal(raw.cleanup.length,4); assert.equal(raw.cleanup.filter(row=>row.resource==='ownedBrowser').length,1);
    assert.equal(raw.cleanup.filter(row=>row.resource==='ownedServer').length,2); assert.equal(raw.cleanup.filter(row=>row.resource==='validatedTemporarySnapshot').length,1);
    const origins = Object.values(raw.origins); assert.equal(new Set(origins).size,2);
    for (const origin of origins) { const url = new URL(origin); assert.equal(url.protocol,'http:'); assert.equal(url.hostname,'127.0.0.1'); assert.notEqual(url.port,'4173'); }
    eq(raw.cleanup.filter(row=>row.resource==='ownedServer').map(row=>row.origin).sort(), origins.sort());
    for (const row of raw.cleanup) assert.equal(row.status,'PASS');
    let expected = raw.summary.verdict;
    if (raw.failure || raw.integrity.status!=='PASS' || observational.pageErrors || observational.networkInstrumentationFailures || raw.cleanup.some(row=>row.status!=='PASS')) expected='INCONCLUSIVE';
    assert.equal(raw.status,expected); assert.equal(observational.gistWriteAttempts,0);
  });
  await asyncCheck('raw report remained byte-identical throughout verification', async () => assert.equal(await hashFile(rawPath),rawSha256));
  const result = { schema:1, verifiedAt:new Date().toISOString(), rawPath, rawBytes:rawBytes.length, rawSha256,
    rawStatus:raw.status, nativeSamplerExit:completion.status, verificationVerdict:failures.length?'INTEGRITY_OR_COMPLETENESS_FAILURE':'EXACT_COMPLETE_RAW_VERIFIED',
    completeDesign, rawCounts, failures, checks, recomputedSummary, observational,
    scope: { onlyFourPrespecifiedWarmupsExcluded:true, failedOrOutlierSamplesRemoved:false, reranMeasurement:false,
      consoleZero:observational.consoleErrors===0, consoleErrorsAreNotTheSamplerPageerrorGate:true,
      workerEvents:observational.serviceWorkerEvents, controllers:observational.controllers, registrations:observational.registrations,
      serviceWorkerScriptAttemptsReportedSeparately:true, registrationAttemptsAreObservationsNotSuccessfulWorkers:true,
      renderer:'Navigation attribution is PARTIAL or UNAVAILABLE, never full startup/OS CPU. Save counters are same-document interaction attribution. No missing sample is zero-filled.',
      ownership:'Owned cleanup statuses are raw recorded evidence. Removed reference payload is NOT reread or asserted present.',
      optionalRequestFailure:'Original aborted-error text is not persisted; owned optional cancellation role/cause is checked without inventing the missing raw error text.',
      requestConsolePrivacy:'Safe categories/counters only; no console text, URLs, storage values or screenshots reconstructed.',
      timing:'Local no-store HTTP and synthetic UI save with desktop scheduling and sampler overhead; not warm HTTP-cache, production network, physical-device or OCR-engine evidence.',
      m3:'All84187 >77227.7 and 6960 integer byte gap remain independent FAIL; this checker cannot grant M4 or release.' } };
  await writeFile(outputPath,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({verificationVerdict:result.verificationVerdict,rawStatus:raw.status,nativeSamplerExit:completion.status,failedChecks:failures.length,outputPath}));
  process.exitCode=failures.length?3:completion.status;
}
main().catch(async error=>{
  const failure={schema:1,verificationVerdict:'VERIFIER_REFUSED_OR_FAILED',errorName:error.name,errorCode:error.code||null,
    note:'No samples were filtered or repaired. Raw/source/site remain read-only. Missing terminal completion prevents reading live raw.'};
  try { await writeFile(resolve(here,'verifier-fatal.json'),JSON.stringify(failure,null,2)+'\n',{flag:'wx'}); } catch (_) {}
  console.error('Finished-pair verification refused or failed; retain all existing evidence and inspect the independent fatal metadata.'); process.exitCode=3;
});
