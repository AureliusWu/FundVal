import assert from 'node:assert/strict';
import { readFile,writeFile,lstat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname,resolve } from 'node:path';
import { fileURLToPath,pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal',sha=b=>createHash('sha256').update(b).digest('hex');
const json=async p=>JSON.parse(await readFile(p,'utf8'));
const reference=await json(resolve(here,'reference.json'));
const frozen=await json('C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a/B-source-frozen.json');
const auditClosure=await json('D:/AI项目/FundVal/docs/v16.0.0/performance-evidence/audit-closure-20261022/final-status.json');
assert.equal(auditClosure.rootQualificationComplete,true);
const rows=[];for(const row of frozen.rows){const b=await readFile(resolve(root,row.path));rows.push({path:row.path,bytes:b.length,sha256:sha(b)});}assert.deepEqual(rows,frozen.rows);
for(const row of auditClosure.installedRows)assert.equal(sha(await readFile(resolve(root,'node_modules',row.path))),row.sha256);
const samplerSha=sha(await readFile(resolve(root,'scripts/measure-performance-pair.mjs')));assert.equal(samplerSha,'2ca754524871b72c3c41f17ec2b6052ac74e3334ad034bf522a933cd9df295d7');
const collectorSha=sha(await readFile(resolve(root,'scripts/collect-baseline.mjs')));assert.equal(collectorSha,'8a98f57980cfcde94e4035987c974b149c80bc27b51a1ca2309d3aed9d85bdd0');
const api=await import(pathToFileURL(resolve(root,'scripts/measure-performance-pair.mjs'))),artifact=await api.artifactFingerprint(resolve(root,'site'));
const expected=(await json('C:/Users/84046/AppData/Local/Temp/fundval-vite824-qualification-20261022-0d5350fa5e31a/ROOT-verification-3.json')).whole;
assert.deepEqual(artifact.files,expected.rows);assert.equal(artifact.fileCount,127);
const p=JSON.parse(await readFile(resolve(root,'package.json'))),r=JSON.parse(spawnSync('git',['show',reference.commit+':package.json'],{cwd:root,encoding:'utf8',windowsHide:true}).stdout);
assert.deepEqual({...p.dependencies,...p.devDependencies},{...r.dependencies,...r.devDependencies});
const lock=await readFile(resolve(root,'package-lock.json')),refLock=spawnSync('git',['show',reference.commit+':package-lock.json'],{cwd:root,encoding:'utf8',windowsHide:true});assert.equal(refLock.status,0);assert.equal(api.normalizedLock(lock),api.normalizedLock(refLock.stdout));
const output=resolve(root,'docs/v16.0.0/performance-evidence/m3-pair-vite824-diagnostics-800-20261022.json');assert.equal(await lstat(output).then(()=>true,()=>false),false);
const report={schema:1,checkedAt:new Date().toISOString(),reference,sourceInput:{count:rows.length,bytes:frozen.bytes,sha256:sha(JSON.stringify(rows))},
 artifact,scriptHashes:{sampler:samplerSha,collector:collectorSha},dependencyLockNormalized:reference.normalizedLockSha256,rootAuditZero:true,
 currentWholeSortedJsonSha256:expected.sha256,output,sourceUnchanged:true,installed68Unchanged:true,currentVersion:p.version,measurementStarted:false};
await writeFile(resolve(here,'preflight.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({...report,artifact:{...artifact,files:undefined},reference:{commit:reference.commit,ref:reference.ref}}));
