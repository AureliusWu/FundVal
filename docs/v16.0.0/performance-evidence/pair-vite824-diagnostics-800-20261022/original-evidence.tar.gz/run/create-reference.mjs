import assert from 'node:assert/strict';
import { readFile,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { dirname,resolve } from 'node:path';
import { fileURLToPath,pathToFileURL } from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root='D:/AI项目/FundVal';
const parent='c2980265d3c89f960517ced1527ba9cb85bf7c2b',ref='refs/fundval-performance/v15.0.2-source-map-js-1.2.2-vite-8.2.4-20261022';
const sha=b=>createHash('sha256').update(b).digest('hex');
function git(args,{env={},input}={}){const r=spawnSync('git',args,{cwd:root,env:{...process.env,...env},input,encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024});assert.equal(r.status,0,r.stderr);return r.stdout;}
const before={head:git(['rev-parse','HEAD']).trim(),branch:git(['branch','--show-current']).trim(),diff:sha(git(['diff','--binary','HEAD'])),index:sha(git(['diff','--cached','--binary','HEAD']))};
const absent=spawnSync('git',['show-ref','--verify','--quiet',ref],{cwd:root,windowsHide:true});assert.equal(absent.status,1,'Ref already exists; stop rather than overwrite');
function diff(a,b,path=[]){if(a===b)return[];if(a&&b&&typeof a==='object'&&typeof b==='object'&&Array.isArray(a)===Array.isArray(b)){return[...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(k=>diff(a[k],b[k],[...path,k]));}return[{path,a,b}];}
const changes=[],files={};
for(const name of ['package.json','package-lock.json']){const bytes=await readFile(resolve(here,'reference-input',name));files[name]=bytes;changes.push(...diff(JSON.parse(git(['show',parent+':'+name])),JSON.parse(bytes)).map(r=>({file:name,...r})));}
const allowed=[['package.json',['devDependencies','vite']],['package-lock.json',['packages','','devDependencies','vite']],...['version','resolved','integrity'].map(k=>['package-lock.json',['packages','node_modules/vite',k]])];
assert.equal(changes.length,5);assert.deepEqual(changes.map(r=>JSON.stringify([r.file,r.path])).sort(),allowed.map(r=>JSON.stringify(r)).sort());
const {normalizedLock}=await import(pathToFileURL(resolve(root,'scripts/measure-performance-pair.mjs')));
const rootLock=await readFile(resolve(root,'package-lock.json'));
assert.equal(normalizedLock(files['package-lock.json']),normalizedLock(rootLock));
const declared=p=>({...p.dependencies,...p.devDependencies});
assert.deepEqual(declared(JSON.parse(files['package.json'])),declared(JSON.parse(await readFile(resolve(root,'package.json')))));
const indexEnv={GIT_INDEX_FILE:resolve(here,'reference.index')};git(['read-tree',parent+'^{tree}'],{env:indexEnv});
const blobs={};for(const [name,bytes]of Object.entries(files)){const blob=git(['hash-object','-w','--stdin'],{input:bytes}).trim();blobs[name]=blob;git(['update-index','--add','--cacheinfo','100644',blob,name],{env:indexEnv});}
const tree=git(['write-tree'],{env:indexEnv}).trim();assert.deepEqual(git(['diff','--name-only',parent+'^{tree}',tree]).trim().split('\n').sort(),['package-lock.json','package.json']);
const epoch=git(['show','-s','--format=%ct',parent]).trim();assert.equal(epoch,'1791676800');const date=new Date(Number(epoch)*1000).toISOString();
const commit=git(['commit-tree',tree,'-p',parent],{input:'Local v15 performance reference: align only Vite8.2.4 security patch; no business change\n',env:{GIT_AUTHOR_NAME:'FundVal Local Performance Baseline',GIT_AUTHOR_EMAIL:'fundval-baseline@invalid.local',GIT_COMMITTER_NAME:'FundVal Local Performance Baseline',GIT_COMMITTER_EMAIL:'fundval-baseline@invalid.local',GIT_AUTHOR_DATE:date,GIT_COMMITTER_DATE:date}}).trim();
assert.equal(git(['show','-s','--format=%ct',commit]).trim(),epoch);assert.equal(git(['show','-s','--format=%P',commit]).trim(),parent);
git(['update-ref',ref,commit,'0'.repeat(40)]);
const after={head:git(['rev-parse','HEAD']).trim(),branch:git(['branch','--show-current']).trim(),diff:sha(git(['diff','--binary','HEAD'])),index:sha(git(['diff','--cached','--binary','HEAD']))};assert.deepEqual(after,before);
const report={schema:1,purpose:'Local-only same-dependency security-aligned v15 business reference, not product commit/release',ref,commit,parent,tree,blobs,epoch:Number(epoch),dateMeaning:'Preserved original reference epoch for reproducible build; synthetic reference metadata, not publication date',changes,
 normalizedLockSha256:sha(normalizedLock(rootLock)),currentLockRawSha256:sha(rootLock),referenceLockRawSha256:sha(files['package-lock.json']),before,after,pushed:false};
await writeFile(resolve(here,'reference.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
