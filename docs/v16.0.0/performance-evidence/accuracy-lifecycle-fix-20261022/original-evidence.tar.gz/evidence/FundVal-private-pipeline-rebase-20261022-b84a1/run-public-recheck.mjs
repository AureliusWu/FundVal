import {readFileSync,writeFileSync,readdirSync,lstatSync,mkdirSync,cpSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const dir=import.meta.dirname,output=resolve(dir,'public-recheck-01'),sha=b=>createHash('sha256').update(b).digest('hex');
const json=p=>JSON.parse(readFileSync(p,'utf8')),save=(p,b)=>writeFileSync(p,b,{flag:'wx'});
function rows(base,part=''){const list=[];for(const e of readdirSync(resolve(base,part),{withFileTypes:true})){const path=part?part+'/'+e.name:e.name,p=resolve(base,path);assert.equal(lstatSync(p).isSymbolicLink(),false);if(e.isDirectory())list.push(...rows(base,path));else{const b=readFileSync(p);list.push({path,bytes:b.length,sha256:sha(b)});}}return list.sort((a,b)=>a.path.localeCompare(b.path));}
if(process.argv[2]!=='--child'){
 mkdirSync(output);const startedAt=new Date().toISOString(),args=[import.meta.filename,'--child'];
 const r=spawnSync(process.execPath,args,{cwd:dir,windowsHide:true,encoding:null,timeout:60000,maxBuffer:8_000_000});
 const stdout=r.stdout||Buffer.alloc(0),stderr=r.stderr||Buffer.alloc(0);
 for(const[k,b]of[['stdout',stdout],['stderr',stderr]])save(resolve(output,'native.'+k),b);
 const receipt={command:process.execPath,args,cwd:dir,startedAt,finishedAt:new Date().toISOString(),exitCode:r.status,signal:r.signal,error:r.error?.message??null,scriptSha256:sha(readFileSync(import.meta.filename)),protocolSha256:sha(readFileSync(resolve(dir,'PUBLIC_RECHECK_PROTOCOL.md'))),stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}};
 save(resolve(output,'native.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));process.stdout.write(stdout);process.stderr.write(stderr);process.exitCode=r.status??99;
}else{
 const helperRoot='C:/Users/84046/AppData/Local/Temp/FundVal-worker-seam-qualification-20261022-a1';
 const hashes={'cases.mjs':'f9fc6e87ed2ccf5e2c316544f333e0197c0f5c94e36d001947c467bc6065db6d','cases.json':'c1ec7df0a66db3de6f756a9899b5d9c8e8b582d8a55384e08ab2fb46c553a644','runner.mjs':'e1dc1f70eb6220e6d8260a02f53e00247dcb42e606814e483420a28873d7f21a'};
 for(const[name,hash]of Object.entries(hashes)){const b=readFileSync(resolve(helperRoot,name));assert.equal(sha(b),hash);cpSync(resolve(helperRoot,name),resolve(output,name),{force:false,errorOnExist:true});}
 const oldRaw=readFileSync(resolve(dir,'references/15-baseline-01.json'));assert.equal(sha(oldRaw),'80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751');const stored=JSON.parse(oldRaw);
 const before=Object.fromEntries(['A','B'].map(side=>[side,rows(resolve(dir,side))]));
 for(const side of['A','B'])assert.deepEqual(before[side],json(resolve(dir,side+'-INVENTORY.json')).rows.map(({path,bytes,sha256})=>({path,bytes,sha256})));
 save(resolve(output,'inputs.json'),JSON.stringify({before,hashes,scriptSha256:sha(readFileSync(import.meta.filename)),protocolSha256:sha(readFileSync(resolve(dir,'PUBLIC_RECHECK_PROTOCOL.md')))},null,2)+'\n');
 const {run}=await import(pathToFileURL(resolve(output,'runner.mjs')).href),{specs,controls}=await import(pathToFileURL(resolve(output,'cases.mjs')).href);
 assert.equal(specs.length,64);assert.equal(controls.length,3);
 const denied={fetch:0,localStorage:0,sessionStorage:0};globalThis.fetch=()=>{denied.fetch++;throw new Error('NETWORK_FORBIDDEN_RECHECK');};for(const key of['localStorage','sessionStorage'])Object.defineProperty(globalThis,key,{configurable:true,get(){denied[key]++;throw new Error('REAL_STORAGE_FORBIDDEN_RECHECK');}});
 async function apiAt(side){const base=resolve(dir,side);return{wire:await import(pathToFileURL(resolve(base,'js/runtime/worker-contract.js')).href),estimates:await import(pathToFileURL(resolve(base,'js/eastmoney-estimate.js')).href),fixtures:await import(pathToFileURL(resolve(base,'test/fixtures/worker-contract-v16.js')).href)};}
 const a=await apiAt('A'),b=await apiAt('B');assert.notEqual(a.wire.WorkerContractError,b.wire.WorkerContractError);
 const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b),records=[],negativeControls=[],failures=[];
 for(const spec of specs){const previous=stored.baseline.find(r=>r.spec.id===spec.id).frozen,actualA=run(a,spec),actualB=run(b,spec),match={AStored:equal(actualA,previous),BStored:equal(actualB,previous),AB:equal(actualA,actualB),expectedOutcome:actualA.expectedOutcomeMatched&&actualB.expectedOutcomeMatched};records.push({spec,stored:previous,actualA,actualB,match});if(!Object.values(match).every(Boolean))failures.push({id:spec.id,match});}
 for(const control of controls){const spec=specs.find(s=>s.id===control.target),actual=run(a,spec,control.id),previous=stored.negativeControls.find(c=>c.id===control.id).mutated,match=equal(actual,previous);negativeControls.push({control,actual,match});if(!match)failures.push({id:control.id,kind:'negative-control-mismatch'});}
 if(Object.values(denied).some(Boolean))failures.push({kind:'forbidden',denied});
 const beforeTests=Object.fromEntries(['A','B'].map(side=>[side,rows(resolve(dir,side))]));assert.deepEqual(beforeTests,before);
 const tests=['test/worker-contract-v16.test.js','test/estimate-wire-characterization-v16.test.js','test/estimate-http-characterization-v16.test.js','test/fund-holdings.test.js','test/eastmoney-estimate.test.js','test/request-signal.test.js'];
 const testsResult=[];
 for(const side of['A','B']){
  for(const path of tests)assert.ok(before[side].some(r=>r.path===path),path);
  const startedAt=new Date().toISOString(),args=['--test',...tests],r=spawnSync(process.execPath,args,{cwd:resolve(dir,side),windowsHide:true,encoding:null,timeout:30000,maxBuffer:8_000_000});
  const stdout=r.stdout||Buffer.alloc(0),stderr=r.stderr||Buffer.alloc(0);for(const[k,data]of[['stdout',stdout],['stderr',stderr]])save(resolve(output,side+'-tests.'+k),data);
  const receipt={side,command:process.execPath,args,cwd:resolve(dir,side),startedAt,finishedAt:new Date().toISOString(),nativeExit:r.status,signal:r.signal,error:r.error?.message??null,stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}};
  testsResult.push(receipt);save(resolve(output,side+'-tests.json'),JSON.stringify(receipt,null,2)+'\n');if(r.status!==0)failures.push({kind:'interface-test-failure',side,nativeExit:r.status});
 }
 const after=Object.fromEntries(['A','B'].map(side=>[side,rows(resolve(dir,side))]));assert.deepEqual(after,before);
 const summary={status:failures.length?'FAIL':'PASS',genericCases:64,AStored:records.filter(r=>r.match.AStored).length,BStored:records.filter(r=>r.match.BStored).length,AB:records.filter(r=>r.match.AB).length,negativeControls:negativeControls.filter(r=>r.match).length,invocations:131,denied,sourceUnchanged:true,testsResult};
 const report={schema:1,kind:'P1-corrected-implementation-stage-public-boundary-only',summary,records,negativeControls,failures,after,fullPrivatePipeline:false,size:'NOT_RUN',latency:'NOT_RUN',adopted:false};
 const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n');save(resolve(output,'result.json'),bytes);console.log(JSON.stringify({summary,failures,raw:{bytes:bytes.length,sha256:sha(bytes)}}));process.exitCode=failures.length?1:0;
}
