# P1-corrected private-pipeline preparation handoff

Status: **PREPARED_ONLY**. No application evaluation, syntax/test, build, npm/install, compression, browser/network or root/old-workspace edit. This is not new behavior, performance, gzip or adoption qualification.

## Ready paths

- A: `C:/Users/84046/AppData/Local/Temp/FundVal-private-pipeline-rebase-20261022-b84a1/A`
- B: `C:/Users/84046/AppData/Local/Temp/FundVal-private-pipeline-rebase-20261022-b84a1/B`
- Fixed pre-copy plan: `PLAN.md`.
- Complete source origin/copy identities: `PREPARED.json`, `A-INVENTORY.json`, `B-INVENTORY.json`.
- Strict final verification: `VERIFICATION.json`; exact raw diff: `native/strict-diff.stdout` with its native1 expected receipt.

## Authority and complete payload

Both sides copy exactly248 nonhistorical payloads from the final model-provenance archive, **not** the old246 snapshot or Git HEAD. This includes `docs/v15.0.2/IMPLEMENTATION_FEEDBACK.md` and both formal model tests. The archive's272 complete source inventory (including24 historical Android outputs) is preserved inside `unpacked/parent/final-state.json`; the24 historical output payloads are not claimed as copied A/B source.

Archive: `D:/AI项目/FundVal/docs/v16.0.0/performance-evidence/model-provenance-fix-20261022/original-evidence.tar.gz`,11490572B/SHA256 `0c127a5bb5fec6ab518a4308c9a59d4f6337fd631cf15553f42d4f3cfb75fde1`. All791 freshly extracted members were verified against the archived individual byte/SHA inventory before copying. Each A/B inventory row records source archive, exact member and extracted absolute origin; PREPARED also records current-root/individual A/B paths.

| Side | Files | Bytes | Canonical path/bytes/SHA rows hash |
|---|---:|---:|---|
| A |248|12151828|`11464eb6c4d500a22e23b4ea02d0146c0b2a7b60aa0ff101b1517466f5ec1033`|
| B |248|12152533|`4876a4c59fd8778b12224ba4eaacae1fc1cb137abcbd5dc575c1f710341813c3`|

Inventory file hashes (different from row hashes): A-INVENTORY.json `fd231410e7eea8945fe8f314dbbf58e04edd564774c730ca3e274d99a5e16e51`; B-INVENTORY.json `d5eda9957993c0102770bd6634eb7268bdca99c987c33d04325d80099ade84a4`. VERIFICATION.json `df2950fab50ae27a20ec6d6f305bb24c5471764ccd90eaec398f4757a06b0aad`.

## Exact single-file transplant

Only `B/js/runtime/worker-contract.js` differs. It was edited with apply_patch, not copied wholesale over new P1 source. All other247 files match A and the final archive byte-for-byte.

| Worker | Bytes | SHA256 |
|---|---:|---|
| A / independent original |16996|`54bab1e12f3127b8d28b98185175864ea4dc420b2c862954ab542b3293aa2b44`|
| B / old partial candidate |17701|`268547d8aae0c405b3a8ef6f224f79cbbbb42d23c3933c5151092bd78d85b4bc`|

A Worker exactly matches old `wire-public-boundary/original`; all6 of its transitive literal relative dependencies exactly match the old partial candidate, so no merge guess or old-model dependency was needed. B Worker exactly matches old private candidate's validation/legacy-finisher patch. The verifier additionally reconstructs the COMPLETE B module from A's prefix, unchanged validation statement span, original legacy return literal/tail, and exactly declared wrappers/locals return; equality is exact, not substring-only acceptance.

This is NOT the older three-file header/items/tail endpoint seam: no fixed endpoint entries, HTTP client import/call changes, Error movement, new module, facade or production graph change was added. Public normalizeWorkerEstimateRow signature/defaults remain; decodeWorkerEstimateEvidence exposes precomputed locals; the public wrapper finishes with the original late spread/return. The parser and validation algorithms were not removed or relaxed. No full private HTTP/cache/App/model pipeline exists in this preparation.

Explicit unchanged guards include P1 `holdings-estimate`, `fund-model-enrichment`, `quote-normalizer`, `app`, `accuracy`; model-provenance/model-consumers tests; public business-features; eastmoney-estimate/fund-holdings clients; real model config; package/lock/build script. Every selected current-root input still matched the archive at final verification. The old246 candidate, archive, protocols, old64 raw oracle/cases and copied references remain unchanged.

## Native evidence and retained preparation error

- `native/prepare-01.*`: native1, retained. All A/B source copying/Worker guards had completed; reference-copy bookkeeping incorrectly split a Windows backslash-resolved path using '/'. No source mismatch or old-patch incompatibility occurred.
- `finish-prepare.mjs`/`native/prepare-02.*`: native0/stderr0. Did not recopy or overwrite A/B. It reverified791 extracted members, both248 source inventories/current selected root/old246 and6 dependencies, then completed references using basename and exclusive copies.
- `native/verify-01.*`: native0/stderr0;1370 static inventory/source checks, exact full reconstruction and protected-file guards passed.
- `archive-native/list.*` and `extract.*`: native0; original archive native output/exit retained.
- `native/strict-diff.*`: git diff --no-index expected native1, stderr0; complete source delta retained. This is not a failing behavioral test.

All probe scripts were created with apply_patch. Original failing script/input copies and stderr are retained; no output was relabeled as an initial clean preparation.

## Stop / next ownership

Parent may now continue the single complete vertical slice in B against this immutable A snapshot. Preparation stops here; no partial gzip probing, old800 inheritance or root adoption follows. Latest §51 baseline remains archived all85956/cold46129 and needs8729 integerB to satisfy unchanged all77227.7; this task did not measure either side. P1 independent-source policy supersedes the old shared-model-corruption compatibility sentence. Accuracy automatic lifecycle remains explicitly unresolved as documented in §51.
