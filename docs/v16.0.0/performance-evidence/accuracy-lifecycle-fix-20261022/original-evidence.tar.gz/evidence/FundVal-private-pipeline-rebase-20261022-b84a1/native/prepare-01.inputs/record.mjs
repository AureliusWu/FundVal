import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,readdirSync,mkdirSync,copyFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const [label,command,...args]=process.argv.slice(2),dir=import.meta.dirname,prefix=resolve(dir,'native',label),sha=b=>createHash('sha256').update(b).digest('hex');
if(!/^[a-z0-9-]+$/.test(label||'')||!command)throw new Error('Bad native recording label');mkdirSync(resolve(dir,'native'),{recursive:true});mkdirSync(prefix+'.inputs');
const inputs=[];for(const path of readdirSync(dir).filter(name=>/\.(?:mjs|md|json)$/.test(name)).sort()){const b=readFileSync(resolve(dir,path));copyFileSync(resolve(dir,path),resolve(prefix+'.inputs',path));inputs.push({path,bytes:b.length,sha256:sha(b)});}
const startedAt=new Date().toISOString(),r=spawnSync(command,args,{cwd:dir,encoding:null,windowsHide:true,timeout:60000,maxBuffer:20_000_000}),stdout=r.stdout||Buffer.alloc(0),stderr=r.stderr||Buffer.alloc(0);
writeFileSync(prefix+'.stdout',stdout,{flag:'wx'});writeFileSync(prefix+'.stderr',stderr,{flag:'wx'});
const receipt={command,args,cwd:dir,startedAt,endedAt:new Date().toISOString(),status:r.status,signal:r.signal,error:r.error?{name:r.error.name,message:r.error.message,code:r.error.code}:null,stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)},inputs};
writeFileSync(prefix+'.receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify(receipt)+'\n');process.exitCode=r.status??98;
