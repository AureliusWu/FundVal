# M3 完整私有 pipeline：有限静态材料性复核

审查时间：2026-10-22；源码 SHA 清单读取时间约 07:20 UTC。审查者：`m3_material_boundary`。

唯一交付写入：本系统 Temp 文件。根项目 `D:/AI项目/FundVal` 未被本审查编辑。本文件不是候选实现、构建收据或采用决定。

## 1. 结论与证据等级

完整 acquisition → cache → projection → compatibility-egress 在结构上可以闭合。但当前没有一个已完成的、含大型独立算法的默认图退休闭包，足以支持将 EvidenceBook 视为材料性候选。有限静态检查找到的可合并池主要是 legacy 包装、别名回写和重复投影；大部分较长函数承担仍必须存在的校验、旧格式导入、模型/金融规则和时钟规则。

这不是“绝对无法优化”的证明，也不是最终压缩测量。不得从源码行数、原文件 raw 字节数、chunk 大小或相同函数的调用次数推算净 gzip 收益。

现有 §51 门禁（引用现有 M3_STATUS 与产物 manifest，不是本审查重新测量）：16 chunks，all gzip **85,956 B**，cold **46,129 B**；原 all 上限 **77,227.7 B** 不变，整数 artifact 至少需要减少 **8,729 B** 才可能通过。当前 all 仍 FAIL。本报告不为任何切面预测 gzip 数字。

当前可证明的完整 pipeline 实际退休账：**没有已完成并经新产物确认的退休项**。现有默认产物仍导出旧 HTTP 入口；仅有 Worker validation/materializer 分界原型，不等于 acquisition/cache/App 全切面已迁移。下面给出完整的条件退休账：它区分“旧符号可消失”和“该符号承担的必要代码也可消失”，不可把前者直接计为净删。

## 2. 审查范围与未执行边界

已完整阅读旧 `pipeline-boundaries-20261022/README.md`、`next-http-boundary/README.md`、`REPORT.md`、`FIELD_LEDGER.json`，以及原 Temp `PROTOCOL.md`、`PUBLIC_BOUNDARY_PROTOCOL.md`。旧协议 addendum 已明确：历史 M04 shared-est 双模型碰撞仅保留为 OLD 证据，不是未来采用所需的正确语义。当前 §51 独立模型证据、损坏槽不救援、旧双 flag 降级、selected Quote 不换赢家、来源/版本/note 绑定和有效期必须保留。

本轮只进行了文件读取、`rg` 静态调用搜索、现有产物 import/export/manifest 检视、SHA-256 读取和本报告写入。没有业务模块执行，没有 build、test、minifier probe、安装、网络、浏览器或依赖变更；没有重跑旧 800 对，也没有复用旧身份的性能 PASS 给当前源。未对完整程序做新 AST 可达性证明；条件退休仍需未来完整候选的静态绑定和真实最终产物确认。

使用 performance-regression-check 的原预算、同身份与 raw/gzip 分离口径；使用 data-reliability-audit 的缺失值、日期、来源、缓存和可追溯约束。按本次授权，不执行两个 skill 中需要业务/运行态采样的步骤。不作生产 TRUSTED 判定。

## 3. 当前默认图与 namespace 前置条件

现有 `site/js/chunks/business-features-CEidwiga.js` 明确转出 `fetchEstimateRows`、`fetchFundHoldings`、`applyOverseasModelEstimate`、`composeFundEnrichment`、`executeRefreshPlan` 等旧入口。它从 `business-runtime-CXdkJSaR.js` 导入；业务 runtime 又与 post-integrity/startup chunk 有静态边。现有 manifest 没有 source-module membership，故不能把整个 business/post-integrity chunk 指给任一退休函数。

App 的旧 namespace 保留边包括：

- `loadSecurityQuoteFeature`，App 115–120：把整个 module 存入 `securityQuoteRuntime` 并返回。
- `loadFundHoldingsFeature`，App 132–135：Promise 返回整个 module；刷新 clients 与详情 `loadFundHoldings` 都用它。
- `loadOverseasModels`，App 143–148：把整个 module 存入 `modelRuntime`。
- `loadHoldingsEstimateFeature`，App 150–157：把整个 module 存入 `holdingsEstimateRuntime` 并返回。
- App 886–941 的 `runRefresh` 取得 execution/holding/estimate namespace，继续调用旧入口。

公开 API 保留在原源码、测试与 copy-to-site 文件，不等于必须留在默认 bundle。闭合条件是：生产 loaders 全部只暴露固定成员，私有 facade 不反向经过旧 barrel 取 valuation 入口，所有刷新与详情 backedge 都迁移，且没有新的 namespace 逃逸。不能只换估值的一条 import，就宣称旧公开实现已经 tree-shake。原五组、ES2022、minify、构建脚本与预算不变；新 facade/codec 的实际新增 artifact 成本必须计入。

## 4. 完整条件退休账

状态定义：`C` = 关闭列明的全部边以后，旧实现/壳可作为默认图退休目标；`K` = 必要规则仍活，最多改 owner/表示，不能把主体算作净删；`Z` = 当前默认生产调用已无该公开实现，不能当本候选新增收益。所有 `C` 当前均未在新完整候选产物中实现或确认。

| ID / 当前源码范围 | 当前实际保留边 | 关闭这些边后能退休什么 | 仍须保留的规则 / 新归属，禁止计入整段净删 | 状态 |
| --- | --- | --- | --- | --- |
| W1 `worker-contract.js` 64–160 的 return 144–160；163–245 的公共 envelope 构造 | 两公共 HTTP → `parseWorkerEnvelope`；estimate parser 225/229 与 HTTP row adapter 再调用 `normalizeWorkerEstimateRow` | 私有消费不需要的 normalized wire alias DTO、transport wrapper、通用 endpoint dispatch/公共返回壳 | header/accounting/partial semantics、两 items 分支、alias 校验、读取/抛错次序、尾部晚读、`WorkerContractError` 真实 class 和错误身份仍要存在；重复调用一个算法不等于多份算法。公共原入口原样保留 | C（壳）/K（校验） |
| H1 `eastmoney-estimate.js` 13–65 `normalizeEstimateRow`；67–94 `fetchEstimateRows` | App 137–140 → fetch；765–815 source gate → HTTP；executeRefreshPlan estimate acquisition | 原 legacy DTO 展开/别名构造、只供 direct API 的安全无用行救援包装，及旧公共入口绑定 | 请求集合/Map 占位、force、signal/timeout/cleanup/error-normalization、二次 options.now 求值次序、原源 Quote 含义；私有 HTTP 必须承接网络部分，不是整段删除。旧 direct API rescue 保留在公共源路径 | C（旧壳）/K（acquisition） |
| H2 `fund-holdings.js` 52–84 `fetchFundHoldings` | runRefresh clients.holdings，App 903；详情 App 1187–1189 | 旧 envelope → status/sourceStatus/wire/report/items 返回壳，旧公共入口绑定 | holdings HTTP、空/降级 status 区分、错误/取消、披露与 items 校验、详情元数据及缓存语义不变。必须同时迁移刷新和详情，不能漏一条 | C（壳）/K（HTTP/契约） |
| M1 `holdings-estimate.js` 156–198 `applyHoldingsEstimate`、206–215 `composeFundEnrichment` | App enriched 938–942 → compose → apply | 只为中间 fund 形状存在的 spread、`est_*`/source alias 回写和旧 compose 入口 | calculateHoldingsEstimate、latestOfficialNavBase、正式来源优先、单 session、披露/coverage/count、独立冻结证据与失败不救援仍要实现；最终 legacy 行若要求同字段，alias 编码转到兼容 egress，不是凭空消失 | C（中间壳）/K（模型与 egress） |
| M2 `fund-model-enrichment.js` 12–62 `applyOverseasModelEstimate` | App buildFundData 668；App modelRuntime 143–148/1133 | 对整个 fund 的模型 alias 回写与旧 mutation wrapper | 模型选择、security input adapter、calculateOverseasEstimate、正式 NAV 基准、validateOverseasEstimatePeriod、独立冻结 evidence 的值/版本/coverage/confidence/note/原 fetchedAt 均须保留；私有函数直接产 evidence 不能删这些规则 | C（中间壳）/K（模型） |
| Q1 `quote-normalizer.js` 423–433 `buildFundQuoteCandidates`、411–421 dedupe、435–438 select wrapper | App fresh 672/680；旧 aggregate 缺 Quote 的 App 1027；失败 856 的空 candidate | 新鲜内部数据的泛型 fund dispatch、临时候选数组包装、旧组装入口 | 旧无 Quote aggregate 仍需解码候选；唯一候选去重规则、`compareQuotesByQuality` 排序与 unavailable fallback 仍活。改为 typed candidate selector 并不删除排序算法 | C（组装壳）/K（导入、优先级） |
| Q2 `quote-normalizer.js` 162–220 generic importer；326–368 两 model wrapper；222–242 official wrapper | HTTP source_quote；Q1；model legacy fallback；render secondary App 1440 | 新鲜 wire/model 路由不再经过 legacy alias getter/spread 的适配部分；旧符号仅当所有剩余 caller 也改 owner 才可退出 | 旧 aggregate 无 Quote、旧单模型 no-slot 必须继续理解旧字段；official provenance、alias presence、诊断/时效仍需 codec。不能迁入 importer 后把 162–220 或两 wrapper 的全部 body 计为删除。当前两 backedge 未断，不能宣称退出 | C（部分适配）/K（旧导入） |
| Q3 `quote-normalizer.js` 137–153、247–324、370–409、440–467 | resource estimateRow 82；resource fallback executor 164；App failure 855/cache 1031/render 1389/secondary 1440；accuracy 68 | 没有已证明可删除的独立规则池；可以改为同一内部表示上的操作 | Quote 合法化、市场时效、缓存 provenance、selected 不换赢家、同 fund 绑定、slot own-data 快照、损坏/null 不救援、季度/validUntil/nextWeekday、note/version/confidence 绑定必须继续；新存储 evidence 仍不可信。不能用内部 trust 免验证 | K |
| R1 `refresh-resource-cache.js` 39–93 `estimateRow`、95–162 `payloadFor` | make179 → payload；validate166 → payload；read201 → validate；executor valid/stage/flush → validate | 不再需要的 select/clean-row 与 Quote 中间重建；字段数组若仍是旧 codec 的 authority 就不能退休 | status/source/capability、strict enumerable extra-key、own presence、数值类型/NaN/null、`1e-7` aliases、base/target/observed/fetched、schema/holding-set/metadata/price 验证仍存。fresh acquisition 非 strict 与旧 resource strict 不可混同 | C（构造尾部）/K（validation/codec） |
| R2 `refresh-resource-cache.js` 166–231 validate/make/read；executor 81–92 acquireEntry、94–101 navMove、139–168 estimate projection | executor 读取旧资源、make 后复查、缓存消费、stage；旧 nav move adaptor | 旧资源 payload → 旧 App DTO 的中间投影可改成 typed record；navMove 包装可在唯一 egress 重建 | 原 envelope/TTL/sourceDate/active code、legacy NAV 原 clock、cache state、取得失败 fallback、每次消费时效和 private JSON copy/freeze 仍活；时间/信任边界不同，不是同一次校验冗余 | C（投影）/K（缓存规则） |
| P1 App 648–713 officialFundFallback/buildFundData；1013–1056 tryShowCache 的 row projection；837–869 failure projection | fresh primary/publish/enriched；冷/离线缓存；失败回显；render 继续读 primary/legacy fields | 多处重复 legacy display/primary/freshness/持仓字段组装入口可归为一个兼容投影 | 名称采用与持仓持久化、当前 holding shares/cost、null→显示 NaN、原 identityMismatch 整行隔离、计算/排序、来源 winner、失败 message、独立时钟及保留未知字段/顺序；原最终字段仍是兼容约束，不能计整 App 函数体 | C（重复组装）/K（规则与一次投影） |
| E1 App 595–607 slimFundCache/saveCache；resource 233–272 serializeRefreshAggregate；scope 107–123 flushCache | holdings edit writer；generation completion writer；单次 synchronous Storage mutation | 行编码/剔除字段规则若确属一致，可集中；旧公开 serializer 符号有条件退出 | 两外层 writer 不等价：edit 顶层 spread 保未知与原采集 clock；refresh 重建规定顶层、active/staged/newer 时钟、fundAcquired 判定。失败/取消/空 stage/去重、exact Storage attempt 数与无重试都保留。两个 writer 不能合并语义 | C（行编码壳）/K（两外层 writer） |
| Z1 `fund-holdings.js` 25–34 normalizeHoldingRow；公开 planner；完整公开 coordinator | 静态 `rg js`：normalizeHoldingRow 无生产引用；executor/security batch 导入 Runtime planners；App 导入 refresh-runtime | 不是本轮新增退休项 | 原文件中存在相似代码不代表当前默认 bundle 有两套实现；禁止把这些源体积计入候选收益 | Z |

表内 C 项形成一个完整纵切面，不代表每行都有独立且正向的净删除：例如 M1/M2 alias 回写在中间态消失，却可能需要在 E1 编码恢复；Q2 移为旧 importer 后语义代码仍在。应逐条用实际候选 diff 标记“消失、共享、迁移、增加”，不可把这些行全部相加。

## 5. 已核对的保留调用链

### 5.1 新鲜数据与两次投影

App `fetchRefreshEstimateRows`765 → source claim767 → dispatch779 → `fetchEstimateRows`137 → public HTTP67 → `parseWorkerEnvelope`83 → parser row normalization225/229 → `normalizeEstimateRow`85 → 再 wire normalize18 → generic Quote56。executor estimate acquisition139 → make resource160 → acquired/cache branch163–166 → ui.primary932 → publish937/buildFundData659；随后 enriched938 → compose/apply holdings → buildFundData → apply market → buildFundQuoteCandidates → select。网络、模型核心和排序算法并未因为多次物化而出现多份独立实现。

### 5.2 旧 aggregate / resource / 失败三条 backedge

1. App loadCache583 → tryShowCache1013；原 selected Quote 优先；无 Quote 才由1027调用 generic candidates。foreign identity1018使整个旧投影隔离；model selected 在1031复查，随后 normalizeCachedQuote保来源和原时钟。
2. executeRefreshPlan29 → readRefreshResources201 → validate166 → payloadFor/estimateRow；旧 NAV 还走 readCacheEnvelope 或 adaptLegacyNavMoveCache217，不得刷新取得时间。cached estimate branch164又将来源转成 cache，绝不是 fresh acquisition。
3. commitRefreshFailure837 → normalizeCachedQuote855，或空候选 unavailable856 → legacy freshness857。旧 Quote、原 clock、失败 reason 保留。

因此“新 HTTP 已 canonical”不能关闭 generic importer、cache provenance 或旧 no-slot 模型路径。

### 5.3 当前模型消费者

App render1389每次重查 selected freshness；1435–1444绑定 selected note 与独立 secondary model。accuracy68读取新槽对应的 freshness；71–81限定 market 来源、同 fund、版本/confidence unknown 不救援并保0。新 evidence 仍经过 own-data/identity/date/numeric/expiry 校验，不得把冻住对象等同于从持久化读回后可信。

accuracy 生命周期边界：App 的自动 hook 在 commitRefreshedFund817–825；enriched938–942没有同一 hook。本轮材料候选不得暗中增加调用/写入、补齐生命周期或把已有测试提升为生命周期已闭合。原独立正确性修复也不等同于生产可信或 M3 预算达标。

### 5.4 source health / planner / executor 不存在所猜测的大重复实现

App24/79只使用 `refresh-runtime.js` 私有 coordinator。其 context143–176委托 source-registry；不是第二套 health transition。

source-registry310 的 recordSourceResponse 已由 Success334/Partial339共享；Failure348、claim392/canAttempt377、release415是不同 transition。不可移除 half-open 独占、abort release 或 late real failure 的状态语义。

executor6、security-quote-batch7仅导入 `createRuntimeRefreshPlan` / `createRuntimeSecurityQuotePlan`。公开 planner 的诊断数组/通用接口源码不能当作新的默认删除池。runtimeCacheDecision230复用 cacheDecisionCore26。

planning-time cache TTL、scope排队后即时 TTL/claim、资源消费时 validation、stage 时 JSON privateCopy/freeze、flush 时 active/newer resource validation，分别处于不同时间/数据所有权边界。这是重复调用同一 validator，不是有几份完整 validator 可整块退休。

## 6. 最小可执行完整切面（最多八项）

1. 从当前 §51 源身份冻结基线与契约；不能用旧246输入或旧800对替代当前证据。P1正确性语义优先于旧双模型 bug forecast。
2. 固定 private facade；收窄 App 所有业务 namespace loader/返回值，保持原 public barrel/export/source 文件；不改五 groups、target、minify 或 budget，不反向经过旧 barrel。
3. 两端点完成 private acquisition；共享原 validation，晚构造公共 legacy DTO；保留 request/error/now/getter 顺序和 Opaque/真实 class，刷新与详情两条 holdings 边都迁移。
4. resource 内部表示与 strict old codec 分离；原 make/read/stage/use/flush 校验和 private JSON copy/freeze 都有唯一明确 owner，不能靠 trust 名义删掉。
5. 完整旧 aggregate/resource/legacy NAV importer；编码 presence、保留 key/order/JSON bytes/未知字段和源 clocks，保持 selected 优先、foreign identity 隔离、旧单flag与损坏新槽规则。
6. official/holding/market typed evidence 与候选选择；保留金融计算、模型合法性、排序与时效；render、secondary、accuracy、通知、当前 holding projection 全接通，accuracy触发时机与Storage行为不顺带改变。
7. 一个兼容行投影配两个原语义外层 writer；原 active/newer/fundAcquired、异常、失败、取消、attempt 次数、未知字段和时钟不合并、不续期。
8. 对第4节逐项提交实际 retirement ledger：旧 caller 清零、必要规则新 owner、代码真正消失/共享/迁移/新增分别列明；只有完整闭合后才申请一次有限最终候选构建测量。若仍只是转移 generic importer/验证或多添codec，不继续把骨架扩展视为材料性进展。

当前架构资格：可作为受控设计研究，但尚无材料性立项依据。建议先把上述逐函数 ledger 与完整 diff 对齐，再决定是否实现/测量；不是默认请求预算豁免，也不是继续做无界 helper/参数扫描。

## 7. 读取范围与复核方法

下列是本次有限材料性审查实际聚焦的内容范围，非声称全程序逐行审计；SHA 清单覆盖的文件不自动等于其全文被业务审查。

| 文件 | 人工审查读取范围 |
| --- | --- |
| AGENTS.md | 全文 |
| next-http README / REPORT / FIELD_LEDGER，pipeline-boundaries README，两个原 Temp协议 | 全文；REPORT分段至EOF，FIELD_LEDGER分段至EOF |
| M3_STATUS.md | §51及相邻收束说明；其全文只作行数/SHA输入，不宣称全文重审 |
| App.js | imports/生产入口；115–157、583–713、765–990、1013–1056、1171–1218、1377–1466；相关函数名与全js调用搜索 |
| eastmoney-estimate.js / fund-holdings.js | 全文94/84行 |
| worker-contract.js | 全文245行 |
| quote-normalizer.js | 全文471行，分段读取 |
| refresh-resource-cache.js | 全文272行 |
| refresh-plan.js / refresh-runtime.js / generation-resource-scope.js | 全文307/264/129行 |
| refresh-execution.js | imports、plan/read/valid、81–183、holdings/model claim与stage/flush/发布相关段；函数/调用全文件rg |
| holdings-estimate.js | export/call搜索，latestOfficialNavBase/apply/compose（137–215） |
| fund-model-enrichment.js | 全文62行 |
| source-registry.js | descriptor/public符号搜索；281–470状态机实现及其委托 |
| refresh-coordinator.js | 121–264，确认公开协调器委托相同health函数；实际App不用此公开入口 |
| accuracy.js / holding-quote-amounts.js | 全文83行/全文 |
| overseas-model.js / security-quote-batch.js / notification-policy.js | import/export/调用与已指认金融/取消/eligibility边界；不声称本轮对三文件所有输入全集重审 |
| build-site.mjs | grouping/build配置与原配方相关段，不执行；不修改 |
| app-chunks.json / business-features产物 | 全文；business-runtime/post-integrity及其入口只检视import/export声明与静态/动态边，不声称新完整AST证明 |

可重查静态边的只读方法：`rg -n 'normalizeHoldingRow|normalizeWorkerEstimateRow|parseWorkerEnvelope|buildFundQuoteCandidates|normalizeEstimateQuote|normalizeOfficialNavQuote|normalizeMarketModelQuote|normalizeHoldingLookthroughQuote|selectPreferredQuote|legacyFreshnessFromQuote|normalizeCachedQuote|normalizeFundQuoteFreshness' js --glob '*.js'`；`rg -n 'createRefreshPlan|createSecurityQuotePlan|createRuntimeRefreshPlan|createRuntimeSecurityQuotePlan|claimSource|canAttempt|sourceHealth|recordSource' js/runtime js/App.js`。这类结果证明直接文本调用/绑定，不是动态行为等价证明。

## 8. 读取时 SHA-256 库存

所有相对路径基于 `D:/AI项目/FundVal`；App.js 是当前 Windows 文件路径，build grouping规范使用小写 `js/app.js`。SHA针对实际文件原字节，不作CRLF归一化。清单不是一个原子全仓冻结，也不是根工作树postflight完整身份收据；仅定位本有限报告的读取对象。没有相加这些原文件大小作为收益。

```text
c22811307c091027b041e900fe7ff9feb2d515cc970396bb1498a4196cd4e3ae  AGENTS.md
893fc80ee51fad3400f8fbfe066208f3b46aa0213c956753b1656471121be3a9  js/App.js
5ed4a84b2d513c7289afd5facfe961f86ccc9d01653e72915a96c5bb5c5bd1d6  js/eastmoney-estimate.js
cf973abf1bd30dc1cf3b2f0095d66cb70a8d368c2278c6b7c2c5bfae0c8894db  js/fund-holdings.js
80ae266916367e43168d8ac7dd3be6d4f916ce66264adc47ef5ffda48fcba276  js/holdings-estimate.js
90da60c7732219ab6f9fa30f98493ef17aa0460251ee4ff30d2a61572c41838e  js/runtime/fund-model-enrichment.js
6f372642cbc45505d7b8066dff307c0e41aa9cf43ec5b95677af530ffb6be895  js/overseas-model.js
92bffb2ec5a65dd5555cddd8aab779b9febccaf8a8538e2719a1b771274c9a2e  js/accuracy.js
8c1f92acda542ba8129651748469b0394c9fe84565097f61bc9b70beae937240  js/runtime/business-features.js
54bab1e12f3127b8d28b98185175864ea4dc420b2c862954ab542b3293aa2b44  js/runtime/worker-contract.js
2268033d6f6852ac6b112b7f6ee6611f3788a4936ba88556df8ca0257cf1d07a  js/runtime/quote-normalizer.js
7f0103a803f83b31df0631cb3a7c53949e7f80259c909becf4eccc6ce0fb6231  js/runtime/refresh-resource-cache.js
462a76335cb145af061d2f9783f1bfaf0e93a9053ed757bbde2b45a792d76afe  js/runtime/refresh-execution.js
93d0df74d802b0b5cd1742dc763a1689cd636a381ace93138815c3446dec6fb5  js/runtime/refresh-plan.js
a8b20f6f2bbe355baf741e279e3bd8ed921c29189667fffc45d5e1730f676cff  js/runtime/refresh-runtime.js
088cf558a229731d64e0e824ccbb6319f91e9d0b678af7c651575d5468ce36c4  js/runtime/refresh-coordinator.js
40795e1a3c19be86e8e828d58dfcca75c11e18c946ced8da8abb4b9871d1a9bc  js/runtime/source-registry.js
6a944c6f279f865409ef57587bd4d80610b8a1786f5b3f8dabb18eea4317d529  js/runtime/security-quote-batch.js
66bdb6c89399ded70f9566a0f797a842f74ee8095cbce2447db96b80f7f959ff  js/runtime/generation-resource-scope.js
0b885a19013db710005ecdd247b95ed317c4caec4f39773fd84959727d5f17b1  js/runtime/holding-quote-amounts.js
b55794b7cf7a19b7ca67928feb7ad419e6eb9901b8d53595d233b97b6fff49e4  js/runtime/notification-policy.js
51a4d35902ad2e6510dd3e82fea7198a12a9b722ef3098c791aeb4c8327ac9a4  scripts/build-site.mjs
d235c4cc7a5b76394bca0c5505af7655cee857296f1763f0ed4a6dade5c1d8d8  site/js/app-chunks.json
f66826105e94a4e52c4fad04dce7b8715dce18f2c3b55ffb82424dd34d95344a  site/js/chunks/business-features-CEidwiga.js
631ef9288047589b4eaa2f4421dc1735d19e5dd81464a55e354483d7086d6a7c  site/js/chunks/business-runtime-CXdkJSaR.js
845070acb63dd2e1cf78ddf79107d5f74a4a569e6342e01128a37eea0bb32142  site/js/chunks/post-integrity-CMfw74KX.js
fcb84209ae106ba2401448dbbef7a4116b0ba9ea8c7e5906b27d01214d78db78  docs/v16.0.0/M3_STATUS.md
c034ae3a5073c8d301c014e157ab2c85dbdf9c3c2597865c864a3060763400b5  docs/v16.0.0/performance-evidence/pipeline-boundaries-20261022/README.md
2df141bf5bc2a237a0f791f0bcd1b40934978e8170bf02fa39d360c3e0e9b344  docs/v16.0.0/performance-evidence/worker-seam-20261022/next-http-boundary/README.md
86d8447d5c01f5a570f3faced296ea05bd43997f66a85b2b71b306a8af6c037a  docs/v16.0.0/performance-evidence/worker-seam-20261022/next-http-boundary/REPORT.md
70d5df26b3c9c37c8069ec69df1a9249726d77c448f09cb1dd027619885c6136  docs/v16.0.0/performance-evidence/worker-seam-20261022/next-http-boundary/FIELD_LEDGER.json
22e3b59a1c374c9e2a4c5f77f780fcc059b2de79dee1189310c2011e22d624eb  C:/Users/84046/AppData/Local/Temp/fundval-private-pipeline-20261022-ab87350b1b/PROTOCOL.md
1866899b7be5f02cfc27079b04ac2ac2d3b4ffa75c7398f9e723e54acd022ddf  C:/Users/84046/AppData/Local/Temp/fundval-private-pipeline-20261022-ab87350b1b/PUBLIC_BOUNDARY_PROTOCOL.md
```

报告写入后，使用只读 Get-FileHash 逐项核对以上 33 条 SHA，全部与实际文件一致。此检查不是业务测试或全仓 postflight。唯一写入仍是本报告。

本报告完成后停止；不自行开展下一候选、性能测量或下一轮任意输入修复。
