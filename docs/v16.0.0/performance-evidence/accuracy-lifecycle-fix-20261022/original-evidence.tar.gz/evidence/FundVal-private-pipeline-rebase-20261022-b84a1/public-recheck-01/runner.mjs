import { makeCase } from './cases.mjs';
function run(api,spec,control=null){
  const trace=[];let tracing=true;
  const labels=new WeakMap(),proxies=new WeakMap();
  const symbolKey=value=>Symbol.keyFor(value)===undefined?String(value):`Symbol.for(${Symbol.keyFor(value)})`;
  const keyOf=value=>typeof value==='symbol'?{kind:'symbol',value:symbolKey(value)}:{kind:'string',value:String(value)};
  const event=(kind,value)=>{if(tracing)trace.push({op:kind,value});};
  const opaqueSymbol=Symbol('synthetic opaque metadata');
  const sentinel=new TypeError('synthetic getter sentinel');
  const contractSentinel=new api.wire.WorkerContractError('WORKER_ROW_INVALID');
  const context={event,opaqueSymbol,sentinel,contractSentinel,sentinels:[sentinel,contractSentinel]};
  const input=makeCase(api.fixtures,api.wire,context,spec.id);
  function proxied(value,path){
    if(value===null||typeof value!=='object'||value instanceof Date)return value;
    if(proxies.has(value))return proxies.get(value);
    const proxy=new Proxy(value,{
      get(target,key,receiver){if(tracing)trace.push({op:'get',path,key:keyOf(key)});return proxied(Reflect.get(target,key,receiver),`${path}.${typeof key==='symbol'?symbolKey(key):String(key)}`);},
      ownKeys(target){if(tracing)trace.push({op:'ownKeys',path});return Reflect.ownKeys(target);},
      getOwnPropertyDescriptor(target,key){if(tracing)trace.push({op:'getOwnPropertyDescriptor',path,key:keyOf(key)});return Reflect.getOwnPropertyDescriptor(target,key);},
    });
    proxies.set(value,proxy);labels.set(value,path);labels.set(proxy,path);return proxy;
  }
  const payload=proxied(input.payload,'payload'),row=proxied(input.row,'row');
  const options=proxied(input.options,'options'),normalizeOptions=proxied(input.normalizeOptions,'normalizeOptions');
  let output,error=null;
  event('phase','invocation.begin');
  try{
    if(control==='eager-source')void payload.source;
    if(control==='extra-clock')Number(options.now);
    if(spec.operation==='parse')output=api.wire.parseWorkerEnvelope(payload,options);
    else if(spec.operation==='normalize')output=api.estimates.normalizeEstimateRow(row,normalizeOptions);
    else if(spec.operation==='sequence'){
      event('phase','envelope.begin');
      const envelope=api.wire.parseWorkerEnvelope(payload,options);
      event('phase','envelope.end');
      event('phase','second-validation-normalize.begin');
      output=envelope.items.map(item=>api.estimates.normalizeEstimateRow(item,{wireVersion:envelope.wireVersion,fetchedAt:envelope.fetchedAt,now:input.options.now}));
      event('phase','second-validation-normalize.end');
    } else throw new Error('Unknown declared operation');
    if(control==='drop-opaque'){delete output.opaqueEvidence;delete output[opaqueSymbol];}
    event('phase','invocation.return');
  }catch(actual){error=actual;event('phase','invocation.throw');}
  // This exact copy is the invocation trace. All descriptor/output inspection below is outside it.
  const invocationTrace=trace.map(item=>({...item,key:item.key?{...item.key}:undefined}));
  tracing=false;
  let nextId=1;const seen=new WeakMap();
  function snapshot(value){
    if(value===null)return {type:'null'};
    if(value===undefined)return {type:'undefined'};
    if(typeof value==='number')return {type:'number',value:Number.isNaN(value)?'NaN':Object.is(value,-0)?'-0':value===Infinity?'+Infinity':value===-Infinity?'-Infinity':String(value)};
    if(typeof value==='string'||typeof value==='boolean')return {type:typeof value,value};
    if(typeof value==='symbol')return {type:'symbol',value:symbolKey(value)};
    if(typeof value==='bigint')return {type:'bigint',value:String(value)};
    if(typeof value==='function')return {type:'function'};
    if(seen.has(value))return {ref:seen.get(value)};
    const id=nextId++;seen.set(value,id);
    const keys=Reflect.ownKeys(value);
    const properties=keys.map(key=>{
      const descriptor=Object.getOwnPropertyDescriptor(value,key);
      const entry={key:keyOf(key),enumerable:descriptor.enumerable,configurable:descriptor.configurable};
      if(Object.hasOwn(descriptor,'value'))Object.assign(entry,{kind:'data',writable:descriptor.writable,value:snapshot(descriptor.value)});
      else Object.assign(entry,{kind:'accessor',get:typeof descriptor.get==='function',set:typeof descriptor.set==='function'});
      return entry;
    });
    return {type:Array.isArray(value)?'array':'object',id,inputOrigin:labels.get(value)||null,frozen:Object.isFrozen(value),ownKeys:keys.map(keyOf),properties};
  }
  const errorData=error?{name:error.name,code:error.code??null,message:error.message,
    instanceofError:error instanceof Error,instanceofWorkerContractError:error instanceof api.wire.WorkerContractError,
    sentinelIdentity:context.sentinels.includes(error),ownKeys:Reflect.ownKeys(error).map(keyOf)}:null;
  const result={id:spec.id,operation:spec.operation,expected:spec.expected,trace:invocationTrace,
    output:error?null:snapshot(output),error:errorData};
  result.expectedOutcomeMatched=spec.expected==='return'?error===null:spec.expected==='sentinel'?!!errorData?.sentinelIdentity:
    errorData?.code===spec.expected&&errorData?.instanceofWorkerContractError===true;
  return result;
}
export { run };
