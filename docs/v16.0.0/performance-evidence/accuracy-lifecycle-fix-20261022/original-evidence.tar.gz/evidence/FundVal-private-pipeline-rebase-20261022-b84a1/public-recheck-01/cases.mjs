const rows = [
  ['e-v1-official','parse','return'], ['e-v2-intraday','parse','return'], ['e-v1-mixed','parse','return'],
  ['e-v2-mixed-no-reason','parse','WORKER_PARTIAL_SEMANTICS_INVALID'], ['e-v2-partial-accounted','parse','return'],
  ['e-schema-string','parse','WORKER_SCHEMA_UNSUPPORTED'], ['e-missing-capability','parse','WORKER_METADATA_INVALID'],
  ['e-invalid-generated','parse','WORKER_METADATA_INVALID'], ['e-metadata-before-row','parse','WORKER_METADATA_INVALID'],
  ['e-duplicate-code','parse','WORKER_DUPLICATE_CODE'], ['e-unrequested-code','parse','WORKER_ACCOUNTING_INVALID'],
  ['e-returned-count','parse','WORKER_ACCOUNTING_INVALID'], ['e-unavailable-accounting','parse','WORKER_ACCOUNTING_INVALID'],
  ['e-top-unavailable-row','parse','WORKER_STATUS_INVALID'], ['e-alias-conflict','parse','WORKER_ALIAS_CONFLICT'],
  ['e-canonical-null','parse','WORKER_ALIAS_CONFLICT'], ['e-zero','parse','return'], ['e-negative-zero','parse','return'],
  ['e-numeric-strings','parse','return'], ['e-holdings-model','parse','return'], ['e-model-coverage','parse','WORKER_MODEL_EVIDENCE_INVALID'],
  ['e-qdii-future','parse','return'], ['e-qdii-uncertainty','parse','WORKER_MODEL_EVIDENCE_INVALID'],
  ['h-v1','parse','return'], ['h-v2','parse','return'], ['h-duplicate','parse','HOLDINGS_DUPLICATE_IDENTITY'],
  ['h-total-weight','parse','HOLDINGS_TOTAL_RATIO_EXCEEDED'], ['h-too-many','parse','HOLDINGS_TOO_MANY_ROWS'],
  ['h-invalid-date','parse','HOLDINGS_REPORT_DATE_INVALID'], ['h-v2-missing-market','parse','HOLDINGS_ROW_INVALID'],
  ['h-partial-no-reason','parse','WORKER_PARTIAL_SEMANTICS_INVALID'], ['h-partial-reason','parse','return'],
  ['h-v1-empty','parse','return'], ['h-unavailable-empty','parse','return'], ['null-payload','parse','WORKER_PAYLOAD_INVALID'],
  ['invalid-endpoint','parse','WORKER_PAYLOAD_INVALID'], ['tail-source-getter','parse','return'],
  ['tail-source-sentinel','parse','sentinel'], ['tail-report-sentinel','parse','sentinel'],
  ['row-error-before-tail','parse','WORKER_ALIAS_CONFLICT'], ['metadata-before-row-and-tail','parse','WORKER_METADATA_INVALID'],
  ['now-object','parse','return'], ['now-date-subclass','parse','return'], ['simulated-http-changing-date','sequence','return'],
  ['public-invalid-safe-rescue','normalize','return'], ['public-changing-getters','normalize','return'],
  ['public-late-type-sentinel','normalize','sentinel'], ['public-early-code-sentinel','normalize','sentinel'],
  ['public-schema-unsupported','normalize','WORKER_SCHEMA_UNSUPPORTED'], ['public-opaque','normalize','return'],
  ['public-invalid-identity-short-circuit','normalize','return'], ['tail-fetched-at-changing','parse','return'],
  ['h-source-required','parse','WORKER_ROW_INVALID'], ['requested-duplicate','parse','WORKER_ACCOUNTING_INVALID'],
  ['items-not-array','parse','WORKER_PAYLOAD_INVALID'], ['h-returned-count','parse','WORKER_ACCOUNTING_INVALID'],
  ['initial-items-sentinel','parse','sentinel'], ['second-items-sentinel','parse','sentinel'],
  ['oversize-before-schema','parse','WORKER_PAYLOAD_INVALID'], ['schema-before-status','parse','WORKER_SCHEMA_UNSUPPORTED'],
  ['row-ownkeys-sentinel','normalize','sentinel'], ['row-descriptor-sentinel','normalize','sentinel'],
  ['wire-real-class-safe-rescue','normalize','return'], ['wire-fake-class-no-rescue','normalize','sentinel'],
];
export const specs = Object.freeze(rows.map(([id, operation, expected], index) => Object.freeze({ index: index + 1, id, operation, expected })));
export const controls = Object.freeze([
  { id: 'eager-source', target: 'metadata-before-row-and-tail', expectDifferences: ['trace','error'] },
  { id: 'extra-clock', target: 'now-object', expectDifferences: ['trace'] },
  { id: 'drop-opaque', target: 'public-opaque', expectDifferences: ['output'] },
]);
export function makeCase(F, api, context, id) {
  const { event, sentinel } = context;
  const NOW = F.WORKER_FIXTURE_NOW;
  let payload = F.estimatesV2(), endpoint = 'estimates', requestedCodes = ['000002'], now = NOW;
  let row = F.intradayRow(), wireVersion = 1;
  const partial = () => F.estimatesV2([F.intradayRow({ fallback_reason: 'partial_batch' })], {
    status: 'partial', requested: 2, returned: 1, unavailable: 1,
    unavailable_codes: ['000004'], unavailable_items: [F.unavailableRow()],
  });
  const getter = (object, key, fn) => Object.defineProperty(object, key, { enumerable: true, configurable: true,
    get() { event('getter', String(key)); return fn(); } });
  switch (id) {
    case 'e-v1-official': payload = F.estimatesV1(); requestedCodes = ['000001']; break;
    case 'e-v2-intraday': break;
    case 'e-v1-mixed': payload = F.estimatesV1([F.intradayRow(), F.officialRow()]); requestedCodes = ['000002','000001']; break;
    case 'e-v2-mixed-no-reason': payload = F.estimatesV2([F.intradayRow(), F.officialRow()], { status: 'degraded' }); requestedCodes = ['000002','000001']; break;
    case 'e-v2-partial-accounted': payload = partial(); requestedCodes = ['000002','000004']; break;
    case 'e-schema-string': payload.schema_version = '2'; break;
    case 'e-missing-capability': payload.capabilities = ['holdings_v2']; break;
    case 'e-invalid-generated': payload.generated_at = '2026-09-30 13:59:30'; break;
    case 'e-metadata-before-row': payload.generated_at = 'bad'; payload.items[0].est_nav = 9; break;
    case 'e-duplicate-code': payload = F.estimatesV2([F.intradayRow(),F.intradayRow()]); break;
    case 'e-unrequested-code': payload = F.estimatesV2([F.officialRow()]); break;
    case 'e-returned-count': payload.returned = 2; break;
    case 'e-unavailable-accounting': payload = partial(); payload.unavailable_codes = []; requestedCodes = ['000002','000004']; break;
    case 'e-top-unavailable-row': payload.status = 'unavailable'; break;
    case 'e-alias-conflict': payload.items[0].est_nav = 9; break;
    case 'e-canonical-null': payload.items[0].value_nav = null; payload.items[0].est_nav = 9; break;
    case 'e-zero': case 'e-negative-zero': {
      const change = id === 'e-zero' ? 0 : -0;
      payload = F.estimatesV2([F.intradayRow({ value_nav: 1, estimate_nav: 1, est_nav: 1, estimate_change: change, est_change: change })]); break;
    }
    case 'e-numeric-strings': payload = F.estimatesV2([F.intradayRow({ base_nav:'1',last_nav:'1',value_nav:'1.01',estimate_nav:'1.01',est_nav:'1.01',estimate_change:'1%',est_change:'1%' })]); break;
    case 'e-holdings-model': payload = F.estimatesV2([F.holdingsModelRow()]); requestedCodes = ['000003']; break;
    case 'e-model-coverage': payload = F.estimatesV2([F.holdingsModelRow({ coverage:49,model_coverage:49 })]); requestedCodes = ['000003']; break;
    case 'e-qdii-future': payload = F.estimatesV2([F.qdiiRow({ target_nav_date:'2026-10-01',value_date:'2026-10-01' })]); requestedCodes = ['000005']; break;
    case 'e-qdii-uncertainty': payload = F.estimatesV2([F.qdiiRow({ uncertainty:{mae:-1,error_p80:1,direction_accuracy:50} })]); requestedCodes = ['000005']; break;
    case 'h-v1': case 'h-v2': case 'h-duplicate': case 'h-total-weight': case 'h-too-many': case 'h-invalid-date':
    case 'h-v2-missing-market': case 'h-partial-no-reason': case 'h-partial-reason': case 'h-v1-empty':
    case 'h-unavailable-empty': case 'h-source-required': case 'h-returned-count': {
      endpoint = 'holdings'; requestedCodes = ['000001']; payload = id === 'h-v1' ? F.holdingsV1() : F.holdingsV2();
      if (id === 'h-duplicate') payload = F.holdingsV2([F.holdingRows()[0],F.holdingRows()[0]]);
      if (id === 'h-total-weight') payload = F.holdingsV2(F.holdingRows().map(value => ({...value,ratio:20})));
      if (id === 'h-too-many') payload = F.holdingsV2(F.holdingRows(11));
      if (id === 'h-invalid-date') payload.report_date = '2026-02-30';
      if (id === 'h-v2-missing-market') payload = F.holdingsV2([{code:'000660',name:'合成证券',ratio:0}]);
      if (id === 'h-partial-no-reason') payload.status = 'partial';
      if (id === 'h-partial-reason') payload = F.holdingsV2(F.holdingRows().map(value => ({...value,status:'ok',reason:'partial_batch'})),{status:'partial'});
      if (id === 'h-v1-empty') payload = F.holdingsV1([],{status:undefined});
      if (id === 'h-unavailable-empty') payload = F.holdingsV2([],{status:'unavailable'});
      if (id === 'h-source-required') payload.source = '';
      if (id === 'h-returned-count') payload.returned = 99;
      break;
    }
    case 'null-payload': payload = null; break;
    case 'invalid-endpoint': endpoint = 'other'; break;
    case 'tail-source-getter': getter(payload,'source',() => 'synthetic-late-source'); break;
    case 'tail-source-sentinel': getter(payload,'source',() => {throw sentinel;}); break;
    case 'tail-report-sentinel': getter(payload,'report_date',() => {throw sentinel;}); break;
    case 'row-error-before-tail': payload.items[0].est_nav = 9; getter(payload,'source',() => {throw sentinel;}); break;
    case 'metadata-before-row-and-tail': payload.generated_at = 'bad'; getter(payload.items[0],'name',() => {throw sentinel;}); getter(payload,'source',() => {throw sentinel;}); break;
    case 'now-object': now = { [Symbol.toPrimitive](hint) { event('clock-coercion',hint); return NOW; } }; break;
    case 'now-date-subclass': now = new (class extends Date { getTime() { event('clock-getTime','stable'); return NOW; } })(NOW); break;
    case 'simulated-http-changing-date': {
      let count = 0;
      now = new (class extends Date { getTime() { event('clock-getTime',++count); return count === 1 ? Date.parse('2026-09-30T02:05:00Z') : Date.parse('2026-09-30T01:00:00Z'); } })(NOW);
      payload = F.estimatesV2([F.intradayRow({source_time:'2026-09-30T10:04:00+08:00',estimate_time:'2026-09-30T10:04:00+08:00',est_time:'2026-09-30T10:04:00+08:00'})],{fetched_at:'2026-09-30T02:04:30Z',generated_at:'2026-09-30T02:04:30Z'}); break;
    }
    case 'public-invalid-safe-rescue': row = {code:'000002',name:'合成缺失',value_nav:NaN}; break;
    case 'public-changing-getters': {
      let codeReads=0,typeReads=0; const diagnostics={primary_reason:null,model_reason:null};
      getter(row,'code',() => ['000002','000003','000004'][codeReads++]);
      getter(row,'type',() => typeReads++ === 0 ? 'wire type' : 'presentation type');
      getter(row,'diagnostics',() => diagnostics); getter(row,context.opaqueSymbol,() => 'synthetic value'); break;
    }
    case 'public-late-type-sentinel': { let count=0; getter(row,'type',() => {if (++count===2) throw context.contractSentinel; return 'wire type';}); break; }
    case 'public-early-code-sentinel': getter(row,'code',() => {throw sentinel;}); break;
    case 'public-schema-unsupported': wireVersion = 3; break;
    case 'public-opaque': row.opaqueEvidence = {synthetic:true,missing:null,zero:-0}; row[context.opaqueSymbol] = 'synthetic opaque value'; row['2']='two';row['1']='one';Object.defineProperty(row,'nonEnumerableOpaque',{value:'not spread',enumerable:false});break;
    case 'public-invalid-identity-short-circuit': row={get code(){event('getter','early-code');return 'bad';},get bzdm(){event('getter','must-not-read-bzdm');throw sentinel;}}; break;
    case 'tail-fetched-at-changing': { let count=0; getter(payload,'fetched_at',() => ++count <= 2 ? '2026-09-30T05:59:30Z' : 'synthetic-late-fetched'); break; }
    case 'requested-duplicate': requestedCodes = ['000002','000002']; break;
    case 'items-not-array': payload.items = {}; break;
    case 'initial-items-sentinel': getter(payload,'items',() => {throw sentinel;});payload.schema_version='bad';break;
    case 'second-items-sentinel': {let count=0;const original=payload.items;getter(payload,'items',() => {if(++count===2)throw sentinel;return original;});payload.generated_at='bad';break;}
    case 'oversize-before-schema': payload.items=Array.from({length:51},()=>F.intradayRow());payload.schema_version='bad';payload.generated_at='bad';break;
    case 'schema-before-status': payload.schema_version='bad';payload.status='bad';payload.generated_at='bad';break;
    case 'row-ownkeys-sentinel': row=new Proxy(row,{ownKeys(){event('custom-ownKeys','sentinel');throw sentinel;}});break;
    case 'row-descriptor-sentinel': row.opaqueProbe='synthetic';row=new Proxy(row,{getOwnPropertyDescriptor(target,key){if(key==='opaqueProbe'){event('custom-descriptor','sentinel');throw sentinel;}return Reflect.getOwnPropertyDescriptor(target,key);}});break;
    case 'wire-real-class-safe-rescue': getter(row,'base_nav',()=>{throw context.contractSentinel;});break;
    case 'wire-fake-class-no-rescue': {const fake=new Error('WORKER_ROW_INVALID');fake.name='WorkerContractError';fake.code='WORKER_ROW_INVALID';context.sentinels.push(fake);getter(row,'base_nav',()=>{throw fake;});break;}
    default: throw new Error(`Undeclared case ${id}`);
  }
  return { payload, row, options:{endpoint,requestedCodes,now}, normalizeOptions:{wireVersion,now,fetchedAt:'2026-09-30T05:59:30Z'} };
}
