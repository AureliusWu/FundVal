# Shared wire-core public boundary check

Declared after the first Temp-only source edit and one successful node --check (tool history, no separate log), BEFORE the functional characterization below. This is implementation-stage evidence, not final pipeline qualification or a new size probe.

Single changed candidate path: js/runtime/worker-contract.js. Original validation statement text is unchanged; a new canonical evidence function returns only already-computed locals plus the input row, a legacy finisher preserves the original return literal, and the exact public signature/defaults wrap them. Future private transport must still preserve second validation/clock/error semantics. No private HTTP or rest-of-pipeline migration has happened yet.

Use exact immutable original64 specs/factory and pure runner from the prior old/qualification workspace. Verify their hashes, copy them here, freeze the independent original14-source closure, and verify every unchanged candidate dependency. Old raw SHA80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751 is the stored control.

One functional command:64 fresh frozen OLD calls +64 candidate public calls +3 old negative controls =131. Compare full traces/output/error/key-order/symbol/null/NaN/-0/frozen/reference/real-class identity/sentinels to stored controls, without filtering candidate trace or changing cases. Keep every expected error. Network/real localStorage/sessionStorage are forbidden guards. This is generic/public64 only, NOT the previous specialized52 and NOT a new private evidence-flow test.

Before/after re-enumerate candidate246 files and old14 source; original parser/HTTP normalizer dependencies apart from the single allowed worker file must match. Capture raw results and actual outer/child native output/exit/time. All failed outputs remain; any implementation repair is a separately recorded version, not a resampling/benchmark retry. No build/minifier/gzip/latency/browser/install/network/root write or adoption. Stop this check after the one command; continue the same full candidate only under its main protocol.
