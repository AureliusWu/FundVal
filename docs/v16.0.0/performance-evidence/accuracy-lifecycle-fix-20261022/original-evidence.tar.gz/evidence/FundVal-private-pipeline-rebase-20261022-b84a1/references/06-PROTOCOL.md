# One complete private EvidenceBook pipeline prototype

2026-10-22, before source copy or edits. This is an isolated implementation workspace for ONE complete candidate, not adoption, another minifier/helper sweep or M3 exit. Prior same-file seam qualification is an independent enabling reference, not a saving to add to this candidate.

## Fixed control and objective

- Repository: D:/AI项目/FundVal, application15.0.2, M3 IN_PROGRESS.
- Copy the exact archived246 nonhistorical inputs from C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/measured-current-inputs. Verify original source rows in sibling postflight/postflight.json before and after copying. Do not use git archive HEAD: it would lose the existing dirty implementation.
- Complete private slice: Worker envelope/rows -> second temporal validation and genuine-class rescue -> immutable primary Quote + field-presence evidence -> resource ingress/legacy egress -> raw aggregate import -> official and ordered effective model composition -> selected Quote/current-holding projection -> UI/accuracy/notification and the TWO legacy outer writer policies.
- Retirement target is repeated legacy transport/materialization from the default graph, not removal of validation algorithms or public source APIs. Actual measured NET all-gzip must be <=77227.7 (integer<=77227); cold<=52241. Present root84187/44699 needs6960 integerB. No saving is presumed or inferred from raw/field/chunk sizes.

## Architecture contract

- Plain internal evidence records own canonical financial values, immutable source Quote, independent official/model evidence and ordered extension/presence state. No string-encoded code, eval, HTML/data/code-as-asset budget evasion, Proxy trick or compressed executable payload.
- Split wire validation from its public legacy materializer, preserving the original public signature/defaults, exact validation reads/short circuits, late row spread, error class binding and error behavior. Private HTTP can consume canonical state, but must still implement the second validation/clock semantics; a brand is not permission to skip untrusted validation.
- Public original modules/API names and identities remain available in source/site. The default App may import a new narrow private facade rather than the public business namespace; no reverse barrel backedge or escaping old namespace. The five ORIGINAL loading groups, build recipe/minifier/ES2022/startup phases remain unchanged; a private facade must not create another named group or bring business/cloud/diagnostics/OCR into earlier phases.
- Existing persisted resource rows/aggregate data[] shapes, exact null/0/-0/NaN/absence/JSON semantics, ordering, wildcard and same-named trusted overrides remain. Resource whitelist is NOT aggregate whitelist. Fields used by Quote before resource pruning cannot be dropped early.
- source_quote and selected quote identity checks both remain. Model slot state must reproduce old ordered effective shared-est writes and simultaneous flags, not silently fix them. Rendering/holding edits use current repository holdings and a later clock.
- Refresh writer and edit writer retain distinct top-unknown, acquisition-clock, error and write-attempt policies. Stage/read/use/flush validations and cancellation/one-write behavior remain. Schema3/Gist/tombstone/device/legacy/OCR/Bridge/privacy behavior is not changed.

## Allowed implementation surface

Only the Temp candidate may change: js/runtime/worker-contract.js, js/eastmoney-estimate.js, js/fund-holdings.js, js/runtime/quote-normalizer.js, js/runtime/refresh-resource-cache.js, js/runtime/refresh-execution.js, js/holdings-estimate.js, js/runtime/fund-model-enrichment.js, js/app.js, js/accuracy.js, and one new narrow js/runtime/valuation-runtime.js facade if needed. Original business-features public export bindings stay intact. Other files, dependencies, manifests, version, SW, build configuration and budgets stay byte-identical. Any necessary expansion must first be explicitly recorded and reviewed; no silent extra source surface.

Normal implementation can use bounded RED/GREEN contract repairs, retaining every failed source/result separately; it cannot change accepted old behavior or acceptance cases to force PASS. Final qualification begins only after the complete slice and final source freeze. No per-stage gzip builds or parameter probes; no partial-stage root adoption. Syntax/functional characterization may run independently without claiming complete qualification.

## Controls and progression

1. Freeze original source/fixtures and immutable old machine controls. Reuse original64/52 Worker and public HTTP contracts. Independently add old-real-source A08/R01/R03/M04/S01/S03/C01 cases BEFORE results; two agents have disjoint new Temp workspaces. No copied algorithm as oracle.
2. Implement the shared validation/public-finisher boundary, then private acquisition and evidence; preserve complete intermediate behavior. Characterize this boundary without measuring partial gzip.
3. Close resource/aggregate codecs, ordered model/UI/accuracy projections and separate writer policies. Keep compatibility exceptions and field presence explicit. Partial work is NOT a size strategy qualified for root.
4. Prove actual default import graph no longer retains retired constructors while original public APIs remain available and match old controls. If the old constructors are merely relocated or still reached through raw cache import, record incomplete retirement.
5. Only a complete candidate receives one finite original-recipe three-build-per-side qualification with complete native output/artifact inventory and unchanged installed inputs, then full project tests/check/E2E/security, fixed fresh performance protocol and exact CI as required before any root adoption/release. No old800 inheritance for changed code. A measured all-budget miss remains FAIL and does not trigger a minifier/helper sweep.

No real financial/provider/Storage/cloud writes, screenshot/OCR access, network, install, browser, commit/push/deploy/version bump or root source/site/config mutation is authorized by this protocol. This isolated functional design does not grant a new overall financial-data trust verdict; independent real-source/date/device/production evidence remains separate and unresolved here.

## Evidence-driven boundary correction, 2026-10-22T06:00Z

The original text above is retained as the pre-implementation protocol. OLD M04 characterization subsequently exposed a reachable provenance defect: holdings composition first installs its contribution, then the real current mainland CSI300 rule can install a market model over the shared est_* values without retiring the holdings flag. The holdings wrapper consequently reads market values and inherits est_model, despite its quarterly source identity. This is not a requirement from the human user to preserve incorrect source attribution.

Consequently the architecture-contract sentence requiring reproduction of the simultaneous effective model flags/shared writes is now limited to immutable OLD characterization and unchanged public wire-boundary testing. It MUST NOT be used to grant adoption or overall data-trust qualification to that defect. The completed 64-case wire factor remains a partial boundary only; there is no implementation of the private HTTP/cache/model/App pipeline yet.

Before continuing a complete compression candidate, decide and independently regress the model provenance policy, including the legacy missing-selected-Quote cache path. Keep that correction separately identifiable from compression equivalence. Retain all old results, including the A08 HK forecast native1 and M04 analysis native1; neither is a product/candidate PASS. The current evidence proves candidate provenance corruption is reachable, but does NOT prove an incorrect user-visible selected amount or production incident. No new root product edit, new baseline laundering, per-stage gzip build or root adoption follows from this addendum.
