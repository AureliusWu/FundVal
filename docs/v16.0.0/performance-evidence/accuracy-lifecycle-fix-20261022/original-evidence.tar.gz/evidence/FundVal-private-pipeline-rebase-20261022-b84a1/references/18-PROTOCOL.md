# Frozen protocol: same-file Worker header/items/tail source preparation

Created 2026-10-22 05:02:17 UTC, before any source copying or semantic modification.

Workspace: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351
Candidate source: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/candidate
Baseline input: C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/measured-current-inputs
Baseline raw inventory: C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/postflight/postflight.json (source.rows)

## Authorized single candidate
- Copy exactly source.rows excluding the 24 .codex-tmp/ historical outputs. Expect 246 archived source files; verify every source and copied byte length/SHA against the original rows, with no extras or missing source files.
- Only candidate/js/runtime/worker-contract.js, candidate/js/fund-holdings.js, and candidate/js/eastmoney-estimate.js may differ semantically from the archived snapshot.
- Same-file extraction only: header original lines 164-182, holdings items 185-193, estimate items 195-240, late tail original return 242-244. All helpers positional; no added default clock/coercion/cache/catch. Keep WorkerContractError and normalizeWorkerEstimateRow exactly unchanged. Preserve public parseWorkerEnvelope signature/default parameter destructuring; header before public endpoint dispatch, tail after item processing.
- New fixed entries: parseWorkerEstimateEnvelope and parseWorkerHoldingsEnvelope. Change only client import/call endpoints; preserve options.now single caller read and its phase/order.
- No added module paths, no Error-class movement, no reverse barrel imports, no build-script or five-group edits.

## Evidence to retain
- Immutable protocol; original inventory reference/raw rows; complete verified before inventory for snapshot and copied source; exact original three source files; after inventory with exactly three changed files; exact per-file unified diff and current three source files; static syntax command/stdout/stderr/exit receipts; source-preparation report.
- Source/byte inventory and static syntax checks only. No application evaluation, behavioral tests, builds, compression, dependency installation, network, browsers, performance pairs, commit, push, deployment, or version/budget changes.
- Do not edit D:/AI项目/FundVal root source/site/docs/dependencies. New evidence stays in this system-Temp workspace.
- This is only a prerequisite seam for a larger prospective pipeline. No 6960-byte net gzip qualification, final-strategy adoption, M3 exit, or release claim follows.
- Stop after preparation for parent review; further validation requires separate instruction.

