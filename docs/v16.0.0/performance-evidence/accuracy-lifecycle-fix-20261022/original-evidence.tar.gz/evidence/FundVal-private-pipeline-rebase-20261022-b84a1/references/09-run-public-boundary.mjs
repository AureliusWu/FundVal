import { readFile,writeFile,mkdir,copyFile,readdir } from 'node:fs/promises';
import { resolve,relative,dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
const dir=import.meta.dirname,sha=b=>createHash('sha256').update(b).digest('hex');
const stage=resolve(dir,'wire-public-boundary');
if(process.argv[2]!=='--child'){
 await mkdir(stage);
 const startedAt=new Date().toISOString(),args=[import.meta.filename,'--child'];
 const native=spawnSync(process.execPath,args,{cwd:dir,windowsHide:true,encoding:null,timeout:45000,maxBuffer:2_000_000});
 const stdout=native.stdout??Buffer.alloc(0),stderr=native.stderr??Buffer.alloc(0);
 for(const [kind,b]of [['stdout',stdout],['stderr',stderr]])await writeFile(resolve(stage,'native.'+kind),b,{flag:'wx'});
 const receipt={startedAt,endedAt:new Date().toISOString(),command:process.execPath,args,cwd:dir,exitCode:native.status,signal:native.signal,error:native.error?.message??null,scriptSha256:sha(await readFile(import.meta.filename)),protocolSha256:sha(await readFile(resolve(dir,'PUBLIC_BOUNDARY_PROTOCOL.md'))),stdout:{bytes:stdout.length,sha256:sha(stdout)},stderr:{bytes:stderr.length,sha256:sha(stderr)}};
 await writeFile(resolve(stage,'native.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(stdout.toString('utf8').trim());console.log(JSON.stringify(receipt));process.exitCode=native.status??98;
}else{
 const originalBase='C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1';
 const runnerBase='C:/Users/84046/AppData/Local/Temp/FundVal-worker-seam-qualification-20261022-a1';
 const candidate=resolve(dir,'candidate'),frozen=resolve(stage,'original');
 const json=async p=>JSON.parse(await readFile(p,'utf8'));
 const baselineRaw=await readFile(resolve(originalBase,'baseline-01.json'));
 assert.equal(sha(baselineRaw),'80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751');
 const stored=JSON.parse(baselineRaw),inventory=await json(resolve(originalBase,'frozen-inventory.json'));
 const helperHashes={'cases.mjs':'f9fc6e87ed2ccf5e2c316544f333e0197c0f5c94e36d001947c467bc6065db6d','cases.json':'c1ec7df0a66db3de6f756a9899b5d9c8e8b582d8a55384e08ab2fb46c553a644','runner.mjs':'e1dc1f70eb6220e6d8260a02f53e00247dcb42e606814e483420a28873d7f21a'};
 for(const [name,hash]of Object.entries(helperHashes)){const b=await readFile(resolve(runnerBase,name));assert.equal(sha(b),hash);await copyFile(resolve(runnerBase,name),resolve(stage,name));}
 await mkdir(frozen);
 for(const r of inventory.files){const original=resolve(originalBase,'frozen',r.path),b=await readFile(original);assert.equal(b.length,r.bytes);assert.equal(sha(b),r.sha256);const p=resolve(frozen,r.path);await mkdir(dirname(p),{recursive:true});await copyFile(original,p);}
 async function rows(base,part=''){const result=[];for(const e of await readdir(resolve(base,part),{withFileTypes:true})){const p=part?part+'/'+e.name:e.name;assert.equal(e.isSymbolicLink(),false);if(e.isDirectory())result.push(...await rows(base,p));else{assert.ok(e.isFile());const b=await readFile(resolve(base,p));result.push({path:p,bytes:b.length,sha256:sha(b)});}}return result.sort((a,b)=>a.path.localeCompare(b.path));}
 const before={candidate:await rows(candidate),original:await rows(frozen)};
 const original246=(await json(resolve(dir,'source-before.json'))).files;
 assert.equal(before.candidate.length,246);
 const changed=before.candidate.filter(r=>{const previous=original246.find(x=>x.path===r.path);return !previous||r.sha256!==previous.sha256||r.bytes!==previous.bytes;});
 assert.deepEqual(changed.map(r=>r.path),['js/runtime/worker-contract.js']);
 for(const r of inventory.files){const c=before.candidate.find(x=>x.path===r.path);assert.ok(c);if(r.path!=='js/runtime/worker-contract.js'){assert.equal(c.bytes,r.bytes);assert.equal(c.sha256,r.sha256);}}
 const oldText=await readFile(resolve(frozen,'js/runtime/worker-contract.js'),'utf8'),newText=await readFile(resolve(candidate,'js/runtime/worker-contract.js'),'utf8');
 const oldStart=oldText.indexOf('  if (!record(row))'),oldFinish=oldText.indexOf('  return {\n    ...row, code, name',oldStart);
 const newStart=newText.indexOf('  if (!record(row))'),newFinish=newText.indexOf('  return { row, code, name',newStart);
 assert.ok(oldStart>0&&oldFinish>oldStart&&newStart>0&&newFinish>newStart);
 assert.equal(newText.slice(newStart,newFinish),oldText.slice(oldStart,oldFinish));
 const oldEnd=oldText.indexOf('\n}\n',oldFinish)+3;
 assert.ok(newText.includes(oldText.slice(oldFinish,oldEnd)));
 const signature='export function normalizeWorkerEstimateRow(row, { wireVersion = 1, now = Date.now() } = {}) {';
 assert.equal(newText.split(signature).length,2);
 await writeFile(resolve(stage,'inputs.json'),JSON.stringify({before,helperHashes,changed,validationStatementSha256:sha(newText.slice(newStart,newFinish)),publicSignature:signature},null,2)+'\n',{flag:'wx'});
 const {run}=await import(pathToFileURL(resolve(stage,'runner.mjs')).href);
 const {specs,controls}=await import(pathToFileURL(resolve(stage,'cases.mjs')).href);
 assert.equal(specs.length,64);assert.equal(controls.length,3);
 const denied={fetch:0,localStorage:0,sessionStorage:0};
 globalThis.fetch=()=>{denied.fetch++;throw new Error('NETWORK_FORBIDDEN_PUBLIC_BOUNDARY');};
 for(const key of ['localStorage','sessionStorage'])Object.defineProperty(globalThis,key,{configurable:true,get(){denied[key]++;throw new Error('REAL_STORAGE_FORBIDDEN_PUBLIC_BOUNDARY');}});
 async function apiAt(base){return {wire:await import(pathToFileURL(resolve(base,'js/runtime/worker-contract.js')).href),estimates:await import(pathToFileURL(resolve(base,'js/eastmoney-estimate.js')).href),fixtures:await import(pathToFileURL(resolve(base,'test/fixtures/worker-contract-v16.js')).href)};}
 const old=await apiAt(frozen),current=await apiAt(candidate);
 assert.notEqual(old.wire.WorkerContractError,current.wire.WorkerContractError);
 const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b),results=[],negativeControls=[],failures=[];
 for(const spec of specs){const expected=stored.baseline.find(r=>r.spec.id===spec.id).frozen,freshOld=run(old,spec),next=run(current,spec);const match={oldStored:equal(freshOld,expected),candidateStored:equal(next,expected),candidateOld:equal(next,freshOld),expectedOutcome:freshOld.expectedOutcomeMatched&&next.expectedOutcomeMatched};results.push({spec,match,stored:expected,freshOld,candidate:next});if(!Object.values(match).every(Boolean))failures.push({id:spec.id,match});}
 for(const control of controls){const spec=specs.find(s=>s.id===control.target),actual=run(old,spec,control.id),expected=stored.negativeControls.find(c=>c.id===control.id).mutated,match=equal(actual,expected);negativeControls.push({control,actual,match});if(!match)failures.push({id:control.id,kind:'negative-control-mismatch'});}
 const after={candidate:await rows(candidate),original:await rows(frozen)};
 assert.deepEqual(after,before);
 if(Object.values(denied).some(Boolean))failures.push({kind:'forbidden-access',denied});
 const summary={status:failures.length?'FAIL':'PASS',genericCases:64,oldStoredMatches:results.filter(r=>r.match.oldStored).length,candidateStoredMatches:results.filter(r=>r.match.candidateStored).length,candidateOldMatches:results.filter(r=>r.match.candidateOld).length,negativeControlsMatched:negativeControls.filter(r=>r.match).length,invocations:131,denied,sourceUnchanged:true};
 const report={schema:1,kind:'implementation-stage-shared-wire-core-public-boundary',summary,results,negativeControls,failures,after,completePrivatePipeline:false,privateEvidenceHTTP:false,gzip:'NOT_RUN',adopted:false};
 const b=Buffer.from(JSON.stringify(report,null,2)+'\n');await writeFile(resolve(stage,'result.json'),b,{flag:'wx'});
 console.log(JSON.stringify({summary,failures,raw:{bytes:b.length,sha256:sha(b)},changed}));process.exitCode=failures.length?1:0;
}
