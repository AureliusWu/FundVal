# One bounded Worker seam behavior qualification

2026-10-22; declared before source copy or behavior execution in this new system Temp workspace. No old baseline/case/result edits, root edits, candidate source edits, builds, installs, compression, browser, network or real Storage are allowed.

Candidate: C:/Users/84046/AppData/Local/Temp/fundval-worker-seam-20261022-fc680351/candidate
Independent old baseline: C:/Users/84046/AppData/Local/Temp/FundVal-worker-baseline-20261022-a1
The candidate's source-preparation protocol/diffs were read; parent authorized exactly one behavioral qualification after static review, not adoption or a7KB claim.

## Immutable harness and comparisons

- Verify original baseline.mjs SHA25639d55ca60b37e11e041584d0504abd70423120664f070455e4d645c6a22a2a0c, cases.mjs f9fc6e87ed2ccf5e2c316544f333e0197c0f5c94e36d001947c467bc6065db6d, cases.json c1ec7df0a66db3de6f756a9899b5d9c8e8b582d8a55384e08ab2fb46c553a644 and baseline-01.json80792820d1fc2c69f72fc07512183fd5f9556cb222189159ce1fa442db62a751 before execution.
- runner.mjs contains the exact substring beginning `function run(api,spec,control=null){` and ending immediately before `const baseline=[];`, with only a makeCase import before it and `export { run };` after it. Preparation must compare the complete expected module bytes and runner substring hash; no edited copy of the runner may execute.
- Copy all14 frozen old source/package/fixture files byte-for-byte into new original/, and copy old cases files/result byte-for-byte to this workspace. Never run the old baseline top-level script. Verify the copied source closure/fixtures and preserve complete before/after candidate, old-baseline and selected-root inventories.
- For all64 fixed cases, call fresh frozen OLD generic API and CANDIDATE generic API independently. Compare each complete result against the stored old frozen result and each other: trace, own-key/order/descriptors, special values, frozen/reference markers, error name/code/message/class/sentinel identity and expected-outcome flag. Keep all expected error cases; no filtering.
- apiAt must import wire, normalizeEstimateRow and fixtures from the same chosen root. Candidate and old use their own public WorkerContractError class for sentinels/instanceof. Candidate fixture bytes must equal frozen fixture bytes. The full parse-then-normalize ChangingDate case remains in all64, including second validation safe rescue and3 clocks.

## Fixed endpoint entries

Select exactly52 cases: all parser cases except invalid-endpoint (51), plus simulated-http-changing-date sequence (1). Exclude exactly11 normalize-only cases because no endpoint entry is involved, and invalid-endpoint because fixed entries have no caller endpoint selector. Null/malformed payloads, accounting, partial, late tail and options clock cases stay included.

Select holdings endpoint solely from the predeclared case IDs starting h- (13 cases), estimates for the other39 selected cases. Never inspect the proxied options.endpoint to choose an endpoint. Candidate uses its exported fixed function directly as the runner's parser slot.

Independent OLD literal adapters are exactly:

    function oldEstimates(payload, { requestedCodes = [], now = Date.now() } = {}) {
      return oldWire.parseWorkerEnvelope(payload, { endpoint: 'estimates', requestedCodes, now });
    }
    function oldHoldings(payload, { requestedCodes = [], now = Date.now() } = {}) {
      return oldWire.parseWorkerEnvelope(payload, { endpoint: 'holdings', requestedCodes, now });
    }

They read requestedCodes then now, do not read caller endpoint, do not add a clock conversion, and call the independently frozen old generic implementation. Compare candidate-fixed against old-bound full results with NO trace normalization. A secondary old-bound-versus-stored-generic sanity check may remove only the one known options.endpoint get from the generic trace; output/error must remain identical. This removal is never applied to candidate-versus-old-bound comparison.

Run the same3 predeclared old negative controls once with the exact runner, comparing to stored controls to establish extraction sensitivity. Total fixed invocation count235:128 generic calls,104 fixed-entry calls,3 old negative-control calls. No trial cases, case additions, candidate repairs or retry/selection based on results.

## Evidence and stopping

Record raw stdout/stderr/exit/time/command plus script copies/hashes for every native probe command. Report every mismatch/error and preserve artifacts. Trace closes before snapshot serialization as in the original runner. Capture network/Storage guard attempts (must remain0). Postflight byte/SHA inventories must show candidate, original baseline and selected root source unchanged. Errors/corrections, if any, receive separate receipts and are not overwritten; no second behavioral qualification is authorized in this protocol.

Stop after this qualification/report. Finite64/52 cases are not full API/input-domain equivalence. HTTP/request-signal clients, builds/chunk graph, gzip, performance, CI, device/data/production qualifications are NOT_RUN. PASS here means this seam passed this bounded synthetic contract check, not final adoption,7KB materiality, M3 exit or release.
