import { readFile,writeFile,mkdir,copyFile,readdir,lstat } from 'node:fs/promises';
import { resolve,dirname,relative } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const dir=import.meta.dirname,candidate=resolve(dir,'candidate');
const source='C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/measured-current-inputs';
const control='C:/Users/84046/AppData/Local/Temp/fundval-pair824-extract-07zGKl/postflight/postflight.json';
const sha=b=>createHash('sha256').update(b).digest('hex');
const raw=await readFile(control),reference=JSON.parse(raw),rows=reference.source.rows.filter(r=>!r.path.startsWith('.codex-tmp/'));
assert.equal(rows.length,246);
async function paths(base,part=''){const result=[];for(const e of await readdir(resolve(base,part),{withFileTypes:true})){const p=part?part+'/'+e.name:e.name;assert.equal(e.isSymbolicLink(),false);if(e.isDirectory())result.push(...await paths(base,p));else{assert.ok(e.isFile());result.push(p);}}return result.sort();}
assert.deepEqual(await paths(source),rows.map(r=>r.path).sort());
await mkdir(candidate);
const checks=[];
for(const row of rows){
 assert.ok(!row.path.split('/').includes('..'));
 const from=resolve(source,row.path),to=resolve(candidate,row.path);
 assert.ok(relative(source,from)&&!relative(source,from).startsWith('..'));
 assert.equal((await lstat(from)).isSymbolicLink(),false);
 const bytes=await readFile(from);assert.equal(bytes.length,row.bytes);assert.equal(sha(bytes),row.sha256);
 await mkdir(dirname(to),{recursive:true});await copyFile(from,to);
 const copied=await readFile(to);assert.equal(copied.length,row.bytes);assert.equal(sha(copied),row.sha256);
 checks.push({...row});
}
assert.deepEqual(await paths(candidate),rows.map(r=>r.path).sort());
const report={schema:1,stage:'PREPARED_ONLY_NO_CANDIDATE_EDITS',candidate,source,referencePath:control,referenceSha256:sha(raw),protocolSha256:sha(await readFile(resolve(dir,'PROTOCOL.md'))),files:checks,bytes:checks.reduce((s,r)=>s+r.bytes,0),filesSha256:sha(JSON.stringify(checks)),install:false,build:false,rootEdits:false};
await writeFile(resolve(dir,'source-before.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({stage:report.stage,files:checks.length,bytes:report.bytes,filesSha256:report.filesSha256,candidate}));
